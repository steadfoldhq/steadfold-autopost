# Steadfold copy standard (house style)

Applies to every word we publish: Gumroad and Etsy listings, Instagram captions, alt text, first comments, product pages, PDFs and emails, for Fully Funded, Locked Hour and Hourback. The checker is `copy-lint.py` in this folder.

## The gate (non-negotiable)

**Every agent runs `copy-lint` before anything is marked ready. Zero errors to ship.**

```
python3 copy-lint.py <file-or-folder> [--brand fullyfunded|lockedhour|hourback]
```

- Exit code 1 means **FIX FIRST**. Fix every ERROR, re-run, and paste the final `PASS` line into the handoff.
- WARN lines are advisory. Fix them in new copy and leave them in live copy unless you are already editing it.
- In prompt files, put the publishable copy between `<<<` and `>>>` lines, under a `CAPTION`, `ALT TEXT`, `FIRST COMMENT` or `DESCRIPTION` label, so the checker knows what to lint.
- If the checker is wrong, fix the checker in this folder (with a test line) and don't work around it.

## The rules

**Capitalisation and lists**
1. **Every bullet starts with a capital letter.** This covers `•`, `-` and numbered lists, with no exceptions inside a list. A bullet may start with a number ("3 phone wallpapers") or a lowercase brand ("iPhone").
2. **Use sentence case for everything except names.** Headings, kickers ("What's in the download:"), buttons and covers all use it. Product, series and brand names keep their capitals ("The 90-Day Lock-In System", "Fine Print №4").
3. **Keep list items parallel.** Use the same grammatical shape all the way down a list. No end punctuation on fragment bullets.
4. **No Oxford comma**, unless leaving it out would make the list ambiguous. Don't mix both styles in one piece.

**Punctuation and spacing**
5. **Use one space** after full stops. Don't leave a space before `,` `.` `:` `?` `!`, and don't leave trailing spaces.
6. **Use straight quotes and apostrophes** in anything pasted into Gumroad, Meta or Etsy. Never mix straight and curly quotes in one piece. Every opening quote and bracket gets closed.
7. **Covers have no exclamation marks**, and `!!` is not allowed anywhere. Captions get at most one emoji, in the hook only, and slides get none.

**Numbers, money and dates**
8. **Write numbers as numerals** ("3 jobs", "90 days"), with commas from 1,000 up ("$5,000", "$68,900"). Write cents only when they matter ("$192.31").
9. **Currency:** use a plain `$` when one country is in context. When CA and US prices or amounts sit side by side, write `CA$9` and `US$9`. Never use `C$`, `CAD $` or `$9 USD`.
10. **Dates are written `Wed Oct 14`**, with no comma after the weekday and no ordinals. Add the year as `Wed Oct 14, 2026` only when it's needed. Times are written "12 pm ET".
11. **Percentages use the % symbol** ("55%"). Use "to" for ranges in prose ("14 to 45 weeks"), and an en dash only in tables.

**Spelling and names**
12. **Use Canadian spelling by default** (colour, centre, behaviour, paycheque, cheque, labour). Use US spelling only on US-only pieces and US editions. Never mix the two in one piece.
13. **Paycheque vs paycheck:** use "paycheque" for Canada and "paycheck" for the US. Both may appear in one piece only when you are naming both editions ("Canadian (paycheque) and US (paycheck) editions included"). "Paycheque Split Calculator" is a product name and never changes.
14. **Write "Steadfold" exactly that way.** Handles, URLs and file names are exempt. Studios are written "Fully Funded", "Locked Hour" and "Hourback", and handles are written "@fullyfundedhq", "@lockedhourhq" and "@hourbackhq".
15. **"Toque" never appears**, in any file, slide, caption or file name.
16. **Sign-off line:** "From [Studio], a Steadfold studio." It goes at the end of every product description.

**Honesty and claims**
17. **Every Fully Funded caption and product description ends with this line on its own:** `General education only, not financial advice.` The line never goes on slides.
18. **No hype words.** These are banned everywhere: guaranteed, secret, game-changer, insane, mind-blowing, life-changing, 10x. "Hack" is banned except for plain uses on Hourback, where "ChatGPT hack" is still banned.
19. **Each brand's banned list applies** (see the brand bibles, section 6). Fully Funded bans "financial freedom", "passive income", "millionaire", "generational wealth", "experts say" and "studies show". Locked Hour bans "unstoppable", "level up", "dopamine", "science-backed" and "no excuses". Hourback bans time-saved claims and "100% accurate".
20. **No fabricated numbers, testimonials, time-saved or income claims, and no real-person quotes.** Examples are labelled "illustrative" or "sample".
21. **Every factual number has a source and a date** in the caption, e.g. "Source: canada.ca · Rules as of Oct 2026".

**Instagram limits**
22. **Use 5 hashtags or fewer** per caption, and put them on the last line.
23. **Captions are 2,200 characters or fewer.** Put the hook in the first 125 characters.

## What the checker enforces

| Rule | Check | Severity |
|---|---|---|
| 1 | bullet-case | ERROR |
| 2 | heading-case (mixing only) | WARN |
| 4 | oxford-comma (mixing only) | WARN |
| 5 | double-space, trailing-space, space-before-punct, repeated-word | ERROR |
| 6 | quote-mix, unbalanced-quote, unbalanced-bracket | ERROR |
| 9 | currency-format | WARN |
| 10 | date-format: ordinals are ERROR, a weekday comma is WARN | ERROR / WARN |
| 12, 13 | spelling-mix | ERROR |
| 14, 15 | brand-name, no-toque | ERROR |
| 17 | disclaimer | ERROR |
| 18, 19 | banned-word | ERROR |
| 22, 23 | hashtags, caption-length | ERROR |

Rules 3, 7, 8, 11, 16, 20 and 21 are checked by the release gate reviewer, not the script.
