# Steadfold Content Standard v3 (from Oct 14, 2026, 11:15 pm)

This standard applies to every post, Reel, cover, caption and agent, for all 4 pages (Fully Funded, Locked Hour, Hourback, Littlefold). It sits on top of PAYOFF-FIRST.md and COPY-STANDARD.md. Where they disagree, this file wins.

Dharma's direction, in his words: "real financial motivation, real financial success, real financial independence… things only the rich talk about, and I want to put it out to the public… hyper-specific, super relatable… calm, peaceful, yet happy, inviting… consider every single thing."

## 1. Audience: global by default
- Every page speaks to anyone, anywhere: India, Australia, the UK, Europe, the US and Canada. Don't assume the reader's country.
- **Canada series**: Canada-only topics (RRSP, TFSA, RESP, CLB, EI, CPP, CCB, benefit cliffs) run as a labelled series: kicker "Canada series", caption line 2 "🇨🇦 Canada series: rules below are for Canada." At most **1 Canada-series feed post per week per page**. The rest of the week is global.
- **Global money language**:
  - Say "your retirement account", "a tax-free account where you live", "your country's child savings plan".
  - Name country accounts only as examples, in one line and with several countries: "(401(k) in the US, RRSP in Canada, NPS in India, super in Australia, ISA/SIPP in the UK)". Never name just one.
  - Currency: plain numbers with "a month" ("100 a month"), plus the line "Any currency. Same math." When a currency sign is needed, use $ and add "($, ₹, €, £: same math)".
- **Global examples**: use universal moments (payday, rent, a first job, a new baby, a parent getting older), not local brands, holidays or tax dates.

## 2. Fully Funded scope: how money really works for people who have it
The goal is real financial motivation, success and independence. Make the conversations wealthy families have in private public, and keep them simple. Topic bank (rotate; one idea per post):
- **Growth and compounding**: start at birth, the cost of waiting 10 years, the boring index-fund rule, fees that quietly eat a third.
- **Retirement and independence**: your freedom number (yearly spend × 25, a rule of thumb), pay yourself first, the employer match, sequence risk.
- **Estates for kids**: a will that names a guardian, beneficiaries on every account, a trust (what it is, in one line), a letter of wishes, where the papers live.
- **Insurance**: term vs whole life in one picture, how much cover (a common rule of thumb, labelled as one), disability insurance protecting your income, umbrella liability.
- **What the rich do differently**: borrowing against investments instead of selling (with the catch), "buy, borrow, die" explained, owning assets rather than things, paying yourself a salary from a business, holding cash on purpose.
- **Tips and hacks**: automatic transfers, the 24-hour rule, "price per use", rate-checking your loans once a year, the "raise rule" (save half of every raise).

Required, every time:
- **Education only.** Explain how something works, who it tends to suit, and the risks. Never tell one person what to buy. No products, providers, affiliates or "DM me".
- **Every strategy shows its catch** on the same slide or the next one: "The catch: …". This applies especially to leverage, lines of credit, insurance and anything that can lose money.
- **Numbers**:
  - Every number is either sourced (an official or primary source, named in the caption) or labelled as a worked example: "Example at 6% a year. Not guaranteed. Real returns vary, before fees, tax and inflation."
  - Do the maths in code and keep the script.
  - Never invent statistics, surveys, "studies show", or people.
- **Rules of thumb** are labelled "a rule of thumb" and say where they come from (for example: the 4% rule comes from US market history research in the 1990s).
- **Wording**:
  - "In many countries…" / "Rules differ where you live; check your country's official site."
  - No promises: never "guaranteed", "risk-free", "get rich" or "passive income".
- Caption lines (Dharma, Oct 15: use the disclaimer where the content needs it, not everywhere):
  - "General education only, not financial advice." goes in the caption ONLY on posts about investing, borrowing, insurance, tax, retirement numbers or any specific strategy/number. Habit, mindset and general money-motivation posts skip it. When it isn't in the caption, it may go in the first comment instead.
  - "Source: … · As of <Mon YYYY>", or "Source: example math, no outside figures · As of <Mon YYYY>".

## 3. Hyper-specific and relatable
- Name the exact moment: "Your kid's first birthday", "the day you get a raise", "the night before you sign a loan". Never "save more money".
- Make it a "that's me" scene in the first line. The reader should feel seen before they feel taught.
- Give one concrete move they can do today, in under 10 minutes.
- **Surprise test**: would most people say "I didn't know that"? If not, sharpen the idea or pick another.

## 4. Hooks: proven formats (vidIQ outlier research, Oct 2026)
Use one of these for slide 1, the Reel's frame 0 and the cover:
1. "X things nobody tells you about ___" / "I wish I knew this at 22"
2. "This is your sign to ___"
3. Contrast: "Rich families do ___. Most people do ___."
4. Number-first: "100 a month from birth → about 600,000 at 65 (example)"
5. Contrarian but true: "Your bank won't explain this", only when it's honest and calm, never angry or conspiratorial
6. "POV: you ___" (for Hourback, Locked Hour and Littlefold moments)
Banned: fear bait, shame, "you're doing it wrong", all-caps rage, fake urgency, clickbait the post doesn't pay off.

## 5. Tone: calm, peaceful, happy, inviting
- Write like a warm friend who knows money (or focus, time, babies), sitting across the table. Gentle, sure and kind.
- Use short sentences. No hype words, exclamation marks only rarely, no emoji walls (0–2 per caption).
- Motion: soft and smooth (rise, fade, gentle wipe). No shakes, flashes, stamps or whip-pans on Fully Funded, Hourback or Littlefold. Locked Hour may be crisper, but still calm.
- Music: warm and hopeful. Lo-fi or soft pop, with a gentle hook in the first second. No harsh impacts. Mix soft under any voice.

## 6. Length: as short as the idea
- **Feed posts: 1, 2 or 3 slides by default.**
  - 1 slide: one big number or one rule.
  - 2 slides: the idea, then the move.
  - 3 slides: the idea, the move, the catch.
  - Use 4 or more only for a real checklist or a series kickoff, and say why in the build notes.
- **Reels: 12–20 seconds, 3–5 scenes.**
  - One idea; on-screen text readable without sound.
  - It should loop cleanly; the last frame flows back to the first.
  - Simple and still beats busy.

## 7. Thumbnails and covers (as important as the post)
The cover is what people see in the grid, on the Reels tab and in shares. It decides the tap.
- Every Reel gets a **separate cover image**, not a raw frame. No caption bars, no subtitles, no half-cut elements.
- **Safe zones** (1080×1920 Reel cover):
  - all hook text sits within **y 300–1400** and **x 90–990**. The profile grid shows the centre 3:4 (y 240–1680), and feed shows 4:5 (y 285–1635); the bottom area is covered by the app's UI.
  - Carousel slide 1 (1080×1350) has text at least 70 px from every edge.
- **Hook text**:
  - 3–7 words, at least 110 px, 2 lines max, with the brand highlighter on 1–3 key words.
  - One supporting visual (big number, object or simple chart). Nothing else.
- **Grid test**: shrink to 200 px wide. You can still read the hook, tell the brand from colours alone, and see it isn't the same as the last 3 covers.
- **Series covers** share a layout, so the grid looks planned. Canada series covers carry a small "Canada series" chip.

## 8. Before anything ships (all pages)
1. Payoff-first 2-slide test and the "people" test (PAYOFF-FIRST.md).
2. copy-lint PASS for the caption.
3. Global test: would a reader in Mumbai, Sydney or Manchester get value? If not, it's a Canada-series slot, or fix it.
4. Catch test (Fully Funded): the risk or limit is shown.
5. Cover grid test (section 7).
6. Tone test: read it aloud. It should sound calm, kind and happy, not loud.
7. Log the "why" for any choice that differs from this file in steadfold-library/DECISIONS.md.
