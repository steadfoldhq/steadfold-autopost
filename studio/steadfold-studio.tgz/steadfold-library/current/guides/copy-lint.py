#!/usr/bin/env python3
"""
copy-lint.py: Steadfold house-style checker (Python 3, stdlib only).

Usage:
  python3 copy-lint.py FILE_OR_FOLDER [...] [--brand fullyfunded|lockedhour|hourback|littlefold]
                       [--quiet-warnings] [--whole]

What it lints ("pieces"):
  * Text between <<< and >>> lines (captions, alt text, first comments, descriptions).
    The label just above the block decides the kind: CAPTION / ALT TEXT / FIRST COMMENT /
    DESCRIPTION. Everything outside the markers is operator instructions and is skipped
    (except the file-wide brand-name checks).
  * Lines after "- Description:" up to the next "P<n>. Name:" / "════" line (Gumroad prompt style).
  * If a file has neither, the whole file is one piece (kind "text").
  * --whole forces whole-file mode.

Brand: from the file name (fullyfunded / lockedhour / hourback / littlefold), else from the piece
("From Fully Funded, a Steadfold studio."), else --brand.

Severity: ERROR fails the gate (exit 1). WARN is advisory (exit 0 if no errors).
See COPY-STANDARD.md in this folder for the rules these checks enforce.
"""
import os
import re
import sys

DISCLAIMER = "General education only, not financial advice."
MAX_HASHTAGS = 5
MAX_CAPTION = 2200
TEXT_EXT = {".txt", ".md", ".markdown", ".csv", ".html", ".json"}

# ---------------------------------------------------------------- word lists
GLOBAL_BANNED = [  # hype words, all brands
    (r"\bguarantee(d|s)?\b", "guaranteed"),
    (r"\bsecrets?\b", "secret"),
    (r"\bgame[- ]?changer\b", "game-changer"),
    (r"\binsane(ly)?\b", "insane"),
    (r"\bmind[- ]?blowing\b", "mind-blowing"),
    (r"\blife[- ]?changing\b", "life-changing"),
    (r"\b10x\b", "10x"),
    (r"!!+", "double exclamation"),
]
HACK = (r"\bhack(s|ed|ing)?\b", "hack")
BRAND_BANNED = {
    "fullyfunded": [
        HACK,
        (r"\bfinancial freedom\b", "financial freedom"),
        (r"\bbanks? don'?[’']?t want you to know\b", "banks don't want you to know"),
        (r"\bmillionaires?\b", "millionaire"),
        (r"\bpassive income\b", "passive income"),
        (r"\bgenerational wealth\b", "generational wealth"),
        (r"\byou[’']re doing it wrong\b", "you're doing it wrong"),
        (r"\bexperts say\b", "experts say"),
        (r"\bstudies show\b", "studies show"),
    ],
    "lockedhour": [
        HACK,
        (r"\bunstoppable\b", "unstoppable"),
        (r"\bbeast mode\b", "beast mode"),
        (r"\bgrindset\b", "grindset"),
        (r"\blevel[- ]up\b", "level up"),
        (r"\bno excuses\b", "no excuses"),
        (r"\bdopamine\b", "dopamine"),
        (r"\bscience[- ]backed\b", "science-backed"),
        (r"\brewire your brain\b", "rewire your brain"),
        (r"\bmonk mode\b", "monk mode"),
        (r"\bstudies show\b", "studies show"),
    ],
    "hourback": [  # bare "hack" allowed on the AI page; the hype versions are not
        (r"\b(chatgpt|ai|prompt) hacks?\b", "ChatGPT/AI hack"),
        (r"\byou[’']re using ai wrong\b", "you're using AI wrong"),
        (r"\b100% accurate\b", "100% accurate"),
        (r"\bsaves? (you )?\d+\s*(hours?|hrs?|minutes?)\b", "time-saved claim"),
        (r"\bnever wrong\b", "never wrong"),
    ],
    "littlefold": [  # parenting page (Oct 14 2026): no shame, no fear marketing, no body talk, no unsourced science
        HACK,
        (r"\b(bounce|snap|spring) back\b", "bounce back"),
        (r"\bbaby weight\b", "baby weight"),
        (r"\bpost-?baby body\b", "post-baby body"),
        (r"\bsuper ?(mom|mum|dad)s?\b", "supermom"),
        (r"\bperfect (parent|mom|mum|dad)s?\b", "perfect parent"),
        (r"\bgood (moms|mums|dads|parents) (always|never)\b", "good parents always/never"),
        (r"\byou[’']re doing it wrong\b", "you're doing it wrong"),
        (r"\b(damage|ruin|harm)(s|ing)? your (baby|child|kid|toddler)\b", "fear claim"),
        (r"\btoxic\b", "toxic"),
        (r"\bstudies show\b", "studies show"),
        (r"\bexperts say\b", "experts say"),
        (r"\bscience[- ]backed\b", "science-backed"),
        (r"\bresearch proves\b", "research proves"),
        (r"\bsleep through the night (fast|in \d+)\b", "sleep promise"),
    ],
}
SPELLING_PAIRS = [  # (Canadian, US) - only MIXING within one piece is flagged
    ("colour", "color"), ("favourite", "favorite"), ("behaviour", "behavior"),
    ("centre", "center"), ("labour", "labor"), ("neighbour", "neighbor"),
    ("honour", "honor"), ("cancelled", "canceled"), ("travelled", "traveled"),
    ("practise", "practice"),  # verb vs noun is subtle; mixing still worth a look
]
SPELLING_WARN_ONLY = {"practise"}
LOWER_START_OK = {"iPhone", "iPad", "iOS", "eBay", "macOS", "e.g.", "i.e."}

# ---------------------------------------------------------------- helpers
class Finding:
    __slots__ = ("path", "line", "sev", "rule", "msg", "fix")

    def __init__(self, path, line, sev, rule, msg, fix):
        self.path, self.line, self.sev, self.rule, self.msg, self.fix = path, line, sev, rule, msg, fix


class Piece:
    def __init__(self, path, kind, start, lines, brand):
        self.path, self.kind, self.start, self.lines, self.brand = path, kind, start, lines, brand

    @property
    def text(self):
        return "\n".join(self.lines)

    def numbered(self):
        for i, l in enumerate(self.lines):
            yield self.start + i, l


def detect_file_brand(path):
    n = os.path.basename(path).lower().replace("-", "").replace("_", "")
    for b in ("fullyfunded", "lockedhour", "hourback", "littlefold"):
        if b in n:
            return b
    return None


def detect_piece_brand(text):
    m = re.search(r"From (Fully Funded|Locked Hour|Hourback|Littlefold), a Steadfold studio", text)
    if m:
        return m.group(1).lower().replace(" ", "")
    hits = [(text.count(n), k) for n, k in
            (("Fully Funded", "fullyfunded"), ("Locked Hour", "lockedhour"), ("Hourback", "hourback"), ("Littlefold", "littlefold"))]
    hits.sort(reverse=True)
    return hits[0][1] if hits[0][0] else None


def kind_from_label(label):
    l = label.upper()
    if "ALT" in l:
        return "alt"
    if "COMMENT" in l:
        return "comment"
    if "CAPTION" in l:
        return "caption"
    if "DESCRIPTION" in l:
        return "description"
    return "text"


def split_pieces(path, raw_lines, force_brand, whole):
    fb = force_brand or detect_file_brand(path)
    pieces = []
    if not whole and any(l.strip() == "<<<" for l in raw_lines):
        i = 0
        while i < len(raw_lines):
            if raw_lines[i].strip() == "<<<":
                label = ""
                for j in range(i - 1, max(-1, i - 4), -1):
                    if raw_lines[j].strip():
                        label = raw_lines[j]
                        break
                start = i + 1
                k = start
                while k < len(raw_lines) and raw_lines[k].strip() != ">>>":
                    k += 1
                body = raw_lines[start:k]
                pieces.append(Piece(path, kind_from_label(label), start + 1, body,
                                    fb or detect_piece_brand("\n".join(body))))
                i = k + 1
            else:
                i += 1
        return pieces
    if not whole and any(re.match(r"^\s*-?\s*Description:\s*$", l) for l in raw_lines):
        i = 0
        while i < len(raw_lines):
            if re.match(r"^\s*-?\s*Description:\s*$", raw_lines[i]):
                start = i + 1
                k = start
                while k < len(raw_lines) and not re.match(r"^\s*(P\d+\.\s+Name:|═|════)", raw_lines[k]):
                    k += 1
                body = raw_lines[start:k]
                while body and not body[-1].strip():
                    body.pop()
                pieces.append(Piece(path, "description", start + 1, body,
                                    fb or detect_piece_brand("\n".join(body))))
                i = k
            else:
                i += 1
        return pieces
    return [Piece(path, "text", 1, raw_lines, fb or detect_piece_brand("\n".join(raw_lines)))]


BULLET_RE = re.compile(r"^\s*(?:[•●▪◦‣·]|[-*–](?=\s)|\d{1,2}[.)](?=\s))\s+(.*)$")


def strip_urls(s):
    return re.sub(r"(https?://\S+|\b[\w.-]+\.(com|ca|gov|org|net|io)\b\S*|@\w+)", "URL", s)


# ---------------------------------------------------------------- checks
def check_piece(p, out):
    E = lambda ln, rule, msg, fix: out.append(Finding(p.path, ln, "ERROR", rule, msg, fix))
    W = lambda ln, rule, msg, fix: out.append(Finding(p.path, ln, "WARN", rule, msg, fix))
    text = p.text
    is_md = p.path.lower().endswith((".md", ".markdown"))
    in_code = False

    # ---- line-level checks
    for ln, line in p.numbered():
        if is_md and line.strip().startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if line != line.rstrip(" \t"):
            E(ln, "trailing-space", "Trailing whitespace", "Delete the spaces at the end of the line")
        body = line.strip()
        if re.search(r"\S  +\S", body):
            E(ln, "double-space", "Double space inside the line",
              "Use one space: " + re.sub(r"(?<=\S)  +(?=\S)", " ", body)[:70])
        clean = strip_urls(body)
        for m in re.finditer(r"\s([,.;:!?])(?=\s|$)", clean):
            if m.group(1) == "." and re.search(r"\.\.\.|…", clean):
                continue
            E(ln, "space-before-punct", f"Space before '{m.group(1)}'", f"Remove the space before '{m.group(1)}'")
        for m in re.finditer(r"\b([A-Za-z]+)\s+\1\b", body, re.I):
            w = m.group(1).lower()
            if w in {"ha", "bye", "no", "very"}:
                continue
            E(ln, "repeated-word", f"Repeated word '{m.group(0)}'", f"Use '{m.group(1)}' once")
        for m in re.finditer(r"\bt(o|u)que\b", body, re.I):
            E(ln, "no-toque", f"'{m.group(0)}' is retired and may not appear anywhere",
              "Remove it; use the current brand or product name")
        # dates: weekday followed by a comma, or ordinal dates
        for m in re.finditer(r"\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{1,2})\b", body):
            W(ln, "date-format", f"'{m.group(0)}': house date is 'Wed Oct 14'",
              f"Write '{m.group(1)} {m.group(2)} {m.group(3)}' (no comma after the weekday)")
        for m in re.finditer(r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(st|nd|rd|th)\b", body):
            E(ln, "date-format", f"Ordinal date '{m.group(0)}'", "Drop the ordinal: 'Oct 14'")
        for m in re.finditer(r"\bC\$|\bCDN\$|\$\s?\d[\d,.]*\s?(USD|CAD)\b|\b(USD|CAD)\s?\$", body):
            W(ln, "currency-format", f"Currency written '{m.group(0)}'",
              "Use CA$ / US$ before the number (CA$9, US$9)")

    # ---- bullets: every item starts with a capital; flag mixing too
    groups, cur = [], []
    for ln, line in p.numbered():
        m = BULLET_RE.match(line)
        if m and m.group(1).strip():
            cur.append((ln, m.group(1).strip()))
        else:
            if cur:
                groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    for g in groups:
        cases = []
        for ln, item in g:
            first = re.search(r"[A-Za-z]", item)
            if not first or re.match(r"^[\W_]*\d", item):
                continue  # starts with a number or symbol: no case to judge
            word = re.match(r"[\w.'’-]+", item[first.start():]).group(0)
            if word in LOWER_START_OK:
                continue
            cases.append((ln, item, first.group(0).isupper()))
        lowers = [c for c in cases if not c[2]]
        mixed = lowers and len(lowers) < len(cases)
        for ln, item, _ in lowers:
            fix = item[0:0] + re.sub(r"[a-z]", lambda m: m.group(0).upper(), item, count=1)
            E(ln, "bullet-case",
              ("Bullet starts lowercase while others in this list are capitalised" if mixed
               else "Bullet starts lowercase (house rule: every bullet starts with a capital)"),
              "• " + fix[:80])

    # ---- headings / kickers: sentence case vs Title Case mixing
    small = {"a", "an", "the", "and", "or", "but", "for", "nor", "of", "on", "in", "to", "at", "by",
             "with", "vs", "from", "as", "per", "into", "your", "you"}
    styles = []
    for ln, line in p.numbered():
        s = line.strip()
        h = re.match(r"^#{1,6}\s+(.*)$", s) if is_md else None
        cand = h.group(1) if h else None
        if not cand and not is_md and 2 <= len(s.split()) <= 8 and s.endswith(":") and not BULLET_RE.match(line):
            cand = s[:-1]
        if not cand:
            continue
        words = [w for w in re.findall(r"[A-Za-z][A-Za-z'’-]*", cand)[1:] if w.lower() not in small and len(w) > 2]
        if len(words) < 2:
            continue
        caps = sum(w[0].isupper() for w in words)
        if caps == len(words):
            styles.append((ln, "Title Case", cand))
        elif caps == 0:
            styles.append((ln, "sentence case", cand))
    kinds = {s[1] for s in styles}
    if len(kinds) > 1:
        for ln, st, cand in styles:
            if st == "Title Case":
                W(ln, "heading-case", f"Heading/kicker in Title Case while others are sentence case: '{cand}'",
                  "Use sentence case: " + cand[0] + cand[1:].lower())

    # ---- quotes: straight vs curly mixing, balance
    straight = len(re.findall(r"[\"']", text))
    curly = len(re.findall(r"[“”‘’]", text))
    if straight and curly:
        ln = next((l for l, s in p.numbered() if re.search(r"[“”‘’]", s)), p.start)
        E(ln, "quote-mix", f"Straight ({straight}) and curly ({curly}) quotes/apostrophes mixed in one piece",
          "Pick one style for the whole piece (house: straight quotes in pasted copy)")
    for ln, line in p.numbered():
        if is_md and (line.strip().startswith("```") or "`" in line):
            continue
        if line.count('"') % 2:
            E(ln, "unbalanced-quote", 'Odd number of " on this line', 'Close the quote with "')
        if line.count("“") != line.count("”"):
            E(ln, "unbalanced-quote", "Curly quotes don't pair up on this line", "Pair every “ with ”")
        for o, c in (("(", ")"), ("[", "]"), ("{", "}")):
            if line.count(o) != line.count(c):
                body = re.sub(r"^\s*(\d{1,2}|[a-z])\)\s", "", line)  # '1) ' list markers
                if body.count(o) != body.count(c):
                    E(ln, "unbalanced-bracket", f"'{o}' and '{c}' don't pair up on this line",
                      f"Add the missing '{c if line.count(o) > line.count(c) else o}'")

    # ---- Oxford comma: only mixing is flagged (advisory; lists are hard to parse)
    ox, nox = [], []
    for ln, line in p.numbered():
        for sent in re.split(r"(?<=[.!?:])\s", line):
            m_ox = re.search(r"\b[\w&'’-]+, ([\w&'’ -]{1,25}), (and|or) \w", sent)
            if m_ox and not re.search(r"\b(and|or)\b", m_ox.group(1)):
                ox.append(ln)
            elif re.search(r"\b[\w'’-]+, [\w'’-]+(?: [\w'’-]+)? (and|or) \w", sent) and sent.count(",") >= 2 \
                    and not re.search(r", (and|or) ", sent):
                nox.append(ln)
    if ox and nox:
        for ln in ox:
            W(ln, "oxford-comma", "Oxford comma here, but this piece also has lists without it",
              "House style: no Oxford comma unless needed for clarity")

    # ---- banned words
    brand = p.brand
    rules = list(GLOBAL_BANNED) + BRAND_BANNED.get(brand, []) + ([] if brand else [HACK])
    for ln, line in p.numbered():
        for pat, name in rules:
            for m in re.finditer(pat, line, re.I):
                E(ln, "banned-word", f"Banned on {brand or 'all brands'}: '{m.group(0)}'",
                  "Rewrite with a plain, specific claim (see brand bible §6)")

    # ---- spelling consistency
    low = text.lower()
    for ca, us in SPELLING_PAIRS:
        a = re.search(r"\b" + ca, low)
        b = re.search(r"\b" + us, low)
        if a and b:
            ln = p.start + low[:b.start()].count("\n")
            (W if ca in SPELLING_WARN_ONLY else E)(ln, "spelling-mix", f"'{ca}' and '{us}' both used",
                                                   f"Canada/default: '{ca}'; US-only piece: '{us}'. Pick one")
    pq = re.sub(r"paycheque split calculator", "", low)
    if re.search(r"\bpaycheques?\b", pq) and re.search(r"\bpaychecks?\b", pq) \
            and not re.search(r"\beditions?\b", pq):
        ln = p.start + low[:re.search(r"\bpaychecks?\b", low).start()].count("\n")
        E(ln, "spelling-mix", "'paycheque' and 'paycheck' in one piece without naming both editions",
          "Use 'paycheque' (Canada) or 'paycheck' (US-only); both only when naming the two editions")

    # ---- disclaimer, hashtags, length
    if brand == "fullyfunded" and p.kind in ("caption", "description"):
        if DISCLAIMER not in text:
            loose = re.search(r"education only,? not financial advice", text, re.I)
            E(p.start + len(p.lines) - 1, "disclaimer",
              "Fully Funded " + p.kind + (" has a non-standard disclaimer" if loose else " is missing the disclaimer"),
              f"Add its own line: '{DISCLAIMER}'")
    if p.kind == "caption":
        tags = re.findall(r"(?<![\w&/])#[A-Za-z]\w*", text)
        if len(tags) > MAX_HASHTAGS:
            E(p.start + len(p.lines) - 1, "hashtags", f"{len(tags)} hashtags (max {MAX_HASHTAGS})",
              f"Keep the {MAX_HASHTAGS} most specific")
        if len(text) > MAX_CAPTION:
            E(p.start, "caption-length", f"Caption is {len(text)} characters (Instagram max {MAX_CAPTION})",
              f"Cut {len(text) - MAX_CAPTION}+ characters")


def check_brand_name(path, raw_lines, out, piece_lines=frozenset()):
    """File-wide: 'Steadfold' spelled exactly (URLs, handles, file and folder names exempt)."""
    for i, line in enumerate(raw_lines, 1):
        for m in re.finditer(r"[\w./@-]*\b(ste+a?d[\s-]?f[o0]ld|ste+d[\s-]?fold|steadford|steadfeld)s?\b[\w./@-]*", line, re.I):
            tok, word = m.group(0).rstrip(".-"), m.group(1)
            if tok != word and not tok.endswith(("'s", "’s")) and re.search(r"[./@_-]", tok.replace(word, "", 1)):
                continue  # URL, handle, file or folder name
            if word == "Steadfold":
                continue
            if word.lower() == "steadfold" and i not in piece_lines:
                continue  # operator text (account usernames etc.): only misspellings count there
            near = re.findall(r"[A-Za-z]{2,}", line[max(0, m.start(1) - 12):m.end(1) + 12])
            if word == "STEADFOLD" and any(w.isupper() and w != "STEADFOLD" for w in near):
                continue  # part of an ALL-CAPS label, e.g. "STEADFOLD PROMPT"
            out.append(Finding(path, i, "ERROR", "brand-name", f"Brand written '{word}'", "Write 'Steadfold'"))


# ---------------------------------------------------------------- driver
def iter_files(args):
    for a in args:
        if os.path.isdir(a):
            for root, _, files in os.walk(a):
                for f in sorted(files):
                    if os.path.splitext(f)[1].lower() in TEXT_EXT:
                        yield os.path.join(root, f)
        elif os.path.isfile(a):
            yield a
        else:
            print(f"copy-lint: not found: {a}", file=sys.stderr)


def main(argv):
    brand, quiet, whole, targets = None, False, False, []
    it = iter(argv)
    for a in it:
        if a == "--brand":
            brand = next(it, None)
        elif a == "--quiet-warnings":
            quiet = True
        elif a == "--whole":
            whole = True
        elif a in ("-h", "--help"):
            print(__doc__)
            return 0
        else:
            targets.append(a)
    if not targets:
        print(__doc__)
        return 2
    total_e = total_w = nfiles = 0
    for path in iter_files(targets):
        nfiles += 1
        try:
            raw = open(path, encoding="utf-8").read().splitlines()
        except UnicodeDecodeError:
            print(f"copy-lint: skipped (not UTF-8): {path}", file=sys.stderr)
            continue
        out = []
        pieces = split_pieces(path, raw, brand, whole)
        for p in pieces:
            check_piece(p, out)
        plines = {ln for p in pieces for ln, _ in p.numbered()}
        check_brand_name(path, raw, out, plines)
        out.sort(key=lambda f: (f.line, f.sev))
        e = sum(f.sev == "ERROR" for f in out)
        w = len(out) - e
        total_e += e
        total_w += w
        status = "FAIL" if e else "PASS"
        print(f"\n{status}  {path}  ({len(pieces)} pieces, {e} errors, {w} warnings)")
        for f in out:
            if quiet and f.sev == "WARN":
                continue
            print(f"  {f.path}:{f.line}  {f.sev:<5} [{f.rule}] {f.msg}\n      fix: {f.fix}")
    print(f"\ncopy-lint: {nfiles} files, {total_e} errors, {total_w} warnings -> "
          f"{'FAIL (fix errors before marking ready)' if total_e else 'PASS'}")
    return 1 if total_e else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
