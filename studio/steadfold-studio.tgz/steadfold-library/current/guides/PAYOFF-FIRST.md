# Payoff-first: how every Steadfold post is written (Dharma, Oct 14 2026, standing)

Dharma's feedback on the first live Locked Hour post: "We're talking more about the study… 'it helped people do this'… Rather than that: do this, and you get this. Attention span is so short. If they don't feel they're getting value instantly, they won't go through the entire thing. Eight slides, and only on the sixth slide do we say 'try this tonight'."

## The shape (every carousel, every page)
1. **Slide 1 (the cover) = the payoff + the action, in "you" language.**
   - Locked Hour: "Fall asleep faster tonight. Write tomorrow's to-do list."
   - Fully Funded: "Get up to $2,000 for your kid's school. Free. Here's how to claim it."
   - Hourback: "Never get a parking ticket again. Snap the sign, ask one question."
   - It must not be a study report ("A study found…", "People who…", "Researchers…").
2. **Slide 2 = exactly what to do, in 3 steps or fewer.** The reader can act after slide 2 even if they stop there.
3. **Slides 3–5 = why it works and what to expect.** Short, one idea per slide. Proof goes in ONE line ("In a sleep-lab study of 57 adults…"), never as the headline.
4. **One slide for the honest limit, if it truly matters**, phrased as a tip: "Still wide awake after 20 minutes? Get up and reset." It is not a disclaimer and not "The catch".
5. **Last slide = save / send / follow**, plus the free tool where it fits.
- **Length fits the idea (Dharma, Oct 14):** 1 slide for one tip, rule or relatable moment; 3–4 for one action with steps; 5–7 for checklists and how-tos. 8 or more only for a hero post. Never pad to hit a number.
- **Weekly mix per page:** 2–3 Reels (reach new people), 2 carousels (saves), 2 single images (shares and stories).

## Voice
- Second person ("you", "your"), present or future tense, imperative verbs: do, write, open, set, snap.
- Benefit before mechanism. Action before evidence.
- Honest promises: "can help you", "most people", "you'll likely". No guarantees, no invented results, no income or time-saved claims.
- Study names never headline a slide. They live on the proof line and the receipt slide (Locked Hour).

## Captions (same shape)
- Line 1 = the payoff + the action. Line 2–4 = the steps. Then one proof line. Then CTA. Then hashtags.
- Keep the required short lines from claude/copy-standard.md (Fully Funded disclaimer + "Source: canada.ca · Rules as of Oct 2026"; Hourback "Example made up for this post…" + privacy tip; safety lines where real harm exists).

## Gate check (panel adds these two mandatory checks)
- **The 2-slide test:** would someone who reads only slides 1–2 know what to do and why it's worth it? If not, it fails.
- **The "people" test:** does any headline describe what other people or studies did instead of what YOU should do? If yes, it fails.

## Audience desk (added Oct 14, after Dharma asked why no agent caught the study-report style)
Our gates checked truth and craft, not whether a real scroller would act. Every post now also passes a 3-persona audience desk (a fresh subagent playing each, reading ONLY slide 1, then slides 1–2, then the whole post):
- **The scroller:** 1.5 seconds on slide 1. Would they stop? Do they know what they get?
- **The "that's me" reader:** does the post name their exact situation in their own words ("You open your laptop at 9 and it's 11 before you start")? Would they save it to themselves?
- **The sender:** who would they send it to, and would they share it to their story? If no one, the post needs a sharper "this is for…" angle.
Each persona answers: stop? (y/n) · save? · send to whom? · what confused you? · the one change that would make you act. Any "no" on stop or save = rewrite slide 1 before the panel scores it.

## Variety (payoff-first is a principle, not one template)
Rotate formats so the feed never feels the same twice. At most 2 of the same format per page per week:
- **Do this tonight:** action + 3 steps (the default)
- **POV / that's-me:** opens with the reader's moment ("POV: it's payday and it's already gone")
- **Myth → truth:** the rule everyone repeats, then what actually works (payoff still on slide 1)
- **Before / after:** the same day, two ways
- **Checklist / save-this:** a reference worth saving
- **Mini story:** one example person (clearly made up) in 4–5 beats, the lesson on the last beat
- **Quiz / poll hook:** a question on slide 1, the answer and the action next
Tone can shift (warm, blunt, playful) within the brand bible. The goals don't change: stop, save, send, follow, and come back tomorrow.

## Push back
Agents and Claude don't simply agree with Dharma's feedback. Test it against the audience desk and real numbers (metrics.md once they exist); say plainly when the evidence points the other way.
