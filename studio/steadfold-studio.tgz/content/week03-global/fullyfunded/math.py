#!/usr/bin/env python3
"""Fully Funded week 03 (global) - every number on the slides and captions is computed here.
Run:  python3 math.py > math-output.txt
All amounts are worked examples in any currency ("Any currency. Same math."). No outside statistics.
Rule-of-thumb inputs: 4% first-year withdrawal (Bengen 1994; Cooley, Hubbard & Walz 1998). See sources.md.
"""


def hr(t):
    print("\n" + "=" * 70 + f"\n{t}\n" + "=" * 70)


def n(x):
    return f"{x:,.0f}"


# ---------------------------------------------------------------- post 1: freedom number
hr("ff-w03-1-freedom-number")
RATE = 0.04
MULT = 1 / RATE
print(f"Multiplier = 1 / {RATE:.0%} = {MULT:g}")
assert round(MULT, 9) == 25
for spend in (30_000, 40_000, 60_000):
    print(f"  spend {n(spend)} a year x {MULT:g} = {n(spend * MULT)}")
assert 30_000 * 25 == 750_000 and 40_000 * 25 == 1_000_000 and 60_000 * 25 == 1_500_000
# check: 4% of the number = the yearly spend
for spend in (30_000, 40_000, 60_000):
    assert abs(spend * 25 * RATE - spend) < 1e-6
print("  check: 4% of each number equals the yearly spend -> OK")

print("\nPension example (step 2 on slide 2):")
spend, pension = 40_000, 10_000
gap = spend - pension
print(f"  spend {n(spend)} - pension {n(pension)} = {n(gap)}; x 25 = {n(gap * 25)}")
assert gap * 25 == 750_000
print(f"  saved vs no pension: {n(spend * 25 - gap * 25)}")

print("\nLower-rate illustration (caption only, not on slides):")
for r in (0.035, 0.03):
    print(f"  at {r:.1%}: multiplier {1 / r:.2f}; 40,000 -> {n(40_000 / r)}")

# ---------------------------------------------------------------- post 2: borrow, don't sell
hr("ff-w03-2-borrow-dont-sell")
inv, loan, sold = 100_000, 30_000, 0
print(f"Cover stub (example): investments {n(inv)}, borrowed {n(loan)}, sold {n(sold)}, still invested {n(inv - sold)}")
ltv = loan / inv
print(f"  loan-to-value at start: {ltv:.0%}")
for drop in (0.20, 0.30):
    after = inv * (1 - drop)
    print(f"  if investments fall {drop:.0%}: {n(inv)} -> {n(after)}; loan stays {n(loan)}; loan-to-value {loan / after:.1%}")
print("  (fall examples are for build notes only; no lender threshold is claimed)")

# ---------------------------------------------------------------- post 3: guardian will
hr("ff-w03-3-guardian-will")
REVIEW_YEARS = 5   # gov.uk 'Making a will: Update your will' - review every 5 years
print(f"Review interval shown on slide 3: every {REVIEW_YEARS} years (gov.uk). No arithmetic needed.")
print("\nAll checks passed.")
