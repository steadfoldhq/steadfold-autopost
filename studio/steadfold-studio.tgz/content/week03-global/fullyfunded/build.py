#!/usr/bin/env python3
"""Fully Funded week 03 (global): captions, lint file, render, repo-ready JPEGs, schedule entries.

Run:  python3 build.py            (renders with the existing pipeline, then everything else)
      python3 build.py --no-render

Writes:
  captions.json                 caption, first_comment, alt_text (one per slide) per post
  captions-lint.txt             CAPTION / FIRST COMMENT / ALT TEXT blocks for copy-lint
  out/<id>/slide-NN.png         via /home/claude/content/design/render.py (engine unchanged)
  media/<id>/NN.jpg             1080x1350 baseline JPEG, quality 92, optimize, PIL default 4:2:0
                                (byte-identical settings to steadfold-autopost/media/ff-w02-*)
  schedule-entries.json         the shape Dharma asked for (images "media/<id>/NN.jpg", alt_text list)
  schedule-entries.repo.json    the same posts in the shape autopost.py reads today
                                (images relative to media/, alt_text one string)
"""
import json
import subprocess
import sys
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
RENDER = Path("/home/claude/content/design/render.py")
LINT = Path("/home/claude/steadfold-library/current/guides/copy-lint.py")
DISC = "General education only, not financial advice."
ASOF = "As of Oct 2026"

POSTS = [
    dict(
        id="ff-w03-1-freedom-number", publish_at="2026-10-16T12:00:00-04:00",
        caption=f"""Your freedom number is your yearly spending × 25. Work yours out tonight.

Spend 30,000 a year: 750,000. Spend 40,000: 1,000,000. Spend 60,000: 1,500,000. Any currency. Same math.
Why 25? It's the 4% rule turned around: 1 ÷ 4% = 25. It's a rule of thumb from US market history research in the 1990s (William Bengen, 1994; the Trinity study, 1998).
Expect a pension or state benefit? Take its yearly amount off first. Spend 40,000 with a 10,000 pension: 30,000 × 25 = 750,000.
The catch: it's a rule of thumb, not a promise. Many planners use a lower rate to be safer (at 3.5%, it's about × 29), and it's before tax and fees.

Save this for later.

Source: Bengen (1994) and the Trinity study (1998), example math · {ASOF}

{DISC}

#personalfinance #retirementplanning #investing #moneytips #financialindependence""",
        first_comment="Did your number come out bigger or smaller than you guessed? One word is perfect.",
        alt_text=[
            "Slide 1 of 3. Kicker: the 4% rule, a rule of thumb. Headline: 'Freedom number: spend × 25.' "
            "Text: Your freedom number: what you spend in a year, times 25. Roughly what you'd need invested to stop working. "
            "A table labelled 'Example, any currency' with a '× 25' tag: spend 30,000 a year, number 750,000; "
            "spend 40,000, number 1,000,000 (highlighted); spend 60,000, number 1,500,000.",
            "Slide 2 of 3. Do this tonight, 10 minutes. 'Find yours in 3 steps.' "
            "1. Add up a year of spending: rent or mortgage, food, bills, fun, or one month multiplied by 12. "
            "2. Take off any pension: subtract the yearly amount of any pension or state benefit first. "
            "3. Multiply by 25. Example: spend 40,000, pension 10,000, which leaves 30,000, and 30,000 × 25 = 750,000.",
            "Slide 3 of 3. The catch: 'A rule of thumb, not a promise.' It's built on US market history, studied in the 1990s. "
            "Many planners use a lower rate, to be safer. It's before tax and fees. Pensions or benefits where you live lower it.",
        ],
    ),
    dict(
        id="ff-w03-2-borrow-dont-sell", publish_at="2026-10-17T12:00:00-04:00",
        caption=f"""Wealthy people often borrow against their investments instead of selling them. Hear it pitched? Ask 3 questions first.

How it works: a loan secured by your investments, so they stay invested. Names differ: securities-based line of credit, portfolio loan, Lombard loan in Europe, loan against shares in India.
Why it appeals: in many countries, a loan isn't taxed as income, while selling can trigger tax on the gain. It's the idea behind "buy, borrow, die": hold for life, borrow to spend, rarely sell.
The catch: you pay interest, often at a variable rate. If the investments fall, the lender can demand more money or sell them for you, often at the worst time (a margin call). You can lose more than you planned. Rules and tax vary by country.
The 3 questions: What's the rate, and can it change? At what drop do you sell my holdings? What happens if I can't pay?

This is education, not a recommendation. Save this for the day someone pitches it to you.

Source: FINRA (finra.org) · {ASOF}

{DISC}

#investing #personalfinance #wealthbuilding #moneytips #stockmarket""",
        first_comment="Had you heard of borrowing against investments before today? Yes or no?",
        alt_text=[
            "Slide 1 of 3. Kicker: what the rich do differently. Headline: 'The rich borrow. Most of us sell.' "
            "Text: A loan against investments keeps them invested. The catch: if they fall, the lender can sell. "
            "An example portfolio loan statement, any currency: investments 100,000; borrowed against them 30,000; "
            "sold 0; still invested 100,000.",
            "Slide 2 of 3. If you ever hear this pitched: 'Ask these 3 questions.' "
            "1. What's the rate? Can it change? Many are variable, so your cost can rise while you hold the loan. "
            "2. At what drop do you sell? Ask for the exact line for your holdings, in writing. "
            "3. What if I can't pay? Ask about deadlines, fees and what you could still owe.",
            "Slide 3 of 3. The catch: 'Markets fall. Loans don't.' You pay interest, often at a variable rate. "
            "A fall can bring a margin call: add money or repay. The lender can sell for you, often at the worst time. "
            "You can lose more than you planned. Rules and tax differ by country.",
        ],
    ),
    dict(
        id="ff-w03-3-guardian-will", publish_at="2026-10-18T12:00:00-04:00",
        caption=f"""Have kids? Write a will that names a guardian. Here's how, in 3 steps.

Without a will, the law where you live decides who gets what, and a court may decide who raises your children.
1. Choose a guardian and a backup, and ask them first.
2. Make a will that names them, with a lawyer or notary, or your country's official will service.
3. Check the beneficiary names on your accounts and insurance, and tell someone where the papers are.
Review it every 5 years and after big changes, like a new baby, a marriage or a move.
Rules differ where you live; check your country's official site.

Send this to someone who just had a baby.

Source: gov.uk (Making a will) and government.nl · {ASOF}

{DISC}

#estateplanning #newparents #parenting #personalfinance #moneytips""",
        first_comment="Do you have a will yet? Yes, no or soon?",
        alt_text=[
            "Slide 1 of 3. Kicker: for parents, estates for kids. Headline: 'This is your sign: name a guardian.' "
            "Text: Without a will, the law decides who inherits, and a court may decide who raises your kids. "
            "A timeline titled 'A will that protects your kids': now, pick a guardian; next, sign a will naming them; "
            "then, say where it's kept; every 5 years, review it.",
            "Slide 2 of 3. Your move this month: 'Do it in 3 steps.' "
            "1. Choose a guardian and a backup: ask them first, and pick someone who shares your values, plus a second choice. "
            "2. Make a will that names them, with a lawyer or notary, or your country's official will service. "
            "3. Check names, share the spot: check beneficiary names on accounts and insurance, and tell someone where the papers are.",
            "Slide 3 of 3. Keep it current: 'Review it every 5 years.' A large 5 years: how often gov.uk suggests reviewing a will. "
            "Also after big changes in your life. Rules differ where you live; check your country's official site. "
            "Tags: a new baby, marriage or separation, a move.",
        ],
    ),
]


def main():
    posts_doc = json.loads((HERE / "posts.json").read_text())
    by_id = {p["id"]: p for p in posts_doc["posts"]}
    assert [p["id"] for p in POSTS] == list(by_id), "post ids/order differ from posts.json"

    # captions into posts.json (as week02 did) + captions.json
    caps = {}
    for p in POSTS:
        n = len(by_id[p["id"]]["slides"])
        assert len(p["alt_text"]) == n, f"{p['id']}: {len(p['alt_text'])} alt texts for {n} slides"
        by_id[p["id"]]["caption"] = p["caption"]
        caps[p["id"]] = {k: p[k] for k in ("caption", "first_comment", "alt_text")}
    (HERE / "posts.json").write_text(json.dumps(posts_doc, indent=2, ensure_ascii=False) + "\n")
    (HERE / "captions.json").write_text(json.dumps(caps, indent=2, ensure_ascii=False) + "\n")

    # lint file
    blocks = []
    for p in POSTS:
        blocks.append(f"# {p['id']}\nCAPTION\n<<<\n{p['caption']}\n>>>\n\nFIRST COMMENT\n<<<\n{p['first_comment']}\n>>>\n")
        for i, a in enumerate(p["alt_text"], 1):
            blocks.append(f"ALT TEXT (slide {i})\n<<<\n{a}\n>>>\n")
    (HERE / "captions-lint-fullyfunded.txt").write_text("\n".join(blocks))
    r = subprocess.run([sys.executable, str(LINT), str(HERE / "captions-lint-fullyfunded.txt"), "--brand", "fullyfunded"],
                       capture_output=True, text=True)
    print(r.stdout.strip() or r.stderr.strip())
    if r.returncode:
        sys.exit("copy-lint FAILED")

    # render (engine unchanged). --no-fail only bypasses render.py's pre-v3 "last slide must be cta" rule;
    # QA errors are enforced here from report.json instead.
    if "--no-render" not in sys.argv:
        subprocess.run([sys.executable, str(RENDER), str(HERE / "posts.json"), "--out", str(HERE / "out"), "--no-fail"], check=True)
    rep = json.loads((HERE / "out" / "report.json").read_text())
    bad = [x for x in rep if x["errors"]]
    if bad:
        sys.exit(f"render QA failed: {bad}")
    print(f"render QA: {len(rep)} slides, 0 errors")

    # repo-ready JPEGs, same settings as steadfold-autopost/media/ff-w02-5-benefit-cliffs/*.jpg
    entries, repo_entries = [], []
    for p in POSTS:
        pngs = sorted((HERE / "out" / p["id"]).glob("slide-*.png"))
        dest = HERE / "media" / p["id"]
        dest.mkdir(parents=True, exist_ok=True)
        for old in dest.glob("*.jpg"):
            old.unlink()
        names = []
        for i, png in enumerate(pngs, 1):
            im = Image.open(png).convert("RGB")
            assert im.size == (1080, 1350), (png, im.size)
            out = dest / f"{i:02d}.jpg"
            im.save(out, "JPEG", quality=92, optimize=True)
            names.append(f"{p['id']}/{i:02d}.jpg")
        entries.append({"id": p["id"], "account": "fullyfunded", "publish_at": p["publish_at"], "caption": p["caption"],
                        "first_comment": p["first_comment"], "alt_text": p["alt_text"],
                        "images": [f"media/{n}" for n in names]})
        repo_entries.append({"id": p["id"], "account": "fullyfunded", "publish_at": p["publish_at"], "caption": p["caption"],
                             "first_comment": p["first_comment"], "alt_text": " ".join(p["alt_text"]), "images": names})
    (HERE / "schedule-entries.json").write_text(json.dumps(entries, indent=1, ensure_ascii=False) + "\n")
    (HERE / "schedule-entries.repo.json").write_text(json.dumps(repo_entries, indent=1, ensure_ascii=False) + "\n")
    print("wrote captions.json, media/, schedule-entries.json, schedule-entries.repo.json")


if __name__ == "__main__":
    main()
