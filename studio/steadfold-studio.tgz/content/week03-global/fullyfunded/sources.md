# Fully Funded · Week 03 (global) sources

Checked on **2026-10-14** through WebSearch/WebFetch. All arithmetic is in `math.py`; its output is in `math-output.txt`.
Every amount on the slides is a worked example in any currency ("Any currency. Same math."). No statistics, surveys or people are invented.

## 1. Your freedom number (`ff-w03-1-freedom-number`, Fri Oct 16)
- Caption Source line: `Source: Bengen (1994) and the Trinity study (1998), example math · As of Oct 2026`
- William P. Bengen, "Determining Withdrawal Rates Using Historical Data," *Journal of Financial Planning*, October 1994, pp. 14–24.
- Philip L. Cooley, Carl M. Hubbard, Daniel T. Walz, "Retirement Savings: Choosing a Withdrawal Rate That Is Sustainable," *AAII Journal* 10(3), February 1998, pp. 16–21 (the "Trinity study"); backtested on US data 1925–1995; 4% first-year withdrawal, later years rise with inflation. Summary checked: https://en.wikipedia.org/wiki/Trinity_study
- × 25 = 1 ÷ 4%. Labelled "a rule of thumb" on the cover kicker, slide 3 and caption. The lower-rate example (3.5% → about × 29) is arithmetic only, not a sourced recommendation.

## 2. Borrow, don't sell (`ff-w03-2-borrow-dont-sell`, Sat Oct 17)
- Caption Source line: `Source: FINRA (finra.org) · As of Oct 2026`
- FINRA, "Securities-Backed Lines of Credit Explained" (published Jan 3, 2024): https://www.finra.org/investors/insights/securities-backed-lines-credit
  - "the interest rate on your loan can change every day"
  - "you'll receive a 'maintenance call' notifying you that you must post additional collateral or repay the loan"
  - "Lenders often can make these decisions without giving you any notice." (selling pledged securities)
  - "market volatility could magnify your potential losses"
  - "An SBLOC might allow you to avoid potential capital gains taxes" / selling: "You could have to pay capital gains taxes on the proceeds"
- Related: SEC investor alert on SBLOCs: https://www.sec.gov/oiea/investor-alerts-and-bulletins/sbloc
- Names (Lombard loan in Europe, loan against shares in India) are common product names, given as examples only. "In many countries" hedges the tax line. "Buy, borrow, die" is named as an idea, in one line, in the caption only.
- Cover stub (100,000 invested, 30,000 borrowed, 0 sold) is a labelled example; no lender loan-to-value threshold is claimed.

## 3. Name a guardian (`ff-w03-3-guardian-will`, Sun Oct 18)
- Caption Source line: `Source: gov.uk (Making a will) and government.nl · As of Oct 2026`
- gov.uk "Making a will: Overview": "If you die without a will, the law decides who gets what." https://www.gov.uk/make-will
- gov.uk "Making a will: Write your will": a will covers "who should look after any children under 18". https://www.gov.uk/make-will/writing-your-will
- gov.uk "Making a will: Update your will": "You should review your will every 5 years and after any major change in your life", listing separation or divorce, getting married, having a child, moving house. https://www.gov.uk/make-will/updating-your-will
- Government.nl "Who looks after children if their parents die?": parents can name a guardian in a will; if no guardian has been recorded, "the court will decide." https://www.government.nl/faq/who-looks-after-children-if-parents-die
- gov.uk does not itself say a court picks the guardian, so the cover says "a court **may** decide" and the second official source (Netherlands) backs it. Caption carries "Rules differ where you live; check your country's official site."
