#!/usr/bin/env python3
"""Proves the QA gate catches what week-1 got wrong. Each case MUST fail the named check."""
import json, os, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from engine import templates, themes  # noqa: E402

T = HERE / "build" / "selftest"; T.mkdir(parents=True, exist_ok=True)
base = {"id": "t", "theme": "lockedhour", "highlight": "C", "slides": [
    {"template": "cover", "fields": {"kicker": "Test", "title": "==One locked hour beats a busy day, every single day.=="}},
    {"template": "cta", "fields": {"title": "x"}}]}
cases = []
# 1. sticker highlight with leading squeezed to 0.95 -> bands of adjacent lines collide / hit text
themes.LEADING["C"] = 0.95; templates.LEADING["C"] = 0.95
cases.append(("highlight-overlap", templates.slide_html(base, 0)))
themes.LEADING["C"] = 1.22; templates.LEADING["C"] = 1.22
# 2. five long steps -> text spills out of the step cards
steps = {"id": "t", "theme": "fullyfunded", "slides": [{"template": "steps", "fields": {"title": "Too much", "steps": [
    {"title": "A long step title here", "body": "And a body that runs on for quite a while so it needs two or three lines."}] * 5}}, {"template": "cta", "fields": {"title": "x"}}]}
cases.append(("text-overflow", templates.slide_html(steps, 0)))
# 3. a near-empty slide -> empty-space
empty = {"id": "t", "theme": "hourback", "slides": [{"template": "cover", "fields": {"title": "Hi", "visual": {"type": "none"}}}, {"template": "cta", "fields": {"title": "x"}}]}
cases.append(("empty-space", templates.slide_html(empty, 0)))

# 4. tabular-nums leaking onto text -> wide "first - time" hyphens
hy = {"id": "t", "theme": "fullyfunded", "slides": [{"template": "steps", "fields": {"title": "Two first-time buyers", "steps": [{"title": "Auto-renews", "body": "x"}, {"title": "b", "body": "c"}]}}, {"template": "cta", "fields": {"title": "x"}}]}
cases.append(("hyphen", templates.slide_html(hy, 0).replace("</style>", "body *{font-variant-numeric:tabular-nums}</style>", 1)))
# 5. cover art pushed into the lead -> art-collision
art = {"id": "t", "theme": "hourback", "slides": [{"template": "cover", "fields": {"title": "Four lines of title that keep on going and going", "lead": "A lead that sits right where the art is forced to go.",
        "visual": {"type": "chat", "bubbles": [{"from": "you", "text": "Hello there"}, {"from": "ai", "text": "Hi"}]}}}, {"template": "cta", "fields": {"title": "x"}}]}
cases.append(("art-collision", templates.slide_html(art, 0).replace("</style>", ".vart{transform:translate(0,-560px)!important}</style>", 1)))

jobs = []
for i, (_, html) in enumerate(cases):
    p = T / f"case{i}.html"; p.write_text(html)
    jobs.append({"id": f"case{i}", "html": str(p), "png": str(T / f"case{i}.png")})
(T / "m.json").write_text(json.dumps({"jobs": jobs, "report": str(T / "report.json")}))
env = dict(os.environ, NODE_PATH=subprocess.run(["npm", "root", "-g"], capture_output=True, text=True).stdout.strip())
subprocess.run(["node", str(HERE / "engine" / "render.js"), str(T / "m.json")], env=env, capture_output=True)
rep = json.loads((T / "report.json").read_text()); ok = True
for (want, _), r in zip(cases, rep):
    hit = any(e.startswith(want) for e in r["errors"])
    ok &= hit
    print(("PASS" if hit else "MISS"), f"expected '{want}' ->", r["errors"][:2])
# 6-8. validation gates (no browser needed)
import render as R  # noqa: E402
def gate(posts, want):
    try:
        R.validate(posts, HERE / "posts"); return False
    except SystemExit as e:
        return want in str(e)
cov = lambda i, v: {"id": f"c{i}", "theme": "lockedhour", "slides": [{"template": "cover", "fields": {"title": "x", "visual": {"type": v}}}, {"template": "cta", "fields": {"title": "x"}}]}
for want, posts in [("cover-variety", [cov(i, "clock") for i in range(3)]),
                    ("image not found", [{"id": "i", "theme": "hourback", "slides": [{"template": "image", "fields": {"title": "x", "src": "nope.png"}}, {"template": "cta", "fields": {"title": "x"}}]}]),
                    ("belong on the cta slide", [{"id": "p", "theme": "lockedhour", "slides": [{"template": "cover", "fields": {"kicker": "Pin this", "title": "x"}}, {"template": "cta", "fields": {"title": "x"}}]}])]:
    hit = gate(posts, want); ok &= hit
    print(("PASS" if hit else "MISS"), f"expected '{want}' (validation)")
sys.exit(0 if ok else 1)
