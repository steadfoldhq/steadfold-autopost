#!/usr/bin/env python3
"""Build the highlight STYLE OPTIONS for the owner: same 3-slide sample per brand x styles A/B/C.
Outputs options/<brand>-style-<X>.png, options/slides/<brand>-<X>-NN.png and options/style-options.png."""
import shutil, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
OPT = HERE / "options"; (OPT / "slides").mkdir(parents=True, exist_ok=True)
F = HERE / "assets" / "fonts"
f = lambda s, w="ExtraBold": ImageFont.truetype(str(F / f"Inter-{w}.ttf"), s)
BRANDS = [("fullyfunded", "ff-sample", "Fully Funded"), ("lockedhour", "lh-sample", "Locked Hour"), ("hourback", "hb-sample", "Hourback")]
STYLES = {"A": "Marker swipe", "B": "Brush underline", "C": "Sticker label"}
BG = (238, 238, 242); INK = (20, 20, 30)

failed = False
for s in STYLES:
    r = subprocess.run([sys.executable, str(HERE / "render.py"), str(HERE / "posts" / "samples.json"), "--out", str(HERE / "build" / f"options-{s}"), "--highlight", s])
    failed |= r.returncode != 0


def strip(brand, pid, name, s, cw=640, gap=24, pad=40):
    src = HERE / "build" / f"options-{s}" / pid
    ims = []
    for i in (1, 2, 3):
        p = src / f"slide-{i:02d}.png"
        shutil.copy(p, OPT / "slides" / f"{brand}-{s}-{i:02d}.png")
        ims.append(Image.open(p).convert("RGB"))
    ch = round(cw * 1350 / 1080)
    out = Image.new("RGB", (pad * 2 + 3 * cw + 2 * gap, 120 + ch + pad), BG)
    d = ImageDraw.Draw(out)
    d.text((pad, 34), f"{name}  ·  Style {s}: {STYLES[s]}", fill=INK, font=f(44))
    for i, im in enumerate(ims):
        out.paste(im.resize((cw, ch), Image.LANCZOS), (pad + i * (cw + gap), 120))
    return out


for brand, pid, name in BRANDS:
    for s in STYLES:
        strip(brand, pid, name, s).save(OPT / f"{brand}-style-{s}.png", optimize=True)

# combined comparison sheet: rows = brands, columns = styles; each cell = cover + content + CTA
cw, gap, cgap, pad = 300, 12, 70, 50
ch = round(cw * 1350 / 1080)
cell_w = 3 * cw + 2 * gap
W = pad * 2 + 3 * cell_w + 2 * cgap + 170
H = 250 + 3 * (ch + 60) + pad
sheet = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(sheet)
d.text((pad, 34), "Steadfold carousel v2 — highlight style options", fill=INK, font=f(52))
d.text((pad, 104), "Same copy and layout in every column; only the highlight changes. Pick one style per brand (or one for all).", fill=(80, 80, 95), font=f(28, "Medium"))
x0 = pad + 170
for j, (s, label) in enumerate(STYLES.items()):
    x = x0 + j * (cell_w + cgap)
    d.rounded_rectangle((x, 160, x + 86, 230), 16, fill=INK)
    d.text((x + 43, 195), s, fill="white", font=f(48, "Black"), anchor="mm")
    d.text((x + 104, 176), label, fill=INK, font=f(40))
for i, (brand, pid, name) in enumerate(BRANDS):
    y = 250 + i * (ch + 60)
    d.text((pad, y + ch // 2), name.replace(" ", "\n"), fill=INK, font=f(34), anchor="lm", spacing=6)
    for j, s in enumerate(STYLES):
        x = x0 + j * (cell_w + cgap)
        for k in (1, 2, 3):
            im = Image.open(OPT / "slides" / f"{brand}-{s}-{k:02d}.png").convert("RGB").resize((cw, ch), Image.LANCZOS)
            sheet.paste(im, (x + (k - 1) * (cw + gap), y))
sheet.save(OPT / "style-options.png", optimize=True)

# cover visuals: one sample cover per visual type, grouped by brand
r = subprocess.run([sys.executable, str(HERE / "render.py"), str(HERE / "posts" / "covers.json"), "--out", str(HERE / "build" / "covers")])
failed |= r.returncode != 0
import json
posts = json.loads((HERE / "posts" / "covers.json").read_text())["posts"]
cw, ch, gap, pad = 400, 500, 22, 50
by = {}
for p in posts:
    by.setdefault(p["theme"], []).append(p)
ncol = max(len(v) for v in by.values())
W = pad * 2 + 200 + ncol * (cw + gap)
H = 170 + len(by) * (ch + 90) + pad
sheet = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(sheet)
d.text((pad, 34), "Steadfold carousel v2.1 — cover visuals (cover.visual.type)", fill=INK, font=f(52))
d.text((pad, 104), "Max 2 covers per brand per batch may share a type. clock/sun are allowed only as a small accent elsewhere.", fill=(80, 80, 95), font=f(28, "Medium"))
y = 170
for th, name in [("fullyfunded", "Fully Funded"), ("lockedhour", "Locked Hour"), ("hourback", "Hourback")]:
    d.text((pad, y + ch // 2), name.replace(" ", "\n"), fill=INK, font=f(34), anchor="lm", spacing=6)
    for i, p in enumerate(by.get(th, [])):
        x = pad + 200 + i * (cw + gap)
        vt = p["slides"][0]["fields"]["visual"]["type"]
        d.text((x, y), vt, fill=INK, font=f(32, "Black"))
        im = Image.open(HERE / "build" / "covers" / p["id"] / "slide-01.png").convert("RGB").resize((cw, ch), Image.LANCZOS)
        sheet.paste(im, (x, y + 50))
    y += ch + 90
sheet.save(OPT / "cover-visuals.png", optimize=True)
print("options written to", OPT, "(QA FAILED)" if failed else "(all QA passed)")
sys.exit(1 if failed else 0)
