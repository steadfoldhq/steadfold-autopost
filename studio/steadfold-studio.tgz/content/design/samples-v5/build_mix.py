#!/usr/bin/env python3
"""grids-MIX tiles: every reference style, each in its page's ORIGINAL palette.
FF Cobalt (#F5F7FF / #2B3FE0 / coral #FF6A3D / ink #0E1440) · LF Sherbet (cream #FFF8E4, pink #FFD6E3, peach #FFA35C,
berry #D9497A, ink #2C2A3A) · LH Zine (butter #FFE27A / cream #FFF4E0, pink #FF5CA8, yellow #FFD43B, ink #141414) ·
HB Sunroom (indigo #5E54C9, cream #FFF8EF, yellow #FFC94D, orange #FF8A3D, ink #2A2238)."""
import importlib.util
import sys
from pathlib import Path

sys.path.insert(0, "/home/claude/content/design/samples-v5")
from lib import render_many, A, PREP as P3  # noqa
import build_a as LA
import build_grid_tiles as GT

D = Path("/home/claude/content/design")
OUT = D / "samples-v5" / "mix"
OUT.mkdir(exist_ok=True)
P5 = D / "samples-v5" / "prep"
MK = D / "assets" / "marks"
V = GT.V

# ---------------------------------------------------------------- Look B covers (page palettes)
LOOKB = {
    "ff-b": (GT.FF("money habits", ["The", ("boring", 1), "money", "habit", "that", "pays", "you", ("forever.", 2)],
                   save="save before payday", obj="ht-piggy.png", obj_w=440, obj_x=610, obj_y=930, rot=-7),
             V("#E8ECFF", "#0E1440", ("#2B3FE0", "#FFFFFF"), ("#FF6A3D", "#0E1440"), "#FF6A3D", "#FFB08F", "#0E1440")),
    "lf-b": (GT.LF("for new parents", ["The", "little", "things", "that", "make", "the", ("first", 1), ("week", 1), ("home", 2), "easier."],
                   save="save for the 3 am feeds", obj="ht-shoe.png", obj_w=400, obj_x=640, obj_y=940, rot=9),
             V("#FFF8E4", "#2C2A3A", ("#FFD6E3", "#D9497A"), ("#FFE27E", "#2C2A3A"), "#E8743B", "#FFD6E3", "#2C2A3A")),
    "lh-b": (GT.LH("the focus fix", ["This", ("one-hour", 1), ("rule", 1), "is", "quietly", "changing", ("everything.", 2)],
                   save="save this for Monday", obj="ht-clock.png", obj_w=380, obj_x=650, obj_y=900, rot=10),
             V("#FFE27A", "#141414", ("#FF5CA8", "#141414"), ("#FFFFFF", "#141414"), "#E85A1A", "#FF5CA8", "#141414")),
    "hb-b": (GT.HB("AI prompts · part 1", ["These", "AI", "prompts", "give", "you", "your", ("evening", 1), ("back.", 2)],
                   save="save this for tonight", obj="ht-point.png", obj_w=500, obj_x=560, obj_y=930, rot=-8, flip=True),
             V("#5E54C9", "#FFFFFF", ("#FFC94D", "#2A2238"), ("#FF8A3D", "#FFFFFF"), "#FFC94D", "#FFC94D", "#FFFFFF")),
}

# ---------------------------------------------------------------- Look A gloves / countdown
FFW = dict(bg="#F5F7FF", head="#0E1440", accent="#FF6A3D", sub="#0E1440", pill="#2B3FE0", pillink="#FFFFFF",
           prefix="ffmix", edition="money edition", glow="rgba(255,255,255,.5)")
LHW = dict(bg="#FFE27A", head="#141414", accent="#E8336F", sub="#141414", pill="#141414", pillink="#FFE27A",
           prefix="lhmix", edition="focus edition", glow="rgba(255,255,255,.35)")
HBW = dict(bg="#5E54C9", head="#FFFFFF", accent="#FFC94D", sub="#FFF8EF", pill="#FFC94D", pillink="#2A2238",
           prefix="hbmix", edition="evening edition", glow="rgba(255,255,255,.08)")
LH_LINES = ["", "you’ve opened the same app three times in one minute.", ""]
HB_LINES = ["", "", "you’ve made dinner decisions at 6:55 pm. Again."]


def glove(w, k, lines, brand, mark, nfing):
    return LA.slide(w, k, brand, mark, lines, photo=lambda kk: (P5 / f"{w['prefix']}-hand{nfing}.png").as_uri())


def lf_countdown():
    blob = lambda x, y, s, c, r=0: (f'<div data-noqa style="position:absolute;left:{x}px;top:{y}px;width:{s}px;height:{s * .86}px;'
                                    f'background:{c};border-radius:52% 48% 60% 40% / 50% 60% 40% 50%;transform:rotate({r}deg)"></div>')
    m = (MK / "littlefold.png").as_uri()
    return (f'<style>.slide{{width:1080px;height:1350px;background:#FFF8E4;overflow:hidden}}'
            f'.h{{position:absolute;left:70px;right:70px;top:150px;text-align:center;font-family:Lora;font-weight:600;font-size:150px;'
            f'line-height:.98;color:#2C2A3A;letter-spacing:-.03em}} .h i{{color:#D9497A;font-weight:500}}'
            f'.s{{position:absolute;left:100px;right:100px;top:500px;text-align:center;font-family:Inter;font-weight:600;font-size:56px;'
            f'line-height:1.18;color:#2C2A3A;text-wrap:balance}}'
            f'.n{{position:absolute;left:0;right:0;top:700px;text-align:center;font-family:Lora;font-weight:600;font-size:440px;line-height:1;color:#E8743B}}'
            f'.b{{position:absolute;left:76px;bottom:80px;display:flex;gap:12px;align-items:center;padding:8px 20px 8px 10px;border-radius:999px;'
            f'background:#fff;font:700 27px Inter;color:#2C2A3A}} .b img{{width:46px;height:46px}}</style>'
            f'<div class="slide">{blob(-160, 860, 560, "#FFD6E3", 10)}{blob(700, 900, 520, "#FFD3AE", -20)}{blob(820, -140, 380, "#FFE27E", 30)}'
            f'<div class="h">Put a finger<br>down <i>if…</i></div><div class="s">…you’ve googled a baby noise at 3 am.</div>'
            f'<div class="n" data-noqa>5</div><div class="b"><img src="{m}">Littlefold</div></div>')


# ---------------------------------------------------------------- slow-pan stills (real photo, one big word)
def still(photo, kicker, word, sub, brand, mark, wordfont, wordcol, kickcol, size=300, bright=.78):
    m = (MK / mark).as_uri()
    return (f'<style>.slide{{width:1080px;height:1350px;background:#111}}'
            f'.bg{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;filter:brightness({bright})}}'
            f'.k{{position:absolute;left:0;right:0;top:360px;text-align:center;font:800 30px/1 Inter;letter-spacing:.24em;color:{kickcol};'
            f'text-shadow:0 2px 14px rgba(0,0,0,.5)}}'
            f'.w{{position:absolute;left:0;right:0;top:430px;text-align:center;font-family:{wordfont};font-size:{size}px;line-height:.9;'
            f'color:{wordcol};letter-spacing:-.03em;filter:drop-shadow(0 10px 40px rgba(0,0,0,.45))}}'
            f'.s{{position:absolute;left:0;right:0;top:820px;text-align:center;font:600 42px/1.2 Inter;color:#fff;text-shadow:0 2px 16px rgba(0,0,0,.6)}}'
            f'.f{{position:absolute;left:0;right:0;top:1190px;display:flex;justify-content:center;align-items:center;gap:14px;font:700 28px/1 Inter;'
            f'color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.5)}} .f img{{width:48px;height:48px;border-radius:50%;background:#fff;padding:3px}}</style>'
            f'<div class="slide"><img class="bg" src="{(A / photo).as_uri()}"><div class="k">{kicker}</div><div class="w">{word}</div>'
            f'<div class="s">{sub}</div><div class="f"><img src="{m}">{brand}</div></div>')


# ---------------------------------------------------------------- handwritten list on paper
def paper_list(bg, paper, ink, accent, mark, brand, title, items, tilt=-2):
    m = (MK / mark).as_uri()
    lis = "".join(f'<li><span class="t">✓</span>{x}</li>' for x in items)
    return (f'<style>.slide{{width:1080px;height:1350px;background:{bg}}}'
            f'.card{{position:absolute;left:110px;top:130px;width:860px;height:1060px;background:{paper};transform:rotate({tilt}deg);'
            f'box-shadow:0 24px 40px rgba(0,0,0,.18);border-radius:6px;'
            f'background-image:linear-gradient({paper} 190px,transparent 190px),repeating-linear-gradient({paper} 0 118px,rgba(80,110,180,.28) 118px 120px);}}'
            f'.card:before{{content:"";position:absolute;left:96px;top:0;bottom:0;width:2px;background:rgba(220,80,80,.45)}}'
            f'.tape{{position:absolute;left:420px;top:100px;width:240px;height:66px;background:rgba(255,255,255,.55);transform:rotate(3deg);'
            f'box-shadow:0 2px 6px rgba(0,0,0,.08)}}'
            f'.ti{{position:absolute;left:130px;top:70px;font-family:CaveatBrush;font-size:100px;color:{accent};line-height:1}}'
            f'ul{{position:absolute;left:130px;right:40px;top:208px;list-style:none;font-family:Caveat;font-weight:700;font-size:76px;'
            f'line-height:120px;color:{ink}}} .t{{color:{accent};margin-right:18px}}'
            f'.b{{position:absolute;left:84px;bottom:76px;display:flex;gap:12px;align-items:center;font:700 26px Inter;color:{ink}}}'
            f'.b img{{width:46px;height:46px;border-radius:50%;background:#fff;padding:2px}}</style>'
            f'<div class="slide"><div class="card"><div class="ti">{title}</div><ul>{lis}</ul></div><div class="tape" data-noqa></div>'
            f'<div class="b"><img src="{m}">{brand}</div></div>')


# ---------------------------------------------------------------- extras: "Instead of… say…" reframe / emoji meme
def reframe(bg, card, ink, accent, mark, brand, inst, say, kicker):
    m = (MK / mark).as_uri()
    return (f'<style>.slide{{width:1080px;height:1350px;background:{bg}}}'
            f'.k{{position:absolute;left:96px;top:110px;font:800 28px Inter;letter-spacing:.2em;text-transform:uppercase;color:{ink};opacity:.8}}'
            f'.col{{position:absolute;left:84px;right:84px;top:190px;bottom:180px;display:flex;flex-direction:column;justify-content:center;gap:40px}}'
            f'.c{{padding:60px 54px;border-radius:40px;background:{card}}}'
            f'.l{{font-family:CaveatBrush;font-size:80px;color:{accent};line-height:1}}'
            f'.q{{font-family:Instrument;font-size:132px;line-height:1;color:{ink};margin-top:14px;letter-spacing:-.02em}}'
            f'.x{{text-decoration:line-through;text-decoration-thickness:6px;text-decoration-color:{accent};opacity:.75}}'
            f'.b{{position:absolute;left:84px;bottom:80px;display:flex;gap:12px;align-items:center;font:700 26px Inter;color:{ink}}}'
            f'.b img{{width:46px;height:46px;border-radius:50%;background:#fff;padding:2px}}</style>'
            f'<div class="slide"><div class="k">✦ {kicker}</div>'
            f'<div class="col"><div class="c"><div class="l">Instead of…</div><div class="q x">“{inst}”</div></div>'
            f'<div class="c" style="background:#FFFFFF"><div class="l">Say…</div><div class="q">“{say}”</div></div></div>'
            f'<div class="b"><img src="{m}">{brand}</div></div>')


def meme(bg, ink, accent, mark, brand, top, emoji, bottom):
    m = (MK / mark).as_uri()
    return (f'<style>.slide{{width:1080px;height:1350px;background:{bg}}}'
            f'.t{{position:absolute;left:84px;right:84px;top:130px;font-family:Inter;font-weight:800;font-size:76px;line-height:1.1;color:{ink};'
            f'letter-spacing:-.03em;text-wrap:balance}}'
            f'.e{{position:absolute;left:0;right:0;top:520px;text-align:center;font-size:330px;line-height:1}}'
            f'.bt{{position:absolute;left:84px;right:84px;top:950px;font-family:CaveatBrush;font-size:80px;line-height:1.05;color:{accent};'
            f'text-align:center;transform:rotate(-3deg)}}'
            f'.b{{position:absolute;left:84px;bottom:80px;display:flex;gap:12px;align-items:center;font:700 26px Inter;color:{ink}}}'
            f'.b img{{width:46px;height:46px;border-radius:50%;background:#fff;padding:2px}}</style>'
            f'<div class="slide"><div class="t">{top}</div><div class="e" data-noqa>{emoji}</div><div class="bt">{bottom}</div>'
            f'<div class="b"><img src="{m}">{brand}</div></div>')


JOBS = {
    "ff-glove": glove(FFW, 1, LA.LINES, "Fully Funded", "fullyfunded.png", 4),
    "lh-glove": glove(LHW, 2, LH_LINES, "Locked Hour", "lockedhour.png", 3),
    "hb-glove": glove(HBW, 3, HB_LINES, "Hourback", "hourback.png", 2),
    "lf-countdown": lf_countdown(),
    "lf-still": still("g-wheat.png", "FOR THE LONG DAYS", "<i>Breathe.</i>", "You’re allowed to go slow.", "Littlefold", "littlefold.png",
                      "Instrument", "#FFF3E0", "#FFD6E3", 330, .8),
    "hb-still": still("g-forest.png", "AFTER 7 PM", "<i>Offline.</i>", "Let the prompts do the rest.", "Hourback", "hourback.png",
                      "Instrument", "#FFFFFF", "#FFC94D", 300, .82),
    "ff-list": paper_list("#2B3FE0", "#FFFDF7", "#0E1440", "#FF6A3D", "fullyfunded.png", "Fully Funded", "Payday checklist",
                          ["Move savings first", "Pay the big bills", "Check subscriptions", "Top up the kid fund", "Enjoy the rest"]),
    "lf-list": paper_list("#FFD6E3", "#FFFDF5", "#2C2A3A", "#D9497A", "littlefold.png", "Littlefold", "Tonight, just this:",
                          ["One warm meal", "Water by the bed", "Say yes to help", "Lights low by 9", "You did enough today"], tilt=2),
    "lh-list": paper_list("#FF5CA8", "#FFFDF2", "#141414", "#E85A1A", "lockedhour.png", "Locked Hour", "Before you lock in:",
                          ["Phone in another room", "One task, written down", "Water + snack", "Timer: 60 min", "Start ugly. Fix later."]),
    "hb-list": paper_list("#FFC94D", "#FFFDF8", "#2A2238", "#5E54C9", "hourback.png", "Hourback", "Hand these to AI:",
                          ["Weekly meal plan", "Birthday-gift shortlist", "Reply to that long email", "Kids’ weekend ideas", "Sunday reset list"], tilt=2),
    "ff-reframe": reframe("#2B3FE0", "#E8ECFF", "#0E1440", "#FF6A3D", "fullyfunded.png", "Fully Funded",
                          "I can’t afford to save.", "I’ll start with 10.", "money reframes"),
    "lf-meme": meme("#FFEFC8", "#2C2A3A", "#D9497A", "littlefold.png", "Littlefold",
                    "Me: “I’ll sleep when the baby sleeps.”", "🫠", "the baby, at 3:07 am: no."),
    "lh-meme": meme("#FFF4E0", "#141414", "#E8336F", "lockedhour.png", "Locked Hour",
                    "Me, 4 minutes into my focus hour:", "📱👀", "“just checking the time”"),
    "hb-reframe": reframe("#FFF8EF", "#FFEEDC", "#2A2238", "#5E54C9", "hourback.png", "Hourback",
                          "Plan dinners.", "5 dinners, 30 min, one shopping list.", "prompt reframes"),
}

if __name__ == "__main__":
    jobs = [(GT.cover(c, v), OUT / k) for k, (c, v) in LOOKB.items()]
    jobs += [(h, OUT / k) for k, h in JOBS.items()]
    only = sys.argv[1:]
    render_many([j for j in jobs if not only or j[1].name in only])
