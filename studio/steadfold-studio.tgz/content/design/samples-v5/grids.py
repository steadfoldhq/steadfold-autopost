#!/usr/bin/env python3
"""Four phone-style profile grids side by side (3x3, centre 3:4 crop as Instagram shows), one picture.
    python3 grids.py old    -> grids-OLD.png   (covers already made in the original style)
    python3 grids.py new    -> grids-NEW.png   (tiles listed in new_tiles.json, built by build_grid_tiles.py)"""
import json
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = Path("/home/claude/content/design")
OUT = D / "samples-v5"
FONTS = D / "assets" / "fonts"
MARKS = D / "assets" / "marks"
C = Path("/home/claude/content")
MEDIA = Path("/home/claude/steadfold-autopost/media")
VO = C / "video" / "out"

PAGES = [("fullyfunded", "Fully Funded", "fullyfundedhq", "Money, made clear."),
         ("littlefold", "Littlefold", "littlefoldhq", "Small days, gently."),
         ("lockedhour", "Locked Hour", "lockedhourhq", "One hour at a time."),
         ("hourback", "Hourback", "hourbackhq", "Get your evenings back.")]

PW, GAP, PAD = 560, 44, 60          # phone panel width, gap, outer padding  -> 4*560 + 3*44 + 2*60 = 2492
TG = 3
F = lambda n, w="SemiBold": ImageFont.truetype(str(FONTS / f"Inter-{w}.ttf"), n)
SERIF = lambda n: ImageFont.truetype(str(FONTS / "InstrumentSerif-Regular.ttf"), n)


def crop34(im):
    im = im.convert("RGB")
    w, h = im.size
    if w / h > 3 / 4:
        cw = round(h * 3 / 4); return im.crop(((w - cw) // 2, 0, (w - cw) // 2 + cw, h))
    ch = round(w * 4 / 3); return im.crop((0, (h - ch) // 2, w, (h - ch) // 2 + ch))


def old_tiles():
    def media(prefix):
        return sorted([p / "01.jpg" for p in MEDIA.iterdir() if p.name.startswith(prefix) and (p / "01.jpg").exists()],
                      reverse=True)
    t = {
        "fullyfunded": [VO / "fullyfunded-reel-oct15-cover-v3.jpg"] + media("ff-w03") + [VO / "fullyfunded-reel-start-at-birth-cover-v3.jpg"] + media("ff-w02"),
        "littlefold": [VO / "littlefold-reel-oct15-cover-v3.jpg", VO / "littlefold-silhouette-not-perfect-cover.jpg",
                       VO / "littlefold-safe-sleep-cover.png"] + media("lf-"),
        "lockedhour": [VO / "lockedhour-reel-oct15-cover-v3.jpg", VO / "lockedhour-phone-room-cover.png"] + media("lh-w2"),
        "hourback": [VO / "hourback-reel-oct15-cover-v3.jpg", VO / "hourback-potluck-quiz-cover.png"] + media("hb-w02"),
    }
    for k, v in t.items():
        v = [p for p in v if Path(p).exists()]
        while len(v) < 9:
            v = v + v[: 9 - len(v)]
        t[k] = v[:9]
    return t


def panel(key, name, handle, bio, tiles, accent):
    tw = (PW - 2 * TG) // 3
    th = round(tw * 4 / 3)
    head = 330
    H = head + 3 * th + 2 * TG + 30
    p = Image.new("RGB", (PW, H), "white")
    d = ImageDraw.Draw(p)
    d.text((26, 22), "9:41", font=F(26, "Bold"), fill="#111")
    d.text((PW // 2, 74), handle, font=F(28, "Bold"), fill="#111", anchor="mm")
    av = 132
    ring = Image.new("RGB", (av, av), "white")
    m = Image.new("L", (av, av), 0); ImageDraw.Draw(m).ellipse((0, 0, av - 1, av - 1), fill=255)
    ImageDraw.Draw(ring).ellipse((0, 0, av - 1, av - 1), fill="#F3F1EE", outline="#DDD", width=2)
    mk = Image.open(MARKS / f"{key}.png").convert("RGBA").resize((88, 88), Image.LANCZOS)
    ring.paste(mk, (22, 22), mk)
    p.paste(ring, (24, 116), m)
    d.text((180, 140), name, font=F(30, "Bold"), fill="#111")
    d.text((180, 182), bio, font=F(21, "Regular"), fill="#555")
    for i, (n, lab) in enumerate((("—", "posts"), ("—", "followers"), ("—", "following"))):
        x = 180 + i * 120
        d.text((x, 216), n, font=F(22, "Bold"), fill="#111"); d.text((x, 244), lab, font=F(17, "Regular"), fill="#666")
    d.rectangle((0, head - 26, PW // 3, head - 23), fill="#111")
    d.rectangle((PW // 3 + 6, head - 25, PW - 6, head - 24), fill="#E5E5E5")
    for i, src in enumerate(tiles):
        r, c = divmod(i, 3)
        im = crop34(Image.open(src)).resize((tw, th), Image.LANCZOS)
        p.paste(im, (c * (tw + TG), head + r * (th + TG)))
    return p


def board(tiles_by_page, out, title, sub):
    panels = [panel(k, n, h, b, tiles_by_page[k], None) for k, n, h, b in PAGES]
    ph = max(x.height for x in panels)
    W = 2 * PAD + 4 * PW + 3 * GAP
    H = 230 + 80 + ph + PAD
    B = Image.new("RGB", (W, H), "#F4EFE8")
    d = ImageDraw.Draw(B)
    d.text((PAD, 52), title, font=SERIF(104), fill="#3A1D22")
    d.text((PAD + 4, 170), sub, font=F(26, "Medium"), fill="#6A5A5C")
    for i, (pn, (k, n, h, b)) in enumerate(zip(panels, PAGES)):
        x = PAD + i * (PW + GAP)
        d.text((x + 4, 238), n, font=SERIF(58), fill="#3A1D22")
        sh = Image.new("RGBA", (PW + 40, pn.height + 40), (0, 0, 0, 0))
        ImageDraw.Draw(sh).rounded_rectangle((20, 26, PW + 20, pn.height + 20), 34, fill=(60, 40, 30, 70))
        sh = sh.filter(ImageFilter.GaussianBlur(12))
        B.paste(sh, (x - 20, 310 - 20), sh)
        mk = Image.new("L", pn.size, 0); ImageDraw.Draw(mk).rounded_rectangle((0, 0, PW - 1, pn.height - 1), 34, fill=255)
        B.paste(pn, (x, 310), mk)
    B.save(out, optimize=True)
    print(out, B.size)


if __name__ == "__main__":
    if sys.argv[1] == "old":
        board(old_tiles(), OUT / "grids-OLD.png", "Profile grids · before",
              "Our original style: the covers and Reel covers made up to Oct 15 (pages with fewer than 9 repeat their earlier posts).")
    else:
        t = json.load(open(OUT / "grid-tiles" / "new_tiles.json"))
        board(t, OUT / "grids-NEW.png", "Profile grids · new brand system",
              "Fully Funded: green + butter · Littlefold: blush + sage · Locked Hour: butter, black + tomato · Hourback: periwinkle + royal blue")
