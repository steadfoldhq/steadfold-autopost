#!/usr/bin/env python3
"""STEADFOLD ORIGINAL: a letter folded in three, opened flat. Two real-looking creases (horizontal) split the slide
into thirds; each panel tilts a little differently to the light, the headline is printed across the folds (the fold
shading sits ON TOP of the type, so the words bend with the paper). Signature details:
  - a folded-corner tab (dog-ear) top-right showing the brand-colour underside, with the brand mark on it,
  - Fraunces SOFT display + Caveat Brush note in the brand accent, tiny small-caps "STEADFOLD ORIGINAL · No.01",
  - the fold glyph (two stacked chevrons) as a recurring mark bottom-right.
Paper texture: generated fibre + grain, no photos (so nothing is reused)."""
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v5")
from lib import *  # noqa

MARKS = D / "assets" / "marks"


def paper_png():
    p = PREP5 / "paper.png"
    if p.exists():
        return p
    rng = np.random.default_rng(11)
    H, W = 2700, 2160
    g = rng.normal(0, 1, (H, W)).astype(np.float32)
    fine = cv2.GaussianBlur(g, (0, 0), 0.8) * 0.5
    mott = cv2.GaussianBlur(rng.normal(0, 1, (H, W)).astype(np.float32), (0, 0), 40) * 3.0
    fib = np.zeros((H, W), np.float32)
    for _ in range(2600):                                     # short paper fibres
        x, y = rng.integers(0, W), rng.integers(0, H)
        a = rng.uniform(0, np.pi); L = rng.integers(10, 40)
        cv2.line(fib, (int(x), int(y)), (int(x + L * np.cos(a)), int(y + L * np.sin(a))), float(rng.uniform(.4, 1)), 1, cv2.LINE_AA)
    fib = cv2.GaussianBlur(fib, (0, 0), 0.7)
    v = 128 + fine * 9 + mott * 2.2 - fib * 14
    Image.fromarray(np.clip(v, 0, 255).astype(np.uint8)).save(p)
    return p


FOLDS = (423, 846)          # sheet is 1270 tall: thirds          # crease positions (y) at 1080x1350: a letter folded in three


def fold_layer():
    """Overlay that sits above the type: per-panel light, crease highlight+shadow, slight bow towards each crease."""
    a, b = FOLDS
    return f"""
<div class="fold" data-noqa style="top:0;height:{a}px;background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,0) 60%,rgba(60,40,20,.10) 100%)"></div>
<div class="fold" data-noqa style="top:{a}px;height:{b - a}px;background:linear-gradient(180deg,rgba(60,40,20,.13),rgba(60,40,20,.03) 22%,rgba(60,40,20,0) 70%,rgba(255,255,255,.12) 100%)"></div>
<div class="fold" data-noqa style="top:{b}px;height:{1270 - b}px;background:linear-gradient(180deg,rgba(60,40,20,.02),rgba(60,40,20,.06) 30%,rgba(60,40,20,.14) 100%)"></div>
<div class="crease" data-noqa style="top:{a - 1}px"></div><div class="crease" data-noqa style="top:{b - 1}px"></div>"""


def tab(color, mark):
    m = (MARKS / mark).as_uri()
    return f"""<svg class="tab" data-noqa width="190" height="190" viewBox="0 0 190 190">
<defs><linearGradient id="u" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{color}"/><stop offset="1" stop-color="{color}" stop-opacity=".85"/></linearGradient>
<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="-6" dy="8" stdDeviation="7" flood-color="#3A2A18" flood-opacity=".30"/></filter></defs>
<path d="M20,0 L190,170 L20,170 Z" fill="url(#u)" filter="url(#sh)"/>
<image href="{m}" x="34" y="98" width="58" height="58"/></svg>"""


def glyph(color):
    return (f'<svg class="glyph" data-noqa width="58" height="46" viewBox="0 0 58 46"><path d="M4,6 L29,22 L54,6 M4,24 L29,40 L54,24" '
            f'fill="none" stroke="{color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>')


def css(t):
    return f"""
.slide{{width:1080px;height:1350px;background:{t['ground']}}}
.sheet{{position:absolute;left:40px;top:40px;width:1000px;height:1270px;background:{t['paper']};overflow:hidden;
  clip-path:polygon(0 0,calc(100% - 170px) 0,100% 170px,100% 100%,0 100%);
  filter:drop-shadow(0 18px 30px rgba(0,0,0,.35))}}
.sheetwrap{{position:absolute;inset:0;filter:drop-shadow(0 22px 34px rgba(0,0,0,.32))}}
.tex{{position:absolute;inset:0;width:100%;height:100%;mix-blend-mode:soft-light;opacity:.55}}
.fold{{position:absolute;left:0;right:0;pointer-events:none;mix-blend-mode:multiply}}
.crease{{position:absolute;left:0;right:0;height:3px;background:linear-gradient(180deg,rgba(70,50,30,.22),rgba(255,255,255,.55))}}
.tab{{position:absolute;right:40px;top:40px}}
.glyph{{position:absolute;right:60px;bottom:52px}}
.sig{{position:absolute;left:66px;bottom:60px;font-family:Inter;font-weight:700;font-size:21px;letter-spacing:.26em;color:{t['ink']};opacity:.7}}
.brand{{position:absolute;left:66px;top:66px;font-family:Inter;font-weight:700;font-size:26px;letter-spacing:.2em;text-transform:uppercase;color:{t['accent']}}}
.h{{position:absolute;left:62px;right:62px;font-family:Fraunces;font-variation-settings:'opsz' 144,'SOFT' 100,'WONK' 1;
  font-weight:560;color:{t['ink']};letter-spacing:-.035em;line-height:.9}}
.h em{{font-style:normal;color:{t['accent']}}}
.note{{position:absolute;white-space:nowrap;font-family:CaveatBrush;color:{t['accent']};line-height:1}}
.body{{position:absolute;left:66px;right:66px;font-family:Fraunces;font-variation-settings:'opsz' 24,'SOFT' 50;font-weight:420;
  font-size:46px;line-height:1.3;color:{t['ink']};letter-spacing:-.008em;text-wrap:pretty}}
.num{{position:absolute;left:60px;font-family:Fraunces;font-variation-settings:'opsz' 144,'SOFT' 100;font-weight:300;font-size:300px;
  line-height:.8;color:{t['accent']};letter-spacing:-.05em}}
"""

THEMES = {
    "ff": dict(ground="#16206B", paper="#F5EEE2", under="#E6DCCB", ink="#16206B", accent="#E2412B", brand="Fully Funded", mark="fullyfunded.png"),
    "lh": dict(ground="#1B1416", paper="#FBF0D2", under="#EADBB3", ink="#1D1A16", accent="#E2412B", brand="Locked Hour", mark="lockedhour.png"),
    "lf": dict(ground="#9DB89A", paper="#FBEDEE", under="#EBD3D5", ink="#3F5A3F", accent="#B0577A", brand="Littlefold", mark="littlefold.png"),
    "hb": dict(ground="#2C3BD1", paper="#F1F3FF", under="#D8DDF7", ink="#1C1F5A", accent="#2C3BD1", brand="Hourback", mark="hourback.png"),
}


def page(t, inner, n, k):
    tex = paper_png().as_uri()
    return (f'<style>{css(t)}</style><div class="slide"><div class="sheetwrap"><div class="sheet"><img class="tex" data-noqa src="{tex}">'
            f'<div class="brand">{t["brand"]}</div>{inner}{fold_layer()}'
            f'<div class="sig">STEADFOLD ORIGINAL · No.01{"" if n == 1 else f" · {k}/{n}"}</div>{glyph(t["accent"])}</div></div>{tab(t["accent"], t["mark"])}</div>')


def ff_slides():
    t = THEMES["ff"]
    cover = (f'<div class="h" style="top:250px;font-size:186px">Fold your<br>pay cheque<br>in <em>three.</em></div>'
             f'<div class="note" style="left:300px;top:1000px;font-size:72px;transform:rotate(-4deg)">the calmest money rule ↓</div>')
    s2 = (f'<div class="num" style="top:230px">1</div>'
          f'<div class="h" style="top:520px;font-size:120px">Future you<br><em>gets paid first.</em></div>'
          f'<div class="body" style="top:950px">On payday, before anything else, move a set amount out. Small is fine. Automatic is better.</div>')
    s3 = (f'<div class="num" style="top:230px">2 <span style="font-size:.5em">&amp;</span> 3</div>'
          f'<div class="h" style="top:520px;font-size:120px">Bills next.<br><em>The rest is yours.</em></div>'
          f'<div class="body" style="top:950px">Spend the last fold without guilt. That’s the point of folding the first two.</div>')
    return [page(t, cover, 3, 1), page(t, s2, 3, 2), page(t, s3, 3, 3)]


def lh_cover():
    t = THEMES["lh"]
    cover = (f'<div class="h" style="top:250px;font-size:212px">Fold your<br>day into<br><em>thirds.</em></div>'
             f'<div class="note" style="left:300px;top:1000px;font-size:72px;transform:rotate(-4deg)">one hour is the middle ↓</div>')
    return page(t, cover, 1, 1)


def simple_cover(key, lines, note):
    t = THEMES[key]
    cover = (f'<div class="h" style="top:250px;font-size:200px">{lines}</div>'
             f'<div class="note" style="left:300px;top:1000px;font-size:72px;transform:rotate(-4deg)">{note}</div>')
    return page(t, cover, 1, 1)


if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] == "extra":
    render_many([
        (lh_cover(), S3 / "original" / "lh-original-cover"),
        (simple_cover("lf", "Fold the<br>day <em>small.</em>", "one feed at a time ↓"), S3 / "original" / "lf-original-cover"),
        (simple_cover("hb", "Fold your<br>week into<br><em>one prompt.</em>", "copy it on Sunday ↓"), S3 / "original" / "hb-original-cover"),
    ])
elif __name__ == "__main__":
    jobs = [(h, S3 / "original" / f"ff-original-{i + 1:02d}") for i, h in enumerate(ff_slides())]
    jobs.append((lh_cover(), S3 / "original" / "lh-original-cover"))
    rep = render_many(jobs)
    json.dump(rep, open(S3 / "qa" / "report-original.json", "w"), indent=1)
    contact_sheet([S3 / "original" / f"{n}.png" for n in ("ff-original-01", "ff-original-02", "ff-original-03", "lh-original-cover")],
                  S3 / "original" / "contact-sheet.png", label="STEADFOLD ORIGINAL · the folded letter (Fully Funded x3, Locked Hour cover)")
