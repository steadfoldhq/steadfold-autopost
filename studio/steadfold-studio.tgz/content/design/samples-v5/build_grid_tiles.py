#!/usr/bin/env python3
"""Extra covers for grids-NEW.png (9 distinct tiles per page, no photo used twice inside a grid).
Look B covers come from samples-v4/build_b.py's system (styles reused, new copy/colours); text-only cards use the same
type system with no object; Hourback adds CSS chat bubbles and a pixelated 'swipe to reveal' prompt card."""
import importlib.util
import json
import sys
from pathlib import Path

sys.path.insert(0, "/home/claude/content/design/samples-v5")
from lib import render_many, PREP as PREP3, A as A3, halftone_cutout  # noqa  (v3 prep + assets)
from PIL import Image, ImageFilter

D = Path("/home/claude/content/design")
S5 = D / "samples-v5"
OUT = S5 / "grid-tiles"
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location("bb", D / "samples-v4" / "build_b.py")
bb = importlib.util.module_from_spec(spec); spec.loader.exec_module(bb)

INK = "#4A1D24"
# extra halftone cut-outs from the sheets (different photos from the single-object ones)
q = lambda i, j: (j * 1024, i * 1024, j * 1024 + 1024, i * 1024 + 1024)
if not (PREP3 / "ht-clock2.png").exists():
    halftone_cutout(A3 / "halftone1.png", PREP3 / "ht-clock2.png", crop=q(1, 1), pitch=7)


def cover(c, v, extra="", obj=True, title_top=300, maxh=690, stamp=True, save=True):
    """bb.cover with optional object / stamp / save-line and extra HTML."""
    mark = (bb.MARKS / c["mark"]).as_uri()
    t = bb.title_html(c["words"])
    o = ""
    if obj and c.get("obj"):
        flip = "scaleX(-1) " if c.get("flip") else ""
        o = (f'<img class="obj" data-noqa style="left:{c["obj_x"]}px;top:{c["obj_y"]}px;width:{c["obj_w"]}px;'
             f'transform:{flip}rotate({c["rot"]}deg)" src="{(PREP3 / c["obj"]).as_uri()}">')
    sv = ""
    if save and c.get("save"):
        sw = 84 + 31 * len(c["save"])
        sv = (f'<div class="save">{c["save"]}</div>'
              f'<div data-noqa style="position:absolute;left:{min(sw, 560)}px;top:1060px">{bb.arrow(v["save"])}</div>')
    st = f'<div class="stamp" data-noqa>{bb.stamp(c, v)}</div>' if stamp else ""
    return (f'<style>{bb.css(v)}.title{{top:{title_top}px}}</style><div class="slide"><div class="paper"></div>'
            f'<div class="chip"><img src="{mark}">{c["brand"]}</div><div class="kick">✦ {c["kicker"]}</div>'
            f'<div class="pills" data-noqa></div><div class="title over" data-maxh="{maxh}">{t}</div>'
            f'{o}{extra}{sv}{st}<div class="handle">{c["handle"]}</div></div>{bb.FIT}')


def V(bg, ink, p1, p2, save, centre, chip):
    return dict(bg=bg, ink=ink, p1=p1, p2=p2, save=save, centre=centre, chip=chip)


def B(brand, mark, handle, tag, kicker, words, save="", obj=None, **kw):
    d = dict(brand=brand, mark=mark, handle=handle, tag=tag, kicker=kicker, words=words, save=save, obj=obj,
             obj_w=420, obj_x=600, obj_y=900, rot=8)
    d.update(kw)
    return d


FF = lambda *a, **k: B("Fully Funded", "fullyfunded.png", "@fullyfundedhq", "MONEY, MADE CLEAR", *a, **k)
LF = lambda *a, **k: B("Littlefold", "littlefold.png", "@littlefoldhq", "SMALL DAYS, GENTLY", *a, **k)
LH = lambda *a, **k: B("Locked Hour", "lockedhour.png", "@lockedhourhq", "ONE HOUR AT A TIME", *a, **k)
HB = lambda *a, **k: B("Hourback", "hourback.png", "@hourbackhq", "GET YOUR EVENINGS BACK", *a, **k)

GREEN, BUTTER, CREAM, TOMATO = "#0F4D3A", "#F8E07A", "#FFF4E2", "#E2412B"
BLUSH, SAGE, SAGED, BERRY = "#F6D3D6", "#9DB89A", "#3F5A3F", "#B0577A"
BLACK = "#1B1416"
PERI, ROYAL = "#C7D0F7", "#2C3BD1"

bubble_css = """.bub{position:absolute;max-width:640px;padding:26px 34px;border-radius:40px;font-family:Inter;font-weight:600;
 font-size:38px;line-height:1.25;box-shadow:0 12px 28px rgba(20,20,60,.18)}
.bub.me{right:84px;background:#2C3BD1;color:#fff;border-bottom-right-radius:12px}
.bub.ai{left:84px;background:#FFFFFF;color:#1C1F3A;border-bottom-left-radius:12px}"""


def bubbles(items, top):
    out, y = [f"<style>{bubble_css}</style>"], top
    for who, txt in items:
        out.append(f'<div class="bub {who}" style="top:{y}px">{txt}</div>')
        y += 150
    return "".join(out)


TILES = {
    # ---------------- Fully Funded: royal green + butter/gold
    "ff-cover-butter-cup": (FF("money habits", ["The", "coffee", "isn’t", "the", ("problem.", 1), "This", ("is.", 2)],
                               save="save before payday", obj="ht-cup.png", obj_w=360, obj_x=650, obj_y=860, rot=8),
                            V(BUTTER, GREEN, (GREEN, BUTTER), (CREAM, TOMATO), TOMATO, CREAM, GREEN), {}),
    # ---------------- Littlefold: blush + sage
    "lf-cover-blush-shoe": (LF("for new parents", ["The", "little", "things", "that", "make", "the", ("first", 1), ("week", 1), ("home", 2), "easier."],
                               save="save for the 3 am feeds", obj="ht-shoe.png", obj_w=400, obj_x=640, obj_y=940, rot=9),
                            V(BLUSH, SAGED, (SAGE, CREAM), (CREAM, BERRY), BERRY, SAGE, SAGED), {}),
    "lf-cover-sage-ok": (LF("a note for tonight", ["You’re", "doing", ("better", 1), "than", "you", ("think.", 2), "Really."],
                            save="save for a hard night", obj="ht-ok.png", obj_w=330, obj_x=680, obj_y=860, rot=-6),
                         V(SAGE, CREAM, (BLUSH, BERRY), (CREAM, SAGED), CREAM, BLUSH, CREAM), {}),
    "lf-card-week-two": (LF("nobody says this", ["Nobody", "tells", "you", "this", "about", ("week", 1), ("two.", 2)], save="read this twice"),
                         V(SAGED, CREAM, (BLUSH, BERRY), (SAGE, CREAM), BLUSH, BLUSH, CREAM), dict(obj=False)),
    "lf-card-3am": (LF("for the night shift", ["Things", "I’d", "tell", "myself", "at", ("3 am.", 1)], save="send to a new parent"),
                    V(BLUSH, SAGED, (SAGE, CREAM), (CREAM, BERRY), BERRY, SAGE, SAGED), dict(obj=False)),
    # ---------------- Locked Hour: butter + black + tomato
    "lh-cover-butter-clock2": (LH("the focus fix", ["Your", "phone", "isn’t", "the", "problem.", "Your", ("start", 1), ("time", 1), ("is.", 2)],
                                  save="save this for Monday", obj="ht-clock2.png", obj_w=380, obj_x=650, obj_y=880, rot=8),
                               V(BUTTER, BLACK, (TOMATO, CREAM), (BLACK, BUTTER), TOMATO, BUTTER, BLACK), {}),
    "lh-cover-black-hourglass": (LH("one rule", ["One", ("locked", 1), ("hour", 1), "beats", "a", "whole", ("distracted", 2), "day."],
                                    save="save for tomorrow", obj="ht-hourglass.png", obj_w=300, obj_x=700, obj_y=860, rot=6),
                                 V(BLACK, CREAM, (TOMATO, CREAM), (BUTTER, BLACK), BUTTER, TOMATO, CREAM), {}),
    "lh-card-missed": (LH("the restart", ["Missed", "the", "hour?", "Start", "the", ("next", 1), ("one.", 2)], save="no guilt, just go"),
                       V(TOMATO, CREAM, (BLACK, BUTTER), (BUTTER, BLACK), BUTTER, BUTTER, CREAM), dict(obj=False)),
    "lh-card-five-rules": (LH("the 5 rules", ["5", "rules", "for", "an", "hour", "that", "actually", ("stays", 1), ("locked.", 2)], save="save for your next lock-in"),
                           V(BUTTER, BLACK, (TOMATO, CREAM), (BLACK, BUTTER), TOMATO, TOMATO, BLACK), dict(obj=False)),
    # ---------------- Hourback: periwinkle + royal blue
    "hb-cover-peri-megaphone": (HB("AI prompts · email", ["Stop", "rewriting", "the", ("same", 1), ("email.", 1), "Try", ("this.", 2)],
                                   save="save for Monday morning", obj="ht-megaphone.png", obj_w=440, obj_x=600, obj_y=880, rot=-8),
                                V(PERI, "#1C1F5A", (ROYAL, CREAM), (BUTTER, "#1C1F5A"), ROYAL, BUTTER, "#1C1F5A"), {}),
    "hb-cover-bubbles": (HB("ask it like this", ["Ask", "AI", "like", ("this,", 1), "not", "like", ("that.", 2)], save=""),
                         V(PERI, "#1C1F5A", (ROYAL, CREAM), ("#FFFFFF", ROYAL), ROYAL, BUTTER, "#1C1F5A"),
                         dict(obj=False, maxh=420, extra=bubbles([("me", "Plan dinners."), ("ai", "Here are 7 ideas…"),
                                                                   ("me", "5 dinners, 30 min, no pork, one shopping list.")], 790))),
    "hb-card-dinners": (HB("tonight’s prompt", ["Let", "it", "plan", "five", ("dinners", 1), ("tonight.", 2)], save=""),
                        V(ROYAL, CREAM, (BUTTER, "#1C1F5A"), (PERI, "#1C1F5A"), BUTTER, BUTTER, CREAM),
                        dict(obj=False, maxh=420, extra=bubbles([("ai", "Mon · lemon chicken traybake · 25 min"),
                                                                  ("ai", "Tue · black bean tacos · 20 min")], 820))),
    "hb-card-sunday": (HB("sunday reset", ["3", "prompts", "for", "a", ("calmer", 1), ("Sunday.", 2)], save="save for Sunday"),
                       V(PERI, "#1C1F5A", (ROYAL, CREAM), (BUTTER, "#1C1F5A"), ROYAL, BUTTER, "#1C1F5A"), dict(obj=False)),
    "lf-card-small-days": (LF("a gentle reminder", ["Small", "days", ("count", 1), ("too.", 2)], save="for the slow days"),
                           V(SAGE, CREAM, (BLUSH, BERRY), (CREAM, SAGED), CREAM, BLUSH, CREAM), dict(obj=False)),
    "lh-card-timer": (LH("start here", ["Phone", "in", "another", "room.", ("Start.", 1)], save=""),
                      V(BUTTER, BLACK, (TOMATO, CREAM), (BLACK, BUTTER), TOMATO, TOMATO, BLACK),
                      dict(obj=False, maxh=420, extra='<div style="position:absolute;left:0;right:0;top:760px;text-align:center;'
                           'font-family:Inter;font-weight:800;font-size:250px;letter-spacing:-.05em;color:#E2412B">60:00</div>')),
    "lh-card-lockin": (LH("tonight", ["Lock", "in.", "One", "hour.", ("One", 1), ("thing.", 2)], save="tag your study buddy"),
                       V(TOMATO, CREAM, (BLACK, BUTTER), (BUTTER, BLACK), BUTTER, BUTTER, CREAM), dict(obj=False)),
    "hb-card-evening": (HB("the goal", ["Your", ("evening,", 1), "back", "by", ("7 pm.", 2)], save="save this for tonight"),
                        V(ROYAL, CREAM, (BUTTER, "#1C1F5A"), (PERI, "#1C1F5A"), BUTTER, BUTTER, CREAM), dict(obj=False)),
    "hb-card-paste": (HB("copy · paste · done", ["Paste", "this", "into", "any", ("AI", 1), ("chat.", 1)], save=""),
                      V(PERI, "#1C1F5A", (ROYAL, CREAM), (BUTTER, "#1C1F5A"), ROYAL, BUTTER, "#1C1F5A"),
                      dict(obj=False, maxh=420, extra='<div style="position:absolute;left:84px;right:84px;top:760px;padding:40px 46px;'
                           'background:#fff;border-radius:34px;font-family:Inter;font-weight:500;font-size:40px;line-height:1.35;color:#1C1F3A;'
                           'box-shadow:0 16px 32px rgba(20,20,80,.18)">“You’re my calm planner. Turn this to-do list into one evening '
                           'with a hard stop at 7 pm…”</div>')),
    "ff-card-payyourself": (FF("the first rule", ["Pay", ("future", 1), ("you", 1), "before", "you", "pay", ("anyone.", 2)], save="save before payday"),
                            V(GREEN, CREAM, (BUTTER, GREEN), (CREAM, TOMATO), BUTTER, BUTTER, CREAM), dict(obj=False)),
    "lh-card-calendar": (LH("the plan", ["Put", "the", ("hour", 1), "in", "your", "calendar", "like", "a", ("meeting.", 2)], save="block it now"),
                         V(BLACK, CREAM, (TOMATO, CREAM), (BUTTER, BLACK), BUTTER, TOMATO, CREAM), dict(obj=False)),
    "hb-card-meeting": (HB("work prompt", ["Turn", "any", "meeting", "into", ("3", 1), ("bullet", 1), ("points.", 2)], save="save for your next call"),
                        V(ROYAL, CREAM, (BUTTER, "#1C1F5A"), (PERI, "#1C1F5A"), BUTTER, BUTTER, CREAM), dict(obj=False)),
}


def swipe_cover():
    """Swipe-to-reveal prompt cover: a real chat card rendered sharp, then pixelated (block 34) and placed on royal blue."""
    card = ("<style>.slide{width:1080px;height:1350px;background:#FFFFFF}.c{position:absolute;left:0;top:0;width:1080px;"
            "height:1350px;padding:90px;font-family:Inter;font-size:52px;line-height:1.35;color:#1C1F3A;font-weight:500}"
            ".c b{background:#C7D0F7;border-radius:14px;padding:0 10px}</style><div class='slide'><div class='c'>Here’s my week: "
            "<b>[paste your calendar]</b>. Plan 5 weeknight dinners under 30 minutes, reuse ingredients, then one shopping "
            "list grouped by aisle. Flag anything that won’t fit.</div></div>")
    render_many([(card, OUT / "_swipe-card")])
    im = Image.open(OUT / "_swipe-card.png")
    sm = im.resize((1080 // 34, 1350 // 34), Image.BOX).resize((1080, 1350), Image.NEAREST)
    sm.save(OUT / "_swipe-pix.png")
    c = HB("swipe to reveal", ["The", "one", "prompt", "that", ("plans", 1), ("your", 1), ("week.", 2)], save="")
    v = V(ROYAL, CREAM, (BUTTER, "#1C1F5A"), (PERI, "#1C1F5A"), BUTTER, BUTTER, CREAM)
    extra = (f'<div data-noqa style="position:absolute;left:84px;right:84px;top:760px;height:330px;border-radius:36px;overflow:hidden;'
             f'box-shadow:0 18px 36px rgba(0,0,40,.35)"><img src="{(OUT / "_swipe-pix.png").as_uri()}" style="width:100%;height:auto;'
             f'image-rendering:pixelated"></div><div style="position:absolute;left:84px;top:1130px;font-family:CaveatBrush;font-size:70px;'
             f'color:{BUTTER};transform:rotate(-4deg)">keep swiping →</div>')
    return cover(c, v, extra=extra, obj=False, maxh=420, save=False)


if __name__ == "__main__":
    jobs = []
    for name, (c, v, opt) in TILES.items():
        jobs.append((cover(c, v, extra=opt.get("extra", ""), obj=opt.get("obj", True), maxh=opt.get("maxh", 690)), OUT / name))
    only = sys.argv[1:]
    jobs = [j for j in jobs if not only or j[1].name in only]
    if not only:
        jobs.append((swipe_cover(), OUT / "hb-cover-swipe"))
    render_many(jobs)
