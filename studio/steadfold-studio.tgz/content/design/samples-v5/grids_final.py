#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import grids as G
D = Path("/home/claude/content/design"); F = D / "samples-v5" / "final"; VO = Path("/home/claude/content/video/out")
T = {
 "fullyfunded": [(F/"ff-b.png","Look B cover"),(F/"ff-rich.png","Series: Rich Habits"),(F/"ff-start.png","One-word photo"),
                 (F/"ff-line.png","Follow the line"),(F/"ff-glove.png","Put a finger down"),(F/"ff-ep.png","Ep.01 · B/W photo"),
                 (F/"ff-list.png","Sticky-note list"),(VO/"samples-v4/fullyfunded-slowpan-bold-cover.jpg","Reel cover"),(F/"ff-template.png","Old template, bigger")],
 "littlefold": [(F/"lf-b.png","Look B cover"),(F/"lf-wins.png","Series: Small Wins"),(VO/"samples-v4/littlefold-silhouette-photo-cover.jpg","Reel cover"),
                (F/"lf-count.png","Soft countdown"),(F/"lf-ep.png","Ep.01 · B/W photo"),(F/"lf-awards.png","Awards"),
                (F/"lf-breathe.png","One-word photo"),(F/"lf-list.png","Sticky-note list"),(F/"lf-meme.png","Emoji meme")],
 "lockedhour": [(F/"lh-b.png","Look B cover"),(F/"lh-word.png","Series: One Word"),(F/"lh-glove.png","Put a finger down"),
                (F/"lh-pano.png","Panorama"),(F/"lh-ep.png","Ep.01 · B/W photo"),(F/"lh-focus.png","One-word photo"),
                (F/"lh-list.png","Sticky-note list"),(VO/"lockedhour-reel-oct15-cover-v3.jpg","Reel cover"),(F/"lh-meme.png","Emoji meme")],
 "hourback": [(F/"hb-b.png","Look B cover"),(F/"hb-potw.png","Series: Prompt"),(F/"hb-offline.png","One-word photo"),
              (F/"hb-list.png","Sticky-note list"),(F/"hb-glove.png","Put a finger down"),(F/"hb-ep.png","Ep.01 · B/W photo"),
              (F/"hb-swipe.png","Swipe to reveal"),(VO/"hourback-potluck-quiz-cover.png","Reel cover"),(F/"hb-reframe.png","Instead of… Say…")],
}
for k, v in T.items():
    assert len({str(p) for p, _ in v}) == 9 and all(p.exists() for p, _ in v), k
panels = [G.panel(k, n, h, b, [p for p, _ in T[k]], None) for k, n, h, b in G.PAGES]
ph = max(x.height for x in panels); W = 2 * G.PAD + 4 * G.PW + 3 * G.GAP; H = 310 + ph + 30 + 150 + G.PAD
B = Image.new("RGB", (W, H), "#F4EFE8"); d = ImageDraw.Draw(B)
d.text((G.PAD, 52), "Profile grids · final", font=G.SERIF(104), fill="#3A1D22")
d.text((G.PAD + 4, 170), "Original palettes, every style mixed, big hooks, clean glove cut-outs, one new recurring series per page.", font=G.F(24, "Medium"), fill="#6A5A5C")
for i, (pn, (k, n, h, b)) in enumerate(zip(panels, G.PAGES)):
    x = G.PAD + i * (G.PW + G.GAP)
    d.text((x + 4, 238), n, font=G.SERIF(58), fill="#3A1D22")
    sh = Image.new("RGBA", (G.PW + 40, pn.height + 40), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle((20, 26, G.PW + 20, pn.height + 20), 34, fill=(60, 40, 30, 70))
    sh = sh.filter(ImageFilter.GaussianBlur(12)); B.paste(sh, (x - 20, 290), sh)
    mk = Image.new("L", pn.size, 0); ImageDraw.Draw(mk).rounded_rectangle((0, 0, G.PW - 1, pn.height - 1), 34, fill=255)
    B.paste(pn, (x, 310), mk)
    for j, (_, lab) in enumerate(T[k]):
        r, c = divmod(j, 3)
        d.text((x + 4 + c * 190, 310 + ph + 30 + r * 40), f"{j + 1}. {lab}"[:24], font=G.F(17, "Medium"), fill="#4A3A3C")
B.save(D / "samples-v5" / "grids-FINAL.png", optimize=True); print(B.size)
