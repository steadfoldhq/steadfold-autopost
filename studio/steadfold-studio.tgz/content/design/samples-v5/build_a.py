#!/usr/bin/env python3
"""Look A v5: colour gloves that pop. (i) butter glove on royal green, (ii) green glove on butter (Fully Funded),
plus Littlefold in blush + sage (its own, different glove photo on the cover; giant numerals inside)."""
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v5")
from lib import *  # noqa

MARKS = D / "assets" / "marks"
LINES = ["you’ve checked your balance before buying a coffee.",
         "you’ve said “I’ll start saving next month” more than once.",
         "a subscription you forgot about renewed this year.",
         "you’ve felt real relief when payday finally landed."]
LF_LINES = ["you’ve googled a baby noise at 3 am.", "you’ve eaten dinner standing up, one-handed.",
            "you’ve whispered “please sleep” like a little prayer.", "you’ve watched them sleep instead of sleeping."]

WAYS = {
    "ff-green": dict(bg="#0F4D3A", head="#FFF1C9", accent="#F6D44C", sub="#FFF1C9", pill="#FFF1C9", pillink="#0F4D3A",
                     prefix="yg", edition="money edition", glow="rgba(255,240,200,.10)"),
    "ff-butter": dict(bg="#F8E07A", head="#0F4D3A", accent="#B5241A", sub="#0F4D3A", pill="#0F4D3A", pillink="#FFF1C9",
                      prefix="gy", edition="money edition", glow="rgba(255,255,255,.35)"),
}


def sparkle(x, y, s, rot=0, op=1.0):
    return (f'<svg data-noqa style="position:absolute;left:{x - s / 2}px;top:{y - s / 2}px;width:{s}px;height:{s}px;'
            f'transform:rotate({rot}deg);opacity:{op}" viewBox="-1 -1 2 2"><defs><linearGradient id="g{x}{y}" x1="0" y1="-1" x2="0" y2="1">'
            f'<stop offset="0" stop-color="#FBE7A6"/><stop offset=".55" stop-color="#E0B04A"/><stop offset="1" stop-color="#B98428"/></linearGradient></defs>'
            f'<path d="M0,-1 C0.09,-0.09 0.09,-0.09 1,0 C0.09,0.09 0.09,0.09 0,1 C-0.09,0.09 -0.09,0.09 -1,0 C-0.09,-0.09 -0.09,-0.09 0,-1Z" fill="url(#g{x}{y})"/></svg>')


def css(w):
    return f"""
.slide{{width:1080px;height:1350px;background:{w['bg']}}}
.photo{{position:absolute;object-fit:cover;-webkit-mask-image:linear-gradient(to bottom,transparent 0,#000 160px)}}
.glow{{position:absolute;inset:0;background:radial-gradient(110% 60% at 50% 15%,{w['glow']},transparent 65%)}}
.head{{position:absolute;left:70px;right:70px;text-align:center;font-family:Playfair;font-weight:600;color:{w['head']};
  letter-spacing:-.03em;line-height:.94}}
.head .if{{font-family:Instrument;font-style:italic;font-weight:400;letter-spacing:0;color:{w['accent']}}}
.sub{{position:absolute;left:96px;right:96px;text-align:center;font-family:Inter;font-weight:600;color:{w['sub']};
  font-size:60px;line-height:1.14;letter-spacing:-.014em;text-wrap:balance}}
.tag{{position:absolute;left:0;right:0;text-align:center;font-family:Inter;font-weight:700;color:{w['accent']};font-size:26px;
  letter-spacing:.22em;text-transform:uppercase}}
.brand{{position:absolute;left:76px;bottom:80px;display:flex;align-items:center;gap:12px;padding:8px 20px 8px 10px;border-radius:999px;
  background:{w['pill']};font-family:Inter;font-weight:700;font-size:27px;color:{w['pillink']}}}
.brand img{{width:46px;height:46px;border-radius:50%;background:#fff}}
.idx{{position:absolute;right:76px;bottom:80px;padding:12px 18px;border-radius:999px;background:{w['pill']};font-family:Inter;
  font-weight:700;font-size:24px;color:{w['pillink']};letter-spacing:.08em}}
.end{{position:absolute;left:110px;right:110px;text-align:center;font-family:Caveat;font-weight:700;font-size:64px;color:{w['accent']};
  line-height:1.02;text-wrap:balance}}
.num{{position:absolute;left:0;right:0;text-align:center;font-family:Playfair;font-weight:500;color:{w['accent']};line-height:.8}}
"""


def slide(w, k, brand="Fully Funded", mark="fullyfunded.png", lines=LINES, end=None, photo=None):
    m = (MARKS / mark).as_uri()
    sp = []
    if k == 0:
        head = (f'<div class="tag" style="top:104px">✦ {w["edition"]} ✦</div>'
                f'<div class="head" style="top:150px;font-size:186px">Put a finger<br>down <span class="if">if…</span></div>')
        sp += [sparkle(118, 190, 104, 0), sparkle(964, 372, 78, 12), sparkle(930, 150, 40, 0, .9), sparkle(160, 480, 48, 8, .9)]
        top, pw = 330, 1140
    else:
        head = (f'<div class="head" style="top:112px;font-size:150px">Put a finger<br>down <span class="if">if…</span></div>'
                f'<div class="sub" style="top:420px">…{lines[k - 1]}</div>')
        sp += [sparkle(112, 130, 76, 0, .95), sparkle(968, 400, 50, 10, .95), sparkle(116, 440, 40, -8, .9)]
        top, pw = 400, 1200
    if k == 4:
        head += f'<div class="end" style="top:600px">{end}</div>'
        top = 580
    if photo and k == 0:
        top, pw = 560, 960
    img = photo(k) if photo else (PREP5 / f"{w['prefix']}-hand{5 - k}.png").as_uri()
    left = -(pw - 1080) // 2
    nomask = ";-webkit-mask-image:none" if (photo and k == 0) else ""
    body = (f'<img class="photo" style="top:{top}px{nomask};left:{left}px;width:{pw}px;height:{round(pw * 1.25)}px" src="{img}">'
            if img else "")
    return (f'<style>{css(w)}</style><div class="slide">{body}<div class="glow"></div>{head}{"".join(sp)}'
            f'<div class="brand"><img src="{m}">{brand}</div><div class="idx">{k + 1}/5</div></div>')


LF = dict(bg="#F6D3D6", head="#5E7B5B", accent="#B0577A", sub="#4C5F4A", pill="#FFF6F1", pillink="#4C5F4A",
          prefix="lf", edition="new parent edition", glow="rgba(255,255,255,.35)")


def lf_slide(k):
    """Littlefold: the cover uses its own sage glove photo; inner slides count down with a giant serif numeral and
    a tiny sage-glove-free sprig, so no photo is shared with the Fully Funded sets."""
    if k == 0:
        return slide(LF, 0, "Littlefold", "littlefold.png", LF_LINES, photo=lambda k: (PREP5 / "lf-hand5.png").as_uri())
    w = LF
    m = (MARKS / "littlefold.png").as_uri()
    endl = (f'<div class="end" style="top:1010px;font-size:58px">Every finger down? You’re doing better than you think.</div>'
            if k == 4 else "")
    numtop = 560 if k < 4 else 470
    return (f'<style>{css(w)}</style><div class="slide"><div class="glow"></div>'
            f'<div class="head" style="top:112px;font-size:150px">Put a finger<br>down <span class="if">if…</span></div>'
            f'<div class="sub" style="top:420px">…{LF_LINES[k - 1]}</div>'
            f'<div class="num" data-noqa style="top:{numtop}px;font-size:{560 if k < 4 else 420}px;opacity:.9">{5 - k}</div>'
            f'{sparkle(250, 760, 70, 0)}{sparkle(830, 900, 50, 10, .9)}{sparkle(800, 640, 34, 0, .8)}{endl}'
            f'<div class="brand"><img src="{m}">Littlefold</div><div class="idx">{k + 1}/5</div></div>')


if __name__ == "__main__":
    jobs = []
    for key, w in WAYS.items():
        for k in range(5):
            jobs.append((slide(w, k, end="Still got a finger up? Good. That’s where saving starts."), S3 / key / f"slide-{k + 1:02d}"))
    for k in range(5):
        jobs.append((lf_slide(k), S3 / "lf-blush" / f"slide-{k + 1:02d}"))
    rep = render_many(jobs)
    json.dump(rep, open(S3 / "qa" / "report-a.json", "w"), indent=1)
    for key, lab in (("ff-green", "Fully Funded · butter glove on royal green"), ("ff-butter", "Fully Funded · green glove on butter"),
                     ("lf-blush", "Littlefold · blush + sage")):
        contact_sheet([S3 / key / f"slide-{k:02d}.png" for k in range(1, 6)], S3 / key / "contact-sheet.png", label=lab)
