#!/usr/bin/env python3
"""grids-FINAL tiles. Every tile: hook >= ~120 px at 1080, <= ~8 words; each page in its original palette;
clean glove cutouts (assets/cutouts, alpha) re-tinted and floated on the page colour with a soft contact shadow."""
import sys
from pathlib import Path
import cv2
import numpy as np

sys.path.insert(0, "/home/claude/content/design/samples-v5")
from lib import render_many, A, PREP as P3, bw_grain  # noqa
import build_grid_tiles as GT
import build_mix as BM

D = Path("/home/claude/content/design")
OUT = D / "samples-v5" / "final"; OUT.mkdir(exist_ok=True)
CUT = D / "assets" / "cutouts"
MK = D / "assets" / "marks"
PF = OUT / "_prep"; PF.mkdir(exist_ok=True)


def mark(m):
    return (MK / m).as_uri()


def tint_glove(n, hexcol, name):
    """Re-tint the clean pink cutout (keeps its shading and highlights); saves RGBA."""
    im = cv2.imread(str(CUT / f"glove-pink-{n}.png"), cv2.IMREAD_UNCHANGED)
    a = im[..., 3].astype(np.float32) / 255
    lab = cv2.cvtColor(im[..., :3], cv2.COLOR_BGR2LAB).astype(np.float32)
    L = lab[..., 0]; gl = np.median(L[a > .9])
    t = cv2.cvtColor(np.uint8([[[int(hexcol[i:i + 2], 16) for i in (5, 3, 1)]]]), cv2.COLOR_BGR2LAB).astype(np.float32)[0, 0]
    out = np.empty_like(lab)
    out[..., 0] = np.clip(t[0] + (L - gl) * 1.1, 0, 255)
    hi = np.clip((L - gl - 18) / 30, 0, 1)
    out[..., 1] = t[1] * (1 - hi * .5) + 128 * hi * .5
    out[..., 2] = t[2] * (1 - hi * .5) + 128 * hi * .5
    bgr = cv2.cvtColor(np.clip(out, 0, 255).astype(np.uint8), cv2.COLOR_LAB2BGR)
    p = PF / f"{name}.png"
    cv2.imwrite(str(p), np.dstack([bgr, im[..., 3]]))
    return p.as_uri()


def bw(src, name, crop=None):
    p = PF / f"{name}.jpg"
    if not p.exists():
        bw_grain(src, p, crop=crop, contrast=1.15, grain=.045)
    return p.as_uri()


def sparkle(x, y, s, col="#E0B04A"):
    return (f'<svg data-noqa style="position:absolute;left:{x - s / 2}px;top:{y - s / 2}px;width:{s}px;height:{s}px" viewBox="-1 -1 2 2">'
            f'<path d="M0,-1 C0.09,-0.09 0.09,-0.09 1,0 C0.09,0.09 0.09,0.09 0,1 C-0.09,0.09 -0.09,0.09 -1,0 C-0.09,-0.09 -0.09,-0.09 0,-1Z" fill="{col}"/></svg>')


BASE = """.slide{width:1080px;height:1350px;position:relative;overflow:hidden}
.chip{position:absolute;left:84px;bottom:80px;display:flex;align-items:center;gap:12px;padding:8px 22px 8px 10px;border-radius:999px;font:700 27px Inter}
.chip img{width:46px;height:46px;border-radius:50%;background:#fff;padding:2px}"""


def chip(brand, m, bg, ink):
    return f'<div class="chip" style="background:{bg};color:{ink}"><img src="{mark(m)}">{brand}</div>'


# ------------------------------------------------------------------ glove "Put a finger down"
def glove_tile(bg, head, accent, sub_col, glove_uri, line, brand, m, chipbg, chipink, spark="#E0B04A", font="Playfair", w=980):
    return (f'<style>{BASE}.h{{position:absolute;left:70px;right:70px;top:110px;text-align:center;font-family:{font};font-weight:600;font-size:158px;'
            f'line-height:.93;letter-spacing:-.03em;color:{head}}} .h i{{font-family:Instrument;font-weight:400;color:{accent}}}'
            f'.s{{position:absolute;left:96px;right:96px;top:430px;text-align:center;font:700 60px/1.12 Inter;color:{sub_col};letter-spacing:-.015em;text-wrap:balance}}'
            f'.g{{position:absolute;left:{540 - w * 0.5}px;top:500px;width:{w}px;filter:drop-shadow(0 30px 34px rgba(0,0,0,.22)) drop-shadow(0 6px 8px rgba(0,0,0,.12))}}</style>'
            f'<div class="slide" style="background:{bg}"><img class="g" data-noqa src="{glove_uri}">'
            f'<div class="h">Put a finger<br>down <i>if…</i></div><div class="s">…{line}</div>'
            f'{sparkle(110, 140, 80, spark)}{sparkle(975, 420, 54, spark)}{sparkle(130, 470, 40, spark)}{chip(brand, m, chipbg, chipink)}</div>')


# ------------------------------------------------------------------ one big word over a real photo
def word_tile(photo, word, kicker, sub, brand, m, wordcol="#fff", kickcol="#FFE27E", font="Instrument", size=330, bright=.74, label=None):
    lab = (f'<div style="position:absolute;left:84px;top:96px;padding:10px 22px;border-radius:999px;background:{kickcol};font:800 24px Inter;'
           f'letter-spacing:.16em;color:#141414">{label}</div>') if label else ""
    return (f'<style>{BASE}.bg{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;filter:brightness({bright})}}'
            f'.k{{position:absolute;left:0;right:0;top:390px;text-align:center;font:800 32px/1 Inter;letter-spacing:.22em;color:{kickcol};text-shadow:0 2px 14px rgba(0,0,0,.5)}}'
            f'.w{{position:absolute;left:0;right:0;top:450px;text-align:center;font-family:{font};font-size:{size}px;line-height:.9;color:{wordcol};'
            f'letter-spacing:-.035em;filter:drop-shadow(0 10px 40px rgba(0,0,0,.45))}}'
            f'.s{{position:absolute;left:0;right:0;top:830px;text-align:center;font:600 46px/1.2 Inter;color:#fff;text-shadow:0 2px 16px rgba(0,0,0,.6)}}</style>'
            f'<div class="slide"><img class="bg" src="{photo}">{lab}<div class="k">{kicker}</div><div class="w">{word}</div><div class="s">{sub}</div>'
            f'{chip(brand, m, "rgba(255,255,255,.92)", "#141414")}</div>')


# ------------------------------------------------------------------ editorial Ep / series with a B/W people photo
def photo_editorial(bg, ink, accent, label, title, photo, brand, m, size=124, photo_h=500, top_photo=True, number=None, chipbg="#fff", chipink="#141414", note=None):
    num = (f'<div style="position:absolute;right:84px;top:{photo_h + 20}px;font-family:Fraunces;font-weight:300;font-size:120px;line-height:.8;color:{accent}">{number}</div>'
           if number else "")
    ph = f'<div data-noqa style="position:absolute;left:0;right:0;{"top:0" if top_photo else "bottom:0"};height:{photo_h}px;overflow:hidden"><img src="{photo}" style="width:100%;height:100%;object-fit:cover"></div>'
    ty = photo_h + 60 if top_photo else 210
    lab_top = photo_h + 10 if top_photo else 96
    nt = f'<div style="position:absolute;left:84px;top:{ty + 470}px;font-family:CaveatBrush;font-size:64px;color:{accent};transform:rotate(-3deg)">{note}</div>' if note else ""
    return (f'<style>{BASE}.t{{position:absolute;left:84px;right:84px;top:{ty}px;font-family:Fraunces;font-variation-settings:"opsz" 144;font-weight:450;font-size:{size}px;'
            f'line-height:.98;letter-spacing:-.03em;color:{ink}}} .t i{{font-family:Instrument;font-weight:400;color:{accent}}}'
            f'.l{{position:absolute;left:84px;top:{lab_top}px;font-family:Caveat;font-weight:700;font-size:62px;color:{accent};line-height:1;'
            f'{"background:" + bg + ";padding:6px 18px 10px;border-radius:14px" if top_photo else ""}}}</style>'
            f'<div class="slide" style="background:{bg}">{ph}<div class="l">{label}</div><div class="t">{title}</div>{num}{nt}'
            f'{"" if top_photo else ""}{chip(brand, m, chipbg, chipink) if not (not top_photo) else ""}</div>')


# ------------------------------------------------------------------ big hook + small supporting visual
def hook_tile(bg, ink, hook, below, brand, m, chipbg, chipink, size=150, font="'Inter Display'", weight=800, top=120, hl=None, lh=.95):
    return (f'<style>{BASE}.h{{position:absolute;left:80px;right:80px;top:{top}px;font-family:{font};font-weight:{weight};font-size:{size}px;line-height:{lh};'
            f'letter-spacing:-.04em;color:{ink}}} .h b{{background:{hl or "transparent"};padding:0 .12em;border-radius:.12em;-webkit-box-decoration-break:clone}}</style>'
            f'<div class="slide" style="background:{bg}"><div class="h">{hook}</div>{below}{chip(brand, m, chipbg, chipink)}</div>')


def follow_lines():
    rows = [("25", "#2B3FE0"), ("35", "#FF6A3D"), ("45", "#0E1440")]
    svg = ['<svg data-noqa style="position:absolute;left:0;top:640px" width="1080" height="520" viewBox="0 0 1080 520">']
    for i, (_, c) in enumerate(rows):
        y0 = 70 + i * 160; y1 = [380, 70, 230][i]
        svg.append(f'<path d="M210,{y0} C520,{y0} 560,{y1} 1080,{y1}" fill="none" stroke="{c}" stroke-width="22" stroke-linecap="round"/>')
    svg.append("</svg>")
    chips = "".join(f'<div style="position:absolute;left:84px;top:{640 + 70 + i * 160 - 56}px;width:112px;height:112px;border-radius:50%;background:{c};'
                    f'color:#fff;font:800 50px/112px Inter;text-align:center;box-shadow:0 8px 16px rgba(0,0,0,.15)">{a}</div>' for i, (a, c) in enumerate(rows))
    return "".join(svg) + chips


def rosettes(cols):
    out = []
    for i, (c, t) in enumerate(cols):
        x = 100 + i * 300
        out.append(f'<div style="position:absolute;left:{x}px;top:680px;width:280px;text-align:center">'
                   f'<svg width="230" height="290" viewBox="0 0 230 290"><path d="M70,160 L40,285 L95,250 L115,290 L130,170 Z M160,160 L190,285 L135,250 L115,290 L100,170 Z" fill="{c}" opacity=".8"/>'
                   f'<circle cx="115" cy="115" r="105" fill="{c}"/><circle cx="115" cy="115" r="78" fill="#FFF8E4"/><circle cx="115" cy="115" r="60" fill="{c}" opacity=".35"/>'
                   f'<text x="115" y="136" text-anchor="middle" font-family="Lora" font-size="62" font-weight="700" fill="#2C2A3A">★</text></svg>'
                   f'<div style="font:700 40px/1.15 Inter;color:#2C2A3A;margin-top:10px">{t}</div></div>')
    return "".join(out)


def hand_list(items, col, ink, top=640, size=70):
    return "".join(f'<div style="position:absolute;left:96px;top:{top + i * 112}px;font-family:Caveat;font-weight:700;font-size:{size}px;color:{ink}">'
                   f'<span style="color:{col}">✓ </span>{t}</div>' for i, t in enumerate(items))


def paw_svg(x, y, s, pad="#FF9F7A", fur="#FFD3AE"):
    return (f'<svg data-noqa style="position:absolute;left:{x}px;top:{y}px" width="{s}" height="{s}" viewBox="0 0 200 200">'
            f'<ellipse cx="100" cy="125" rx="78" ry="66" fill="{fur}"/><ellipse cx="100" cy="135" rx="42" ry="34" fill="{pad}"/>'
            + "".join(f'<ellipse cx="{cx}" cy="{cy}" rx="20" ry="24" fill="{pad}"/>' for cx, cy in ((48, 72), (80, 52), (120, 52), (152, 72)))
            + '<path d="M40,170 q60,30 120,0" stroke="#E8A07E" stroke-width="5" fill="none" opacity=".5"/></svg>')


def bubble(txt, who, top, bg, col, size=50, side=84):
    pos = f"right:{side}px" if who == "me" else f"left:{side}px"
    rad = "border-bottom-right-radius:14px" if who == "me" else "border-bottom-left-radius:14px"
    return (f'<div style="position:absolute;{pos};top:{top}px;max-width:780px;padding:30px 40px;border-radius:44px;{rad};background:{bg};color:{col};'
            f'font:700 {size}px/1.2 Inter;box-shadow:0 14px 30px rgba(20,20,60,.22)">{txt}</div>')


SHERBET_BG = ("<div data-noqa style='position:absolute;inset:0;background:"
              "radial-gradient(50% 40% at 0% 100%,#FFC9D6 0,transparent 70%),radial-gradient(45% 35% at 100% 95%,#FFD3AE 0,transparent 70%),"
              "radial-gradient(40% 30% at 95% 5%,#FFE27E 0,transparent 70%),#FFF4E0'></div>"
              "<div data-noqa style='position:absolute;inset:0;opacity:.35;mix-blend-mode:multiply;"
              "background-image:radial-gradient(rgba(120,70,40,.16) 1px,transparent 1.3px);background-size:6px 6px'></div>")

FFm, LFm, LHm, HBm = "fullyfunded.png", "littlefold.png", "lockedhour.png", "hourback.png"

T = {}
# =============================== FULLY FUNDED (Cobalt)
T["ff-glove"] = glove_tile("#2B3FE0", "#FFFFFF", "#FFB08F", "#FFFFFF", tint_glove(3, "#FF6A3D", "ff-glove3"),
                           "a subscription you forgot about renewed this year.", "Fully Funded", FFm, "#FFFFFF", "#2B3FE0", spark="#FFB08F")
T["ff-rich"] = photo_editorial("#F5F7FF", "#0E1440", "#FF6A3D", "Rich Habits, Decoded",
                               "Rich families <i>automate</i> first.", bw(A / "g-couple.png", "ff-couple"), "Fully Funded", FFm,
                               size=136, photo_h=520, number="No.1", chipbg="#2B3FE0", chipink="#fff")
T["ff-start"] = word_tile((A / "g-clouds.png").as_uri(), "Start.", "INVESTING FOR YOUR KID?", "Time does the heavy lifting.", "Fully Funded", FFm,
                          kickcol="#FFE7D6", size=360, bright=.8)
T["ff-line"] = hook_tile("#F5F7FF", "#0E1440", "Pick your<br><b>age.</b>", follow_lines() +
                         '<div style="position:absolute;right:84px;top:520px;font-family:CaveatBrush;font-size:56px;color:#FF6A3D;transform:rotate(-3deg)">follow your colour →</div>',
                         "Fully Funded", FFm, "#2B3FE0", "#fff", size=190, hl="#FFB08F")
T["ff-ep"] = photo_editorial("#16206B", "#F5F7FF", "#FFB08F", "Ep.01", "Franklin’s <i>200-year</i> gift.", bw(A / "g-family.png", "ff-family"),
                             "Fully Funded", FFm, size=150, photo_h=520, chipbg="#fff", chipink="#16206B")
T["ff-list"] = hook_tile("#FF6A3D", "#FFFFFF", "Payday,<br>in 3 steps.", hand_list(["Save first", "Bills next", "Enjoy the rest"], "#0E1440", "#FFFFFF", top=600, size=96),
                         "Fully Funded", FFm, "#fff", "#FF6A3D", size=170)
T["ff-template"] = hook_tile("#2B3FE0", "#FFFFFF", "Freedom<br>number:<br><b>spend × 25.</b>",
                             '<div style="position:absolute;left:84px;top:860px;font:600 46px/1.3 Inter;color:#D3D9FF;width:800px">A rule of thumb for how much you’d need invested to stop working.</div>',
                             "Fully Funded", FFm, "#fff", "#2B3FE0", size=170, hl="#FF6A3D")
T["ff-reframe"] = BM.reframe("#2B3FE0", "#E8ECFF", "#0E1440", "#FF6A3D", FFm, "Fully Funded", "I can’t afford to save.", "I’ll start with 10.", "money reframes")

# =============================== LITTLEFOLD (warm Sherbet)
LFB = GT.V("#FFF4E0", "#2C2A3A", ("#FFC9D6", "#D9497A"), ("#FFE27E", "#2C2A3A"), "#E8743B", "#FFD6E3", "#2C2A3A")
lfc = GT.LF("for new parents", ["The", ("first", 1), ("week", 1), "home,", "made", ("easier.", 2)], save="save for the 3 am feeds",
            obj="ht-shoe.png", obj_w=420, obj_x=620, obj_y=900, rot=9)
T["lf-b"] = GT.cover(lfc, LFB, extra=SHERBET_BG.replace("position:absolute;inset:0", "position:absolute;inset:0;z-index:-1"))
T["lf-wins"] = ("<style>" + BASE + "</style><div class='slide'>" + SHERBET_BG +
                "<div style='position:absolute;left:84px;top:96px;padding:10px 24px;border-radius:999px;background:#FF8A70;color:#fff;font:800 26px Inter;letter-spacing:.14em'>SMALL WINS · No.3</div>"
                "<div style='position:absolute;left:80px;right:80px;top:200px;font-family:Lora;font-weight:600;font-size:150px;line-height:.95;letter-spacing:-.03em;color:#2C2A3A'>"
                "You drank <i style=\"color:#D9497A\">warm</i> tea today.</div>"
                + paw_svg(140, 760, 330) + paw_svg(560, 820, 300, pad="#FFB3C4", fur="#FFE2EA") +
                "<div style='position:absolute;right:96px;top:1150px;font-family:CaveatBrush;font-size:62px;color:#E8743B;transform:rotate(-3deg)'>it counts ♡</div>"
                + chip("Littlefold", LFm, "#fff", "#2C2A3A") + "</div>")
T["lf-count"] = ("<style>" + BASE + "</style><div class='slide'>" + SHERBET_BG +
                 "<div style='position:absolute;left:70px;right:70px;top:120px;text-align:center;font-family:Lora;font-weight:600;font-size:150px;line-height:.95;letter-spacing:-.03em;color:#2C2A3A'>"
                 "Put a finger<br>down <i style=\"color:#D9497A\">if…</i></div>"
                 "<div style='position:absolute;left:100px;right:100px;top:450px;text-align:center;font:700 60px/1.15 Inter;color:#2C2A3A'>…you’ve googled a baby noise at 3 am.</div>"
                 "<div data-noqa style='position:absolute;left:0;right:0;top:640px;text-align:center;font-family:Lora;font-weight:700;font-size:520px;line-height:1;color:#FF8A70'>4</div>"
                 + sparkle(220, 760, 70, "#FFB347") + sparkle(860, 880, 50, "#D9497A") + chip("Littlefold", LFm, "#fff", "#2C2A3A") + "</div>")
T["lf-ep"] = photo_editorial("#FFF4E0", "#2C2A3A", "#D9497A", "Ep.01", "Notes for the <i>first week</i> home.", bw(A / "g-father.png", "lf-father"),
                             "Littlefold", LFm, size=132, photo_h=540, chipbg="#FFD6E3", chipink="#2C2A3A")
T["lf-breathe"] = word_tile((A / "g-wheat.png").as_uri(), "<i>Breathe.</i>", "FOR THE LONG DAYS", "You’re allowed to go slow.", "Littlefold", LFm,
                            kickcol="#FFD6E3", wordcol="#FFF4E0", size=340, bright=.82)
T["lf-awards"] = hook_tile("#FFF4E0", "#2C2A3A", "You earned<br><i style='color:#D9497A'>every one.</i>",
                           SHERBET_BG.replace("position:absolute;inset:0", "position:absolute;inset:0;z-index:-1") +
                           rosettes([("#FF8A70", "Ate something warm"), ("#FFB347", "Said yes to help"), ("#F28AA8", "Laughed at 3 am")]),
                           "Littlefold", LFm, "#fff", "#2C2A3A", size=150, font="Lora", weight=600)
T["lf-list"] = hook_tile("#FFC9D6", "#2C2A3A", "Tonight,<br>just this.", hand_list(["One warm meal", "Water by the bed", "Lights low by 9"], "#D9497A", "#2C2A3A", top=620, size=92),
                         "Littlefold", LFm, "#fff", "#2C2A3A", size=170, font="Lora", weight=600)
T["lf-meme"] = BM.meme("#FFE27E", "#2C2A3A", "#D9497A", LFm, "Littlefold", "“I’ll sleep when the baby sleeps.”", "🫠", "the baby, at 3:07 am: no.").replace(
    "font-size:76px;line-height:1.1", "font-size:112px;line-height:1.02").replace("font-size:80px;line-height:1.05", "font-size:92px;line-height:1.05").replace("top:520px", "top:620px").replace("top:950px", "top:1010px")

# =============================== LOCKED HOUR (Zine: butter, pink, yellow, black ink)
T["lh-word"] = word_tile((A / "g-street.png").as_uri(), "Begin.", "", "Not ready. Just begin.", "Locked Hour", LHm, wordcol="#FFD43B",
                         kickcol="#FF5CA8", font="'Inter Display';font-weight:900", size=320, label="ONE WORD · No.1")
T["lh-glove"] = glove_tile("#FFE27A", "#141414", "#E8336F", "#141414", tint_glove(2, "#FF5CA8", "lh-glove2"),
                           "you’ve opened the same app 3 times in a minute.", "Locked Hour", LHm, "#141414", "#FFE27A", spark="#FF5CA8",
                           font="'Inter Display';font-weight:800")
T["lh-focus"] = word_tile((A / "g-forest.png").as_uri(), "Focus.", "THE NEXT 60 MINUTES", "Phone in another room.", "Locked Hour", LHm,
                          wordcol="#FFFFFF", kickcol="#FFD43B", size=330, bright=.78)
T["lh-pano"] = hook_tile("#FFF4E0", "#141414", "The first<br><b>10 minutes</b><br>are the hardest.",
                         '<svg data-noqa style="position:absolute;left:0;top:860px" width="1080" height="240"><path d="M0,140 C200,40 380,220 560,120 S900,40 1080,120" '
                         'fill="none" stroke="#141414" stroke-width="30" stroke-linecap="round"/><path d="M0,140 C200,40 380,220 560,120 S900,40 1080,120" fill="none" '
                         'stroke="#FFD43B" stroke-width="16" stroke-linecap="round"/><circle cx="300" cy="140" r="26" fill="#FF5CA8" stroke="#141414" stroke-width="6"/>'
                         '<circle cx="760" cy="80" r="26" fill="#FF5CA8" stroke="#141414" stroke-width="6"/></svg>', "Locked Hour", LHm, "#141414", "#FFE27A", size=140, hl="#FF5CA8")
T["lh-ep"] = photo_editorial("#FFE27A", "#141414", "#E8336F", "Ep.01 · reframes", "Not motivation.<br><i>A start time.</i>", bw(A / "g-family.png", "lh-family", crop=(300, 0, 2000, 1728)),
                             "Locked Hour", LHm, size=136, photo_h=520, chipbg="#141414", chipink="#FFE27A")
T["lh-list"] = hook_tile("#FF5CA8", "#141414", "Before you<br>lock in:", hand_list(["Phone away", "One task", "Timer: 60"], "#FFFFFF", "#141414", top=620, size=96),
                         "Locked Hour", LHm, "#141414", "#FFE27A", size=170)
T["lh-meme"] = BM.meme("#FFF4E0", "#141414", "#E8336F", LHm, "Locked Hour", "4 minutes into my focus hour:", "📱👀", "“just checking the time”").replace(
    "font-size:76px;line-height:1.1", "font-size:120px;line-height:1").replace("font-size:80px;line-height:1.05", "font-size:92px;line-height:1.05").replace("top:520px", "top:600px").replace("top:950px", "top:1000px")
T["lh-b"] = GT.cover(*BM.LOOKB["lh-b"])

# =============================== HOURBACK (indigo + yellow)
T["hb-potw"] = ("<style>" + BASE + "</style><div class='slide' style='background:#5E54C9'>"
                "<div style='position:absolute;left:84px;top:96px;padding:10px 24px;border-radius:999px;background:#FFC94D;color:#2A2238;font:800 26px Inter;letter-spacing:.14em'>PROMPT OF THE WEEK</div>"
                + bubble("Plan dinners.", "me", 210, "#FFC94D", "#2A2238", 64)
                + bubble("5 dinners, 30 min each, one shopping list.", "ai", 420, "#FFFFFF", "#2A2238", 86)
                + "<div style='position:absolute;right:96px;top:1040px;font-family:CaveatBrush;font-size:66px;color:#FFC94D;transform:rotate(-3deg)'>copy it →</div>"
                + chip("Hourback", HBm, "#fff", "#5E54C9") + "</div>")
T["hb-glove"] = glove_tile("#5E54C9", "#FFFFFF", "#FFC94D", "#FFF8EF", tint_glove(1, "#FFC94D", "hb-glove1"),
                           "you’ve decided dinner at 6:55 pm. Again.", "Hourback", HBm, "#FFC94D", "#2A2238", spark="#FFC94D", font="Poppins;font-weight:700", w=900)
T["hb-offline"] = word_tile((A / "g-clouds.png").as_uri(), "<i>Offline.</i>", "AFTER 7 PM", "Let the prompts do the rest.", "Hourback", HBm,
                            wordcol="#FFFFFF", kickcol="#FFC94D", size=320, bright=.7)
T["hb-swipe"] = hook_tile("#FFF8EF", "#2A2238", "Keep<br>swiping to<br><b>reveal.</b>",
                          f'<div data-noqa style="position:absolute;left:84px;right:84px;top:780px;height:300px;border-radius:36px;overflow:hidden;box-shadow:0 16px 32px rgba(40,30,90,.2)">'
                          f'<img src="{(D / "samples-v5/grid-tiles/_swipe-pix.png").as_uri()}" style="width:100%;image-rendering:pixelated"></div>',
                          "Hourback", HBm, "#5E54C9", "#fff", size=150, font="Poppins", weight=700, hl="#FFC94D", lh=1.1)
T["hb-ep"] = photo_editorial("#2A2238", "#FFF8EF", "#FFC94D", "Ep.01", "How one <i>good prompt</i> is built.", bw(A / "g-shoulders.png", "hb-shoulders", crop=(0, 700, 1440, 1900)),
                             "Hourback", HBm, size=136, photo_h=520, chipbg="#FFC94D", chipink="#2A2238")
T["hb-list"] = hook_tile("#FFC94D", "#2A2238", "Hand these<br>to AI:", hand_list(["Meal plan", "Gift ideas", "That long email"], "#5E54C9", "#2A2238", top=620, size=96),
                         "Hourback", HBm, "#5E54C9", "#fff", size=170, font="Poppins", weight=700)
T["hb-reframe"] = BM.reframe("#FFF8EF", "#FFEEDC", "#2A2238", "#5E54C9", HBm, "Hourback", "Plan dinners.", "5 dinners, 30 min, one list.", "prompt reframes")
T["hb-b"] = GT.cover(*BM.LOOKB["hb-b"])
T["ff-b"] = GT.cover(*BM.LOOKB["ff-b"])

# sticky-note lists (approved look, Oct 15): taped, lined note card on the page colour. The plain handwritten
# hook_tile lists above are retired; these overrides keep the keys stable for grids_final.py.
for _k in ("ff-list", "lf-list", "lh-list", "hb-list"):
    T[_k] = BM.JOBS[_k]

if __name__ == "__main__":
    only = sys.argv[1:]
    render_many([(h, OUT / k) for k, h in T.items() if not only or k in only])
