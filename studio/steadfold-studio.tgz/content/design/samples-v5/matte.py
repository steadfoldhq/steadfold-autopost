#!/usr/bin/env python3
"""Clean glove mattes for the pink-glove photos (pink glove on near-identical pink backdrop).
1. rough mask = the colour/lightness difference mask from recolor.py (it over-fills the gaps between fingers),
2. markers: sure-glove = rough mask eroded hard; sure-backdrop = outside the dilated rough mask + backdrop-coloured
   pixels between the fingertips (in the hull, far from edges),
3. watershed on the photo's own gradient, so the cut follows the real finger outlines and the gaps flood as backdrop,
4. guided-filter alpha (cv2.ximgproc) for a soft natural edge, then despill (edge pixels re-coloured from the glove
   interior, not from the backdrop).
Output: /home/claude/content/design/assets/cutouts/<name>.png  (RGBA, original pink glove, full resolution)."""
import sys
from pathlib import Path
import cv2
import numpy as np

OUTD = Path("/home/claude/content/design/assets/cutouts")
OUTD.mkdir(parents=True, exist_ok=True)
RESTORE = False
# hand-traced backdrop wedges between fingers (source px), checked at 100%
GAPS = {"hand3.png": [[(684, 690), (721, 690), (730, 840), (731, 900), (741, 992), (730, 960), (718, 900), (710, 840), (688, 760)], [(876, 905), (893, 905), (885, 998), (879, 998)]]}


def guided(I, p, r, eps):
    """He et al. guided filter, grey guide. I, p float32 0..1."""
    bx = lambda x: cv2.boxFilter(x, -1, (2 * r + 1, 2 * r + 1))
    mI, mp = bx(I), bx(p)
    a = (bx(I * p) - mI * mp) / (bx(I * I) - mI * mI + eps)
    b = mp - a * mI
    return bx(a) * I + bx(b)


def rough(im):
    lab = cv2.cvtColor(im, cv2.COLOR_BGR2LAB).astype(np.float32)
    labf = cv2.bilateralFilter(lab, 9, 8, 9)
    bgl = np.median(lab[:200].reshape(-1, 3), 0)
    d = cv2.GaussianBlur(np.abs(labf - bgl).sum(2), (0, 0), 5)
    m = cv2.morphologyEx((d > 4.0).astype(np.uint8), cv2.MORPH_OPEN, np.ones((11, 11), np.uint8))
    k, cc, st, _ = cv2.connectedComponentsWithStats(m)
    m = (cc == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    ff = m * 255; mk = np.zeros((m.shape[0] + 2, m.shape[1] + 2), np.uint8)
    cv2.floodFill(ff, mk, (0, 0), 128)
    return (ff != 128).astype(np.uint8), lab, bgl


def matte(src, bottom_keep=True):
    im = cv2.imread(str(src))
    H, W = im.shape[:2]
    m, lab, bgl = rough(im)
    # gradient of the photo (lightness + a little chroma)
    L = cv2.GaussianBlur(lab[..., 0], (0, 0), 1.5); a = cv2.GaussianBlur(lab[..., 1], (0, 0), 1.5)
    gx = cv2.Sobel(L, cv2.CV_32F, 1, 0) ** 2 + cv2.Sobel(L, cv2.CV_32F, 0, 1) ** 2
    gx += 4 * (cv2.Sobel(a, cv2.CV_32F, 1, 0) ** 2 + cv2.Sobel(a, cv2.CV_32F, 0, 1) ** 2)
    grad = np.sqrt(gx)
    markers = np.zeros((H, W), np.int32)
    core = cv2.erode(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (71, 71)))
    markers[cv2.dilate(m, np.ones((31, 31), np.uint8)) == 0] = 1          # backdrop
    # backdrop seeds between the fingers: backdrop-coloured, smooth, inside the hull, not in the core
    hull = np.zeros_like(m); cv2.fillConvexPoly(hull, cv2.convexHull(cv2.findNonZero(m)), 1)
    near = np.abs(cv2.bilateralFilter(lab, 9, 8, 9) - bgl).sum(2) < 2.2
    smooth = cv2.GaussianBlur(grad, (0, 0), 6) < np.percentile(grad, 55)
    seeds = (hull > 0) & near & smooth & (core == 0)
    seeds = cv2.erode(seeds.astype(np.uint8), np.ones((15, 15), np.uint8)) > 0
    markers[seeds & (cv2.dilate(core, np.ones((61, 61), np.uint8)) == 0)] = 1
    markers[core > 0] = 2
    g8 = np.clip(grad / np.percentile(grad, 99.5) * 255, 0, 255).astype(np.uint8)
    ws = cv2.watershed(cv2.cvtColor(g8, cv2.COLOR_GRAY2BGR), markers.copy())
    hard = (ws == 2).astype(np.uint8)
    # second pass: re-seed backdrop from slivers the first pass left (backdrop-coloured or shadowed, away from the core)
    dist = cv2.distanceTransform(hard, cv2.DIST_L2, 5)
    dcol = np.abs(cv2.bilateralFilter(lab, 9, 8, 9) - bgl)
    shadow = (dcol[..., 0] > 2) & (lab[..., 0] < bgl[0]) & (dcol[..., 1] < 3.5) & (dcol[..., 2] < 3.5)
    sliver = (hard > 0) & shadow & (dist < 30) & (core == 0)
    sliver = cv2.morphologyEx(sliver.astype(np.uint8), cv2.MORPH_OPEN, np.ones((9, 9), np.uint8)) > 0
    m2 = markers.copy(); m2[sliver] = 1
    ws = cv2.watershed(cv2.cvtColor(g8, cv2.COLOR_GRAY2BGR), m2)
    hard = (ws == 2).astype(np.uint8)
    hard = cv2.morphologyEx(hard, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    # restore "bites": rough-mask pixels the watershed dropped that are NOT between two fingers on the same row
    drop = (m > 0) & (hard == 0)
    R = 140
    idx = np.arange(W)[None, :].repeat(H, 0)
    fgpos = np.where(hard > 0, idx, -10**6)
    lastL = np.maximum.accumulate(fgpos, axis=1)                       # nearest fg at or left of x
    fgpos2 = np.where(hard > 0, idx, 10**6)
    nextR = np.minimum.accumulate(fgpos2[:, ::-1], axis=1)[:, ::-1]    # nearest fg at or right of x
    between = (idx - lastL < R) & (nextR - idx < R)
    restore = drop & ~between
    restore = cv2.morphologyEx(restore.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) > 0
    # bright, less-saturated wedges at the bottom of narrow gaps = backdrop
    dist2 = cv2.distanceTransform(hard, cv2.DIST_L2, 5)
    labs = cv2.GaussianBlur(lab, (0, 0), 1.2)
    wedge = (hard > 0) & (labs[..., 1] < bgl[1] + 11) & (labs[..., 0] > bgl[0] - 12) & (dist2 < 30) & (core == 0)
    colhas = hard.any(0)
    top = np.where(colhas, hard.argmax(0), H)
    yy = np.arange(H)[:, None]
    wedge &= (yy - top[None, :]) > 170                                  # never near a fingertip
    wedge = cv2.morphologyEx(wedge.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)) > 0
    nW, ccW, stW, _ = cv2.connectedComponentsWithStats(wedge.astype(np.uint8))
    keep = [i for i in range(1, nW) if stW[i, cv2.CC_STAT_WIDTH] < 50 and stW[i, cv2.CC_STAT_HEIGHT] > 2 * stW[i, cv2.CC_STAT_WIDTH]]
    wedge = np.isin(ccW, keep)
    hard[wedge] = 0
    for poly in GAPS.get(Path(src).name, []):
        cv2.fillPoly(hard, [np.array(poly, np.int32)], 0)
    ffh = hard.copy() * 255; mkh = np.zeros((H + 2, W + 2), np.uint8)
    cv2.floodFill(ffh, mkh, (0, 0), 128); hard = (ffh != 128).astype(np.uint8)   # fill enclosed holes
    if RESTORE:
        hard = (hard | restore).astype(np.uint8)
    hard = cv2.morphologyEx(hard, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    hard = (cv2.GaussianBlur(hard.astype(np.float32), (0, 0), 3.5) > 0.5).astype(np.uint8)
    # wrist rows: keep only the cuff's own column span (drops backdrop patches beside the wrist)
    y0 = int(H * 0.72)
    spans = [np.where(hard[y] > 0)[0] for y in range(int(H * 0.58), int(H * 0.68), 10)]
    spans = [s_ for s_ in spans if len(s_)]
    if spans:
        lo = min(s_.min() for s_ in spans) - 60; hi = max(s_.max() for s_ in spans) + 60
        hard[y0:, :max(lo, 0)] = 0; hard[y0:, hi:] = 0
    k, cc, st, _ = cv2.connectedComponentsWithStats(hard)
    hard = (cc == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    k, cc, st, _ = cv2.connectedComponentsWithStats(hard)
    hard = (cc == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    # soft alpha: guided filter on the hard mask, guided by the photo
    alpha = guided(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255, hard.astype(np.float32), 4, 1e-3)
    alpha = np.clip((alpha - 0.5) * 1.6 + 0.5, 0, 1)
    alpha[hard == 0] = np.minimum(alpha[hard == 0], cv2.dilate(hard, np.ones((5, 5), np.uint8))[hard == 0].astype(np.float32))
    # despill: colour of edge pixels from the nearest interior glove pixels
    inner = cv2.erode(hard, np.ones((9, 9), np.uint8))
    fill = cv2.inpaint(im, ((inner == 0) * 255).astype(np.uint8), 7, cv2.INPAINT_TELEA)
    w = np.clip(1 - alpha * 1.0, 0, 1)[..., None] * (cv2.dilate(hard, np.ones((3, 3))) > 0)[..., None]
    rgb = im.astype(np.float32) * (1 - w) + fill.astype(np.float32) * w
    return np.dstack([np.clip(rgb, 0, 255), alpha * 255]).astype(np.uint8), hard


if __name__ == "__main__":
    srcs = {f"glove-pink-{n}": f"/home/claude/content/design/samples-v3/prep/hand{n}.png" for n in (3, 2, 1)}
    only = sys.argv[1:]
    for name, s in srcs.items():
        if only and name not in only:
            continue
        rgba, _ = matte(s)
        cv2.imwrite(str(OUTD / f"{name}.png"), rgba)
        print("ok", name)
