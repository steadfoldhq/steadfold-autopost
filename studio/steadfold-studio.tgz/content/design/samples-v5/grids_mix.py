#!/usr/bin/env python3
"""grids-MIX.png: 4 phone grids, each page in its ORIGINAL palette, every reference style mixed in; legend under each."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import grids as G

D = Path("/home/claude/content/design"); M = D / "samples-v5" / "mix"; DE = D / "demos-episode"; DI = D / "demos-interactive"
VO = Path("/home/claude/content/video/out"); MED = Path("/home/claude/steadfold-autopost/media")
T = {
 "fullyfunded": [(M / "ff-b.png", "Look B cover"), (DE / "ff-ep01-franklin/slide-01.png", "Ep.01 editorial"), (M / "ff-glove.png", "Put a finger down"),
                 (VO / "samples-v3/fullyfunded-slowpan-01-cover.jpg", "Slow-pan still"), (DI / "follow-the-line/slide-02.png", "Follow the line"), (M / "ff-list.png", "Handwritten list"),
                 (M / "ff-reframe.png", "Instead of… Say…"), (MED / "ff-w03-1-freedom-number/01.jpg", "Original template"), (VO / "fullyfunded-reel-start-at-birth-cover-v3.jpg", "Reel cover")],
 "littlefold": [(M / "lf-b.png", "Look B cover"), (VO / "samples-v4/littlefold-silhouette-photo-cover.jpg", "Reel cover"), (M / "lf-countdown.png", "Soft countdown"),
                (M / "lf-list.png", "Handwritten list"), (DI / "awards/slide-02.png", "Awards"), (M / "lf-still.png", "Slow-pan still"),
                (DE / "lf-ep01-first-week-home/slide-01.png", "Ep.01 editorial"), (M / "lf-meme.png", "Emoji meme"), (MED / "lf-02-first-72-hours/01.jpg", "Original template")],
 "lockedhour": [(M / "lh-b.png", "Look B cover"), (D / "samples-v5/grid-tiles/lh-time.png", "Slow-pan still"), (M / "lh-glove.png", "Put a finger down"),
                (M / "lh-list.png", "Handwritten list"), (DI / "panorama/slide-02.png", "Panorama"), (DE / "lh-ep01-reframes/slide-02.png", "Ep.01 reframe"),
                (MED / "lh-w2-05-restart/01.jpg", "Original template"), (M / "lh-meme.png", "Emoji meme"), (VO / "lockedhour-reel-oct15-cover-v3.jpg", "Reel cover")],
 "hourback": [(M / "hb-b.png", "Look B cover"), (M / "hb-reframe.png", "Instead of… Say…"), (M / "hb-still.png", "Slow-pan still"),
              (M / "hb-list.png", "Handwritten list"), (DE / "hb-ep01-behind-the-prompt/slide-01.png", "Ep.01 editorial"), (DI / "swipe-to-reveal/slide-02.png", "Swipe to reveal"),
              (VO / "hourback-potluck-quiz-cover.png", "Reel cover"), (M / "hb-glove.png", "Put a finger down"), (MED / "hb-w02-6-parking-sign/01.jpg", "Original template")],
}
for k, v in T.items():
    assert len({str(p) for p, _ in v}) == 9 and all(p.exists() for p, _ in v), k

panels = [G.panel(k, n, h, b, [p for p, _ in T[k]], None) for k, n, h, b in G.PAGES]
ph = max(x.height for x in panels)
LEG = 150
W = 2 * G.PAD + 4 * G.PW + 3 * G.GAP
H = 310 + ph + 30 + LEG + G.PAD
B = Image.new("RGB", (W, H), "#F4EFE8"); d = ImageDraw.Draw(B)
d.text((G.PAD, 52), "Profile grids · mixed styles", font=G.SERIF(104), fill="#3A1D22")
d.text((G.PAD + 4, 170), "Each page keeps its own palette: Fully Funded Cobalt · Littlefold Sherbet · Locked Hour Zine · Hourback indigo + yellow. Every reference style appears in every grid.",
       font=G.F(24, "Medium"), fill="#6A5A5C")
for i, (pn, (k, n, h, b)) in enumerate(zip(panels, G.PAGES)):
    x = G.PAD + i * (G.PW + G.GAP)
    d.text((x + 4, 238), n, font=G.SERIF(58), fill="#3A1D22")
    sh = Image.new("RGBA", (G.PW + 40, pn.height + 40), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle((20, 26, G.PW + 20, pn.height + 20), 34, fill=(60, 40, 30, 70))
    sh = sh.filter(ImageFilter.GaussianBlur(12)); B.paste(sh, (x - 20, 290), sh)
    mk = Image.new("L", pn.size, 0); ImageDraw.Draw(mk).rounded_rectangle((0, 0, G.PW - 1, pn.height - 1), 34, fill=255)
    B.paste(pn, (x, 310), mk)
    y0 = 310 + ph + 30
    for j, (_, lab) in enumerate(T[k]):
        r, c = divmod(j, 3)
        d.text((x + 4 + c * 190, y0 + r * 40), f"{j + 1}. {lab}", font=G.F(19, "Medium"), fill="#4A3A3C")
B.save(D / "samples-v5" / "grids-MIX.png", optimize=True)
print(B.size)
