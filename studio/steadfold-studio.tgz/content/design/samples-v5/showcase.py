#!/usr/bin/env python3
"""SHOWCASE.png: every v3 set at phone size, labelled, on one board."""
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v5")
sys.path.insert(0, "/home/claude/content/video/src")
from lib import *  # noqa
from PIL import ImageDraw, ImageFont
import slowpan as SP

V = Path("/home/claude/content/video/out/samples-v4")
TW = 300                      # tile width (a feed post on a phone is ~390 pt wide; this board is a 3x-ish overview)
GAP, PAD = 22, 70
BG = "#F6F1EA"
f_h = ImageFont.truetype(str(FONTS / "InstrumentSerif-Regular.ttf"), 64)
f_hi = ImageFont.truetype(str(FONTS / "InstrumentSerif-Italic.ttf"), 64)
f_s = ImageFont.truetype(str(FONTS / "Inter-Medium.ttf"), 22)
f_t = ImageFont.truetype(str(FONTS / "InstrumentSerif-Regular.ttf"), 120)
f_l = ImageFont.truetype(str(FONTS / "Inter-SemiBold.ttf"), 18)


def tile(im, w=TW):
    im = im.convert("RGB")
    h = round(w * im.height / im.width)
    t = im.resize((w, h), Image.LANCZOS)
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), radius=14, fill=255)
    return t, m


S4 = D / "samples-v4"
SECTIONS = [
    ("Look A", "Fully Funded · butter glove on royal green",
     [Image.open(S3 / "ff-green" / f"slide-{k:02d}.png") for k in range(1, 6)], None),
    ("Look A", "Fully Funded · green glove on butter (A/B of the same post)",
     [Image.open(S3 / "ff-butter" / f"slide-{k:02d}.png") for k in range(1, 6)], None),
    ("Look A", "Littlefold · blush + sage, its own photo, numeral countdown",
     [Image.open(S3 / "lf-blush" / f"slide-{k:02d}.png") for k in range(1, 6)], None),
    ("Original", "STEADFOLD ORIGINAL · the folded letter · Fully Funded ×3 + Locked Hour cover",
     [Image.open(S3 / "original" / f"{n}.png") for n in ("ff-original-01", "ff-original-02", "ff-original-03", "lh-original-cover")], None),
    ("Look B", "Kept from v4 · edge-to-edge covers, a = pastel + tomato, b = bold",
     [Image.open(S4 / "covers-b" / f"{p}-cover-{v}.png") for p in ("hb", "ff", "lf") for v in "ab"], None),
]

W = PAD * 2 + 6 * TW + 5 * GAP
blocks = []
for tag, desc, ims, tw in SECTIONS:
    tw = tw or TW
    tiles = [tile(im, tw) for im in ims]
    h = max(t.height for t, _ in tiles)
    blocks.append((tag, desc, tiles, h, tw))
grid = Image.open(S3 / "grid-mock.png").convert("RGB")
gw = 560
grid = grid.resize((gw, round(gw * grid.height / grid.width)), Image.LANCZOS)

H = 300 + sum(110 + h + 50 for *_, h, _ in blocks) + 140 + grid.height + PAD
board = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(board)
d.text((PAD, 70), "Samples v5", font=f_t, fill="#4A1D24")
d.text((PAD + 560, 132), "colour gloves · our own folded-letter look · no reused photos", font=f_s, fill="#7A5A5E")
y = 260
for tag, desc, tiles, h, tw in blocks:
    d.text((PAD, y), tag, font=f_hi, fill="#A8606E")
    d.text((PAD + 250, y + 30), desc, font=f_s, fill="#3A2A2C")
    y += 100
    x = PAD
    for t, m in tiles:
        sh = Image.new("L", t.size, 0); ImageDraw.Draw(sh).rounded_rectangle((0, 0, t.width - 1, t.height - 1), 14, fill=70)
        board.paste((222, 210, 200), (x + 4, y + 8), sh)
        board.paste(t, (x, y), m)
        x += tw + GAP
    y += h + 60
d.text((PAD, y), "Grid", font=f_hi, fill="#A8606E")
d.text((PAD + 250, y + 30), "3×3 profile mock (centre 3:4 crop as the app shows it): planned, colourful, no look-alike neighbours",
       font=f_s, fill="#3A2A2C")
y += 100
board.paste(grid, (PAD, y))
notes = ["One photo = one post (IMAGE-USE.md).",
         "Gloves: Canva AI photos recoloured in code.",
         "",
         "Every slide: rendered 2160×2700, Lanczos to 1080×1350.",
         "Text ≥ 70 px from every edge (QA-checked).",
         "Video: H.264 CRF 17–18, text layer pixel-still,",
         "warm grade + fine grain, music −14 LUFS (Reel)."]
for k, s in enumerate(notes):
    d.text((PAD + gw + 60, y + 40 + k * 36), s, font=f_s, fill="#3A2A2C")
board.save(S3 / "SHOWCASE-v5.png", optimize=True)
print(board.size)
