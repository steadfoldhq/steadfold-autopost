#!/usr/bin/env python3
"""Recolour the pink-glove photos (v3 prep/handN.png, flat-fielded) into new glove/background colourways.
Glove: keep the photo's own shading (LAB lightness relative to the glove median) and highlights, re-tinted to the
target colour. Background: solid target colour with the photo's own soft contact shadow kept as a multiply.
usage: python3 recolor.py NAME GLOVE_HEX BG_HEX [--mirror]"""
import sys
import cv2
import numpy as np

SRC = "/home/claude/content/design/samples-v3/prep/hand{}.png"


def hex2lab(h):
    rgb = np.uint8([[[int(h[i:i + 2], 16) for i in (5, 3, 1)]]])        # BGR
    return cv2.cvtColor(rgb, cv2.COLOR_BGR2LAB).astype(np.float32)[0, 0]


def recolor(n, glove, bg, mirror=False):
    im = cv2.imread(SRC.format(n))
    if mirror:
        im = im[:, ::-1].copy()
    lab = cv2.cvtColor(im, cv2.COLOR_BGR2LAB).astype(np.float32)
    bgl = np.median(lab[:200].reshape(-1, 3), 0)
    labf = cv2.bilateralFilter(lab, 9, 8, 9)
    d = cv2.GaussianBlur(np.abs(labf - bgl).sum(2), (0, 0), 7)
    hard = cv2.morphologyEx((d > 4.2).astype(np.uint8), cv2.MORPH_OPEN, np.ones((15, 15), np.uint8))
    for _ in range(2):                         # local backdrop model: inpaint the hand out at low res, re-measure
        sm = 8
        ls = cv2.resize(labf, None, fx=1 / sm, fy=1 / sm, interpolation=cv2.INTER_AREA)
        ms = cv2.resize(cv2.dilate(hard, np.ones((41, 41), np.uint8)), (ls.shape[1], ls.shape[0]), interpolation=cv2.INTER_NEAREST)
        bgs = cv2.inpaint(np.clip(ls, 0, 255).astype(np.uint8), ms, 6, cv2.INPAINT_TELEA).astype(np.float32)
        bgs = cv2.GaussianBlur(cv2.resize(bgs, (lab.shape[1], lab.shape[0]), interpolation=cv2.INTER_CUBIC), (0, 0), 20)
        d = cv2.GaussianBlur(np.abs(labf - bgs).sum(2), (0, 0), 5)
        hard = cv2.morphologyEx((d > 4.5).astype(np.uint8), cv2.MORPH_OPEN, np.ones((15, 15), np.uint8))
        k0, cc0, st0, _ = cv2.connectedComponentsWithStats(hard)
        hard = (cc0 == 1 + np.argmax(st0[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    dd = labf - bgl
    f = ((cv2.GaussianBlur(dd[..., 1], (0, 0), 4) > 2.2) | (cv2.GaussianBlur(dd[..., 0], (0, 0), 4) > 3)).astype(np.uint8)
    f = cv2.morphologyEx(f, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (17, 17)))
    ff2 = f * 255; mk2 = np.zeros((f.shape[0] + 2, f.shape[1] + 2), np.uint8)
    cv2.floodFill(ff2, mk2, (0, 0), 128); f = (ff2 != 128).astype(np.uint8)
    # glove = backdrop-difference mask, minus shadowed backdrop (darker but not more magenta than the backdrop);
    # keep the lower 25% (wrist/cuff, often darker) from the plain mask
    cut = int(hard.shape[0] * 0.75)
    plain = hard.copy()
    hard[:cut] &= f[:cut]
    hard = cv2.morphologyEx(hard, cv2.MORPH_OPEN, np.ones((9, 9), np.uint8))
    hard = cv2.morphologyEx(hard, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    if n == 4:                                 # left finger: outer edge has no neighbour gap, plain mask is right
        hard[:1100, :640] |= plain[:1100, :640]
    hard = (cv2.GaussianBlur(hard.astype(np.float32), (0, 0), 9) > 0.5).astype(np.uint8)   # smooth contour
    dmask = cv2.dilate(hard, np.ones((15, 15), np.uint8))
    # keep the largest component (the hand) and fill holes
    k, lab_cc, st, _ = cv2.connectedComponentsWithStats(hard)
    hard = (lab_cc == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    ff = hard.copy() * 255; mk = np.zeros((ff.shape[0] + 2, ff.shape[1] + 2), np.uint8)
    cv2.floodFill(ff, mk, (0, 0), 128); hard = (ff != 128).astype(np.uint8)
    # GrabCut refine (some glove areas sit very close to the backdrop pink): probable-fg = dilated rough mask
    gc = np.where(cv2.dilate(hard, np.ones((31, 31), np.uint8)) > 0, cv2.GC_PR_BGD, cv2.GC_BGD).astype(np.uint8)
    gc[cv2.erode(hard, np.ones((41, 41), np.uint8)) > 0] = cv2.GC_FGD
    hull = cv2.convexHull(cv2.findNonZero(hard))
    hm = np.zeros_like(hard); cv2.fillConvexPoly(hm, hull, 1)
    gc[(hard > 0) & (gc == cv2.GC_PR_BGD)] = cv2.GC_PR_FGD
    s4 = 2
    small = cv2.resize(im, None, fx=1 / s4, fy=1 / s4, interpolation=cv2.INTER_AREA)
    gcs = cv2.resize(gc, (small.shape[1], small.shape[0]), interpolation=cv2.INTER_NEAREST)
    bgm, fgm = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
    import os
    if os.environ.get('NOGC'):
        gcs = np.where(cv2.resize(hard, (small.shape[1], small.shape[0]), interpolation=cv2.INTER_NEAREST) > 0, 1, 0).astype(np.uint8)
    else:
        cv2.grabCut(small, gcs, None, bgm, fgm, 6, cv2.GC_INIT_WITH_MASK)
    hard = cv2.resize(((gcs == 1) | (gcs == 3)).astype(np.uint8), (im.shape[1], im.shape[0]), interpolation=cv2.INTER_LINEAR)
    hard = cv2.morphologyEx(hard, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    hard &= cv2.dilate(dmask, np.ones((7, 7), np.uint8))
    k, lab_cc, st, _ = cv2.connectedComponentsWithStats(hard)
    hard = (lab_cc == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    ff = hard.copy() * 255; mk = np.zeros((ff.shape[0] + 2, ff.shape[1] + 2), np.uint8)
    cv2.floodFill(ff, mk, (0, 0), 128); hard = (ff != 128).astype(np.uint8)
    hard = cv2.erode(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))   # drop the old pink fringe
    soft = cv2.GaussianBlur(hard.astype(np.float32), (0, 0), 1.4)          # antialiased edge
    L = lab[..., 0]
    gl = np.median(L[hard > 0])
    G, B = hex2lab(glove), hex2lab(bg)
    rel = (L - gl)                                                          # glove shading, in L units
    out_g = np.empty_like(lab)
    out_g[..., 0] = np.clip(G[0] + rel * 1.1, 0, 255)
    hi = np.clip((L - gl - 18) / 30, 0, 1)                                  # specular highlights stay neutral
    out_g[..., 1] = G[1] * (1 - hi * .6) + 128 * hi * .6
    out_g[..., 2] = G[2] * (1 - hi * .6) + 128 * hi * .6
    # background: solid colour, keep the photo's soft shadow (L relative to backdrop) as multiply
    shade = np.clip(cv2.GaussianBlur((L - bgl[0]) / 255 * 1.4, (0, 0), 25), -0.30, 0.0)
    out_b = np.empty_like(lab)
    out_b[..., 0] = np.clip(B[0] * (1 + shade), 0, 255)
    out_b[..., 1], out_b[..., 2] = B[1], B[2]
    out = out_g * soft[..., None] + out_b * (1 - soft[..., None])
    return cv2.cvtColor(np.clip(out, 0, 255).astype(np.uint8), cv2.COLOR_LAB2BGR)


if __name__ == "__main__":
    name, glove, bg = sys.argv[1:4]
    mirror = "--mirror" in sys.argv
    for n in (5, 4, 3, 2, 1):
        cv2.imwrite(f"/home/claude/content/design/samples-v5/prep/{name}-hand{n}.png", recolor(n, glove, bg, mirror))
    print("ok", name)
