# samples-v5 image use (one photo = one post; never reuse a photo on two posts within 30 days or across pages)

| Post | Image(s) | Source |
|---|---|---|
| Fully Funded · Put a finger down (green **or** butter) | prep/yg-hand5..1 / prep/gy-hand5..1 | Canva AI pink-glove set (MAHYEluxmoc, MAHYEshmz48, MAHYEubHdN8, MAHYEpSV9UE, MAHYEgPS6dM), recoloured in code (recolor.py). The two colourways are A/B alternatives of ONE post: publish only one. |
| Littlefold · Put a finger down (blush + sage) | prep/lf-hand5.png (cover only); inner slides use giant numerals, no photo | A different Canva AI glove photo (assets/inbox/hand5.png), recoloured sage on blush |
| STEADFOLD ORIGINAL (FF x3, Locked Hour cover) | none: generated paper texture only | code |
| Retired after v3/v4 (do not use again on these pages for 30 days) | pink glove set on Littlefold v4, glam glove (dropped), silhouettes (Reel), clouds/wheat/forest/street (slow-pans), halftone objects on the v4 covers, B/W character photos (Ep.01) | |

Note: the pink-glove photos appeared in v3/v4 **samples** only (never published). Once the Fully Funded green set is posted, that pose set is spent for 30 days on every page.
Canva quota was exhausted this run, so no new gloves were generated; Look A was made by recolouring.
