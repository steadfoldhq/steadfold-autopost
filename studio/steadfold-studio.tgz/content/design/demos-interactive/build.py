#!/usr/bin/env python3
"""Interactive-format demos (Oct 2026): one sample post per format, rendered with the normal pipeline.

Run:  python3 build.py
Writes posts.json (+ math.txt), renders via ../render.py into <format>/slide-NN.png, checks report.json
(0 QA errors, every panorama seam identical to its continuous-canvas probe), and makes contact-sheet.png
(panorama groups are butted together with no gap so the seams can be eyeballed).
Demos have no cta slide (CONTENT-STANDARD-v3: save/send lives in the caption), so render.py runs with
--no-fail and the only validation message allowed is "last slide must be the cta template".
"""
import json, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
DESIGN = HERE.parent
FONT = DESIGN / "assets" / "fonts"


# ------------------------------------------------------------------ Fully Funded example math (kept with the post)
def fv_monthly(pmt, annual, years):
    """Future value of `pmt` paid at the end of every month, `annual` rate compounded monthly."""
    r, n = annual / 12, years * 12
    return pmt * ((1 + r) ** n - 1) / r


AGES, PMT, RATE, END = [25, 35, 45], 100, 0.06, 65
MATH = {a: (round(fv_monthly(PMT, RATE, END - a)), PMT * 12 * (END - a)) for a in AGES}
(HERE / "math.txt").write_text(
    "Example math: 100 a month, 6% a year compounded monthly, paid at the end of each month, until 65.\n"
    "FV = 100 x ((1 + 0.06/12)^(12 x years) - 1) / (0.06/12)\n"
    + "".join(f"start {a}: {END-a} years, put in {MATH[a][1]:,}, grows to {MATH[a][0]:,}\n" for a in AGES))


def n(x):
    return f"{x:,}"


POSTS = [
    # 1. Fully Funded - follow the line
    {"id": "follow-the-line", "theme": "fullyfunded", "highlight": "A", "topic": "growth", "series": "Global", "slides": [
        {"template": "cover", "fields": {
            "kicker": "Follow the line · example math",
            "title": "100 a month: ==pick your age.==",
            "lead": "Same 100 a month, three starting ages. Follow your line to see what it becomes by 65.",
            "save_line": "save this for your next birthday",
            "visual": {"type": "timeline", "label": "100 a month · example at 6% a year", "points": [
                {"when": "Age 25", "label": "Start here?"}, {"when": "Age 35", "label": "Or here?"},
                {"when": "Age 45", "label": "Or here?"}, {"when": "At 65", "label": "What it becomes", "on": True}]}}},
        {"template": "follow-the-line", "fields": {
            "kicker": "100 a month, until 65",
            "title": "Pick your ==starting age.==",
            "choices": [{"icon": str(a), "label": f"Start at {a}", "answer": {"value": n(MATH[a][0]), "note": f"You put in {n(MATH[a][1])}"}} for a in AGES],
            "middle": [{"kicker": "Follow your colour", "title": "Same 100. ==Different start.=="},
                       {"kicker": "Keep going", "title": "Time does the ==heavy lifting.=="}],
            "end": {"kicker": "At 65 · example math", "title": "Here's where ==it lands.==",
                    "note": "Example at 6% a year, compounded monthly. Not guaranteed. Real returns vary, before fees, tax and inflation. Any currency. Same math."},
            "seed": 3}}]},
    # 2. Littlefold - awards
    {"id": "awards", "theme": "littlefold", "highlight": "A", "slides": [
        {"template": "cover", "fields": {
            "kicker": "For the first weeks",
            "title": "Gold star ==new-parent== behaviour",
            "save_line": "save this for the 3 am feed",
            "visual": {"type": "arch", "ill": "crib", "caption": "Tiny wins count."}}},
        {"template": "awards", "fields": {
            "kicker": "Today's awards",
            "title": "You earned ==every one.==",
            "items": ["Ate something warm", "Said yes to help", "Slept when someone else had the baby",
                      "Laughed at 3 am", "Drank a full glass of water", "Stepped outside for a minute"]}}]},
    # 3. Hourback - swipe to reveal
    {"id": "swipe-to-reveal", "theme": "hourback", "highlight": "A", "topic": "prompts", "slides": [
        {"template": "cover", "fields": {
            "kicker": "Swipe to reveal",
            "title": "Your week, ==planned by 1 prompt.==",
            "save_line": "save this for Sunday night",
            "visual": {"type": "doc", "title": "My week, planned", "lines": [
                {"text": "Mon 9:00 · Hardest task first", "hl": True}, "", "Tue · 30 min of buffer after lunch", "",
                "Fri · Move: the optional meeting"]}}},
        {"template": "swipe-to-reveal", "fields": {
            "kicker": "The 1 prompt that plans your week",
            "steps": [{"title": "Keep swiping ==to reveal.=="}, {"title": "Getting ==clearer…=="},
                      {"title": "Almost ==there.=="}, {"title": "Here it is. ==Copy it.=="}],
            "hint": "Keep swiping to reveal",
            "done_hint": "Paste into any AI chat. Fill the [brackets].",
            "target": {"kind": "prompt", "label": "AI chat · your week",
                       "text": "Here's my week: [paste your calendar, deadlines and to-dos]. My top 3 priorities are [priorities]. "
                               "Plan my week in 45-minute focus blocks. Put the hardest task when my energy is highest [mornings or afternoons]. "
                               "Leave 30 minutes of buffer each day. If it won't all fit, tell me what to drop or move."}}}]},
    # 4. Locked Hour - panorama
    {"id": "panorama", "theme": "lockedhour", "highlight": "A", "topic": "focus", "slides": [
        {"template": "cover", "fields": {
            "kicker": "Swipe the timeline",
            "title": "One locked hour, ==minute by minute.==",
            "visual": {"type": "clock", "progress": 0.75, "stickers": ["60 minutes", "Phone away"]}}},
        {"template": "panorama", "fields": {
            "slides": 3,
            "kicker": "Minutes 0–10",
            "title": "The first 10 minutes ==are the hardest.==",
            "heads": [None, {"kicker": "Minutes 10–45", "title": "Then the noise ==goes quiet.=="},
                      {"kicker": "Minutes 45–60", "title": "Finish ==on purpose.=="}],
            "stops": [{"time": "0:00", "text": "Phone in another room. Timer on."},
                      {"time": "0:04", "text": "The itch to check. Let it pass."},
                      {"time": "0:12", "text": "The task stops feeling heavy."},
                      {"time": "0:25", "text": "Deep in it. Time flies."},
                      {"time": "0:40", "text": "A wobble. Sip of water, back in."},
                      {"time": "0:52", "text": "Wrap up. Note where to restart."},
                      {"time": "1:00", "text": "Done. Stand up and stretch."}],
            "per_slide": [2, 3, 2],
            "objects": [{"art": "clock", "seam": 2, "size": 160, "progress": 0.75}]}}]},
]


def contact_sheet(order):
    cell, gap, pad = 360, 20, 28
    ch = round(cell * 1350 / 1080)
    rows = []
    f = ImageFont.truetype(str(FONT / "Inter-ExtraBold.ttf"), 26)
    fs = ImageFont.truetype(str(FONT / "Inter-Medium.ttf"), 18)
    rep = {r["id"]: r for r in json.loads((HERE / "report.json").read_text())}
    for pid in order:
        pngs = sorted((HERE / pid).glob("slide-*.png"))
        # panorama slides (seams recorded in the report) are butted together; others get a gap
        joined = set()
        for r in rep.values():
            for s in r.get("seams", []):
                a, b = [x.strip() for x in s["seam"].split("|")]
                joined.add((a, b))
        xs, x = [], pad
        for i, p in enumerate(pngs):
            xs.append(x)
            nxt = f"{pid}/{i+2:02d}"
            x += cell + (0 if (f"{pid}/{i+1:02d}", nxt) in joined else gap)
        im = Image.new("RGB", (x - gap + pad, 70 + ch + 40), (236, 236, 240)); d = ImageDraw.Draw(im)
        post = next(p for p in POSTS if p["id"] == pid)
        d.text((pad, 22), f"{pid}  ·  {post['theme']}", fill=(20, 20, 30), font=f)
        for i, p in enumerate(pngs):
            im.paste(Image.open(p).convert("RGB").resize((cell, ch), Image.LANCZOS), (xs[i], 70))
            d.text((xs[i], 70 + ch + 10), f"{i+1:02d}", fill=(90, 90, 110), font=fs)
        for (a, b) in joined:
            if a.startswith(pid + "/"):
                k = int(b.split("/")[1]) - 1
                d.polygon([(xs[k] - 7, 58), (xs[k] + 7, 58), (xs[k], 68)], fill=(255, 92, 168))
        rows.append(im)
    sheet = Image.new("RGB", (max(r.width for r in rows), sum(r.height for r in rows)), (236, 236, 240))
    y = 0
    for r in rows:
        sheet.paste(r, (0, y)); y += r.height
    sheet.save(HERE / "contact-sheet.png", optimize=True)


def main():
    doc = {"_build_notes": "Interactive-format demos. 4+ slides on purpose: the format IS the swipe (CONTENT-STANDARD-v3 s6 exception, "
                           "logged in STUDIO-README 'Interactive formats'). No cta slide; save/send goes in the caption.", "posts": POSTS}
    (HERE / "posts.json").write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
    r = subprocess.run([sys.executable, str(DESIGN / "render.py"), str(HERE / "posts.json"), "--out", str(HERE), "--no-fail"],
                       capture_output=True, text=True)
    print(r.stdout[-4000:]); print(r.stderr[-3000:], file=sys.stderr)
    if r.returncode:
        sys.exit("render failed")
    val = [ln.strip()[2:] for ln in r.stderr.splitlines() if ln.strip().startswith("- ")]
    bad_val = [v for v in val if "last slide must be the cta template" not in v]
    rep = json.loads((HERE / "report.json").read_text())
    errs = [(x["id"], e) for x in rep for e in x["errors"]]
    seams = [s for x in rep for s in x.get("seams", [])]
    contact_sheet([p["id"] for p in POSTS])
    print(f"\n{len(rep)} slides, {len(errs)} QA errors, {len(bad_val)} unexpected validation errors, {len(seams)} seams checked")
    for e in errs + [("validation", v) for v in bad_val]:
        print("  -", *e)
    for s in seams:
        print(f"  seam {s['seam']}: diff 2x={s['max_diff_2x']} 1x={s['max_diff_1x']}, "
              f"art crosses {s['rows_with_art_crossing']} rows")
    if errs or bad_val or any(s["max_diff_2x"] or s["max_diff_1x"] or not s["rows_with_art_crossing"] for s in seams):
        sys.exit(1)


if __name__ == "__main__":
    main()
