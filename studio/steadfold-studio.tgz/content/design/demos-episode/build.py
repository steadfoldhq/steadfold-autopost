#!/usr/bin/env python3
"""Editorial-episode demos (Oct 2026): one Ep.01 per brand, rendered with the normal pipeline.

Run:  python3 build.py
Writes posts.json + math.txt, renders <post-id>/slide-NN.png via ../render.py, checks report.json (0 QA errors;
the only validation message allowed is "last slide must be the cta template": episodes end on their own move,
save/send lives in the caption), then contact-sheet.png and the Fully Funded grid mock (grid-fullyfunded.png).
Facts and sources: SOURCES.md (Franklin) - every figure on the slides is in it.
"""
import json, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
DESIGN = HERE.parent
FONT = DESIGN / "assets" / "fonts"
DISC = "General education only, not financial advice."

# ------------------------------------------------------------------ example math (Fully Funded)
FRANKLIN_100Y = round(1000 * 1.05 ** 100)          # 5% a year, compounded yearly: Franklin's own estimate was £131,000
r, n = 0.06 / 12, 18 * 12
KIDS_POT = round(50 * ((1 + r) ** n - 1) / r)      # 50 a month from birth to 18, 6% a year compounded monthly
KIDS_IN = 50 * n
(HERE / "math.txt").write_text(
    f"£1,000 at 5% a year, compounded yearly, 100 years: {FRANKLIN_100Y:,} (Franklin's codicil estimate: £131,000)\n"
    f"50 a month from birth to 18 at 6% a year, compounded monthly, paid at month end: {KIDS_POT:,}; put in {KIDS_IN:,}\n")

POSTS = [
    {"id": "ff-ep01-franklin", "theme": "fullyfunded", "topic": "growth", "series": "Episodes",
     "caption": ("Benjamin Franklin left £1,000 each to Boston and Philadelphia in 1789, to grow for 200 years.\n\n"
                 "By 1990 the funds were worth about $4.5 million (Boston) and about $2 million (Philadelphia). That's far less "
                 "than his own estimate, but still a lot from £1,000.\nThe lesson: time is the ingredient.\n\n"
                 "Source: Franklin's codicil, 23 June 1789 (The Franklin Institute, via ExplorePAhistory); City of Boston Archives; "
                 f"Education Week, 25 Apr 1990; example math · As of Oct 2026\n\n{DISC}"),
     "slides": [
        {"template": "ep-cover", "fields": {"label": "Ep.01", "title": "Benjamin Franklin left money to two cities, *on purpose*, to grow for ==200 years.==",
                                            "stamp": True, "palette_index": 0}},
        {"template": "ep-statement", "fields": {"label": "June 1789", "statement": "A codicil to his will left ==£1,000== each to Boston and Philadelphia.",
                                                "sub": "Lent to young married tradespeople at 5% a year, and left to grow."}},
        {"template": "ep-handwritten", "fields": {"line": "He did the maths himself.",
                                                  "sub": "At 5% a year, he expected each £1,000 to reach about £131,000 in 100 years, and about £4 million in 200."}},
        {"template": "ep-statement", "fields": {"label": "By 1990", "statement": "Boston's fund: about *$4.5 million.* Philadelphia's: about $2 million.",
                                                "sub": "The catch: far less than his plan. Real growth is never a straight line."}},
        {"template": "ep-statement", "fields": {"statement": "Time is the ==ingredient.==", "sub": "Not a big start. A long one.", "align": "center"}},
        {"template": "ep-step", "fields": {"step": "your move.", "title": "Start a pot for your kids.",
                                          "body": f"Example: 50 a month from birth, at 6% a year, could grow to about {KIDS_POT:,} by 18. "
                                                  f"You'd put in {KIDS_IN:,}. Example math, not guaranteed. Before fees, tax and inflation."}},
     ]},
    {"id": "lh-ep01-reframes", "theme": "lockedhour", "topic": "focus", "series": "Episodes",
     "slides": [
        {"template": "ep-cover", "fields": {"label": "Ep.01 · Reframes", "title": "Change the sentence, *change* ==the hour.==",
                                            "sub": "Three small swaps for the days you can't start."}},
        {"template": "ep-reframe", "fields": {"label": "reframe 1.", "instead": "I need motivation.", "say": "I need a start time."}},
        {"template": "ep-reframe", "fields": {"label": "reframe 2.", "instead": "I don't have time.", "say": "I haven't booked it yet."}},
        {"template": "ep-reframe", "fields": {"label": "reframe 3.", "instead": "I'll start on Monday.", "say": "I'll start at 4:00 today."}},
        {"template": "ep-handwritten", "fields": {"line": "One hour. One start time.",
                                                  "sub": "Write yours on a sticky note tonight, and put it where you'll see it first."}},
     ]},
    {"id": "hb-ep01-behind-the-prompt", "theme": "hourback", "topic": "prompts", "series": "Episodes",
     "slides": [
        {"template": "ep-cover", "fields": {"label": "Ep.01 · Behind the prompt", "title": "How one ==good prompt== is built, piece by piece.",
                                            "image": {"src": "../fixtures/prompts-page.png", "position": "bottom", "height": 310, "crop": [6.2, 39.2, 87.6, 23.4]}}},
        {"template": "ep-step", "fields": {"title": "Give it a role.",
                                          "body": "Start with who it should be. *“You're a practical home cook who plans quick weeknight dinners.”*"}},
        {"template": "ep-step", "fields": {"title": "Add your context.",
                                          "body": "Tell it what it can't guess. *“We're 2 adults and a 6-year-old, we don't eat pork, and weeknights give us 30 minutes.”*"}},
        {"template": "ep-step", "fields": {"title": "Make one clear ask.",
                                          "body": "*“Plan 5 weeknight dinners for next week, reusing ingredients so little goes to waste.”*"}},
        {"template": "ep-step", "fields": {"title": "Name the format.",
                                          "body": "*“Show a table: day, dinner, cooking time. Then one shopping list, grouped by aisle.”*"}},
        {"template": "ep-step", "fields": {"title": "Ask it to check.",
                                          "body": "*“Before you answer, check every dinner fits in 30 minutes, and flag any that don't.”*"}},
     ]},
    {"id": "lf-ep01-first-week-home", "theme": "littlefold", "topic": "newborn", "series": "Episodes",
     "slides": [
        {"template": "ep-cover", "fields": {"label": "Ep.01", "title": "Notes for the *first week* home.", "sub": "Calm, small and kind. Read one a day.",
                                            "stamp": True}},
        {"template": "ep-handwritten", "fields": {"label": "note 1.", "line": "Let the small jobs wait.",
                                                  "sub": "The dishes can sit. Rest when you can, even for twenty minutes."}},
        {"template": "ep-step", "fields": {"step": "note 2.", "title": "Say yes to help.",
                                          "body": "When someone offers, give them a real job: a meal, a load of laundry, a walk with the pram."}},
        {"template": "ep-step", "fields": {"step": "note 3.", "title": "Keep the numbers close.",
                                          "body": "Write your midwife's, nurse's or doctor's number where everyone at home can find it."}},
        {"template": "ep-statement", "fields": {"label": "note 4.", "statement": "Not sure about something? ==Ask.==",
                                                "sub": "Feeding, sleep, a worry at 2 am: your midwife, nurse or doctor is there for exactly these questions."}},
        {"template": "ep-handwritten", "fields": {"label": "note 5.", "line": "You're learning together.",
                                                  "sub": "Be as kind to yourself as you are to them."}},
     ]},
]


def contact_sheet(ids):
    cell, gap, pad = 300, 16, 28
    ch = round(cell * 1350 / 1080)
    f = ImageFont.truetype(str(FONT / "Inter-ExtraBold.ttf"), 24)
    rows = []
    for pid in ids:
        pngs = sorted((HERE / pid).glob("slide-*.png"))
        im = Image.new("RGB", (pad * 2 + 6 * cell + 5 * gap, 64 + ch + pad), (236, 236, 240)); d = ImageDraw.Draw(im)
        d.text((pad, 20), pid, fill=(20, 20, 30), font=f)
        for i, p in enumerate(pngs):
            im.paste(Image.open(p).convert("RGB").resize((cell, ch), Image.LANCZOS), (pad + i * (cell + gap), 64))
        rows.append(im)
    sheet = Image.new("RGB", (max(r.width for r in rows), sum(r.height for r in rows)), (236, 236, 240)); y = 0
    for r_ in rows:
        sheet.paste(r_, (0, y)); y += r_.height
    sheet.save(HERE / "contact-sheet.png", optimize=True)


def rotation_mock(tiles):
    """Same grid, but the upcoming (unpublished) week 03 covers and the follow-the-line cover get feed.palette_index
    (+ one stamp), to show the rotation breaking up a run of look-alike tiles. Older, published covers stay as they are."""
    src = json.loads(Path("/home/claude/content/week03-global/fullyfunded/posts.json").read_text())["posts"]
    by = {p["id"]: p for p in src}
    demo = json.loads((DESIGN / "demos-interactive/posts.json").read_text())["posts"][0]
    plan = [(demo, 0, False), (by["ff-w03-3-guardian-will"], 1, True), (by["ff-w03-2-borrow-dont-sell"], 2, False), (by["ff-w03-1-freedom-number"], 3, False)]
    posts = []
    for p, idx, stamp in plan:
        q = json.loads(json.dumps(p)); q["id"] = p["id"] + "-rot"; q.pop("caption", None)
        cov = q["slides"][0]["fields"]; cov["palette_index"] = idx
        if stamp:
            cov["stamp"] = True
        q["slides"] = q["slides"][:2] if q["slides"][1]["template"] not in ("follow-the-line",) else [q["slides"][0], {"template": "quote", "fields": {"line": "x"}}]
        posts.append(q)
    out = HERE / "_rotation"; out.mkdir(exist_ok=True)
    (out / "posts.json").write_text(json.dumps({"posts": posts}, indent=1, ensure_ascii=False))
    subprocess.run([sys.executable, str(DESIGN / "render.py"), str(out / "posts.json"), "--out", str(out), "--no-fail"], capture_output=True, text=True)
    rep = json.loads((out / "report.json").read_text())
    n = sum(len(x["errors"]) for x in rep if x["id"].endswith("/01"))
    new = [tiles[0]] + [out / q["id"] / "slide-01.png" for q in posts] + tiles[5:]
    g = subprocess.run([sys.executable, str(DESIGN / "grid_preview.py"), *map(str, new), "--theme", "fullyfunded",
                        "--out", str(HERE / "grid-fullyfunded-rotated.png"), "--title", "With palette rotation (upcoming posts only)"], capture_output=True, text=True)
    print(g.stdout)
    for x in rep:
        if x["id"].endswith("/01") and x["errors"]:
            print("  rotation QA:", x["id"], x["errors"][:3])
    return n


def main():
    doc = {"_build_notes": "Editorial episodes, Ep.01 x 4 brands. 5-6 slides: an episode is a short story (CONTENT-STANDARD-v3 s6 exception, "
                           "noted in STUDIO-README). No cta slide; save/send in the caption.", "posts": POSTS}
    (HERE / "posts.json").write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
    r = subprocess.run([sys.executable, str(DESIGN / "render.py"), str(HERE / "posts.json"), "--out", str(HERE), "--no-fail"],
                       capture_output=True, text=True)
    print(r.stdout[-3000:]); print(r.stderr[-2000:], file=sys.stderr)
    if r.returncode:
        sys.exit("render failed")
    val = [ln.strip()[2:] for ln in r.stderr.splitlines() if ln.strip().startswith("- ")]
    bad_val = [v for v in val if "last slide must be the cta template" not in v]
    rep = json.loads((HERE / "report.json").read_text())
    errs = [(x["id"], e) for x in rep for e in x["errors"]]
    contact_sheet([p["id"] for p in POSTS])
    # Fully Funded grid mock: newest first (this episode, the follow-the-line demo, then the live week 03 + week 02 covers)
    C = Path("/home/claude/content")
    tiles = [HERE / "ff-ep01-franklin/slide-01.png", DESIGN / "demos-interactive/follow-the-line/slide-01.png"] + \
            [C / f"week03-global/fullyfunded/out/{k}/slide-01.png" for k in ("ff-w03-3-guardian-will", "ff-w03-2-borrow-dont-sell", "ff-w03-1-freedom-number")] + \
            [C / f"week02/fullyfunded/out/{k}/slide-01.png" for k in ("ff-w02-6-ei-weeks", "ff-w02-5-benefit-cliffs", "ff-w02-4-learning-bond", "ff-w02-1-paycheque-fall")]
    missing = [t for t in tiles if not Path(t).exists()]
    if missing:   # a fresh studio session may not have older rendered weeks; the mock is optional
        print(f"grid mock skipped: {len(missing)} older cover PNGs not on disk (e.g. {missing[0]})")
        g = subprocess.CompletedProcess([], 0); rot_errs = 0
    else:
        g = subprocess.run([sys.executable, str(DESIGN / "grid_preview.py"), *map(str, tiles), "--theme", "fullyfunded",
                            "--out", str(HERE / "grid-fullyfunded.png"), "--title", "Grid preview · Ep.01 + recent covers"], capture_output=True, text=True)
        print(g.stdout, g.stderr)
        rot_errs = rotation_mock(tiles)
    print(f"\n{len(rep)} slides, {len(errs)} QA errors, {len(bad_val)} unexpected validation errors, rotation mock QA errors: {rot_errs}")
    for e in errs + [("validation", v) for v in bad_val]:
        print("  -", *e)
    if errs or bad_val or g.returncode or rot_errs:
        sys.exit(1)


if __name__ == "__main__":
    main()
