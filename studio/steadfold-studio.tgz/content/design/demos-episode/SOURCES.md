# Ep.01 demos: facts and sources (checked Oct 15, 2026)

## Fully Funded Ep.01: Benjamin Franklin's codicil
| Slide claim | Source |
|---|---|
| Codicil dated 23 June 1789 | Codicil text: "this twenty-third day of June, Anno Domini one thousand Seven hundred and eighty nine" (The Last Will and Testament of Benjamin Franklin, The Franklin Institute, via ExplorePAhistory.com, WITF/PHMC): https://explorepahistory.com/odocument.php?docId=1-4-2DE. Also City of Boston Archives, *Guide to the Franklin Fund records*: "in a codicil to his will dated June 23, 1789": https://www.cityofboston.gov/images_documents/Guide%20to%20the%20Franklin%20Fund%20records_tcm3-20691.pdf |
| £1,000 each to Boston and Philadelphia | Codicil ("one thousand thereof to the inhabitants of the town of Boston … the other thousand to the inhabitants of the city of Philadelphia"), quoted by Philanthropy Roundtable: https://www.philanthropyroundtable.org/magazine/what-miracle-of-compound-interest/ ; Boston Archives guide; Education Week (below) |
| Lent to young married tradespeople at 5% a year | Codicil: loans "to assist young married artificers in setting up their business"; "let out the sum upon interest, at five per cent, per annum" (ExplorePAhistory). Boston guide: "young married artificers, under the Age of twenty-five years". "Artificers" = skilled tradespeople. |
| He expected about £131,000 after 100 years and about £4 million after 200 | Codicil: "the sum will then be one hundred and thirty-one thousand pounds"; "four millions and sixty one thousand pounds sterling" (ExplorePAhistory; Boston guide). Check: £1,000 × 1.05^100 = £131,501 (math.txt). |
| By 1990: Boston about $4.5 million; Philadelphia about $2 million | Boston: "approximately $4.5 million in Boston" (Julia Woltman, *Education Week*, 25 Apr 1990: https://www.edweek.org/education/benjamin-franklins-penny-saved-means-training-dollars-for-2-cities/1990/04); NYT figure "about $4.5 million" cited by Snopes: https://www.snopes.com/fact-check/ben-franklin-2000-dollars/ (Philanthropy Roundtable says "almost $5 million"; we use the lower, twice-sourced figure). Philadelphia: "the remainder was about $2 million" (Philanthropy Roundtable); "the then-$2 million total" (Snopes). |
| "Far less than his plan" | £4,061,000 projected vs about $4.5M + $2M actual (sources above). Philadelphia's fund at the 100-year mark was "less than a fourth" of his projection (Philanthropy Roundtable). |
| Kids' pot example | Example math only (math.txt): 50 a month for 18 years at 6% a year, compounded monthly = 19,368; 10,800 put in. Labelled "Example math, not guaranteed. Before fees, tax and inflation." |

Not used (could not verify from two sources): exact 1990 dollar amounts beyond "about"; why the funds fell short.

## Locked Hour Ep.01: reframes
Original wording, no facts claimed. Reframe 1 is Dharma's brief. Reframes 2 and 3 are new.

## Hourback Ep.01: Behind the prompt
A real prompt, built in 5 parts (role, context, ask, format, check). Put together:
"You're a practical home cook who plans quick weeknight dinners. We're 2 adults and a 6-year-old, we don't eat pork, and weeknights give us 30 minutes. Plan 5 weeknight dinners for next week, reusing ingredients so little goes to waste. Show a table: day, dinner, cooking time. Then one shopping list, grouped by aisle. Before you answer, check every dinner fits in 30 minutes, and flag any that don't."
The cover image is Hourback's own product page (`design/fixtures/prompts-page.png`), with a soft black-and-white treatment.

## Littlefold Ep.01: Notes for the first week home
General, non-medical guidance only: rest, accept help, keep care contacts visible, ask your midwife, nurse or doctor. No health claims, so there are no sources to cite.
