"""Steadfold "Editorial episode" template family (Oct 2026). Original design: paper grain, alternating deep/light
slides, a large Fraunces serif with an occasional Lora-italic word, Caveat handwritten labels, brush underlines,
huge whitespace and a tiny monospace signature.

Templates: ep-cover, ep-step, ep-statement, ep-reframe, ep-handwritten (fields in post.schema.json / STUDIO-README).
Markup inside any text: ==words== brush underline · *word* italic serif · **bold** · \\n line break.
Rules enforced: all text >= 90 px from every edge (render.js data-edge), body text >= 40 px (CSS), <= 45 words a slide
(validate). Slides alternate deep / light by index (cover = deep); "surface": "deep"|"light" overrides.
"""
import hashlib, re
from pathlib import Path

from .themes import THEMES, FONTS, MARKS
from .markup import md
from . import feed

W, H = 1080, 1350
EDGE = 90
MAXGAP = 760          # editorial whitespace is deliberate; this still catches an empty slide
EP_TEMPLATES = ["ep-cover", "ep-step", "ep-statement", "ep-reframe", "ep-handwritten"]
HL_JS = (Path(__file__).parent / "highlight.js").read_text()

# deep / light pair per brand (from each palette): bg, ink, muted, brush (underline), label (handwriting)
EP = {
    "fullyfunded": dict(deep=dict(bg="#16206B", ink="#F7F1E5", muted="#C9CDEB", brush="#FF7A4D", label="#FFB08F", soft="#2B3FE0"),
                        light=dict(bg="#F7F1E5", ink="#121A55", muted="#4B5178", brush="#FF6A3D", label="#2B3FE0", soft="#FFD2BF"),
                        tagline="MONEY, MADE CLEAR"),
    "lockedhour": dict(deep=dict(bg="#151413", ink="#FFF1C9", muted="#D9CFBE", brush="#FF5CA8", label="#FFD43B", soft="#5A4A12"),
                       light=dict(bg="#FFF1C9", ink="#151413", muted="#4D463E", brush="#FF5CA8", label="#C81F6A", soft="#FFD43B"),
                       tagline="ONE HOUR AT A TIME"),
    "hourback": dict(deep=dict(bg="#3A2240", ink="#FFEBDD", muted="#E8CFDC", brush="#FF8A3D", label="#FFC94D", soft="#5E3A66"),
                     light=dict(bg="#FFE6D3", ink="#3A2240", muted="#6E4F66", brush="#FF8A3D", label="#5E54C9", soft="#FFC94D"),
                     tagline="GET YOUR EVENINGS BACK"),
    "littlefold": dict(deep=dict(bg="#7A2149", ink="#FFF1F4", muted="#F6CFDC", brush="#FFA35C", label="#FFE27E", soft="#9A3462"),
                       light=dict(bg="#FCE5EB", ink="#3A1B2C", muted="#7A5566", brush="#D9497A", label="#C2386A", soft="#FFE27E"),
                       tagline="SMALL DAYS, GENTLY"),
}


def words(f):
    txt = " ".join(str(v) for k, v in f.items() if k in ("label", "title", "sub", "body", "statement", "note", "instead", "say", "line", "step"))
    return len(re.findall(r"[A-Za-z0-9£$€₹%][\w'’.,%£$€₹-]*", re.sub(r"[=*]", "", txt)))


def validate(p):
    errs = []
    for i, s in enumerate(p["slides"]):
        t = s["template"]
        if t not in EP_TEMPLATES:
            continue
        f = s.get("fields", {}); at = f"{p['id']} slide {i+1} ({t})"
        need = {"ep-cover": ["title"], "ep-step": ["title", "body"], "ep-statement": ["statement"],
                "ep-reframe": ["instead", "say"], "ep-handwritten": ["line"]}[t]
        for k in need:
            if not f.get(k):
                errs.append(f"{at}: missing '{k}'")
        n = words(f)
        if n > 45:
            errs.append(f"{at}: {n} words (max 45 a slide)")
        img = f.get("image")
        if img and t != "ep-cover":
            errs.append(f"{at}: image panels only exist on ep-cover")
    return errs


# ------------------------------------------------------------------ markup + art
def _uri(svg):
    return "data:image/svg+xml;utf8," + svg.replace("#", "%23").replace('"', "'").replace("<", "%3C").replace(">", "%3E")


def brush_under(col):   # tapered dry-brush stroke, stretched under the words
    return _uri(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 30" preserveAspectRatio="none">'
                f'<path d="M3 17 C60 9 130 7 210 8 C250 8 280 9 297 12 C285 15 250 16 210 17 C150 19 90 21 40 24 C22 25 9 24 3 17 Z" fill="{col}"/>'
                f'<path d="M30 25 C90 21 170 19 260 18" stroke="{col}" stroke-width="2.4" fill="none" opacity=".55" stroke-linecap="round"/></svg>')


def brush_blob(col):    # soft highlighter block behind a label
    return _uri(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 60" preserveAspectRatio="none">'
                f'<path d="M6 14 C50 6 120 4 194 9 C198 24 197 40 192 52 C130 57 60 58 8 52 C3 40 2 26 6 14 Z" fill="{col}" opacity=".9"/></svg>')


def swash(col, w=260):  # hand-drawn swash used as an accent under handwritten lines
    return (f'<svg class="swash" width="{w}" height="{w*0.16:.0f}" viewBox="0 0 260 42" fill="none" stroke="{col}" stroke-width="5" stroke-linecap="round">'
            f'<path d="M6 30 C60 6 120 40 170 20 C200 8 228 12 254 22"/><path d="M200 34 C220 30 236 32 250 36" opacity=".7"/></svg>')


def emd(s):
    """md() + episode markup: ==x== brush underline (not the marker engine), *x* italic serif."""
    h = md(s)
    h = re.sub(r'<span class="hl( nw)?">', lambda m: f'<span class="ul{m.group(1) or ""}">', h)
    h = re.sub(r"(?<![*\w])\*(?!\*)([^*]+?)\*(?![*\w])", r"<em>\1</em>", h)
    return h


def grain_css(deep):
    if deep:
        mat = "0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 .10 0"; blend, op = "screen", ".55"
    else:
        mat = "0 0 0 0 .30  0 0 0 0 .22  0 0 0 0 .14  0 0 0 .12 0"; blend, op = "multiply", ".6"
    svg = ("<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' "
           f"numOctaves='3' stitchTiles='stitch'/><feColorMatrix values='{mat}'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")
    return f"background-image:url(\"data:image/svg+xml;utf8,{svg}\");mix-blend-mode:{blend};opacity:{op}"


# ------------------------------------------------------------------ image panel (soft B&W + grain)
def treat_image(post, src, w, h, crop=None, focus=(50, 50)):
    """Soft black-and-white with grain, cover-cropped to w x h (rendered at 2x). Returns a file URI."""
    import numpy as np
    from PIL import Image, ImageFilter, ImageOps
    base = Path(post.get("_base") or ".")
    p = Path(src) if Path(src).is_absolute() else base / src
    if not p.exists():
        raise FileNotFoundError(f"image not found: {p}")
    im = Image.open(p).convert("RGB")
    if crop:
        x, y, cw, ch = crop; IW, IH = im.size
        im = im.crop((round(IW*x/100), round(IH*y/100), round(IW*(x+cw)/100), round(IH*(y+ch)/100)))
    W2, H2 = w * 2, h * 2
    IW, IH = im.size; s = max(W2 / IW, H2 / IH)
    im = im.resize((max(W2, round(IW * s)), max(H2, round(IH * s))), Image.LANCZOS)
    fx, fy = focus; IW, IH = im.size
    l = round((IW - W2) * fx / 100); t = round((IH - H2) * fy / 100)
    im = im.crop((l, t, l + W2, t + H2))
    g = ImageOps.autocontrast(ImageOps.grayscale(im), cutoff=1).filter(ImageFilter.GaussianBlur(0.7))
    a = np.asarray(g).astype(float) / 255
    a = 0.12 + 0.80 * a ** 0.92                                  # lifted blacks, soft whites
    seed = int(hashlib.md5(f"{p}|{w}x{h}".encode()).hexdigest()[:8], 16)
    a += np.random.default_rng(seed).normal(0, 0.035, a.shape)   # film grain
    a = np.clip(a, 0, 1)
    warm = np.stack([a * 1.0, a * 0.985, a * 0.95], axis=2)     # a whisper of warmth, still reads as B&W
    out = Image.fromarray((np.clip(warm, 0, 1) * 255).astype("uint8"))
    d = Path(post.get("_imgdir") or "build/_img"); d.mkdir(parents=True, exist_ok=True)
    dst = d / f"ep-{hashlib.md5(f'{p.resolve()}|{p.stat().st_mtime}|{w}x{h}|{crop}|{focus}'.encode()).hexdigest()[:12]}.png"
    out.save(dst)
    return dst.resolve().as_uri()


# ------------------------------------------------------------------ templates
def _label(txt, cls="eplab"):
    return f'<div class="{cls}" data-box>{emd(txt)}</div>' if txt else ""


def _fit(n, steps):
    for lim, px in steps:
        if n <= lim:
            return px
    return steps[-1][1]


def ep_cover(t, f, post, ctx):
    title = f["title"]; n = len(re.sub(r"[=*]", "", title))
    fs = _fit(n, [(34, 112), (60, 96), (90, 84), (999, 72)])
    if f.get("image"):
        fs = min(fs, 80)
    lab = _label(f.get("label") or "Ep.01")
    head = f'<h1 class="eptitle" data-box style="font-size:{fs}px">{emd(title)}</h1>'
    sub = f'<p class="epsub" data-box>{emd(f["sub"])}</p>' if f.get("sub") else ""
    img = ""
    if f.get("image"):
        im = f["image"]; hgt = int(im.get("height", 500))
        uri = treat_image(post, im["src"], W - 2 * EDGE - 12, hgt, im.get("crop"), tuple(im.get("focus", (50, 50))))
        img = f'<div class="epimg" data-box style="height:{hgt}px"><img src="{uri}" alt=""></div>'
    stamp = ""
    if f.get("stamp"):
        stamp = f'<div class="epstamp" data-box>{feed.stamp_svg(t, 200, ctx["c"]["ink"], ctx["c"]["bg"], text=f["stamp"] if isinstance(f["stamp"], str) else None)}</div>'
    pos = (f.get("image") or {}).get("position", "bottom")
    if img and pos == "top":
        body = img + '<div class="epgap"></div>' + lab + head + sub
    elif img:
        body = lab + head + sub + '<div class="epgap"></div>' + img
    else:
        body = lab + '<div class="epgap"></div>' + head + sub + (f'<div class="epfoot">{stamp}</div>' if stamp else "")
        stamp = ""
    return body + stamp


def ep_step(t, f, post, ctx):
    n = f.get("n") or ctx["stepno"]
    lab = _label(f.get("step") or f"step {n}.", "eplab big")
    head = f'<h2 class="eph2" data-box>{emd(f["title"])}</h2>'
    body = f'<p class="epbody" data-box>{emd(f["body"])}</p>'
    return '<div class="epgap"></div>' + lab + head + body + '<div class="epgap"></div>'


def ep_statement(t, f, post, ctx):
    s = f["statement"]; n = len(re.sub(r"[=*]", "", s))
    fs = _fit(n, [(40, 104), (80, 84), (130, 68), (999, 58)])
    al = f.get("align", "left")
    lab = _label(f.get("label"))
    st = f'<h2 class="epstate" data-box style="font-size:{fs}px;text-align:{al}">{emd(s)}</h2>'
    sub = f'<p class="epsub" data-box style="text-align:{al}">{emd(f["sub"])}</p>' if f.get("sub") else ""
    note = f'<div class="epnote" data-box style="align-self:{"center" if al == "center" else "flex-start"}">{emd(f["note"])}</div>' if f.get("note") else ""
    return lab + '<div class="epgap"></div>' + st + sub + note + '<div class="epgap"></div>'


def ep_reframe(t, f, post, ctx):
    lab = _label(f.get("label"))
    a = (f'<div class="rf a" data-box><span class="rfl">{emd(f.get("instead_label", "Instead of"))}</span>'
         f'<div class="rfq">“{emd(f["instead"])}”</div></div>')
    arrow = (f'<svg class="rfarr" width="120" height="96" viewBox="0 0 120 96" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">'
             f'<path d="M20 8 C14 40 30 70 84 78"/><path d="M68 62 L86 78 L64 90"/></svg>')
    b = (f'<div class="rf b" data-box><span class="rfl">{emd(f.get("say_label", "Say"))}</span>'
         f'<div class="rfq">“{emd(f["say"])}”</div></div>')
    note = f'<div class="epnote" data-box>{emd(f["note"])}</div>' if f.get("note") else ""
    return lab + '<div class="epgap"></div>' + a + f'<div class="rfmid">{arrow}</div>' + b + note + '<div class="epgap"></div>'


def ep_handwritten(t, f, post, ctx):
    line = f["line"]; n = len(re.sub(r"[=*]", "", line))
    fs = _fit(n, [(22, 150), (40, 124), (70, 104), (999, 88)])
    lab = _label(f.get("label"))
    hw = f'<h2 class="ephand" data-box style="font-size:{fs}px">{emd(line)}</h2>'
    sw = f'<div class="epsw">{swash(ctx["c"]["brush"], 300)}</div>'
    sub = f'<p class="epsub" data-box>{emd(f["sub"])}</p>' if f.get("sub") else ""
    return lab + '<div class="epgap"></div>' + hw + sw + sub + '<div class="epgap"></div>'


BUILDERS = {"ep-cover": ep_cover, "ep-step": ep_step, "ep-statement": ep_statement, "ep-reframe": ep_reframe, "ep-handwritten": ep_handwritten}


# ------------------------------------------------------------------ page
def font_css():
    u = FONTS.as_uri()
    return (f"@font-face{{font-family:'Fraunces';font-weight:100 900;src:url({u}/Fraunces-Variable.ttf) format('truetype')}}"
            f"@font-face{{font-family:'EP Italic';font-weight:400 700;font-style:normal;src:url({u}/Lora-Italic-Variable.ttf) format('truetype')}}"
            f"@font-face{{font-family:'Caveat';font-weight:400 700;src:url({u}/Caveat-Variable.ttf) format('truetype')}}"
            f"@font-face{{font-family:'Caveat Brush';src:url({u}/CaveatBrush-Regular.ttf) format('truetype')}}"
            f"@font-face{{font-family:'Inter';font-weight:500;src:url({u}/Inter-Medium.ttf) format('truetype')}}")


def css(c, deep):
    return f"""{font_css()}
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{width:1080px;height:1350px;overflow:hidden;background:{c['bg']}}}
body{{-webkit-font-smoothing:antialiased}}
.slide{{position:absolute;inset:0;overflow:hidden;background:{c['bg']};color:{c['ink']}}}
.deco{{position:absolute;pointer-events:none;z-index:0}}
.grain{{inset:0;{grain_css(deep)}}}
.vign{{inset:0;background:radial-gradient(ellipse at 50% 42%,transparent 55%,{'rgba(0,0,0,.28)' if deep else 'rgba(90,60,30,.10)'} 100%)}}
.main{{position:absolute;left:{EDGE+6}px;right:{EDGE+6}px;top:{EDGE+14}px;bottom:{EDGE+70}px;z-index:1;display:flex;flex-direction:column}}
.epgap{{flex:1 1 0;min-height:24px}}
.eplab{{align-self:flex-start;font:600 50px/1 Caveat;color:{c['label']};margin-top:18px;transform:rotate(-2deg);transform-origin:0 100%;letter-spacing:.01em}}
.eplab.big{{font:700 64px/1 Caveat;margin-bottom:26px}}
.eptitle,.eph2,.epstate{{font-family:Fraunces;font-weight:380;font-variation-settings:'SOFT' 60,'WONK' 0;font-optical-sizing:auto;letter-spacing:-.018em;line-height:1.06;color:{c['ink']};text-wrap:balance}}
.eptitle{{margin-top:26px}}
.eph2{{font-size:78px;line-height:1.05}}
.epstate{{line-height:1.08}}
em{{font-family:'EP Italic';font-style:normal;font-weight:500;letter-spacing:-.01em}}
.ul{{-webkit-box-decoration-break:clone;box-decoration-break:clone;background-image:url("{brush_under(c['brush'])}");background-repeat:no-repeat;background-size:100% .26em;background-position:0 98%;padding:0 .04em .04em}}
.ul.nw{{white-space:nowrap}}
.nb{{white-space:nowrap}}
b{{font-weight:600}}
.epsub{{font-family:Fraunces;font-weight:360;font-variation-settings:'SOFT' 80;font-size:42px;line-height:1.32;color:{c['muted']};margin-top:34px;text-wrap:pretty;max-width:860px}}
.epbody{{font-family:Fraunces;font-weight:340;font-variation-settings:'SOFT' 80;font-size:42px;line-height:1.38;color:{c['muted']};margin-top:36px;text-wrap:pretty}}
.epbody b,.epsub b{{color:{c['ink']}}}
.epnote{{font:500 54px/1.1 Caveat;color:{c['label']};margin-top:40px;transform:rotate(-2deg)}}
.ephand{{font-family:'Caveat Brush';font-weight:400;line-height:1.02;color:{c['ink']};text-wrap:balance;letter-spacing:.005em}}
.epsw{{margin-top:6px}}.swash{{display:block}}
.rf{{display:flex;flex-direction:column;align-items:flex-start}}
.rfl{{font:700 54px/1 Caveat;padding:6px 22px 10px 18px;margin-left:-18px;color:{c['ink']};background-image:url("{brush_blob(c['soft'])}");background-size:100% 100%;background-repeat:no-repeat}}
.rf.a .rfq{{font-family:Fraunces;font-weight:340;font-size:58px;line-height:1.12;color:{c['muted']};margin-top:22px;text-wrap:balance;text-decoration:line-through;text-decoration-thickness:3px;text-decoration-color:{c['brush']}}}
.rf.b .rfq{{font-family:Fraunces;font-weight:420;font-size:78px;line-height:1.06;letter-spacing:-.015em;color:{c['ink']};margin-top:22px;text-wrap:balance}}
.rfmid{{color:{c['label']};margin:28px 0 22px 40px}}.rfarr{{display:block}}
.epimg{{flex:none;width:100%;border-radius:6px;overflow:hidden;position:relative;box-shadow:0 30px 60px -40px rgba(0,0,0,.6)}}
.epimg img{{display:block;width:100%;height:100%;object-fit:cover}}
.epfoot{{display:flex;justify-content:flex-end;margin-top:40px}}
.epstamp{{flex:none}}.epstamp svg{{display:block}}
.epsig{{position:absolute;left:{EDGE+6}px;right:{EDGE+6}px;bottom:{EDGE+12}px;z-index:2;display:flex;justify-content:space-between;align-items:baseline;
  font:500 22px/1 'DejaVu Sans Mono',monospace;letter-spacing:.06em;color:{c['muted']};opacity:.85}}
"""


def slide_html(post, i):
    t = post["theme"]; s = post["slides"][i]; f = s.get("fields", {})
    surf = s.get("surface")
    deep = (surf == "deep" or surf == "dark") if surf else (i % 2 == 0)
    c = dict(EP[t]["deep" if deep else "light"])
    if s["template"] == "ep-cover" and f.get("palette_index") is not None:
        c["bg"] = feed.episode_deep(t, int(f["palette_index"])) if deep else c["bg"]
    stepno = sum(1 for x in post["slides"][: i + 1] if x["template"] == "ep-step")
    ctx = {"c": c, "stepno": stepno}
    inner = BUILDERS[s["template"]](t, f, post, ctx)
    ep = next((x["fields"].get("label") for x in post["slides"] if x["template"] == "ep-cover" and x["fields"].get("label")), "Ep.01")
    n = len(post["slides"])
    sig = (f'<div class="epsig"><span data-box>© {THEMES[t]["name"]} · {md(re.sub(r"[=*]", "", ep))}</span>'
           f'<span data-box>{i+1:02d} / {n:02d}</span></div>')
    return (f'<!doctype html><html><head><meta charset="utf-8"><style>{css(c, deep)}</style></head>'
            f'<body data-edge="{EDGE}" data-maxgap="{MAXGAP}" data-ep="{s["template"]}" data-hl="A" data-theme="{t}" data-template="{s["template"]}">'
            f'<div class="slide {"deep" if deep else "light"}"><div class="deco grain"></div><div class="deco vign"></div>'
            f'<div class="main">{inner}</div>{sig}</div><script>{HL_JS}</script></body></html>')
