"""Littlefold (Steadfold parenting studio) - brand mark, line illustrations, cover visuals and CSS.
Kept in its own module so the three original themes' code paths and HTML stay byte-identical.
Look (Sherbet, Oct 14 2026): butter paper, deep ink, pink + orange + baby blue, Lora display with italic emphasis, soft paper shadows."""
from .markup import md
from .visuals import icon

OAT, CREAM, INK, MUTED = "#FFF8E4", "#FFFFFF", "#2C2A3A", "#6B6676"
CLAY, CLAY2, BLUSH = "#D9497A", "#F5A3BD", "#FFE27E"
SAGE, SAGE2, SAGESOFT, MOSS = "#FFA35C", "#FFC79A", "#FFE9D6", "#D44C79"


# ------------------------------------------------------------------ mark: a folded shelter over a sprout
def mark_svg(size=120, variant="light"):
    if variant == "onmoss":
        l, r, s1, s2, g = OAT, BLUSH, "#FFD3AE", SAGE2, OAT
    elif variant == "onclay":
        l, r, s1, s2, g = OAT, "#FFE0EA", SAGESOFT, "#FFD3AE", OAT
    else:
        l, r, s1, s2, g = CLAY, CLAY2, SAGE, SAGE2, INK
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">'
            f'<path d="M60 19 L11 63 L22 73 L60 38 Z" fill="{l}" stroke="{l}" stroke-width="4" stroke-linejoin="round"/>'
            f'<path d="M60 19 L109 63 L98 73 L60 38 Z" fill="{r}" stroke="{r}" stroke-width="4" stroke-linejoin="round"/>'
            f'<path d="M60 99 L60 70" stroke="{s1}" stroke-width="5.5" stroke-linecap="round" fill="none"/>'
            f'<path d="M59 84 C50 84 43 78 41 69 C51 69 58 75 59 84 Z" fill="{s1}"/>'
            f'<path d="M61 78 C69 77 76 71 78.5 62 C69 62 62.5 68 61 78 Z" fill="{s2}"/>'
            f'<path d="M46 101 L74 101" stroke="{g}" stroke-width="4.5" stroke-linecap="round" opacity=".85"/></svg>')


# ------------------------------------------------------------------ line illustrations (200x200, ink line + soft fills)
def _ill(body, size, w=200, h=200):
    return (f'<svg class="ill" width="{size}" height="{size*h/w:.0f}" viewBox="0 0 {w} {h}" fill="none" stroke="{INK}" '
            f'stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round">{body}</svg>')


def ill_crib(size=300):
    slats = "".join(f'<path d="M{x} 92 V146"/>' for x in range(54, 150, 13))
    return _ill(
        f'<path d="M70 38 a16 16 0 1 0 22 -18 a13 13 0 1 1 -22 18z" fill="{CREAM}" stroke="none"/>'
        f'<path d="M118 30 l3 -8 l3 8 l8 3 l-8 3 l-3 8 l-3 -8 l-8 -3z" fill="{CLAY2}" stroke="none"/>'
        f'<path d="M140 52 l2 -5 l2 5 l5 2 l-5 2 l-2 5 l-2 -5 l-5 -2z" fill="{SAGE2}" stroke="none"/>'
        f'<rect x="40" y="134" width="120" height="14" rx="5" fill="{CREAM}"/>'
        f'<path d="M36 80 V170 M164 80 V170"/><path d="M36 92 H164 M36 148 H164"/>{slats}'
        f'<path d="M36 80 q0 -6 6 -6 M164 80 q0 -6 -6 -6"/><path d="M30 170 H46 M154 170 H170" />', size)


def ill_cart(size=300):
    return _ill(
        f'<circle cx="104" cy="100" r="64" fill="{SAGESOFT}" stroke="none"/>'
        f'<path d="M24 52 H44 L60 128 H150"/><path d="M48 70 H166 L154 112 H58" fill="{CREAM}"/>'
        f'<path d="M84 70 L88 112 M118 70 L118 112 M150 70 L142 112"/>'
        f'<circle cx="72" cy="148" r="10" fill="{CREAM}"/><circle cx="140" cy="148" r="10" fill="{CREAM}"/>'
        f'<path d="M98 44 c-4 -10 6 -18 12 -10 c6 -8 16 0 12 10 l-12 12z" fill="{CLAY2}" stroke="none"/>', size)


ILLS = {"crib": ill_crib, "cart": ill_cart}


# ------------------------------------------------------------------ cover visuals
COVER_TYPES = ["arch", "note", "days", "pair"]


def _pills(chips):
    if not chips:
        return "<div></div>"
    return '<div class="vchips">' + "".join(
        f'<div class="lfpill"><span class="d">{icon("check", 22, 3)}</span>{md(c)}</div>' for c in chips) + "</div>"


def lf_arch(v):
    ill = ILLS.get(v.get("ill", "crib"), ill_crib)(330)
    cap = f'<div class="acap">{md(v["caption"])}</div>' if v.get("caption") else ""
    tone = " sage" if v.get("tone") == "sage" else ""
    return (f'<div class="archwrap"><div class="arch{tone}"><div class="aill">{ill}</div>{cap}</div></div>', _pills(v.get("chips", [])))


def lf_note(v):
    rows = ""
    for it in v.get("items", []):
        it = it if isinstance(it, dict) else {"text": it}
        on = it.get("done", True)
        rows += (f'<div class="nr"><span class="tk{" on" if on else ""}">{icon("check", 24, 3.2) if on else ""}</span>'
                 f'<span>{md(it["text"])}</span></div>')
    return (f'<div class="notewrap"><div class="note"><div class="tape"></div><div class="nh"><span class="nl">{md(v.get("label","The list"))}</span>'
            f'<span class="ns">{md(v.get("sub",""))}</span></div>{rows}</div></div>')


def lf_days(v):
    pts = ""
    for i, p in enumerate(v.get("points", [])):
        on = " on" if p.get("on") else ""
        pts += (f'<div class="dp{on}"><div class="dw">{md(p.get("when",""))}</div><div class="dd"></div>'
                f'<div class="dl">{md(p.get("label",""))}</div></div>')
    return (f'<div class="days"><div class="dh"><span class="label">{md(v.get("label",""))}</span>'
            f'<span class="dm">{md(v.get("sub",""))}</span></div><div class="drow">{pts}</div></div>')


def lf_pair(v):
    return (f'<div class="pair"><div class="pc a"><span class="pt">{md(v.get("say_label","What they say"))}</span>'
            f'<div class="pq">"{md(v.get("say",""))}"</div></div>'
            f'<div class="parr">{icon("arrow", 34, 2.6)}</div>'
            f'<div class="pc b"><span class="pt">{md(v.get("do_label","What actually helps"))}</span><div class="pd">{md(v.get("do",""))}</div></div></div>')


def render_visual(k, v):
    return {"arch": lf_arch, "note": lf_note, "days": lf_days, "pair": lf_pair}[k](v)


def cta_illo():
    return f'<div class="lfcti"><div class="arch mini">{mark_svg(170)}</div></div>'


TABLE_COLS = [CLAY, SAGE, MOSS, CLAY2]


STAR = ("<svg width='{w}' height='{w}' viewBox='0 0 24 24'><path d='M12 1 L14.6 9.4 L23 12 L14.6 14.6 L12 23 "
        "L9.4 14.6 L1 12 L9.4 9.4Z' fill='{c}'/></svg>")
# Sherbet blob pairs for inner slides, rotated by slide index so every page carries pink, blue and butter
INNER = [("#FFE1EA", "#E3F3FD", "#F5A3BD"), ("#E3F3FD", "#FFF0CF", "#7CC4EE"), ("#FFF0CF", "#FFE1EA", "#FFA35C")]


def _star(x, y, w, c, side="left"):
    return f'<div class="deco" style="{side}:{x}px;top:{y}px">{STAR.format(w=w, c=c)}</div>'


def bg_deco(surface, template, vtype=None, idx=0):
    grain = ("<div class='deco' style=\"inset:0;opacity:.35;mix-blend-mode:multiply;background-image:url(&quot;data:image/svg+xml;utf8,"
             "<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/>"
             "<feColorMatrix values='0 0 0 0 .42  0 0 0 0 .33  0 0 0 0 .24  0 0 0 .09 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>&quot;)\"></div>")
    if surface == "dark":
        return (f'<div class="deco" style="right:-300px;top:-300px;width:760px;height:760px;border-radius:50%;background:#EB729A"></div>'
                f'<div class="deco" style="left:-200px;bottom:-260px;width:520px;height:520px;border-radius:50%;background:#D44C79"></div>'
                + _star(70, 200, 34, "#FFE27E", "right") + grain)
    if template == "cover":
        return (f'<div class="deco" style="right:-280px;top:-320px;width:820px;height:820px;border-radius:50%;background:#FFE1EA"></div>'
                f'<div class="deco" style="left:-180px;bottom:-200px;width:480px;height:480px;border-radius:50%;background:#E3F3FD;opacity:.8"></div>' + grain)
    big, small, star = INNER[idx % 3]
    return (f'<div class="deco" style="right:-260px;top:-280px;width:640px;height:640px;border-radius:50%;background:{big}"></div>'
            f'<div class="deco" style="left:-170px;bottom:-190px;width:420px;height:420px;border-radius:50%;background:{small}"></div>'
            + _star(64, 150, 30, star, "right") + _star(36, 1190, 22, "#FFE27E", "left") + grain)


def cover_css():
    return f"""
.visual{{position:relative}}
.vart{{position:absolute;left:0;right:0;bottom:0;transform-origin:50% 100%}}
.vchips{{display:flex;flex-direction:column;align-items:flex-start;gap:18px}}
.vside{{position:absolute;left:0;bottom:0;z-index:4}}
.lfpill{{display:flex;align-items:center;gap:14px;font:600 28px/1.2 Inter;padding:15px 26px 15px 15px;border-radius:999px;background:{CREAM};color:{INK};
  border:1.5px solid #F5E6C4;box-shadow:0 18px 34px -24px rgba(110,52,78,.45);white-space:nowrap}}
.lfpill .d{{flex:none;width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:{SAGE};color:{CREAM}}}
.archwrap{{display:flex;justify-content:flex-end}}
.arch{{width:440px;height:560px;border-radius:220px 220px 30px 30px;background:{BLUSH};display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;
  box-shadow:inset 0 0 0 10px rgba(255,255,255,.55)}}
.arch.sage{{background:{SAGESOFT}}}
.arch .aill{{margin-top:40px}}
.acap{{font:italic 500 34px/1.2 Lora;color:{INK};text-align:center;padding:0 40px;text-wrap:balance}}
.notewrap{{display:flex;justify-content:flex-end}}
.note{{position:relative;width:680px;background:{CREAM};border-radius:22px;padding:42px 46px 34px;transform:rotate(-1.6deg);
  box-shadow:0 40px 70px -40px rgba(110,52,78,.5),0 0 0 1.5px #F5E6C4}}
.note .tape{{position:absolute;top:-20px;left:50%;width:170px;height:44px;margin-left:-85px;background:rgba(255,226,126,.85);transform:rotate(2.5deg);border-radius:4px}}
.nh{{display:flex;justify-content:space-between;align-items:baseline;padding-bottom:18px;border-bottom:1.5px solid #F3E3BE;margin-bottom:8px}}
.nl{{font:italic 500 40px/1.1 Lora;color:{INK}}}
.ns{{font:700 21px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:{MUTED}}}
.nr{{display:flex;align-items:center;gap:20px;font:500 31px/1.25 Inter;color:{INK};padding:15px 0;border-bottom:1.5px dashed #F3E3BE}}
.nr:last-child{{border-bottom:0}}
.tk{{flex:none;width:44px;height:44px;border-radius:50%;display:grid;place-items:center;border:2.5px solid {SAGE};color:{CREAM}}}
.tk.on{{background:{SAGE};border-color:{SAGE}}}
.days{{background:{CREAM};border-radius:34px;padding:36px 40px 40px;box-shadow:0 34px 60px -40px rgba(110,52,78,.45),0 0 0 1.5px #F5E6C4}}
.dh{{display:flex;justify-content:space-between;align-items:baseline}}
.dh .label{{color:{MUTED}}}
.dm{{font:italic 500 30px/1 Lora;color:{CLAY}}}
.drow{{position:relative;display:flex;margin-top:30px}}
.drow:before{{content:"";position:absolute;left:12%;right:12%;top:68px;height:3px;border-radius:3px;background:repeating-linear-gradient(90deg,#F0CFA0 0 10px,transparent 10px 18px)}}
.dp{{flex:1 1 0;display:flex;flex-direction:column;align-items:center;text-align:center;position:relative;min-width:0}}
.dw{{font:italic 500 34px/1 Lora;color:{INK};height:44px}}
.dd{{width:30px;height:30px;border-radius:50%;background:{SAGE2};border:7px solid {CREAM};box-sizing:content-box;margin-top:4px}}
.dp.on .dd{{background:{CLAY};width:40px;height:40px;margin-top:-1px;box-shadow:0 0 0 8px rgba(212,76,121,.16)}}
.dl{{font:600 26px/1.25 Inter;color:{INK};margin-top:16px;text-wrap:balance;padding:0 10px}}
.pair{{display:flex;flex-direction:column;width:780px;margin-left:auto}}
.pc{{border-radius:30px;padding:30px 38px 34px}}
.pc.a{{background:#E3F3FD;transform:rotate(-1.4deg);width:640px}}
.pc.b{{background:{MOSS};transform:rotate(1deg);align-self:flex-end;width:700px;box-shadow:0 40px 70px -40px rgba(150,40,85,.7)}}
.pt{{display:inline-block;font:700 25px/1 Inter;letter-spacing:.14em;text-transform:uppercase;padding:10px 15px;border-radius:999px;margin-bottom:16px}}
.pc.a .pt{{background:{CREAM};color:{MUTED}}}.pc.b .pt{{background:{BLUSH};color:{INK}}}
.pq{{font:italic 500 44px/1.18 Lora;color:{MUTED};text-wrap:balance}}
.pd{{font:500 40px/1.2 Lora;color:{CREAM};text-wrap:balance}}
.parr{{flex:none;width:72px;height:72px;margin:-18px 0 -18px 300px;transform:rotate(90deg);z-index:2;border-radius:50%;background:{CLAY};color:{CREAM};display:grid;place-items:center;
  box-shadow:0 12px 24px -12px rgba(0,0,0,.4)}}
"""


def template_css():
    """Overrides appended after the shared base CSS, for Littlefold only (later rules win)."""
    return f"""
.display{{font-size:100px;line-height:1.08;font-weight:500}}
.h1{{font-size:70px;line-height:1.1;font-weight:500}}
.h2{{font-family:Lora;font-weight:600;letter-spacing:-.01em;font-size:40px}}
.display .hl,.h1 .hl,.qline .hl{{font-style:italic;font-weight:500}}
.brand{{font-family:Lora;font-weight:600;font-size:30px;letter-spacing:-.005em;gap:12px}}
.brand img{{width:56px;height:56px}}
.kick{{font:700 21px/1 Inter;letter-spacing:.18em;color:var(--kick)}}
.lead{{color:var(--muted)}}
.swipe{{background:{INK};color:{OAT};font:700 23px/1 Inter;letter-spacing:.02em}}
.prog i.on{{background:{CLAY}}}
.badge{{font-family:Lora;font-weight:600;font-size:44px;font-style:italic}}\n.step:nth-child(3n+2) .badge{{background:#FFD6E3}}.step:nth-child(3n+3) .badge{{background:#BFE4FA}}\n.ck:nth-child(3n+2) .box{{border-color:{CLAY2}}}.ck:nth-child(3n+2) .box.on{{background:{CLAY2}}}\n.ck:nth-child(3n+3) .box{{border-color:#7CC4EE}}.ck:nth-child(3n+3) .box.on{{background:#7CC4EE}}
.box{{border-radius:50%;border:2.5px solid {SAGE}}}
.box.on{{background:{SAGE};color:{CREAM}}}
.box.not{{border-style:solid;border-color:#F2A7BE;color:{CLAY};background:#FFE4EC}}
.box.warn{{color:{CLAY}}}.box.warn svg{{fill:#FFE4EC}}
.box.ex{{color:{CLAY};border:0;background:#FFF0D6}}
.ck{{border-bottom:1.5px dashed var(--line)}}
.ck .t{{font:500 34px/1.3 Inter}}
.cmp.a .tag{{background:#E3F3FD;color:{MUTED}}}
.cmp.b .tag{{background:{BLUSH};color:{INK}}}
.cmp .h2{{font-size:42px;font-weight:500}}
.cmp.a .h2{{font-style:italic;font-size:54px;line-height:1.15;color:var(--muted);word-spacing:normal;text-wrap:balance}}
.cmp.a .it .ic{{color:{CLAY}}}.cmp.b .it .ic{{color:{BLUSH}}}
.vs span{{background:{CLAY};color:{CREAM};box-shadow:0 10px 24px -10px rgba(0,0,0,.35)}}
.num{{font-family:Lora;font-weight:500;color:{CLAY};letter-spacing:-.03em;text-shadow:none}}
.num small{{font-style:italic}}
.chip{{background:{CREAM};color:{MUTED};border:1.5px solid #F3E3BE}}
.qmark{{font-family:Lora;color:{CLAY2};font-weight:500}}
.qline{{font-family:Lora;font-weight:500;font-size:74px;line-height:1.14;letter-spacing:-.015em}}
.track{{background:var(--surface)}}
.cta1{{background:{CREAM};color:{INK};box-shadow:0 34px 60px -30px rgba(0,0,0,.45)}}
.cta1 .ib{{border-radius:50%;background:{BLUSH};color:{INK}}}
.cta1 .k{{color:{CLAY}}}
.cta1 .tx{{font-family:Lora;font-weight:500;font-size:60px}}
.cta1 .tx b{{color:{CLAY};font-weight:600;font-style:italic}}
.cta2 .ic{{color:{BLUSH}}}
.lfcti{{display:flex;justify-content:center}}
.arch.mini{{width:230px;height:250px;border-radius:115px 115px 22px 22px;gap:0;background:{OAT};box-shadow:none}}
.arch.mini svg{{margin-top:20px}}
"""
