"""Steadfold carousel v2 - brand themes. Colours/fonts match the approved products exactly."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FONTS = ROOT / "assets" / "fonts"
MARKS = ROOT / "assets" / "marks"

THEMES = {
    "fullyfunded": dict(
        name="Fully Funded", handle="@fullyfundedhq", mark="fullyfunded.png", family="cobalt",
        head="'Inter Display'", head_w=800, head_ls="-0.03em",
        light=dict(bg="#F5F7FF", surface="#E8ECFF", card="#FFFFFF", ink="#0E1440", muted="#4B5178", line="#D9DEF5",
                   accent="#2B3FE0", accent2="#FF6A3D", soft="#FFB08F", kick="#C2410C",
                   hlA="#FF6A3D", hlA_ink="#0E1440", hlB="#FF6A3D", hlB_ink="#2B3FE0",
                   hlC="#2B3FE0", hlC_ink="#FFFFFF", hlC_border="0", hlC_shadow="#FF6A3D", hlC_radius="0.14em"),
        dark=dict(bg="#2B3FE0", surface="#3547E6", card="#FFFFFF", ink="#FFFFFF", muted="#D3D9FF", line="#5566EC",
                  accent="#FFFFFF", accent2="#FF6A3D", soft="#FFB08F", kick="#FFB08F",
                  hlA="#FF6A3D", hlA_ink="#0E1440", hlB="#FF6A3D", hlB_ink="#FFFFFF",
                  hlC="#FFFFFF", hlC_ink="#2B3FE0", hlC_border="0", hlC_shadow="#FF6A3D", hlC_radius="0.14em"),
        card_border="2px solid #DCE1FA", card_shadow="0 28px 50px -26px rgba(14,20,64,.30)", radius="28px",
        badge_bg="#2B3FE0", badge_ink="#FFFFFF", badge_border="0", badge_radius="24px",
        chip_bg="#E8ECFF", chip_ink="#2B3FE0",
        alt=dict(bg="#2B3FE0", ink="#FFFFFF", muted="#D3D9FF", border="0", shadow="0 28px 50px -24px rgba(43,63,224,.55)"),
    ),
    "lockedhour": dict(
        name="Locked Hour", handle="@lockedhourhq", mark="lockedhour.png", family="zine",
        head="'Inter Display'", head_w=900, head_ls="-0.035em",
        light=dict(bg="#FFF4E0", surface="#FFE9C2", card="#FFFFFF", ink="#141414", muted="#4D463E", line="#141414",
                   accent="#141414", accent2="#FF5CA8", soft="#FFD43B", kick="#141414",
                   hlA="#FFD43B", hlA_ink="#141414", hlB="#FF5CA8", hlB_ink="#141414",
                   hlC="#FF5CA8", hlC_ink="#141414", hlC_border="3px solid #141414", hlC_shadow="#141414", hlC_radius="0.08em"),
        dark=dict(bg="#141414", surface="#232323", card="#FFF4E0", ink="#FFF4E0", muted="#D9CFBE", line="#FFF4E0",
                  accent="#FFD43B", accent2="#FF5CA8", soft="#FFD43B", kick="#141414",
                  hlA="#FFD43B", hlA_ink="#141414", hlB="#FF5CA8", hlB_ink="#FFF4E0",
                  hlC="#FFD43B", hlC_ink="#141414", hlC_border="3px solid #141414", hlC_shadow="#FF5CA8", hlC_radius="0.08em"),
        card_border="3px solid #141414", card_shadow="8px 8px 0 #141414", radius="16px",
        badge_bg="#FFD43B", badge_ink="#141414", badge_border="3px solid #141414", badge_radius="50%",
        chip_bg="#FFFFFF", chip_ink="#141414",
        alt=dict(bg="#FFD43B", ink="#141414", muted="#3A3428", border="3px solid #141414", shadow="8px 8px 0 #141414"),
    ),
    "hourback": dict(
        name="Hourback", handle="@hourbackhq", mark="hourback.png", family="sunroom",
        head="'Poppins'", head_w=800, head_ls="-0.02em",
        light=dict(bg="#FFF8EF", surface="#FFEEDC", card="#FFFFFF", ink="#2A2238", muted="#655A6E", line="#F1E3CF",
                   accent="#5E54C9", accent2="#FF8A3D", soft="#FFC94D", kick="#B4490A",
                   hlA="#FFC94D", hlA_ink="#2A2238", hlB="#FF8A3D", hlB_ink="#5E54C9",
                   hlC="#FFC94D", hlC_ink="#2A2238", hlC_border="0", hlC_shadow="rgba(180,73,10,.22)", hlC_radius="0.22em"),
        dark=dict(bg="#5E54C9", surface="#6E64DD", card="#FFF8EF", ink="#FFFFFF", muted="#E3DFFF", line="#7D74E0",
                  accent="#FFC94D", accent2="#FF8A3D", soft="#FFC94D", kick="#FFC94D",
                  hlA="#FFC94D", hlA_ink="#2A2238", hlB="#FFC94D", hlB_ink="#FFC94D",
                  hlC="#FFC94D", hlC_ink="#2A2238", hlC_border="0", hlC_shadow="rgba(26,18,80,.35)", hlC_radius="0.22em"),
        card_border="2px solid #F3E6D3", card_shadow="0 28px 50px -26px rgba(94,84,201,.38)", radius="32px",
        badge_bg="#FF8A3D", badge_ink="#FFFFFF", badge_border="0", badge_radius="26px",
        chip_bg="#FFFFFF", chip_ink="#5E54C9",
        alt=dict(bg="#5E54C9", ink="#FFFFFF", muted="#E3DFFF", border="0", shadow="0 28px 50px -24px rgba(94,84,201,.6)"),
    ),
    # Littlefold (parenting, Oct 2026): "Sherbet" - butter paper, pink + orange + baby blue, deep ink, Lora display. Happy, new beginnings.
    "littlefold": dict(
        name="Littlefold", handle="@littlefoldhq", mark="littlefold.png", family="oat",
        head="'Lora'", head_w=500, head_ls="-0.018em",
        light=dict(bg="#FFF8E4", surface="#FFEFC8", card="#FFFFFF", ink="#2C2A3A", muted="#6B6676", line="#F3E3BE",
                   accent="#D9497A", accent2="#FFA35C", soft="#FFD6E3", kick="#C2386A",
                   hlA="#FFE27E", hlA_ink="#2C2A3A", hlB="#BFE4FA", hlB_ink="#2C2A3A",
                   hlC="#FFE27E", hlC_ink="#2C2A3A", hlC_border="0", hlC_shadow="rgba(212,76,121,.18)", hlC_radius="0.3em"),
        dark=dict(bg="#E25A86", surface="#EB729A", card="#FFFFFF", ink="#FFFFFF", muted="#FFE4EC", line="#F5A3BD",
                  accent="#FFD6E3", accent2="#FFD3AE", soft="#FFD6E3", kick="#FFD6E3",
                  hlA="#FFD6E3", hlA_ink="#2C2A3A", hlB="#FFD6E3", hlB_ink="#FFFFFF",
                  hlC="#FFD6E3", hlC_ink="#2C2A3A", hlC_border="0", hlC_shadow="rgba(0,0,0,.18)", hlC_radius="0.3em"),
        card_border="1.5px solid #F5E6C4", card_shadow="0 30px 60px -38px rgba(110,52,78,.34)", radius="34px",
        badge_bg="#FFE27E", badge_ink="#2C2A3A", badge_border="0", badge_radius="50%",
        chip_bg="#FFFFFF", chip_ink="#6B6676",
        alt=dict(bg="#E25A86", ink="#FFFFFF", muted="#FFE4EC", border="0", shadow="0 30px 60px -34px rgba(150,40,85,.55)"),
    ),
}

# Which slides default to the dark surface (matches each product's cover/back pages)
# Topic-matched free assets for cta.freebie = "auto" (keyed by the post's `topic`). No asset -> no freebie.
FUNNELS = {
    "fullyfunded": {"paycheque": "Paycheque Split Calculator"},
    "lockedhour": {"focus": "90-day lock-in tracker", "habits": "90-day lock-in tracker"},
    "hourback": {"prompts": "25 everyday AI prompts"},
    "littlefold": {},
}
for _t, _f in FUNNELS.items():
    THEMES[_t]["funnels"] = _f

DEFAULT_DARK = {"fullyfunded": {"cta"}, "lockedhour": {"cta"}, "hourback": {"cover", "cta"}, "littlefold": {"cta"}}

# Fixed typography scale (px). Same for every brand; only the heading face changes.
SCALE = dict(display=108, h1=74, h2=42, body=31, lead=34, label=22, small=24, num=250)
# Headline line-height per highlight style (each band is proven to fit inside this leading)
LEADING = {"A": 1.10, "B": 1.14, "C": 1.22}


def font_css(t=None):
    f = FONTS.as_uri()
    lora = ""
    if t == "littlefold":   # variable Lora (roman + italic); only loaded for Littlefold so other themes' HTML is unchanged
        lora = (f"@font-face{{font-family:'Lora';font-weight:400 700;font-style:normal;src:url({f}/Lora-Variable.ttf) format('truetype')}}"
                f"@font-face{{font-family:'Lora';font-weight:400 700;font-style:italic;src:url({f}/Lora-Italic-Variable.ttf) format('truetype')}}")
    faces = [("Inter", 400, "Inter-Regular"), ("Inter", 500, "Inter-Medium"), ("Inter", 600, "Inter-SemiBold"),
             ("Inter", 700, "Inter-Bold"), ("Inter", 800, "Inter-ExtraBold"), ("Inter", 900, "Inter-Black"),
             ("Inter Display", 800, "InterDisplay-ExtraBold"), ("Inter Display", 900, "InterDisplay-Black"),
             ("Poppins", "400", "Poppins-Regular"), ("Poppins", "500 600", "Poppins-Medium"), ("Poppins", "700 900", "Poppins-Bold")]
    return lora + "".join(f"@font-face{{font-family:'{n}';font-weight:{w};src:url({f}/{fn}.ttf) format('truetype')}}" for n, w, fn in faces)


def vars_css(t, surface):
    T = THEMES[t]; C = T[surface]
    keys = {k.replace("_", "-"): v for k, v in C.items()}
    out = ";".join(f"--{k}:{v}" for k, v in keys.items())
    if surface == "dark" and t != "lockedhour":
        extra = dict(card_border="0", card_shadow="0 30px 60px -30px rgba(0,0,0,.45)")
    elif surface == "dark":
        extra = dict(card_border="3px solid #141414", card_shadow="8px 8px 0 #FF5CA8")
    else:
        extra = {}
    for k in ("card_border", "card_shadow", "radius", "badge_bg", "badge_ink", "badge_border", "badge_radius", "chip_bg", "chip_ink"):
        out += f";--{k.replace('_', '-')}:{extra.get(k, T[k])}"
    return out
