"""Steadfold carousel v2 - slide templates. One HTML document per slide (1080x1350)."""
import hashlib, html, re, sys
from .themes import THEMES, DEFAULT_DARK, SCALE, LEADING, MARKS, ROOT, font_css, vars_css
from .visuals import clock_lh, sun_hb, icon
from .markup import md
from .covers import cover_css, render_cover_visual, visual_type
from . import littlefold as LF
from pathlib import Path

HL_JS = (Path(__file__).parent / "highlight.js").read_text()
TEMPLATES = ["cover", "big-number", "steps", "checklist", "compare", "output", "image", "table", "quote", "cta"]


# ------------------------------------------------------------------ images
def prep_image(post, src, crop=None):
    """Resolve a local PNG/JPG relative to the posts file, crop it ([x%, y%, w%, h%]) and return (file-uri, aspect w/h)."""
    from PIL import Image
    base = Path(post.get("_base") or ".")
    p = (base / src) if not Path(src).is_absolute() else Path(src)
    if not p.exists():
        raise FileNotFoundError(f"image not found: {p}")
    im = Image.open(p)
    if crop:
        x, y, w, h = crop
        W, H = im.size
        im = im.crop((round(W * x / 100), round(H * y / 100), round(W * (x + w) / 100), round(H * (y + h) / 100)))
    out = Path(post.get("_imgdir") or (ROOT / "build" / "_img")); out.mkdir(parents=True, exist_ok=True)
    key = hashlib.md5(f"{p.resolve()}|{p.stat().st_mtime}|{crop}".encode()).hexdigest()[:12]
    dst = out / f"img-{key}.png"
    if not dst.exists():
        im.convert("RGB").save(dst)
    return dst.resolve().as_uri(), im.size[0] / im.size[1]


# ------------------------------------------------------------------ CSS
def base_css(t, style):
    T = THEMES[t]; S = SCALE; A = T["alt"]; L = T["light"]
    zine = t == "lockedhour"; sun = t == "hourback"; cob = t == "fullyfunded"
    lightvars = ";".join(f"--{k.replace('_','-')}:{v}" for k, v in L.items())
    BEZEL = {"fullyfunded": "#0E1440", "lockedhour": "#141414", "hourback": "#2A2238"}.get(t, "#2B2622")
    DEVSH = "9px 9px 0 #FF5CA8" if zine else "0 40px 70px -30px rgba(10,6,40,.6)"
    D = dict(T["dark"]) if not zine else dict(L, hlA="#FF5CA8", hlB="#141414")
    altvars = ";".join(f"--{k.replace('_','-')}:{v}" for k, v in D.items() if k.startswith("hl"))
    return font_css(t) + cover_css(t) + f"""
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{width:1080px;height:1350px;overflow:hidden;background:#000}}
body{{font-family:Inter;-webkit-font-smoothing:antialiased}}
/* tabular figures ONLY on number elements (tnum also widens hyphens in Inter Display/Poppins) */
.num,.val,.amt,.count,.sh td.r,.cl b,.tot,.n,.a{{font-variant-numeric:tabular-nums}}
.slide{{position:absolute;inset:0;overflow:hidden;background:var(--bg);color:var(--ink);
  --head:{T['head']};--hw:{T['head_w']};--hls:{T['head_ls']};--lh:{LEADING[style]}}}
b{{font-weight:800;color:var(--ink)}}
.deco{{position:absolute;pointer-events:none;z-index:0}}
.hdr,.ftr,.main{{position:absolute;left:80px;right:80px;z-index:1}}
.hdr{{top:54px;height:64px;display:flex;align-items:center;justify-content:space-between}}
.brand{{display:flex;align-items:center;gap:14px;font-family:var(--head);font-weight:var(--hw);font-size:28px;letter-spacing:-.01em;color:var(--ink)}}
.brand img{{width:60px;height:60px;display:block}}
.count{{font:800 22px/1 Inter;letter-spacing:.08em;color:var(--muted)}}
.ftr{{bottom:50px;height:58px;display:flex;align-items:center;justify-content:space-between}}
.handle{{font:700 24px/1 Inter;color:var(--muted);letter-spacing:.01em}}
.prog{{display:flex;gap:8px;align-items:center}}.prog i{{display:block;width:26px;height:8px;border-radius:8px;background:var(--line);opacity:.8}}
.prog i.on{{width:52px;background:var(--accent2);opacity:1}}
.swipe{{display:flex;align-items:center;gap:12px;font:800 24px/1 Inter;padding:16px 20px 16px 28px;border-radius:999px;
  background:{'#FFD43B' if zine else ('#FFC94D' if sun else '#0E1440')};color:{'#141414' if zine else ('#2A2238' if sun else '#FFFFFF')};
  {'border:3px solid #141414;box-shadow:5px 5px 0 #141414;' if zine else ''}}}
.main{{top:166px;bottom:138px;display:flex;flex-direction:column}}
.kick{{align-self:flex-start;font:800 {S['label']}px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:var(--kick);
  {'background:#FFD43B;border:3px solid #141414;padding:11px 16px 10px;border-radius:8px;box-shadow:4px 4px 0 #141414;' if zine else ''}}}
.display,.h1,.h2{{font-family:var(--head);font-weight:var(--hw);letter-spacing:var(--hls);text-wrap:balance;color:var(--ink)}}
.display{{font-size:{S['display']}px;line-height:var(--lh);margin-top:30px}}
.h1{{font-size:{S['h1']}px;line-height:var(--lh);margin-top:26px}}
.h2{{font-size:{S['h2']}px;line-height:1.14}}
.lead{{font:500 {S['lead']}px/1.4 Inter;color:var(--muted);text-wrap:pretty;margin-top:26px;max-width:880px}}
.body{{font:500 {S['body']}px/1.42 Inter;color:var(--muted);text-wrap:pretty}}
.small{{font:600 {S['small']}px/1.4 Inter;color:var(--muted)}}
.label{{font:800 {S['label']}px/1 Inter;letter-spacing:.14em;text-transform:uppercase}}

/* highlights: the shape is drawn by highlight.js behind the text */
.hl{{-webkit-box-decoration-break:clone;box-decoration-break:clone;padding:0 {'.14em' if style=='C' else '.04em'};color:var(--hl{style}-ink)}}
.hl-host{{position:relative;isolation:isolate}}
.hl-layer{{position:absolute;left:0;top:0;width:0;height:0;z-index:-1;pointer-events:none}}
.bp{{display:inline-block;width:0;height:0}}
.hl.nw,.nb{{white-space:nowrap}}
.stk{{display:block;box-sizing:border-box;transform-origin:50% 60%}}

/* cards */
.card{{{lightvars};background:var(--card);color:var(--ink);border:{T['card_border']};border-radius:{T['radius']};box-shadow:{T['card_shadow']};position:relative}}
.dark .card{{border:{'3px solid #141414' if zine else '0'};box-shadow:{'8px 8px 0 #FF5CA8' if zine else '0 30px 60px -30px rgba(0,0,0,.45)'}}}
.card.alt{{--ink:{A['ink']};--muted:{A['muted']};background:{A['bg']};border:{A['border']};box-shadow:{A['shadow']};{altvars}}}
.stack{{flex:1 1 0;min-height:0;display:flex;flex-direction:column;gap:24px;margin-top:44px}}

/* steps (identical component for every step) */
.step{{flex:1 1 0;min-height:0;display:flex;align-items:center;gap:30px;padding:26px 36px 26px 30px}}
.badge{{flex:none;width:92px;height:92px;display:grid;place-items:center;font-family:var(--head);font-weight:var(--hw);font-size:46px;letter-spacing:-.02em;
  background:{T['badge_bg']};color:{T['badge_ink']};border:{T['badge_border']};border-radius:{T['badge_radius']};{'box-shadow:4px 4px 0 #141414;' if zine else ''}}}
.step .h2{{margin-bottom:8px}}

/* checklist */
.list{{flex:1 1 0;min-height:0;display:flex;flex-direction:column;padding:12px 40px}}
.ck{{flex:1 1 0;display:flex;align-items:center;gap:28px;border-bottom:{'3px solid #141414' if zine else '2px dashed var(--line)'}}}
.ck:last-child{{border-bottom:0}}
.box{{flex:none;width:58px;height:58px;display:grid;place-items:center;border-radius:{'10px' if not sun else '18px'};
  border:{'3px solid #141414' if zine else '3px solid var(--accent)'};color:#fff;background:transparent}}
.box.on{{background:{'#FF5CA8' if zine else 'var(--accent)'};color:{'#141414' if zine else '#fff'}}}
.box.not{{border-style:dashed;color:{'#D6246E' if zine else ('#C2410C' if cob else '#B4490A')};border-color:{'#141414' if zine else 'var(--muted)'}}}
.box.warn{{border:0;background:transparent;color:{'#141414' if zine else ('#C2410C' if cob else '#B4490A')}}}
.box.warn svg{{fill:{'#FFD43B' if zine else ('#FFD9C9' if cob else '#FFEEDC')}}}
.box.ex{{border:0;color:{'#D6246E' if zine else 'var(--accent)'}}}
.ck.not .t{{color:var(--muted)}}
.ck .t{{font:650 36px/1.28 Inter;color:var(--ink);text-wrap:pretty}}

/* compare */
.cmp{{flex:1 1 0;min-height:0;padding:34px 40px;display:flex;flex-direction:column;justify-content:center;gap:18px}}
.tag{{align-self:flex-start;font:800 {S['label']}px/1 Inter;letter-spacing:.14em;text-transform:uppercase;padding:11px 16px 10px;border-radius:{'8px' if zine else '999px'};
  background:var(--chipbg,#0000);}}
.cmp.a .tag{{background:{'#FFFFFF' if zine else ('#E8ECFF' if cob else '#FFEEDC')};color:{'#141414' if zine else ('#4B5178' if cob else '#B4490A')};{'border:3px solid #141414;' if zine else ''}}}
.cmp.b .tag{{background:{'#FF5CA8' if zine else ('#FF6A3D' if cob else '#FFC94D')};color:{'#141414' if zine else ('#FFFFFF' if cob else '#2A2238')};{'border:3px solid #141414;' if zine else ''}}}
.cmp .h2{{font-size:40px}}
.items{{display:flex;flex-direction:column;gap:18px}}
.it{{display:flex;align-items:center;gap:20px;font:600 36px/1.3 Inter;color:var(--ink)}}
.it .ic{{flex:none}}
.cmp.a .it{{color:var(--muted)}}.cmp.a .it .ic{{color:{'#D6246E' if zine else ('#C2410C' if cob else '#B4490A')}}}
.cmp.b .it .ic{{color:{'#141414' if zine else ('#FFB08F' if cob else '#FFC94D')}}}
.vs{{position:relative;height:0;z-index:3;display:flex;justify-content:center}}
.vs span{{position:absolute;top:-46px;width:68px;height:68px;border-radius:50%;display:grid;place-items:center;transform:rotate(90deg);
  background:{'#FFD43B' if zine else ('#FF6A3D' if cob else '#FF8A3D')};color:{'#141414' if zine else '#fff'};{'border:3px solid #141414;box-shadow:4px 4px 0 #141414;' if zine else 'box-shadow:0 10px 24px -8px rgba(0,0,0,.35);'}}}

/* output / screenshot card */
.win{{flex:1 1 0;min-height:0;display:flex;flex-direction:column;overflow:hidden;padding:0}}
.bar{{flex:none;height:64px;display:flex;align-items:center;gap:10px;padding:0 28px;border-bottom:{'3px solid #141414' if zine else '2px solid var(--line)'};
  background:{'#FFD43B' if zine else ('#E8ECFF' if cob else '#FFEEDC')}}}
.bar i{{width:16px;height:16px;border-radius:50%;background:var(--ink);opacity:.22;display:block}}
.bar .label{{margin-left:12px;color:var(--ink);opacity:.8;font-size:21px}}
.wb{{flex:1 1 0;min-height:0;padding:30px 34px;display:flex;flex-direction:column;gap:22px;justify-content:space-evenly}}
.composer{{flex:none;margin:0 26px 26px;height:76px;border-radius:{'10px' if zine else '999px'};display:flex;align-items:center;justify-content:space-between;padding:0 12px 0 28px;
  font:500 26px Inter;color:var(--muted);border:{'3px solid #141414' if zine else '2px solid var(--line)'};background:{'#FFFFFF' if zine else ('#F5F7FF' if cob else '#FFF8EF')}}}
.composer span.go{{width:54px;height:54px;border-radius:{'8px' if zine else '50%'};display:grid;place-items:center;background:{'#FF5CA8' if zine else 'var(--accent)'};color:{'#141414' if zine else '#fff'};{'border:3px solid #141414;' if zine else ''}}}
.who{{font:800 21px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-bottom:12px}}
.bub{{font:500 29px/1.45 Inter;color:var(--ink);background:{'#FFF4E0' if zine else ('#F5F7FF' if cob else '#FFF8EF')};
  border-left:{'6px solid #FF5CA8' if zine else ('6px solid #2B3FE0' if cob else '6px solid #FF8A3D')};border-radius:{'6px' if zine else '14px'};padding:20px 24px;text-wrap:pretty}}
.ph{{color:{'#D6246E' if zine else ('#C2410C' if cob else '#B4490A')};font-weight:700}}
.ans{{display:flex;flex-direction:column;gap:12px}}
.ln{{display:flex;gap:16px;align-items:baseline;font:500 29px/1.4 Inter;color:var(--ink)}}
.ln .n{{flex:none;width:44px;height:44px;border-radius:{'8px' if zine else '12px'};display:grid;place-items:center;font:800 22px Inter;transform:translateY(8px);
  background:{'#FFD43B' if zine else 'var(--accent)'};color:{'#141414' if zine else '#fff'};{'border:3px solid #141414;' if zine else ''}}}
table.sh{{width:100%;height:100%;border-collapse:collapse;font:500 30px/1.2 Inter}}
.sh th{{font:800 21px/1 Inter;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);text-align:left;padding:0 16px 14px}}
.sh td{{padding:18px 16px;border-top:2px solid var(--line);color:var(--ink)}}
.sh td.r,.sh th.r{{text-align:right}}
.sh tr.on td{{background:{'#FFD43B' if zine else ('#FFD9C9' if cob else '#FFEEDC')};font-weight:800}}
.calc{{flex:1 1 0;display:flex;flex-direction:column;justify-content:space-evenly}}
.cl{{display:flex;justify-content:space-between;align-items:baseline;font:500 34px/1.3 Inter;padding:14px 0;border-bottom:2px dashed var(--line)}}
.cl b{{font-weight:800}}
.cl.tot{{border-bottom:0;padding-top:20px;font:800 34px Inter}}.cl.tot b{{font-family:var(--head);font-size:56px;color:var(--accent);letter-spacing:-.02em}}

/* table / mini chart */
.chart{{flex:1 1 0;min-height:0;padding:30px 40px;display:flex;flex-direction:column;justify-content:space-evenly}}
.row .top{{display:flex;justify-content:space-between;align-items:baseline;gap:20px}}
.row .lab{{font:700 32px/1.25 Inter;color:var(--ink)}}.row .lab span{{display:block;font:500 24px/1.3 Inter;color:var(--muted);margin-top:4px}}
.row .val{{font-family:var(--head);font-weight:var(--hw);font-size:46px;letter-spacing:-.02em;color:var(--ink)}}
.track{{height:24px;border-radius:{'6px' if zine else '24px'};background:{'#FFF4E0' if zine else 'var(--surface)'};margin-top:14px;overflow:hidden;{'border:3px solid #141414;' if zine else ''}}}
.fill{{height:100%;border-radius:inherit}}
.caption{{margin-top:22px}}

/* big number */
.bign{{flex:1 1 0;min-height:0;display:flex;flex-direction:column;justify-content:center;padding:44px 56px}}
.num{{font-family:var(--head);font-weight:var(--hw);font-size:{S['num']}px;line-height:.9;letter-spacing:-.045em;color:{'#141414' if zine else 'var(--accent)'};
  {'text-shadow:8px 8px 0 #FF5CA8;' if zine else ''}}}
.num small{{font-size:.42em;letter-spacing:-.02em;margin-left:.06em}}
.bign .h2{{margin-top:26px}}.bign .body{{margin-top:14px}}
.chips{{display:flex;flex-wrap:wrap;gap:14px}}
.chip{{font:700 24px/1 Inter;padding:15px 22px;border-radius:{'8px' if zine else '999px'};background:var(--chip-bg,{T['chip_bg']});color:{T['chip_ink']};
  {'border:3px solid #141414;box-shadow:4px 4px 0 #141414;' if zine else ('border:2px solid #DCE1FA;' if cob else 'border:2px solid #F3E6D3;')}}}

/* quote */
.qwrap{{flex:1 1 0;min-height:0;display:flex;flex-direction:column;justify-content:center;padding:56px 60px;margin-top:44px}}
.qmark{{font-family:var(--head);font-weight:var(--hw);font-size:200px;line-height:.7;height:110px;color:{'#FF5CA8' if zine else ('#FF6A3D' if cob else '#FF8A3D')}}}
.qline{{font-family:var(--head);font-weight:var(--hw);letter-spacing:var(--hls);font-size:88px;line-height:var(--lh);text-wrap:balance;color:var(--ink)}}
.qby{{margin-top:34px;display:flex;align-items:center;gap:16px}}
.qby img{{width:52px;height:52px}}

/* cta */
.acts{{flex:1 1 0;min-height:0;display:flex;flex-direction:column;gap:22px;margin-top:46px}}
.act{{flex:1 1 0;min-height:0;display:flex;align-items:center;gap:30px;padding:0 36px;border-radius:{T['radius']};
  {'background:#FFF4E0;color:#141414;border:3px solid #141414;box-shadow:8px 8px 0 #FF5CA8;' if zine else ('background:rgba(255,255,255,.10);border:2px solid rgba(255,255,255,.20);' if cob else 'background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.22);')}}}
.act .ib{{flex:none;width:88px;height:88px;border-radius:{'50%' if zine else ('24px' if cob else '28px')};display:grid;place-items:center;
  background:{'#FFD43B' if zine else ('#FF6A3D' if cob else '#FFC94D')};color:{'#141414' if zine else ('#FFFFFF' if cob else '#2A2238')};{'border:3px solid #141414;' if zine else ''}}}
.act .tx{{text-wrap:balance;font:500 36px/1.3 Inter;color:{'#141414' if zine else 'var(--ink)'};text-wrap:pretty}}
.act .tx b{{color:inherit}}
.prod{{flex:none;margin-top:30px;display:flex;align-items:center;gap:18px;padding:24px 30px;border-radius:{'12px' if zine else '999px'};font:800 30px/1.2 Inter;
  background:{'#FF5CA8' if zine else ('#FFFFFF' if cob else '#FFC94D')};color:{'#141414' if zine else ('#2B3FE0' if cob else '#2A2238')};{'border:3px solid #141414;box-shadow:6px 6px 0 #FFD43B;' if zine else ''}}}

.ctatop{{display:flex;align-items:center;gap:30px}}.ctatop .ctl{{flex:1 1 0;min-width:0}}.ctatop .cti{{flex:none;width:250px;height:250px;display:grid;place-items:center}}
.cti svg,.cti img{{width:250px;height:auto;display:block}}
/* cover visuals (shared) */
.visual{{flex:1 1 0;min-height:0;margin-top:40px;position:relative}}
.split{{padding:36px 40px}}
.split .hd{{display:flex;justify-content:space-between;align-items:baseline}}
.split .tot{{font-family:var(--head);font-weight:var(--hw);font-size:60px;letter-spacing:-.03em;color:var(--ink)}}
.sbar{{display:flex;height:76px;border-radius:20px;overflow:hidden;margin-top:22px;gap:6px}}
.sbar div{{display:flex;align-items:center;padding-left:20px;font:800 26px Inter;color:#fff}}
.tiles{{display:flex;gap:16px;margin-top:20px}}
.tile{{flex:1 1 0;padding:18px 20px;border-radius:20px;background:#F5F7FF}}
.tile .nm{{display:flex;align-items:center;gap:10px;font:700 22px/1 Inter;color:var(--muted)}}
.tile .nm i{{width:14px;height:14px;border-radius:4px;display:block}}
.tile .amt{{font-family:var(--head);font-weight:var(--hw);font-size:44px;letter-spacing:-.02em;margin-top:10px;color:var(--ink)}}
.sticker{{font:900 25px/1 'Inter Display';letter-spacing:.05em;text-transform:uppercase;padding:16px 22px;border-radius:999px;border:3px solid #141414;box-shadow:5px 5px 0 #141414;white-space:nowrap;color:#141414}}

/* image slot: device frames sized with container-query units so they always fit their slot */
.imgfit{{flex:1 1 0;min-height:0;min-width:0;container-type:size;display:flex;align-items:center;justify-content:center;padding-bottom:26px}}
.devwrap{{position:relative}}
.dev{{position:relative}}
.dev .scr{{position:relative;overflow:hidden;background:#fff}}
.dev .scr img{{width:100%;height:100%;object-fit:cover;display:block}}
.dev.phone{{width:min(100cqw,calc(100cqh * 9 / 19.5 - 2px));aspect-ratio:9/19.5;border-radius:56px;padding:14px;background:{BEZEL};box-shadow:{DEVSH}}}
.dev.phone .scr{{width:100%;height:100%;border-radius:43px}}
.dev.phone .notch{{position:absolute;top:26px;left:50%;width:30%;height:26px;transform:translateX(-50%);border-radius:20px;background:{BEZEL};z-index:2}}
.dev.laptop{{width:min(100cqw,calc(100cqh * 16 / 11.4))}}
.dev.laptop .lid{{background:{BEZEL};border-radius:24px 24px 6px 6px;padding:16px 16px 20px;box-shadow:{DEVSH}}}
.dev.laptop .scr{{aspect-ratio:16/10;border-radius:8px}}
.dev.laptop .base{{height:24px;margin:0 -5%;border-radius:0 0 22px 22px;background:{'#141414' if zine else 'linear-gradient(#DCDDE6,#B7BACB)'}}}
.dev.card{{padding:16px}}
.dev.card .scr{{border-radius:{'8px' if zine else '18px'};width:100%;height:100%}}
.dev.card .scr img{{object-fit:contain;background:#fff}}
.capchip{{position:absolute;left:22px;bottom:-22px;z-index:4;transform:rotate(-2deg);white-space:nowrap;font:800 22px/1 Inter;letter-spacing:.06em;text-transform:uppercase;padding:13px 18px;border-radius:{'8px' if zine else '999px'};
  background:{'#FFD43B' if zine else ('#FF6A3D' if cob else '#FFC94D')};color:{'#141414' if zine else ('#FFFFFF' if cob else '#2A2238')};{'border:3px solid #141414;box-shadow:4px 4px 0 #141414;' if zine else 'box-shadow:0 10px 22px -10px rgba(0,0,0,.45);'}}}
.ring{{position:absolute;width:92px;height:92px;margin:-46px 0 0 -46px;border-radius:50%;border:7px solid {'#FF5CA8' if zine else ('#FF6A3D' if cob else '#FF8A3D')};box-shadow:0 0 0 6px rgba(255,138,61,.25);z-index:3}}
.imgrow{{flex:1 1 0;min-height:0;display:flex;gap:40px;align-items:stretch}}
.imgrow .imgfit{{flex:0 0 400px}}
.pts{{flex:1 1 0;min-width:0;display:flex;flex-direction:column;justify-content:center;gap:24px}}
.pt{{padding:26px 28px;display:flex;gap:18px;align-items:flex-start}}
.pt .badge{{width:56px;height:56px;font-size:28px;border-radius:{'50%' if zine else '16px'}}}
.pt .tx{{font:600 29px/1.3 Inter;color:var(--ink);text-wrap:pretty}}

/* single CTA */
.cta1{{flex:1 1 0;min-height:0;margin-top:44px;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;gap:34px;padding:50px 56px;border-radius:{T['radius']};
  {'background:#FFF4E0;color:#141414;border:3px solid #141414;box-shadow:10px 10px 0 #FF5CA8;' if zine else ('background:#FFFFFF;color:#0E1440;box-shadow:0 34px 60px -30px rgba(0,0,0,.5);' if cob else 'background:#FFF8EF;color:#2A2238;box-shadow:0 34px 60px -30px rgba(10,6,40,.6);')}}}
.cta1 .ib{{flex:none;width:136px;height:136px;border-radius:{'50%' if zine else '34px'};display:grid;place-items:center;
  background:{'#FFD43B' if zine else ('#FF6A3D' if cob else '#FFC94D')};color:{'#141414' if zine else ('#FFFFFF' if cob else '#2A2238')};{'border:3px solid #141414;' if zine else ''}}}
.cta1 .tb{{min-width:0;width:100%}}
.cta1 .k{{font:800 22px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:{'#D6246E' if zine else ('#C2410C' if cob else '#B4490A')};margin-bottom:16px}}
.cta1 .tx{{font-family:var(--head);font-weight:600;font-size:62px;line-height:1.12;letter-spacing:-.02em;text-wrap:balance;color:inherit}}
.cta1 .tx b{{color:{'#D6246E' if zine else ('#2B3FE0' if cob else '#5E54C9')};font-weight:var(--hw)}}
.cta1 .fn{{font-family:var(--head);font-weight:var(--hw);font-size:64px;line-height:1.08;letter-spacing:var(--hls);text-wrap:balance;color:inherit}}
.cta1 .fl{{font:600 30px/1.3 Inter;margin-top:16px;opacity:.85;text-wrap:balance}}
.cta2{{flex:none;margin-top:34px;display:flex;align-items:center;gap:16px;font:600 30px/1.3 Inter;color:var(--muted);max-width:100%}}
.cta2 .ic{{flex:none;color:{'#FFD43B' if zine else ('#FFB08F' if cob else '#FFC94D')}}}
.cta2 span{{text-wrap:balance}}
.cta2 b{{color:var(--ink)}}
"""


# ------------------------------------------------------------------ frame
def frame(t, style, surface, idx, n, inner, deco="", template=""):
    T = THEMES[t]
    mark = (MARKS / T["mark"]).as_uri()
    if template == "cover":
        right = f'<div class="swipe" data-box>Swipe {icon("arrow", 28, 2.8)}</div>'
    else:
        right = '<div class="prog">' + "".join(f'<i class="{"on" if k == idx else ""}"></i>' for k in range(n)) + "</div>"
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{base_css(t, style)}{LF.template_css() if t == "littlefold" else ""}</style></head>
<body data-hl="{style}" data-theme="{t}" data-template="{template}">
<div class="slide {surface}" style="{vars_css(t, surface)}">
{deco}
<div class="hdr" data-box><div class="brand"><img src="{mark}" alt="">{T['name']}</div><div class="count">{idx+1:02d} / {n:02d}</div></div>
<div class="main">{inner}</div>
<div class="ftr"><div class="handle" data-box>{T['handle']}</div>{right}</div>
</div><script>{HL_JS}</script></body></html>"""


def head(f, cls="h1"):
    out = f'<div class="kick" data-box>{md(f["kicker"])}</div>' if f.get("kicker") else ""
    if f.get("title"):
        out += f'<h1 class="{cls}" data-box>{md(f["title"])}</h1>'
    if f.get("lead"):
        out += f'<p class="lead" data-box>{md(f["lead"])}</p>'
    return out


def bg_deco(t, surface, template, vtype=None, idx=0):
    """Purposeful background shapes per brand (all full-bleed decoration, never behind body text blocks)."""
    if t == "littlefold":
        return LF.bg_deco(surface, template, vtype, idx)
    if t == "fullyfunded":
        if surface == "dark":
            return ('<div class="deco" style="right:-260px;top:-200px;width:720px;height:720px;border-radius:50%;background:#3547E6"></div>'
                    '<div class="deco" style="left:-160px;bottom:-220px;width:460px;height:460px;border-radius:50%;background:#2436C9"></div>')
        if template == "cover" and vtype != "bignum":
            return ('<div class="deco" style="right:-300px;bottom:-330px;width:980px;height:980px;border-radius:50%;background:#2B3FE0"></div>'
                    '<div class="deco" style="left:-120px;bottom:180px;width:260px;height:260px;border-radius:50%;background:#FFD9C9;opacity:.7"></div>')
        return ('<div class="deco" style="right:-240px;top:-240px;width:620px;height:620px;border-radius:50%;background:#E8ECFF"></div>'
                '<div class="deco" style="left:-140px;bottom:-160px;width:380px;height:380px;border-radius:50%;background:#FFD9C9;opacity:.55"></div>')
    if t == "lockedhour":
        dot = "rgba(255,244,224,.10)" if surface == "dark" else "rgba(20,20,20,.13)"
        return f'<div class="deco" style="inset:0;background-image:radial-gradient({dot} 2.2px,transparent 2.6px);background-size:30px 30px;background-position:15px 15px"></div>'
    # hourback
    if surface == "dark":
        return ('<div class="deco" style="inset:0;background:linear-gradient(160deg,#6E64DD 0%,#5E54C9 45%,#4A40B8 100%)"></div>'
                '<div class="deco" style="right:-220px;top:-260px;width:700px;height:700px;border-radius:50%;background:radial-gradient(rgba(150,140,255,.45),transparent 65%)"></div>')
    return ('<div class="deco" style="right:-300px;top:-320px;width:860px;height:860px;border-radius:50%;background:radial-gradient(#FFC94D55,transparent 62%)"></div>'
            '<div class="deco" style="left:-260px;bottom:-300px;width:760px;height:760px;border-radius:50%;background:radial-gradient(#FFEEDC,transparent 65%)"></div>')


# ------------------------------------------------------------------ templates
def t_cover(t, f, post):
    v = f.get("visual") or {}
    img = None
    if v.get("img"):
        img, _ = prep_image(post, v["img"], v.get("crop"))
    art = render_cover_visual(t, v, post.get("id", ""), (MARKS / THEMES[t]["mark"]).as_uri(), img)
    h = head(f, "display")
    if visual_type(t, f) in ("phone", "receipt"):   # leave a free column on the right so the phone can stand tall beside the lead
        h = h.replace('<p class="lead" data-box>', '<p class="lead" data-box style="max-width:540px">')
    return h + art


def t_bignum(t, f, post=None):
    num = md(f["number"]) + (f'<small>{md(f["unit"])}</small>' if f.get("unit") else "")
    chips = "".join(f'<span class="chip">{md(c)}</span>' for c in f.get("chips", []))
    return (head(f) + f'<div class="stack"><div class="card bign" data-box><div class="num">{num}</div>'
            f'<div class="h2">{md(f.get("label",""))}</div><p class="body">{md(f.get("body",""))}</p></div>'
            + (f'<div class="chips" data-box>{chips}</div>' if chips else "") + "</div>")


def t_steps(t, f, post=None):
    steps = "".join(f'<div class="card step" data-box><div class="badge">{i+1}</div><div><div class="h2">{md(s["title"])}</div>'
                    f'<p class="body">{md(s.get("body",""))}</p></div></div>' for i, s in enumerate(f["steps"]))
    return head(f) + f'<div class="stack">{steps}</div>'


CK_ICONS = {"done": ("on", "check"), "todo": ("", None), "not": ("not", "x"), "warn": ("warn", "warn"), "example": ("ex", "arrow")}


def t_checklist(t, f, post=None):
    """mode: todo (empty boxes, default) | checks (ticks) | examples (arrow bullets, no box) | mixed (per-item state).
    item: "text" or {text, state: done|todo|not|warn} (legacy {text, done: bool} and all_done still work)."""
    mode = f.get("mode") or ("checks" if f.get("all_done") else "mixed")
    rows = ""
    for it in f["items"]:
        it = it if isinstance(it, dict) else {"text": it}
        st = it.get("state") or ("done" if it.get("done") else None)
        if not st:
            st = {"checks": "done", "examples": "example"}.get(mode, "todo")
        if mode == "examples":
            st = "example"
        cls, ic = CK_ICONS[st]
        rows += (f'<div class="ck {cls}"><span class="box {cls}">{icon(ic, 34 if st != "warn" else 46, 3.2) if ic else ""}</span>'
                 f'<div class="t">{md(it["text"])}</div></div>')
    return head(f) + f'<div class="stack"><div class="card list" data-box>{rows}</div></div>'


def t_compare(t, f, post=None):
    mode = f.get("mode", "before-after")
    la, lb = ("Before", "After") if mode == "before-after" else ("Myth", "Truth")
    def side(s, cls, ic):
        s = s or {}
        lab = md(s.get("label") or (la if cls == "a" else lb))
        if s.get("items"):
            body = '<div class="items">' + "".join(f'<div class="it">{icon(ic, 36, 3)}<span>{md(x)}</span></div>' for x in s["items"]) + "</div>"
        else:
            body = f'<div class="h2">{md(s.get("text",""))}</div>'
        return f'<div class="card cmp {cls}{" alt" if cls=="b" else ""}" data-box><div class="tag">{lab}</div>{body}</div>'
    return (head(f) + '<div class="stack">' + side(f.get("left"), "a", "x")
            + f'<div class="vs"><span>{icon("arrow", 34, 3)}</span></div>' + side(f.get("right"), "b", "check") + "</div>")


def t_output(t, f, post=None):
    k = f.get("kind", "chat"); body = ""
    if k == "chat":
        lines = "".join(f'<div class="ln"><span class="n">{i+1}</span><span>{md(x)}</span></div>' for i, x in enumerate(f.get("reply", [])))
        body = (f'<div><div class="who">{md(f.get("you_label","You"))}</div><div class="bub">{md(f["prompt"], ph=True)}</div></div>'
                f'<div><div class="who">{md(f.get("ai_label","AI reply"))}</div><div class="ans">{lines}</div></div>')
    elif k == "sheet":
        cols = f["columns"]
        num = [i for i in range(1, len(cols)) if all(re.fullmatch(r"[\s$%0-9.,+\-–a-z]*", str(r[i])) and re.search(r"\d", str(r[i])) for r in f["rows"])]
        th = "".join(f'<th class="{"r" if i in num else ""}">{md(c)}</th>' for i, c in enumerate(cols))
        tr = "".join(f'<tr class="{"on" if r == f.get("highlight_row") else ""}">' + "".join(f'<td class="{"r" if i in num else ""}">{md(c)}</td>' for i, c in enumerate(row)) + "</tr>"
                     for r, row in enumerate(f["rows"]))
        body = f'<table class="sh"><tr>{th}</tr>{tr}</table>'
    elif k == "image":
        uri, ar = prep_image(post, f["src"], f.get("crop"))
        ring = f'<span class="ring" style="left:{f["ring"][0]}%;top:{f["ring"][1]}%"></span>' if f.get("ring") else ""
        cap = f'<span class="capchip" data-box>{md(f["caption"])}</span>' if f.get("caption") else ""
        body = (f'<div class="imgfit"><div class="devwrap" style="width:min(100cqw,calc(100cqh * {ar:.4f}));aspect-ratio:{ar:.4f}">'
                f'<div class="scr" style="width:100%;height:100%;border-radius:12px;overflow:hidden;position:relative">'
                f'<img src="{uri}" alt="" style="width:100%;height:100%;object-fit:contain;display:block">{ring}</div>{cap}</div></div>')
    else:  # calc
        rows = "".join(f'<div class="cl"><span>{md(a)}</span><b>{md(b)}</b></div>' for a, b in f["lines"])
        if f.get("total"):
            rows += f'<div class="cl tot"><span>{md(f["total"][0])}</span><b>{md(f["total"][1])}</b></div>'
        body = f'<div class="calc">{rows}</div>'
    comp = (f'<div class="composer"><span>{md(f.get("composer","Ask a follow-up"))}</span><span class="go">{icon("arrow", 28, 3)}</span></div>' if k == "chat" else "")
    win = (f'<div class="card win" data-box><div class="bar"><i></i><i></i><i></i><span class="label">{md(f.get("app","AI chat"))}</span></div>'
           f'<div class="wb{" wimg" if k == "image" else ""}">{body}</div>{comp}</div>')
    note = f'<p class="small" data-box>{md(f["note"])}</p>' if f.get("note") else ""
    return head(f) + f'<div class="stack">{win}{note}</div>'


def t_table(t, f, post=None):
    cols = {"fullyfunded": ["#2B3FE0", "#FF6A3D", "#0E1440", "#FFB08F"], "lockedhour": ["#FF5CA8", "#FFD43B", "#141414", "repeating-linear-gradient(135deg,#141414 0 7px,#FFD43B 7px 15px)"],
            "hourback": ["#5E54C9", "#FF8A3D", "#FFC94D", "#2A2238"], "littlefold": LF.TABLE_COLS}[t]
    rows = ""
    for i, r in enumerate(f["rows"]):
        sub = f'<span>{md(r["note"])}</span>' if r.get("note") else ""
        rows += (f'<div class="row"><div class="top"><div class="lab">{md(r["label"])}{sub}</div><div class="val">{md(r["value"])}</div></div>'
                 f'<div class="track"><div class="fill" style="width:{max(2,min(100,float(r.get("pct",0))))}%;background:{cols[i%4]}"></div></div></div>')
    cap = f'<p class="small caption" data-box>{md(f["caption"])}</p>' if f.get("caption") else ""
    return head(f) + f'<div class="stack"><div class="card chart" data-box>{rows}</div>{cap}</div>'


def t_quote(t, f, post=None):
    T = THEMES[t]
    by = md(f.get("by") or f"A {T['name']} rule")
    return (head({"kicker": f.get("kicker")}) +
            f'<div class="card qwrap" data-box><div class="qmark">&ldquo;</div><div class="qline">{md(f["line"])}</div>'
            f'<div class="qby"><img src="{(MARKS/T["mark"]).as_uri()}" alt=""><span class="small" style="font-weight:700">{by}</span></div></div>')


def t_image(t, f, post):
    """A real screenshot/output: local PNG/JPG, optional crop, in a phone / laptop / plain card frame."""
    frame_ = f.get("frame", "card")
    uri, ar = prep_image(post, f["src"], f.get("crop"))
    fx, fy = (f.get("focus") or [50, 0])
    ring = f'<span class="ring" style="left:{f["ring"][0]}%;top:{f["ring"][1]}%"></span>' if f.get("ring") else ""
    img = f'<img src="{uri}" alt="" style="object-position:{fx}% {fy}%">'
    cap = f'<span class="capchip" data-box>{md(f["caption"])}</span>' if f.get("caption") else ""
    if frame_ == "phone":
        dev = f'<div class="devwrap"><div class="dev phone" data-box><div class="scr">{img}{ring}</div><div class="notch"></div></div>{cap}</div>'
    elif frame_ == "laptop":
        dev = f'<div class="devwrap"><div class="dev laptop" data-box><div class="lid"><div class="scr">{img}{ring}</div></div><div class="base"></div></div>{cap}</div>'
    else:
        dev = (f'<div class="devwrap" style="width:min(100cqw,calc((100cqh - 32px) * {ar:.4f} + 32px))"><div class="card dev" data-box style="aspect-ratio:auto">'
               f'<div class="scr" style="aspect-ratio:{ar:.4f}">{img}{ring}</div></div>{cap}</div>')
    pts = f.get("points") or []
    if pts and frame_ == "phone":
        cards = "".join(f'<div class="card pt" data-box><span class="badge">{i+1}</span><div class="tx">{md(p)}</div></div>' for i, p in enumerate(pts))
        body = f'<div class="imgrow"><div class="pts">{cards}</div><div class="imgfit">{dev}</div></div>'
    else:
        body = f'<div class="imgfit">{dev}</div>'
    note = f'<p class="small" data-box style="margin-top:8px">{md(f["note"])}</p>' if f.get("note") else ""
    return head(f) + f'<div class="stack">{body}{note}</div>'


def resolve_freebie(t, f, post):
    fb = f.get("freebie")
    if fb == "auto":
        name = THEMES[t].get("funnels", {}).get(post.get("topic") or "")
        fb = {"name": name} if name else None
    if isinstance(fb, str):
        fb = {"name": fb}
    return fb


def t_cta(t, f, post=None):
    """ONE primary action + one small secondary line. action: save|send|follow|freebie.
    Legacy save/send/follow fields still work; legacy `product` is ignored (use a topic-matched `freebie`)."""
    post = post or {}
    T = THEMES[t]
    fb = resolve_freebie(t, f, post)
    action = f.get("action") or ("freebie" if fb else "save")
    if action == "freebie" and not fb:
        action = "save"
    if f.get("product") and not f.get("freebie"):
        print(f"  note: {post.get('id','?')}: cta.product is ignored in v2.1; set a topic-matched cta.freebie", file=sys.stderr)
    legacy = {"save": f.get("save") or "**Save this** for later.", "send": f.get("send") or "**Send it** to someone who needs it.",
              "follow": f.get("follow") or f"**Follow {T['handle']}** for more."}
    icons = {"save": "save", "send": "send", "follow": "follow", "freebie": "gift"}
    kick = {"freebie": "Free · link in bio"}.get(action, "")
    if action == "freebie":
        tb = f'<div class="k">{md(f.get("primary_kicker") or kick)}</div><div class="fn">{md(fb["name"])}</div>' + \
             (f'<div class="fl">{md(fb["line"])}</div>' if fb.get("line") else "")
    else:
        k = f.get("primary_kicker") or kick
        tb = (f'<div class="k">{md(k)}</div>' if k else "") + f'<div class="tx">{md(f.get("primary") or legacy[action])}</div>'
    primary = f'<div class="cta1" data-box><span class="ib">{icon(icons[action], 64, 2.4)}</span><div class="tb">{tb}</div></div>'
    sec = f.get("secondary")
    if sec is None:
        sec = legacy["follow"] if action != "follow" else legacy["save"]
    secondary = f'<div class="cta2" data-box>{icon("follow" if action != "follow" else "save", 34, 2.4)}<span>{md(sec)}</span></div>' if sec else ""
    illo = LF.cta_illo() if t == "littlefold" else {"fullyfunded": f'<img src="{(MARKS/T["mark"]).as_uri()}" alt="">', "lockedhour": clock_lh(250), "hourback": sun_hb(250)}[t]
    return f'<div class="ctatop"><div class="ctl">{head(f)}</div><div class="cti" data-box>{illo}</div></div>{primary}{secondary}'


BUILDERS = {"cover": t_cover, "big-number": t_bignum, "steps": t_steps, "checklist": t_checklist, "compare": t_compare,
            "output": t_output, "image": t_image, "table": t_table, "quote": t_quote, "cta": t_cta}


def slide_html(post, i):
    t = post["theme"]; style = post.get("highlight", "A")
    s = post["slides"][i]; tpl = s["template"]; f = s.get("fields", {})
    surface = s.get("surface") or ("dark" if tpl in DEFAULT_DARK[t] else "light")
    inner = BUILDERS[tpl](t, f, post)
    vt = visual_type(t, f) if tpl == "cover" else None
    return frame(t, style, surface, i, len(post["slides"]), inner, bg_deco(t, surface, tpl, vt, i), tpl)
