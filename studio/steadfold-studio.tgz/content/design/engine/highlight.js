// Steadfold carousel v2 - hand-drawn highlight engine (runs inside each slide page).
// Every .hl span is measured per line fragment, then a shape is drawn BEHIND the text
// in a band computed from the real baseline, so it can never reach the line above/below.
//   A = marker swipe (irregular filled SVG)   B = brush underline scribble (stroked SVG)
//   C = sticker/label block (bordered block, hard offset shadow)
(function () {
  function hash(s) { let h = 2166136261; for (const c of s) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { let s = seed || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
  function smooth(pts) { // closed-ish smooth path through points using quadratic midpoints
    let d = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
      d += ` Q${pts[i][0].toFixed(1)} ${pts[i][1].toFixed(1)} ${mx.toFixed(1)} ${my.toFixed(1)}`;
    }
    const L = pts[pts.length - 1]; return d + ` L${L[0].toFixed(1)} ${L[1].toFixed(1)}`;
  }
  const NS = 'http://www.w3.org/2000/svg';
  function svgEl(w, h) { const s = document.createElementNS(NS, 'svg'); s.setAttribute('width', w); s.setAttribute('height', h); s.setAttribute('viewBox', `0 0 ${w} ${h}`); s.style.overflow = 'visible'; return s; }
  function path(d, attrs) { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); for (const k in attrs) p.setAttribute(k, attrs[k]); return p; }

  // Bands are in em, relative to the baseline (y down). Must stay inside the line's own leading.
  const BAND = { A: [-0.60, 0.13], B: [0.04, 0.31], C: [-0.84, 0.20] };

  function markerA(w, h, R, color, dark) {
    const s = svgEl(w, h); const n = Math.max(5, Math.round(w / 70));
    const tilt = (R() - 0.5) * h * 0.10;
    const top = [], bot = [];
    for (let i = 0; i <= n; i++) { const x = i / n * w; const t = i / n;
      top.push([x, h * 0.08 + (R() - 0.5) * h * 0.14 + tilt * t]);
      bot.unshift([x, h * 0.94 + (R() - 0.5) * h * 0.10 + tilt * t]); }
    const pts = [[h * 0.06, h * 0.30 + R() * h * 0.1], ...top.slice(1, -1), [w - h * 0.02, h * 0.06 + tilt], [w + h * 0.04, h * 0.52 + tilt], [w - h * 0.05, h * 0.96 + tilt], ...bot.slice(1, -1), [-h * 0.05, h * 0.82], [h * 0.06, h * 0.30]];
    s.appendChild(path(smooth(pts) + 'Z', { fill: color, opacity: dark ? '1' : '.92' }));
    // second, thinner pass = the "drag" of a real chisel marker
    const y0 = h * (0.30 + R() * 0.12), y1 = y0 + (R() - 0.5) * h * 0.18 + tilt;
    s.appendChild(path(`M${h * 0.2} ${y0} Q${w * 0.5} ${(y0 + y1) / 2 + (R() - 0.5) * h * 0.2} ${w - h * 0.15} ${y1}`,
      { stroke: color, 'stroke-width': (h * 0.34).toFixed(1), 'stroke-linecap': 'round', fill: 'none', opacity: dark ? '1' : '.55' }));
    if (!dark) s.style.mixBlendMode = 'multiply';
    return s;
  }
  function scribbleB(w, h, R, color, sw) {
    // fast felt-tip underline: a wobbly left-to-right swipe, then a tighter return stroke underneath
    const s = svgEl(w, h);
    const a = h * (0.30 + R() * 0.08), b = h * (0.26 + R() * 0.10);
    const c = h * (0.74 + R() * 0.06);
    let d = `M${sw * 0.6} ${a + h * 0.06}`;
    d += ` C${w * 0.22} ${a - h * 0.10} ${w * 0.48} ${a + h * 0.14} ${w * 0.70} ${(a + b) / 2}`;
    d += ` S${w - sw * 2} ${b - h * 0.04} ${w - sw * 0.6} ${b}`;
    d += ` C${w * 0.80} ${b + h * 0.30} ${w * 0.55} ${c - h * 0.04} ${w * (0.10 + R() * 0.08)} ${c}`;
    s.appendChild(path(d, { stroke: color, 'stroke-width': sw.toFixed(1), 'stroke-linecap': 'round', 'stroke-linejoin': 'round', fill: 'none' }));
    return s;
  }

  // Cover art: scale .vart (down, or up to 1.5x) so the whole drawing - rotations and overhangs included - fills its
  // .visual slot without touching the title/lead. Art keeps its horizontal anchoring and is centred vertically.
  // Elements that actually paint something (layout-only wrappers are ignored when measuring art).
  window.__paints = function (e) {
    if (e.closest('svg') && e.tagName.toLowerCase() !== 'svg') return false;
    if (e.tagName.toLowerCase() === 'svg' || e.tagName.toLowerCase() === 'img') return true;
    if (!e.children.length) return true;
    const c = getComputedStyle(e);
    return c.backgroundColor !== 'rgba(0, 0, 0, 0)' || c.backgroundImage !== 'none' || parseFloat(c.borderTopWidth) > 0 || c.boxShadow !== 'none' || c.filter !== 'none';
  };
  function fitArt() {
    document.querySelectorAll('.visual > .vart').forEach((art) => {
      art.style.transform = '';
      const vis = art.parentElement, V = vis.getBoundingClientRect(), A = art.getBoundingClientRect();
      let L = Infinity, T = Infinity, Rr = -Infinity, Bb = -Infinity;
      art.querySelectorAll('*').forEach((e) => { if (!window.__paints(e)) return; const r = e.getBoundingClientRect(); if (r.width > 1 && r.height > 1) {
        L = Math.min(L, r.left); T = Math.min(T, r.top); Rr = Math.max(Rr, r.right); Bb = Math.max(Bb, r.bottom); } });
      if (!isFinite(L)) return;
      const uW = Rr - L, uH = Bb - T, maxUp = +(vis.dataset.maxscale || 1.5);
      // text lines above the slot (title/lead); art may rise past the slot top only where no text line is in its column
      const lines = [];
      vis.parentElement.querySelectorAll('.kick, h1, .lead').forEach((el) => {
        const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT); let n;
        while ((n = w.nextNode())) { const rg = document.createRange(); rg.selectNodeContents(n); for (const r of rg.getClientRects()) lines.push(r); }
        el.querySelectorAll('.hlb').forEach((b) => lines.push(b.getBoundingClientRect()));
      });
      const side = vis.querySelector('.vside'); const sideR = side ? side.getBoundingClientRect().right + 30 : null;
      const availW = side ? V.right - sideR : V.width + 24;
      const rightAnch = !!side || Math.abs(Rr - V.right) < 40 && Math.abs(L - V.left) > 40, leftAnch = Math.abs(L - V.left) < 40 && Math.abs(Rr - V.right) > 40;
      const h1 = vis.parentElement.querySelector('h1');
      let top = Math.max(V.top - 400, h1 ? h1.getBoundingClientRect().top : V.top), s = 1, newL = V.left;
      for (let k = 0; k < 10; k++) {   // top only moves down -> scale only shrinks -> converges
        s = Math.max(0.3, Math.min(maxUp, (V.bottom - top) / uH, availW / uW));
        newL = rightAnch ? V.right - s * uW : leftAnch ? V.left : V.left + (V.width - s * uW) / 2;
        const x0 = newL, x1 = newL + s * uW, y1 = top + s * uH + (V.bottom - top - s * uH);
        let ceil = top;
        for (const r of lines) if (r.right > x0 - 24 && r.left < x1 + 24 && r.bottom + 28 > top && r.top < y1) ceil = Math.max(ceil, Math.min(r.bottom + 28, V.top));
        if (ceil <= top + 0.5) break; top = ceil;
      }
      const newT = top + (V.bottom - top - s * uH) / 2;
      const tx = newL - (A.left + s * (L - A.left)), ty = newT - (A.top + s * (T - A.top));
      art.style.transformOrigin = '0 0';
      art.style.transform = `translate(${tx.toFixed(1)}px,${ty.toFixed(1)}px) scale(${s.toFixed(4)})`;
      art.dataset.scale = s.toFixed(4);
    });
  }

  function draw() {
    fitArt();
    const style = document.body.dataset.hl || 'A';
    document.querySelectorAll('.hl').forEach((el) => {
      const host = el.parentElement;
      host.classList.add('hl-host');
      let layer = host.querySelector(':scope > .hl-layer');
      if (!layer) { layer = document.createElement('span'); layer.className = 'hl-layer'; host.prepend(layer); }
      const cs = getComputedStyle(el), fs = parseFloat(cs.fontSize);
      const probe = document.createElement('i'); probe.className = 'bp'; el.prepend(probe);
      const rects = [...el.getClientRects()].filter((r) => r.width > fs * 0.45);
      const base0 = probe.getBoundingClientRect().top - el.getClientRects()[0].top;
      probe.remove();
      const hr = host.getBoundingClientRect();
      const v = (n) => getComputedStyle(host).getPropertyValue(n).trim();
      const scope = host.closest('.card, .dark'); const dark = !!scope && (scope.classList.contains('dark') || scope.classList.contains('alt'));
      const R = rng(hash(el.textContent + style));
      rects.forEach((r) => {
        const baseline = r.top + base0;
        // on dark surfaces the highlighted words switch to ink, so the marker must cover the full glyph height
        const [b0, b1] = style === 'A' && dark ? [-0.80, 0.17] : BAND[style];
        let x = r.left, w = r.width, y = baseline + b0 * fs, h = (b1 - b0) * fs, node, ext = 0;
        if (style === 'A') { x -= fs * 0.03; w += fs * 0.06; node = markerA(w, h, R, v('--hlA'), dark); }
        else if (style === 'B') { const sw = Math.max(4, fs * 0.085); x -= fs * 0.02; w += fs * 0.06; node = scribbleB(w, h, R, v('--hlB'), sw); }
        else {
          node = document.createElement('span'); node.className = 'stk';
          const sh = Math.max(3, Math.round(fs * 0.055)); ext = sh;
          node.style.cssText = `width:${w}px;height:${h}px;background:${v('--hlC')};border:${v('--hlC-border')};border-radius:${v('--hlC-radius')};box-shadow:${sh}px ${sh}px 0 ${v('--hlC-shadow')}`;
          const maxDeg = Math.asin(Math.min(1, (0.06 * fs) / w)) * 180 / Math.PI;
          node.style.transform = `rotate(${(-(0.4 + R() * 0.6) * Math.min(1.6, maxDeg)).toFixed(2)}deg)`;
        }
        node.classList.add('hlb');
        node.style.position = 'absolute'; node.style.left = (x - hr.left) + 'px'; node.style.top = (y - hr.top) + 'px';
        node.dataset.base = baseline; node.dataset.fs = fs; node.dataset.ext = ext;
        layer.appendChild(node);
      });
    });
    window.__hlDone = true;
  }
  document.fonts.ready.then(() => requestAnimationFrame(() => requestAnimationFrame(draw)));
})();
