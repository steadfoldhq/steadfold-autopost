"""Inline markup shared by every template and cover visual."""
import html, re

MONTHS = r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec|January|February|March|April|June|July|August|September|October|November|December)"


def md(s, ph=False):
    """Escape, then: ==x== highlight, **x** bold, [x] placeholder chip (ph=True), \\n line break.
    Never breaks inside hyphenated words, dates ("Oct 21", "21 Oct", "Oct 21, 2026"), "§ 5", or a number and its unit."""
    s = str(s or "").replace("‑", "-")                       # Poppins has no U+2011; the nb span does the job
    s = html.escape(s, quote=False)
    s = re.sub(r"(\w+(?:-\w+)+)", r'<span class="nb">\1</span>', s)
    s = re.sub(r"\b" + MONTHS + r"\.? (\d{1,2})\b(,? \d{4})?", lambda m: m.group(0).replace(" ", "&nbsp;"), s)
    s = re.sub(r"\b(\d{1,2}) " + MONTHS + r"\b", r"\1&nbsp;\2", s)
    s = s.replace("§ ", "§&nbsp;")
    s = re.sub(r"(\d) (%|min|mins|h|hr|hrs|days?|weeks?|months?|years?|pays?|am|pm|AM|PM)\b", r"\1&nbsp;\2", s)
    s = re.sub(r"==(.+?)==", lambda m: f'<span class="hl{" nw" if len(re.sub("<[^>]+>", "", m.group(1))) <= 18 else ""}">{m.group(1)}</span>', s)
    s = s.replace("\n", "<br>")
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    if ph:
        s = re.sub(r"\[([^\]]+)\]", r'<span class="ph">[\1]</span>', s)
    return s
