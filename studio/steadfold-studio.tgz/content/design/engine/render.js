// Steadfold carousel v2 - Playwright renderer + layout QA.
// usage: NODE_PATH=$(npm root -g) node render.js manifest.json
// manifest: {"jobs":[{"id","html","png"}], "report":"path.json"}
// Screenshots at deviceScaleFactor 2 (2160x2700); render.py downsamples with LANCZOS.
const fs = require('fs');
const { chromium } = require('playwright');

const SAFE = { l: 60, t: 44, r: 1080 - 60, b: 1350 - 44 };   // nothing meaningful outside this
const MAIN_GAP = 200;                                      // max empty vertical band inside the content area (px)
const MIN_FONT = 20;                                       // px at 1080 wide
const INNER = 16;                                          // min gap between text and its card edge

async function qa(page) {
  return page.evaluate(({ SAFE, MAIN_GAP, MIN_FONT, INNER }) => {
    const errs = [];
    const R = (r) => ({ l: r.left, t: r.top, r: r.right, b: r.bottom });
    const inter = (a, b, pad = 0) => Math.min(a.r, b.r) - Math.max(a.l, b.l) > pad && Math.min(a.b, b.b) - Math.max(a.t, b.t) > pad;
    const desc = (el) => (el.className && typeof el.className === 'string' ? el.tagName.toLowerCase() + '.' + el.className.split(' ')[0] : el.tagName.toLowerCase());
    const txt = (s) => (s || '').trim().slice(0, 40);

    // ---- font metrics probe (ascent/descent ratio per family+weight) to locate real baselines
    const metricCache = {};
    function metrics(cs) {
      const key = cs.fontFamily + '|' + cs.fontWeight + '|' + cs.fontStyle;
      if (metricCache[key]) return metricCache[key];
      const s = document.createElement('span'); s.style.cssText = `font-family:${cs.fontFamily};font-weight:${cs.fontWeight};font-size:100px;line-height:normal;position:absolute;left:-9999px;top:0;white-space:nowrap`;
      s.textContent = 'Hxg'; const p = document.createElement('i'); p.style.cssText = 'display:inline-block;width:0;height:0'; s.appendChild(p);
      document.body.appendChild(s);
      const sr = s.getBoundingClientRect(), pr = p.getBoundingClientRect();
      const m = { asc: (pr.top - sr.top) / 100, desc: (sr.bottom - pr.top) / 100 }; s.remove();
      return (metricCache[key] = m);
    }

    const hyCache = {};
    function hyphenRef(cs) {   // natural hyphen advance for this exact font/size/spacing, with tabular figures OFF
      const key = [cs.fontFamily, cs.fontWeight, cs.fontSize, cs.letterSpacing, cs.textTransform].join('|');
      if (hyCache[key] != null) return hyCache[key];
      const s = document.createElement('span');
      s.style.cssText = `font-family:${cs.fontFamily};font-weight:${cs.fontWeight};font-size:${cs.fontSize};letter-spacing:${cs.letterSpacing};text-transform:${cs.textTransform};font-variant-numeric:normal;font-feature-settings:normal;position:absolute;left:-9999px;top:0;white-space:nowrap`;
      s.textContent = 'a-b'; document.body.appendChild(s);
      const r = document.createRange(); r.setStart(s.firstChild, 1); r.setEnd(s.firstChild, 2);
      const w = r.getBoundingClientRect().width; s.remove();
      return (hyCache[key] = w);
    }

    // ---- 1. collect every rendered text line fragment, with a glyph "ink box" from the real baseline
    const lines = [];
    const walker = document.createTreeWalker(document.querySelector('.slide'), NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (!n.textContent.trim()) continue;
      const el = n.parentElement; if (el.closest('.hl-layer')) continue;
      const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none') continue;
      const art = el.closest('.vart');
      const fs = parseFloat(cs.fontSize) * (art ? +(art.dataset.scale || 1) : 1);   // effective size after art fitting
      if (fs < MIN_FONT) errs.push(`min-font: ${fs}px < ${MIN_FONT}px in ${desc(el)} "${txt(n.textContent)}"`);
      const m = metrics(cs);
      for (const hm of n.textContent.matchAll(/\w-(?=\w)/g)) {   // a hyphen must render as this font's own hyphen, not a figure dash
        const hr = document.createRange(); hr.setStart(n, hm.index + 1); hr.setEnd(n, hm.index + 2);
        const sc0 = el.closest('.vart') ? +(el.closest('.vart').dataset.scale || 1) : 1;
        const w = hr.getBoundingClientRect().width / sc0, ref = hyphenRef(cs);
        if (w > ref * 1.12 + 0.5) errs.push(`hyphen: "${txt(n.textContent)}" hyphen is ${(w / parseFloat(cs.fontSize)).toFixed(2)}em wide vs ${(ref / parseFloat(cs.fontSize)).toFixed(2)}em normal (tabular-nums on text?)`);
      }
      const rg = document.createRange(); rg.selectNodeContents(n);
      for (const r of rg.getClientRects()) {
        if (r.width < 1) continue;
        const base = r.top + m.asc * fs;  // content-area top + ascent
        lines.push({ el, fs, base, text: n.textContent, art: !!el.closest('.visual'), box: { l: r.left, r: r.right, t: base - 0.74 * fs, b: base + 0.22 * fs }, raw: R(r) });
      }
    }

    // ---- 2. safe area: all text + all [data-box] blocks inside SAFE
    const out = (b) => b.l < SAFE.l - 0.5 || b.t < SAFE.t - 0.5 || b.r > SAFE.r + 0.5 || b.b > SAFE.b + 0.5;
    for (const L of lines) if (out(L.box)) errs.push(`safe-area: text "${txt(L.text)}" at ${JSON.stringify(L.box, (k, v) => typeof v === 'number' ? Math.round(v) : v)}`);
    const boxes = [...document.querySelectorAll('[data-box]')];
    for (const b of boxes) { const r = R(b.getBoundingClientRect()); if (out(r)) errs.push(`safe-area: ${desc(b)} ${Math.round(r.l)},${Math.round(r.t)},${Math.round(r.r)},${Math.round(r.b)}`); }
    // ---- 2b. interactive posts (body[data-edge]): every text line at least EDGE px from each slide edge
    const EDGE = +(document.body.dataset.edge || 0);
    if (EDGE) for (const L of lines) { const b = L.box;
      if (b.l < EDGE - 0.5 || b.t < EDGE - 0.5 || b.r > 1080 - EDGE + 0.5 || b.b > 1350 - EDGE + 0.5)
        errs.push(`edge: text "${txt(L.text)}" is closer than ${EDGE}px to the slide edge (${Math.round(b.l)},${Math.round(b.t)},${Math.round(b.r)},${Math.round(b.b)})`); }

    // ---- 3. text overflow: every text line must sit inside its card / step / container box
    for (const L of lines) {
      const c = L.el.closest('.card, .act, .prod, .chip, .sticker, .pill, .tag, .kick, .swipe');
      if (!c) continue;
      const ccs = getComputedStyle(c);   // only boxes that visibly contain text (filled or bordered)
      if (ccs.backgroundColor === 'rgba(0, 0, 0, 0)' && !(parseFloat(ccs.borderTopWidth) > 0) && ccs.backgroundImage === 'none') continue;
      const cr = R(c.getBoundingClientRect());
      if (L.raw.l < cr.l - 1 || L.raw.r > cr.r + 1 || L.box.t < cr.t - 1 || L.box.b > cr.b + 1)
        errs.push(`text-overflow: "${txt(L.text)}" spills out of ${desc(c)}`);
      else if (c.matches('.card, .act')) {   // cards must keep breathing room: text never closer than INNER px to an edge
        const m = Math.min(L.raw.l - cr.l, cr.r - L.raw.r, L.box.t - cr.t, cr.b - L.box.b);
        if (m < INNER) errs.push(`text-overflow: "${txt(L.text)}" is ${Math.round(m)}px from the edge of ${desc(c)} (min ${INNER})`);
      }
    }
    for (const el of document.querySelectorAll('.main *')) {
      if (el.closest('.hl-layer,svg') || el.classList.contains('visual')) continue;
      if (el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflow !== 'visible' && el.clientWidth > 0)
        errs.push(`clipped: ${desc(el)} scrollWidth ${el.scrollWidth} > ${el.clientWidth}`);
      if (el.scrollHeight > el.clientHeight + 2 && getComputedStyle(el).overflow !== 'visible' && el.clientHeight > 0)
        errs.push(`clipped: ${desc(el)} scrollHeight ${el.scrollHeight} > ${el.clientHeight}`);
    }
    const main = document.querySelector('.main'); const mr = R(main.getBoundingClientRect());
    for (const b of boxes) { if (!main.contains(b)) continue; const r = R(b.getBoundingClientRect()); if (r.b > mr.b + 1) errs.push(`overflow: ${desc(b)} bottom ${Math.round(r.b)} > content bottom ${Math.round(mr.b)}`); }

    // ---- 4. block collisions: sibling blocks must not intersect (cards may not touch titles etc.)
    for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i], b = boxes[j]; if (a.contains(b) || b.contains(a)) continue;
      if (a.classList.contains('capchip') || b.classList.contains('capchip')) continue;   // caption chips overlap their frame on purpose
      if (inter(R(a.getBoundingClientRect()), R(b.getBoundingClientRect()), 0.5)) errs.push(`collision: ${desc(a)} x ${desc(b)}`);
    }

    // ---- 5. highlights: each band may only touch glyphs of its OWN line; bands of different lines may not touch
    const bands = [...document.querySelectorAll('.hlb')].map((e) => {
      const r = R(e.getBoundingClientRect()); const x = +e.dataset.ext || 0;
      return { e, base: +e.dataset.base, fs: +e.dataset.fs, box: { l: r.l, t: r.t, r: r.r + x, b: r.b + x } };
    });
    for (const B of bands) {
      for (const L of lines) {
        if (Math.abs(L.base - B.base) < 0.3 * Math.max(L.fs, B.fs)) continue;   // same line: covering it is the point
        if (inter(B.box, L.box, 0.5)) errs.push(`highlight-overlap: band on line @${Math.round(B.base)} hits text "${txt(L.text)}" on line @${Math.round(L.base)}`);
      }
      for (const C of bands) if (C !== B && Math.abs(C.base - B.base) > 0.3 * B.fs && inter(B.box, C.box, -2))
        errs.push(`highlight-overlap: bands on lines @${Math.round(B.base)} and @${Math.round(C.base)} touch`);
    }
    if (document.querySelectorAll('.hl').length && !bands.length) errs.push('highlight: .hl present but no band drawn');

    // ---- 5b. cover art: never shrunk below 60%, never touching the title/lead/highlights
    for (const art of document.querySelectorAll('.vart')) {
      const sc = +(art.dataset.scale || 1);
      if (sc < 0.6) errs.push(`art-squeezed: cover visual "${art.parentElement.dataset.vis}" had to shrink to ${Math.round(sc * 100)}% (shorten title/lead or pick a shorter visual)`);
    }
    const artEls = [...document.querySelectorAll('.art *, .vacc')].filter((e) => window.__paints(e)).map((e) => R(e.getBoundingClientRect())).filter((r) => r.r - r.l > 1 && r.b - r.t > 1);
    const hlBoxes = [...document.querySelectorAll('.hlb')].filter((e) => !e.closest('.visual')).map((e) => R(e.getBoundingClientRect()));
    const outside = lines.filter((L) => !L.art || L.el.closest('.vside')).map((L) => ({ box: L.box, text: L.text })).concat(hlBoxes.map((b) => ({ box: b, text: '(highlight)' })));
    let hits = 0;
    for (const a of artEls) for (const o of outside) if (hits < 3 && inter(a, o.box, 1)) { hits++; errs.push(`art-collision: cover art overlaps "${txt(o.text)}"`); }

    // ---- 5c. brand stamp (interactive.py, .ixstamp): its circle may not cover any text outside itself
    for (const st of document.querySelectorAll('.ixstamp')) {
      const sr = st.getBoundingClientRect(), cx = sr.left + sr.width / 2, cy = sr.top + sr.height / 2, rad = sr.width / 2 + 6;
      for (const L of lines) { if (st.contains(L.el)) continue; const b = L.box;
        const nx = Math.max(b.l, Math.min(cx, b.r)), ny = Math.max(b.t, Math.min(cy, b.b));
        if ((nx - cx) ** 2 + (ny - cy) ** 2 < rad * rad) { errs.push(`stamp-collision: brand stamp covers "${txt(L.text)}" (try stamp_pos tl|tr|bl|br, or no stamp on this cover)`); break; } }
    }

    // ---- 6. empty space: no tall empty band inside the content area
    const artUnion = (vis) => { let u = null; vis.querySelectorAll('.vart *').forEach((e) => { if (!window.__paints(e)) return; const r = R(e.getBoundingClientRect());
      if (r.r - r.l > 1 && r.b - r.t > 1) u = u ? { l: Math.min(u.l, r.l), t: Math.min(u.t, r.t), r: Math.max(u.r, r.r), b: Math.max(u.b, r.b) } : r; }); return u; };
    const ys = boxes.filter((b) => main.contains(b)).map((b) => (b.classList.contains('visual') ? artUnion(b) : R(b.getBoundingClientRect())))
      .filter(Boolean).sort((a, b) => a.t - b.t);   // cover art counts by what is actually drawn, not by its slot
    let cur = mr.t, gap = 0;
    for (const r of ys) { gap = Math.max(gap, r.t - cur); cur = Math.max(cur, r.b); }
    gap = Math.max(gap, mr.b - cur);
    const MAXG = +(document.body.dataset.maxgap || MAIN_GAP);   // editorial episode pages set a larger allowance
    if (gap > MAXG) errs.push(`empty-space: ${Math.round(gap)}px empty band in content area (max ${MAXG})`);

    // ---- 7. fonts: every face actually used must have loaded (no silent fallback)
    for (const f of document.fonts) if (f.status === 'error') errs.push(`font: failed to load ${f.family} ${f.weight}`);
    const used = new Set(lines.map((L) => { const cs = getComputedStyle(L.el); return `${cs.fontWeight} 40px ${cs.fontFamily}`; }));
    for (const u of used) if (!document.fonts.check(u)) errs.push(`font: not loaded ${u}`);

    return { errors: [...new Set(errs)], stats: { lines: lines.length, bands: bands.length, maxGap: Math.round(gap) } };
  }, { SAFE, MAIN_GAP, MIN_FONT, INNER });
}

(async () => {
  const man = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM || '/opt/pw-browsers/chromium' });
  const ctx = await browser.newContext({ viewport: { width: 1080, height: 1350 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const report = [];
  for (const j of man.jobs) {
    if (j.raw) {   // interactive panorama canvas: one wide page (j.w x 1350), screenshot only, no slide QA
      await page.setViewportSize({ width: j.w, height: 1350 });
      await page.goto('file://' + j.html, { waitUntil: 'load' });
      await page.evaluate(() => document.fonts.ready);
      await page.screenshot({ path: j.png, clip: { x: 0, y: 0, width: j.w, height: 1350 } });
      await page.setViewportSize({ width: 1080, height: 1350 });
      report.push({ id: j.id, png: j.png, errors: [] }); process.stdout.write(`ok   ${j.id} (canvas ${j.w}px)\n`);
      continue;
    }
    await page.goto('file://' + j.html, { waitUntil: 'load' });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForFunction(() => window.__hlDone === true, null, { timeout: 10000 });
    const r = await qa(page);
    await page.screenshot({ path: j.png, clip: { x: 0, y: 0, width: 1080, height: 1350 } });
    report.push({ id: j.id, png: j.png, ...r });
    process.stdout.write(`${r.errors.length ? 'FAIL' : 'ok  '} ${j.id}${r.errors.length ? '\n   - ' + r.errors.join('\n   - ') : ''}\n`);
  }
  fs.writeFileSync(man.report, JSON.stringify(report, null, 2));
  await browser.close();
})().catch((e) => { console.error(e); process.exit(2); });
