"""Brand illustrations + icons (pure SVG/HTML, no external assets)."""
import math

INK_LH = "#141414"


def clock_lh(size=420, progress=0.75):
    """Locked Hour zine timer: yellow face, thick ink outline, pink locked-hour wedge, hard offset shadow."""
    cx, cy, r = 200, 228, 160
    a_end = -90 + 360 * progress
    ex, ey = cx + 122 * math.cos(math.radians(a_end)), cy + 122 * math.sin(math.radians(a_end))
    large = 1 if progress > 0.5 else 0
    ticks = "".join(
        f'<line x1="{cx + 138*math.cos(math.radians(h*30)):.1f}" y1="{cy + 138*math.sin(math.radians(h*30)):.1f}" '
        f'x2="{cx + (146 if h % 3 else 128)*math.cos(math.radians(h*30)):.1f}" y2="{cy + (146 if h % 3 else 128)*math.sin(math.radians(h*30)):.1f}" '
        f'stroke="{INK_LH}" stroke-width="{9 if h % 3 == 0 else 7}" stroke-linecap="round"/>' for h in range(12))
    hx, hy = cx + 100 * math.cos(math.radians(a_end)), cy + 100 * math.sin(math.radians(a_end))
    return (f'<svg width="{size}" height="{size*440/400:.0f}" viewBox="0 0 400 440">'
            f'<circle cx="{cx+12}" cy="{cy+12}" r="{r}" fill="{INK_LH}"/>'
            f'<rect x="174" y="26" width="52" height="40" rx="8" fill="#FF5CA8" stroke="{INK_LH}" stroke-width="8"/>'
            f'<rect x="191" y="62" width="18" height="14" fill="{INK_LH}"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="#FFD43B" stroke="{INK_LH}" stroke-width="10"/>'
            f'<path d="M{cx} {cy} L{cx} {cy-122} A122 122 0 {large} 1 {ex:.1f} {ey:.1f} Z" fill="#FF5CA8" stroke="{INK_LH}" stroke-width="8" stroke-linejoin="round"/>'
            + ticks +
            f'<line x1="{cx}" y1="{cy}" x2="{hx:.1f}" y2="{hy:.1f}" stroke="{INK_LH}" stroke-width="14" stroke-linecap="round"/>'
            f'<circle cx="{cx}" cy="{cy}" r="17" fill="{INK_LH}"/><circle cx="{cx}" cy="{cy}" r="6" fill="#FFF4E0"/></svg>')


def sun_hb(size=440, yellow="#FFC94D", orange="#FF8A3D", ink="#2A2238", indigo="#5E54C9"):
    """Hourback sun-clock (same construction as the 25 Prompts cover)."""
    rays = []
    for k in range(13):
        a = math.radians(180 + k * 15)
        r1, r2 = 35.5, (48 if k % 2 == 0 else 42.5)
        w = 1.9 if k % 2 == 0 else 1.3
        px, py = -math.sin(a), math.cos(a)
        x1, y1 = 50 + r1 * math.cos(a), 50 + r1 * math.sin(a)
        x2, y2 = 50 + r2 * math.cos(a), 50 + r2 * math.sin(a)
        pts = f"{x1+px*w:.2f},{y1+py*w:.2f} {x2+px*w*.45:.2f},{y2+py*w*.45:.2f} {x2-px*w*.45:.2f},{y2-py*w*.45:.2f} {x1-px*w:.2f},{y1-py*w:.2f}"
        rays.append(f'<polygon points="{pts}" fill="{yellow}" stroke="{yellow}" stroke-width=".6" stroke-linejoin="round"/>')
    ticks = []
    for h in range(12):
        a = math.radians(h * 30 - 90); big = h % 3 == 0
        r1, r2 = (19.5 if big else 20.6), 23.2
        ticks.append(f'<line x1="{50+r1*math.cos(a):.2f}" y1="{50+r1*math.sin(a):.2f}" x2="{50+r2*math.cos(a):.2f}" y2="{50+r2*math.sin(a):.2f}" '
                     f'stroke="#E9792E" stroke-width="{1.5 if big else 1}" stroke-linecap="round"/>')
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 100 100">' + "".join(rays) +
            f'<circle cx="50" cy="50" r="31.5" fill="{orange}"/>'
            f'<circle cx="50" cy="50" r="25" fill="{yellow}"/>' + "".join(ticks) +
            f'<path d="M50 50 L50 37" stroke="{ink}" stroke-width="2.2" stroke-linecap="round"/>'
            f'<path d="M50 50 L41.5 45" stroke="{ink}" stroke-width="2.2" stroke-linecap="round"/>'
            f'<circle cx="50" cy="50" r="2.1" fill="{ink}"/>'
            f'<path d="M60.5 33.5 A19.5 19.5 0 0 0 37 35.5" fill="none" stroke="{indigo}" stroke-width="1.6" stroke-linecap="round"/>'
            f'<path d="M36.2 31.6 L36.6 36.3 L41.2 35.2" fill="none" stroke="{indigo}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>')


ICONS = {
    "save": '<path d="M7 3.5h10a1.5 1.5 0 0 1 1.5 1.5v15.5l-6.5-4.6-6.5 4.6V5A1.5 1.5 0 0 1 7 3.5z"/>',
    "send": '<path d="M21 3 10.2 13.8M21 3l-6.6 18-4.2-7.2L3 9.6z"/>',
    "follow": '<circle cx="9.5" cy="8" r="4"/><path d="M2.5 20.5c.8-3.8 3.6-6 7-6s6.2 2.2 7 6M19 7.5v6M16 10.5h6"/>',
    "gift": '<path d="M4 11h16v9.5H4zM3 7.5h18V11H3zM12 7.5v13M12 7.5S10.8 3 8 3.6C5.5 4.2 6.8 7.5 12 7.5zM12 7.5s1.2-4.5 4-3.9c2.5.6 1.2 3.9-4 3.9z"/>',
    "arrow": '<path d="M4 12h15M13 6l6 6-6 6"/>',
    "check": '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    "x": '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    "warn": '<path d="M12 3.5 22 20.5H2z"/><path d="M12 10v4.5M12 17.6v.2"/>',
    "dash": '<path d="M7 12h10"/>',
    "spark": '<path d="M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3"/>',
}


def icon(name, size=40, sw=2.4):
    return (f'<svg class="ic" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            f'stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{ICONS[name]}</svg>')
