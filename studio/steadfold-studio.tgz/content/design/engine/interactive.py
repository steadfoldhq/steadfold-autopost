"""Steadfold interactive carousel formats (Oct 2026). Original layouts in each brand's own look.

Formats (all are slide entries in a normal post JSON; see STUDIO-README "Interactive formats"):
  panorama         one continuous canvas (N x 1080 wide) sliced into N slides; a path/timeline and optional
                   objects flow across the slide edges. Stops (time + text cards) sit inside each slide.
  follow-the-line  slide 1: 3-5 choices on the left; coloured lines wind across the middle slides (one panorama)
                   and end on the last slide at each choice's answer (the icon repeats beside the answer).
  swipe-to-reveal  one card (prompt / big number / brand art) goes from heavily pixelated to sharp over 3-5 slides.
  awards           one slide: a grid of 4-6 rosettes / stars / medals, each with a tiny relatable win.
  cover.save_line  optional handwritten-style accent line on a cover ("save this if...").

How it plugs in (render.py): validate() -> expand() turns each macro slide into concrete "_ix" slides ->
slide_html() builds them (plain slides go to templates.slide_html untouched) -> render.js screenshots + QA ->
finalize() downsamples (panorama groups as ONE strip so the seams stay continuous), pixelates reveal steps,
and checks every seam against the canvas image (must be identical, pixel for pixel, at 2x and 1x).
Panorama canvases are rendered ONCE as a wide page (render.js "raw" job) before the slides that show slices of it.
Posts without interactive slides or a save_line produce byte-identical HTML and PNGs to before.
"""
import copy, math, random, re
from pathlib import Path

from .themes import THEMES, FONTS, MARKS
from .templates import frame, bg_deco, slide_html as _plain_slide_html
from .markup import md
from .visuals import clock_lh, sun_hb, icon
from . import littlefold as LF
from . import episode as EPI, feed

W, H = 1080, 1350
ML, MT, MR, MB = 80, 166, 1000, 1212          # .main box (slide px)
EDGE = 70                                     # text must stay >= 70 px from every slide edge (render.js data-edge)
FORMATS = ["panorama", "follow-the-line", "swipe-to-reveal", "awards"]
FTR_CSS = ".ftr{bottom:58px}"
SEAM_BAND = 60                                # px each side of a seam compared against the canvas (1x)

# ------------------------------------------------------------------ brand tokens (light surface unless noted)
TOK = {
    "fullyfunded": dict(lines=["#2B3FE0", "#FF6A3D", "#0E1440", "#8C9BFF", "#F2A23A"],
                        path="#2B3FE0", path_case="#D9DEF5", dot="#FF6A3D", dot_ring="#FFFFFF",
                        chip_bg="#FF6A3D", chip_ink="#FFFFFF", pill_bg="#0E1440", pill_ink="#FFFFFF", pill_extra="",
                        save="#2B3FE0", save_dark="#FFFFFF", arrow="#FF6A3D",
                        awards=[("#FF6A3D", "#FFB08F"), ("#2B3FE0", "#8C9BFF"), ("#F2A23A", "#FFE0A8")], award_ink=None),
    "lockedhour": dict(lines=["#FF5CA8", "#141414", "#FFD43B", "#7A5CFF", "#2BB673"],
                       path="#FFD43B", path_case="#141414", dot="#FF5CA8", dot_ring="#141414",
                       chip_bg="#FFD43B", chip_ink="#141414", pill_bg="#FFD43B", pill_ink="#141414",
                       pill_extra="border:3px solid #141414;box-shadow:5px 5px 0 #141414;",
                       save="#141414", save_dark="#FFD43B", arrow="#FF5CA8",
                       awards=[("#FFD43B", "#FFF4E0"), ("#FF5CA8", "#FFD0E6"), ("#FFFFFF", "#FFD43B")], award_ink="#141414"),
    "hourback": dict(lines=["#5E54C9", "#FF8A3D", "#2A2238", "#E9B300", "#B28DFF"],
                     path="#FF8A3D", path_case="#FFE3C4", dot="#5E54C9", dot_ring="#FFFFFF",
                     chip_bg="#5E54C9", chip_ink="#FFFFFF", pill_bg="#FFC94D", pill_ink="#2A2238", pill_extra="",
                     save="#5E54C9", save_dark="#FFC94D", arrow="#FF8A3D",
                     awards=[("#FFC94D", "#FFEEDC"), ("#FF8A3D", "#FFC94D"), ("#5E54C9", "#C9C4F5")], award_ink=None),
    "littlefold": dict(lines=["#D9497A", "#FFA35C", "#4FA9DD", "#2C2A3A", "#F5A3BD"],
                       path="#D9497A", path_case="#FFE1EA", dot="#FFA35C", dot_ring="#FFFFFF",
                       chip_bg="#FFE27E", chip_ink="#2C2A3A", pill_bg="#2C2A3A", pill_ink="#FFF8E4", pill_extra="",
                       save="#D9497A", save_dark="#FFE27E", arrow="#FFA35C",
                       awards=[("#FFE27E", "#FFF5CC"), ("#F5A3BD", "#FFE1EA"), ("#7CC4EE", "#E3F3FD"), ("#FFA35C", "#FFE9D6")],
                       award_ink="#2C2A3A"),
}
HAND_FONTS = ["CaveatBrush-Regular.ttf", "Caveat-Variable.ttf", "Caveat[wght].ttf", "Caveat-Medium.ttf", "Caveat-Regular.ttf", "Kalam-Regular.ttf",
              "PatrickHand-Regular.ttf", "Handlee-Regular.ttf", "ShadowsIntoLight-Regular.ttf"]


def hand_font():
    """(css @font-face, family, size-scale). A bundled handwriting TTF in assets/fonts wins; else Lora Italic."""
    for fn in HAND_FONTS:
        p = FONTS / fn
        if p.exists():   # variable Caveat spans 400-700; every other hand face is a single weight (never synthesise bold)
            rng, wt = ("font-weight:400 700;", 600) if "Variable" in fn else ("font-weight:400;", 400)
            return f"@font-face{{font-family:'SF Hand';{rng}src:url({p.as_uri()}) format('truetype')}}", "'SF Hand'", 1.25, "normal", wt
    p = FONTS / "Lora-Italic-Variable.ttf"
    return (f"@font-face{{font-family:'SF Hand';font-weight:400 700;font-style:normal;src:url({p.as_uri()}) format('truetype')}}",
            "'SF Hand'", 1.0, "normal", 500)


# ------------------------------------------------------------------ validation (raw posts, before expand)
def validate(p):
    errs = EPI.validate(p)
    for i, s in enumerate(p["slides"]):
        f = s.get("fields", {}); tpl = s["template"]; at = f"{p['id']} slide {i+1} ({tpl})"
        if f.get("save_line") is not None:
            if tpl != "cover":
                errs.append(f"{at}: save_line only exists on the cover")
            elif len(str(f["save_line"])) > 40:
                errs.append(f"{at}: save_line is {len(str(f['save_line']))} chars (max 40)")
        if tpl == "follow-the-line":
            ch = f.get("choices") or []
            if not 3 <= len(ch) <= 5:
                errs.append(f"{at}: needs 3-5 choices (got {len(ch)})")
            for c in ch:
                if not c.get("label") or not (c.get("answer") or {}).get("value"):
                    errs.append(f"{at}: every choice needs a label and answer.value")
            if not 1 <= len(f.get("middle") or [{}, {}]) <= 3:
                errs.append(f"{at}: middle must list 1-3 slides")
            eo = f.get("end_order")
            if eo is not None and sorted(eo) != list(range(len(ch))):
                errs.append(f"{at}: end_order must be a permutation of 0..{len(ch)-1}")
        elif tpl == "panorama":
            n = int(f.get("slides", 3))
            if not 2 <= n <= 5:
                errs.append(f"{at}: slides must be 2-5")
            ps = f.get("per_slide") or _distribute(len(f.get("stops", [])), n)
            if len(ps) != n or sum(ps) != len(f.get("stops", [])) or max(ps or [0]) > 3:
                errs.append(f"{at}: per_slide must have {n} counts (max 3 each) that add up to the number of stops")
        elif tpl == "swipe-to-reveal":
            st = f.get("steps") or []
            if not 3 <= len(st) <= 5:
                errs.append(f"{at}: needs 3-5 steps (got {len(st)})")
            if (f.get("target") or {}).get("kind") not in ("prompt", "number", "art"):
                errs.append(f"{at}: target.kind must be prompt, number or art")
            if not any("keep swiping" in str(x.get("title", "") + x.get("kicker", "") + f.get("hint", "keep swiping")).lower() for x in st):
                errs.append(f"{at}: say 'keep swiping to reveal' (hint or a step title)")
        elif tpl == "awards":
            it = f.get("items") or []
            if not 4 <= len(it) <= 6:
                errs.append(f"{at}: needs 4-6 items (got {len(it)})")
            for x in it:
                x = x if isinstance(x, dict) else {"text": x}
                if len(x.get("text", "")) > 40:
                    errs.append(f"{at}: award '{x['text'][:20]}...' is over 40 chars")
    return errs


def uses_interactive(p):
    return any(s["template"] in FORMATS or s["template"] in EPI.EP_TEMPLATES or s["template"] == "_ix"
               or any((s.get("fields") or {}).get(k) is not None for k in ("save_line", "stamp", "palette_index")) for s in p["slides"])


# ------------------------------------------------------------------ expand macros -> concrete slides
def expand(post):
    if not uses_interactive(post):
        return post
    p = copy.deepcopy(post); out = []; gi = 0
    for s in post["slides"]:
        tpl = s["template"]; f = s.get("fields", {})
        if tpl == "panorama":
            n = int(f.get("slides", 3)); gi += 1
            out += [{"template": "_ix", "surface": s.get("surface"), "fields": f, "_ix": {"kind": "panorama", "k": k, "n": n, "group": f"{p['id']}#{gi}"}} for k in range(n)]
        elif tpl == "follow-the-line":
            n = 2 + len(f.get("middle") or [{}, {}]); gi += 1
            out += [{"template": "_ix", "surface": s.get("surface"), "fields": f, "_ix": {"kind": "follow", "k": k, "n": n, "group": f"{p['id']}#{gi}"}} for k in range(n)]
        elif tpl == "swipe-to-reveal":
            st = f["steps"]; lv = f.get("levels") or {3: [40, 10, 0], 4: [40, 20, 10, 0], 5: [40, 20, 10, 5, 0]}[len(st)]
            out += [{"template": "_ix", "surface": s.get("surface"), "fields": f, "_ix": {"kind": "reveal", "k": k, "n": len(st), "block": lv[k]}} for k in range(len(st))]
        elif tpl == "awards":
            out.append({"template": "_ix", "surface": s.get("surface"), "fields": f, "_ix": {"kind": "awards", "k": 0, "n": 1}})
        else:
            out.append(s)
    p["slides"] = out; p["_ix_post"] = True
    return p


def job_meta(post, i):
    s = post["slides"][i]; x = s.get("_ix")
    if not x:
        return {}
    m = {"kind": x["kind"]}
    if x.get("group"):
        m.update(group=x["group"], k=x["k"], n=x["n"])
    if x["kind"] == "reveal" and x["block"]:
        m["pixelate"] = list(REVEAL_RECT) + [x["block"]]
    return {"ix": m}


# ------------------------------------------------------------------ HTML
def slide_html(post, i):
    s = post["slides"][i]
    if s["template"] in EPI.EP_TEMPLATES:
        return EPI.slide_html(post, i)
    if s["template"] != "_ix":
        f = s.get("fields", {}); pal = None
        if s["template"] == "cover" and f.get("palette_index") is not None:   # feed rotation: recolour this cover
            pal = feed.cover_palette(post["theme"], f["palette_index"])
            post = dict(post, slides=[dict(x, surface=pal["surface"]) if k == i else x for k, x in enumerate(post["slides"])])
            s = post["slides"][i]
        h = _plain_slide_html(post, i)
        if pal and pal["bg"]:
            h = h.replace("</style>", f".slide.light{{--bg:{pal['bg']}!important}}</style>", 1)
        if s["template"] == "cover" and f.get("stamp"):
            h = _inject_stamp(h, post["theme"], s, f["stamp"], f.get("stamp_pos", "tr"))
        if s["template"] == "cover" and f.get("save_line"):
            h = _inject_save_line(h, post["theme"], s, f["save_line"])
        if post.get("_ix_post"):   # same frame as the interactive slides: footer 8 px higher so its text clears 70 px
            h = h.replace("</style>", FTR_CSS + "</style>", 1).replace("<body data-hl=", f'<body data-edge="{EDGE}" data-hl=', 1)
        return h
    t = post["theme"]; x = s["_ix"]; f = s["fields"]
    surface = s.get("surface") or "light"
    inner, deco = {"panorama": pano_slide, "follow": follow_slide, "reveal": reveal_slide, "awards": awards_slide}[x["kind"]](t, f, x, surface, post, i)
    h = frame(t, post.get("highlight", "A"), surface, i, len(post["slides"]), inner, deco, "_ix")
    h = h.replace("</style>", ix_css(t, surface) + "</style>", 1)
    return h.replace("<body data-hl=", f'<body data-edge="{EDGE}" data-ix="{x["kind"]}" data-hl=', 1)


def _ckey(group):
    return re.sub(r"[^a-z0-9-]", "-", group)


def canvas_png(post, group):
    return Path(post.get("_imgdir") or "build/_img").parent / f"canvas-{_ckey(group)}@2x.png"


def canvas_html(post, group):
    """The whole panorama (n x 1080 wide) as one page. Rendered ONCE; every slide then shows its own 1080 px slice of
    this image at 1:1 device pixels, so neighbouring slides share pixel columns with the same continuous canvas."""
    s = next(s for s in post["slides"] if (s.get("_ix") or {}).get("group") == group)
    x = s["_ix"]; t = post["theme"]; surface = s.get("surface") or "light"; n = x["n"]
    layers, svg = {"panorama": pano_canvas, "follow": follow_canvas}[x["kind"]](t, s["fields"], n, surface)
    return (f'<!doctype html><html><head><meta charset="utf-8"><style>*{{margin:0;padding:0;box-sizing:border-box}}'
            f'html,body{{width:{n*W}px;height:{H}px;overflow:hidden;background:{THEMES[t][surface]["bg"]}}}</style></head>'
            f'<body><div style="position:relative;width:{n*W}px;height:{H}px;overflow:hidden">{layers}{svg}</div></body></html>')


def canvas_jobs(posts, build):
    jobs = []
    for p in posts:
        seen = {}
        for s in p["slides"]:
            x = s.get("_ix") or {}
            if x.get("group") and x["group"] not in seen:
                seen[x["group"]] = x["n"]
        for g, n in seen.items():
            hp = build / f"canvas-{_ckey(g)}.html"; hp.write_text(canvas_html(p, g))
            jobs.append({"id": f"{p['id']}/canvas", "html": str(hp), "png": str(canvas_png(p, g)), "raw": True, "w": n * W,
                         "group": g, "n": n})
    return jobs


def _head(f, cls="h1"):
    out = f'<div class="kick" data-box>{md(f["kicker"])}</div>' if f.get("kicker") else ""
    if f.get("title"):
        out += f'<h1 class="{cls}" data-box>{md(f["title"])}</h1>'
    if f.get("lead"):
        out += f'<p class="lead" data-box>{md(f["lead"])}</p>'
    return out


def _ixart(top_slide_y, body, extra=""):
    """Positioned layer inside .main: everything interactive lives here, in slide coordinates via _at()."""
    return f'<div class="ixart" data-box style="top:{top_slide_y - MT}px{extra}">{body}</div>', top_slide_y


def _at(x, y, top):  # slide px -> ixart px
    return x - ML, y - top


# ------------------------------------------------------------------ panorama canvas helpers
def _canvas_div(post, group, n, k):
    """Slide k's window onto the pre-rendered canvas image (natural size n*2160 x 2700 = n*1080 x 1350 CSS at 2x)."""
    uri = canvas_png(post, group).resolve().as_uri()
    return (f'<div class="deco ixcanvas" style="left:{-k*W}px;top:0;width:{n*W}px;height:{H}px">'
            f'<img src="{uri}" alt="" style="display:block;width:{n*W}px;height:{H}px"></div>')


def _canvas_bg(t, n, surface):
    """Full-width background for a panorama, so blobs/grids are continuous across seams. Returns (html layers, svg shapes)."""
    if t == "lockedhour":
        dot = "rgba(255,244,224,.10)" if surface == "dark" else "rgba(20,20,20,.13)"
        return (f'<div style="position:absolute;inset:0;background-image:radial-gradient({dot} 2.2px,transparent 2.6px);'
                f'background-size:30px 30px;background-position:15px 15px"></div>', "")
    shapes = ""
    if t == "fullyfunded":
        cols = ["#E8ECFF", "#FFD9C9"]
        shapes += f'<circle cx="{n*W-60}" cy="40" r="300" fill="#E8ECFF"/>'
        for j in range(1, n):
            shapes += f'<circle cx="{j*W}" cy="{80 if j % 2 else 1290}" r="250" fill="{cols[j % 2]}" opacity="{1 if j % 2 else .55}"/>'
        shapes += '<circle cx="-40" cy="1330" r="260" fill="#FFD9C9" opacity=".55"/>'
        return "", shapes
    if t == "hourback":
        defs = ('<defs><radialGradient id="hbg1"><stop offset="0" stop-color="#FFC94D" stop-opacity=".33"/><stop offset=".62" stop-color="#FFC94D" stop-opacity="0"/></radialGradient>'
                '<radialGradient id="hbg2"><stop offset="0" stop-color="#FFEEDC"/><stop offset=".65" stop-color="#FFEEDC" stop-opacity="0"/></radialGradient></defs>')
        shapes += defs + f'<circle cx="{n*W-40}" cy="60" r="430" fill="url(#hbg1)"/>'
        for j in range(1, n):
            shapes += f'<circle cx="{j*W}" cy="{140 if j % 2 else 1240}" r="400" fill="url(#{"hbg1" if j % 2 else "hbg2"})"/>'
        return "", shapes
    # littlefold: sherbet blobs + the same paper grain, as one continuous layer
    cols = ["#FFE1EA", "#E3F3FD", "#FFF0CF"]
    shapes += f'<circle cx="{n*W-60}" cy="20" r="320" fill="#FFE1EA"/>'
    for j in range(1, n):
        shapes += f'<circle cx="{j*W}" cy="{90 if j % 2 else 1280}" r="240" fill="{cols[j % 3]}"/>'
    grain = ("<div style=\"position:absolute;inset:0;opacity:.35;mix-blend-mode:multiply;background-image:url(&quot;data:image/svg+xml;utf8,"
             "<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/>"
             "<feColorMatrix values='0 0 0 0 .42  0 0 0 0 .33  0 0 0 0 .24  0 0 0 .09 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>&quot;)\"></div>")
    return grain, shapes


def _svg(n, body):
    return (f'<svg width="{n*W}" height="{H}" viewBox="0 0 {n*W} {H}" xmlns="http://www.w3.org/2000/svg" '
            f'style="position:absolute;left:0;top:0;display:block">{body}</svg>')


def _nested(svg, x, y):
    return svg.replace("<svg ", f'<svg x="{x:.1f}" y="{y:.1f}" ', 1)


# ------------------------------------------------------------------ PANORAMA
PANO_MID, PANO_AMP, PANO_X0 = 860, 64, 150


def _distribute(k, n):
    base, rem = divmod(k, n); out = [base] * n
    order = sorted(range(n), key=lambda j: (abs(j - (n - 1) / 2), j))
    for j in order[:rem]:
        out[j] += 1
    return out


def _pano_y(x, n):
    return PANO_MID + PANO_AMP * math.sin(2 * math.pi * (x - PANO_X0) / W)


def _pano_stops(f, n):
    stops = f.get("stops", []); ps = f.get("per_slide") or _distribute(len(stops), n)
    out = []; si = 0
    for j, c in enumerate(ps):
        for m in range(c):
            x = j * W + ML + (MR - ML) * (m + 0.5) / c
            out.append(dict(stops[si], x=x, y=_pano_y(x, n), slide=j, side=("up" if si % 2 == 0 else "down"), c=c))
            si += 1
    return out


def pano_canvas(t, f, n, surface):
    T = TOK[t]; bgc = THEMES[t][surface]["bg"]; layers, shapes = _canvas_bg(t, n, surface)
    x0, x1 = PANO_X0, n * W - PANO_X0
    pts = [(x, _pano_y(x, n)) for x in range(x0, x1 + 1, 4)]
    d = "M" + " L".join(f"{x} {y:.2f}" for x, y in pts)
    style = f.get("path", "wave")
    if style == "straight":
        d = f"M{x0} {PANO_MID} L{x1} {PANO_MID}"
    if t == "lockedhour":
        body = (f'<path d="{d}" transform="translate(8 8)" stroke="#141414" stroke-width="28" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
                f'<path d="{d}" stroke="#141414" stroke-width="28" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
                f'<path d="{d}" stroke="{T["path"]}" stroke-width="13" fill="none" stroke-linecap="round" stroke-linejoin="round"/>')
    elif t == "littlefold":
        body = (f'<path d="{d}" stroke="{T["path_case"]}" stroke-width="30" fill="none" stroke-linecap="round"/>'
                f'<path d="{d}" stroke="{T["path"]}" stroke-width="9" fill="none" stroke-linecap="round" stroke-dasharray="2 22"/>')
    else:
        body = (f'<path d="{d}" stroke="{T["path_case"]}" stroke-width="32" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
                f'<path d="{d}" stroke="{T["path"]}" stroke-width="12" fill="none" stroke-linecap="round" stroke-linejoin="round"/>')
    for s in _pano_stops(f, n):   # connector + dot per stop (inside its own slide, never on a seam)
        dy = -1 if s["side"] == "up" else 1
        ink = "#141414" if t == "lockedhour" else T["path"]
        body += f'<path d="M{s["x"]:.1f} {s["y"]:.1f} V{s["y"] + dy*52:.1f}" stroke="{ink}" stroke-width="5" stroke-dasharray="{"none" if t == "lockedhour" else "3 9"}" stroke-linecap="round"/>'
        if t == "lockedhour":
            body += f'<circle cx="{s["x"]+4:.1f}" cy="{s["y"]+4:.1f}" r="22" fill="#141414"/><circle cx="{s["x"]:.1f}" cy="{s["y"]:.1f}" r="22" fill="{T["dot"]}" stroke="#141414" stroke-width="6"/>'
        else:
            body += f'<circle cx="{s["x"]:.1f}" cy="{s["y"]:.1f}" r="21" fill="{T["dot"]}" stroke="{bgc}" stroke-width="8"/>'
    # start + end markers
    sy, ey = _pano_y(x0, n), _pano_y(x1, n)
    if t == "lockedhour":
        body += f'<circle cx="{x0}" cy="{sy:.1f}" r="16" fill="#141414"/>'
        body += (f'<circle cx="{x1+6}" cy="{ey+6:.1f}" r="40" fill="#141414"/><circle cx="{x1}" cy="{ey:.1f}" r="40" fill="#FF5CA8" stroke="#141414" stroke-width="6"/>'
                 f'<path d="M{x1-16} {ey:.1f} l11 11 l21 -23" stroke="#141414" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>')
    else:
        body += f'<circle cx="{x0}" cy="{sy:.1f}" r="14" fill="{T["path"]}"/>'
        body += (f'<circle cx="{x1}" cy="{ey:.1f}" r="38" fill="{T["path"]}"/>'
                 f'<path d="M{x1-15} {ey:.1f} l10 10 l20 -22" stroke="#FFFFFF" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>')
    for o in f.get("objects", []):    # traveling objects: anything may straddle a seam (art only, never text)
        cx = o["seam"] * W if "seam" in o else float(o.get("x", W))
        cy = float(o.get("y", _pano_y(cx, n))); sz = float(o.get("size", 170)); art = o.get("art", "clock")
        if art == "clock":
            g = clock_lh(sz, float(o.get("progress", 0.75))); body += _nested(g, cx - sz / 2, cy - sz * 228 / 400)
        elif art == "sun":
            g = sun_hb(sz); body += _nested(g, cx - sz / 2, cy - sz / 2)
        elif art == "mark":
            g = LF.mark_svg(int(sz)); body += _nested(g, cx - sz / 2, cy - sz / 2)
        else:  # star
            body += _nested(LF.STAR.format(w=int(sz), c=o.get("color", T["dot"])).replace("'", '"'), cx - sz / 2, cy - sz / 2)
    return layers, _svg(n, shapes + body)


def pano_slide(t, f, x, surface, post, i):
    k, n = x["k"], x["n"]; T = TOK[t]
    hd = (f if k == 0 else ((f.get("heads") or [None] * n)[k] if len(f.get("heads") or []) > k else None)) or {}
    if k == 0:
        hd = {"kicker": f.get("kicker"), "title": f.get("title")}
    head = _head(hd)
    top = 470 if (hd.get("title")) else MT
    cards = ""
    for s in _pano_stops(f, n):
        if s["slide"] != k:
            continue
        w = 400 if s["c"] <= 2 else 340
        lx = max(ML, min(MR - w, s["x"] - k * W - w / 2))
        ax, _ = _at(lx, 0, top)
        if s["side"] == "up":
            pos = f"bottom:{(MB - (s['y'] - 54)):.0f}px"
        else:
            pos = f"top:{(s['y'] + 54 - top):.0f}px"
        cards += (f'<div class="card ixc stp" data-box style="left:{ax:.0f}px;{pos};width:{w}px">'
                  f'<span class="tm amt">{md(s.get("time",""))}</span><div class="stx">{md(s.get("text",""))}</div></div>')
    art, _ = _ixart(top, cards)
    deco = _canvas_div(post, x["group"], n, k)
    return head + art, deco


# ------------------------------------------------------------------ FOLLOW-THE-LINE
FL_TOP, FL_BOT = 500, 1120
FL_CARD_R = 460        # choice cards: x 80..460 on slide 1
FL_ANS_L = 560         # answer cards: x 560..1000 on the last slide


def _fl_lanes(L):
    return [FL_TOP + (FL_BOT - FL_TOP) * i / L for i in range(L + 1)]


def _fl_bounds(n):
    b = [440, 760, 1080]
    for j in range(1, n - 1):
        b += [j * W + 270, j * W + 540, j * W + 810, (j + 1) * W]
    b += [(n - 1) * W + 270, (n - 1) * W + FL_ANS_L + 30]
    return b


def _fl_actions(state, lanes):
    """Single moves: (new_state, lane interval, crossings). state[i] = lane of line i."""
    occ = {l: i for i, l in enumerate(state)}; acts = []
    for a in range(lanes - 1):
        if a in occ and a + 1 in occ:
            s = list(state); s[occ[a]], s[occ[a + 1]] = a + 1, a
            acts.append((tuple(s), (a, a + 1), 1))
    for i, l in enumerate(state):
        for to in (l - 2, l - 1, l + 1, l + 2):
            if 0 <= to < lanes and to not in occ:
                mid = (l + to) // 2 if abs(to - l) == 2 else None
                cross = 1 if (mid is not None and mid in occ) else 0
                s = list(state); s[i] = to
                acts.append((tuple(s), (min(l, to), max(l, to)), cross))
    return acts


def _fl_options(state, lanes):
    single = _fl_actions(state, lanes); opts = [(state, 0)]
    for s, iv, c in single:
        opts.append((s, c))
    for a in range(len(single)):         # two independent moves in separate lane bands
        for b in range(a + 1, len(single)):
            (sa, ia, ca), (sb, ib, cb) = single[a], single[b]
            if ia[1] < ib[0] or ib[1] < ia[0]:
                merged = tuple(sb[i] if sb[i] != state[i] else sa[i] for i in range(len(state)))
                if len(set(merged)) == len(merged):
                    opts.append((merged, ca + cb))
    return opts


def _fl_braid(L, end_lane, nmove, seed):
    """Lane plan per boundary. Lines start in lanes 0..L-1, end in end_lane[line]; every crossing is a clean X."""
    lanes = L + 1; start = tuple(range(L)); goal = tuple(end_lane)
    from collections import deque
    dist = {goal: 0}; q = deque([goal])
    while q:
        s = q.popleft()
        for ns, _ in _fl_options(s, lanes):
            if ns not in dist:
                dist[ns] = dist[s] + 1; q.append(ns)
    for attempt in range(400):
        R = random.Random(seed * 1000 + attempt); s = start; plan = [s]; cross = 0; touched = set()
        for step in range(nmove):
            left = nmove - step - 1
            opts = [(ns, c) for ns, c in _fl_options(s, lanes) if dist.get(ns, 99) <= left]
            wts = [(0.35 if ns == s else 1.0 + 2.2 * c) for ns, c in opts]
            ns, c = R.choices(opts, wts)[0]
            if c:
                touched |= {i for i in range(L) if ns[i] != s[i]}
            cross += c; s = ns; plan.append(s)
        if s == goal and cross >= L + 1 and len(touched) == L:
            return plan
    raise RuntimeError("follow-the-line: could not build a line plan")


def _fl_plan(f, n):
    ch = f["choices"]; L = len(ch)
    order = f.get("end_order")              # top->bottom choice index on the last slide
    if order is None:
        R = random.Random(f.get("seed", 7) + L)
        while True:
            order = list(range(L)); R.shuffle(order)
            if all(order[j] != j for j in range(L)):
                break
    end_lane = [0] * L
    for lane, ci in enumerate(order):
        end_lane[ci] = lane
    b = _fl_bounds(n); nmove = len(b) - 1 - 3     # first segment + last two are straight
    plan = _fl_braid(L, end_lane, nmove, int(f.get("seed", 7)))
    states = [plan[0]] + plan + [plan[-1], plan[-1]]
    return b, states, order


def follow_canvas(t, f, n, surface):
    T = TOK[t]; L = len(f["choices"]); lanes = _fl_lanes(L); bgc = THEMES[t][surface]["bg"]
    b, states, _ = _fl_plan(f, n)
    layers, shapes = _canvas_bg(t, n, surface)
    sw = 17 if L <= 3 else 14; case = sw + 16
    body = ""
    for i in range(L):
        y0 = lanes[states[0][i]]; d = f"M{b[0]} {y0:.1f}"
        for j in range(1, len(b)):
            ya, yb = lanes[states[j - 1][i]], lanes[states[j][i]]
            if abs(ya - yb) < .5:
                d += f" L{b[j]} {yb:.1f}"
            else:
                xm = (b[j - 1] + b[j]) / 2
                d += f" C{xm:.1f} {ya:.1f} {xm:.1f} {yb:.1f} {b[j]} {yb:.1f}"
        col = T["lines"][i]
        casing = "#141414" if t == "lockedhour" else bgc
        if t == "lockedhour":   # zine: ink outline + hard shadow, then the colour
            body += (f'<path d="{d}" transform="translate(6 6)" stroke="#141414" stroke-width="{sw+8}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
                     f'<path d="{d}" stroke="{bgc}" stroke-width="{case+6}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
                     f'<path d="{d}" stroke="#141414" stroke-width="{sw+8}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>')
        else:
            body += f'<path d="{d}" stroke="{casing}" stroke-width="{case}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
        body += f'<path d="{d}" stroke="{col}" stroke-width="{sw}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
    return layers, _svg(n, shapes + body)


def _disc(c, col, size, t):
    txt = md(c.get("icon") or str(c.get("label", "?"))[:2])
    emoji = bool(re.search(r"[\U0001F000-\U0001FAFF☀-➿]", str(c.get("icon", ""))))
    ink = "#141414" if (t == "lockedhour" and col in ("#FFD43B", "#FFFFFF")) else "#FFFFFF"
    bg = "#FFFFFF" if emoji else col
    brd = f"border:4px solid {col};" if emoji else ("border:3px solid #141414;" if t == "lockedhour" else "")
    fs = size * (0.5 if emoji else (0.42 if len(re.sub("<[^>]+>", "", txt)) <= 2 else 0.32))
    return (f'<span class="disc amt" style="width:{size}px;height:{size}px;background:{bg};color:{ink};{brd}font-size:{fs:.0f}px">{txt}</span>')


def follow_slide(t, f, x, surface, post, i):
    k, n = x["k"], x["n"]; T = TOK[t]; ch = f["choices"]; L = len(ch); lanes = _fl_lanes(L)
    _, _, order = _fl_plan(f, n)
    mids = f.get("middle") or [{}, {}]
    hd = {"kicker": f.get("kicker"), "title": f.get("title")} if k == 0 else (f.get("end") or {} if k == n - 1 else (mids[k - 1] or {}))
    head = _head({"kicker": hd.get("kicker"), "title": hd.get("title")})
    top = 410
    ch_h = min(150, (lanes[1] - lanes[0]) - 36); disc = int(min(84, ch_h - 22))
    body = ""
    if k == 0:
        for ci, c in enumerate(ch):
            y = lanes[ci]; ax, ay = _at(ML, y - ch_h / 2, top)
            body += (f'<div class="card ixc ch" data-box style="left:{ax}px;top:{ay:.0f}px;width:{FL_CARD_R-ML}px;height:{ch_h:.0f}px">'
                     f'{_disc(c, T["lines"][ci], disc, t)}<span class="chl">{md(c["label"])}</span></div>')
    elif k == n - 1:
        last = 0
        for lane, ci in enumerate(order):
            c = ch[ci]; a = c["answer"]; y = lanes[lane]; ax, ay = _at(FL_ANS_L, y - ch_h / 2, top)
            sub = f'<div class="as">{md(a["note"])}</div>' if a.get("note") else ""
            body += (f'<div class="card ixc an" data-box style="left:{ax}px;top:{ay:.0f}px;width:{MR-FL_ANS_L}px;height:{ch_h:.0f}px;'
                     f'box-shadow:inset 8px 0 0 {T["lines"][ci]}{"" if t != "lockedhour" else ",8px 8px 0 #141414"}">'
                     f'{_disc(c, T["lines"][ci], int(disc*0.86), t)}<div class="anb"><div class="av amt">{md(a["value"])}</div>{sub}</div></div>')
            last = max(last, y + ch_h / 2)
        e = f.get("end") or {}
        if e.get("note"):
            ax, ay = _at(ML, last + 34, top)
            body += f'<p class="small ixnote" data-box style="left:{ax}px;top:{ay:.0f}px;width:{MR-ML}px">{md(e["note"])}</p>'
    art, _ = _ixart(top, body)
    deco = _canvas_div(post, x["group"], n, k)
    return head + art, deco


# ------------------------------------------------------------------ SWIPE-TO-REVEAL
REVEAL_RECT = (80, 440, 1000, 1120)   # x0, y0, x1, y1 of the revealed card (slide px, 1x); 920x680 divides by 40/20/10/8/5


def _reveal_target(t, tg):
    k = tg.get("kind")
    if k == "prompt":
        return (f'<div class="rvbar"><i></i><i></i><i></i><span class="label">{md(tg.get("label","AI chat"))}</span></div>'
                f'<div class="rvp"><p>{md(tg.get("text",""), ph=True)}</p></div>')
    if k == "number":
        num = md(tg["number"]) + (f'<small>{md(tg["unit"])}</small>' if tg.get("unit") else "")
        return (f'<div class="rvn"><div class="num">{num}</div><div class="h2" style="margin-top:26px">{md(tg.get("label",""))}</div>'
                + (f'<p class="body" style="margin-top:14px">{md(tg["body"])}</p>' if tg.get("body") else "") + "</div>")
    art = {"sun": lambda: sun_hb(420), "clock": lambda: clock_lh(400, float(tg.get("progress", .75))),
           "mark": lambda: LF.mark_svg(380)}.get(tg.get("art", "mark"), lambda: LF.mark_svg(380))()
    return f'<div class="rva">{art}' + (f'<div class="h2">{md(tg["label"])}</div>' if tg.get("label") else "") + "</div>"


def reveal_slide(t, f, x, surface, post, i):
    k, n = x["k"], x["n"]; st = f["steps"][k]
    head = _head({"kicker": st.get("kicker", f.get("kicker")), "title": st.get("title")})
    top = 430
    x0, y0, x1, y1 = REVEAL_RECT; ax, ay = _at(x0, y0, top)
    card = (f'<div class="card ixc rv rv-{f["target"]["kind"]}" data-box style="left:{ax}px;top:{ay}px;width:{x1-x0}px;height:{y1-y0}px">'
            f'{_reveal_target(t, f["target"])}</div>')
    meter = "".join(f'<i class="{"on" if j <= k else ""}"></i>' for j in range(n))
    last = k == n - 1
    txt = st.get("hint") or (f.get("done_hint", "") if last else f.get("hint", "Keep swiping to reveal"))
    pill = ""
    if txt:
        px, py = _at(x0, y1 + 24, top)
        pill = (f'<div class="ixpill" data-box style="left:{px}px;top:{py}px"><span class="mt">{meter}</span>'
                f'<span>{md(txt, ph=True)}</span>{"" if last else icon("arrow", 26, 3)}</div>')
    art, _ = _ixart(top, card + pill)
    return head + art, bg_deco(t, surface, "_ix", None, i)


# ------------------------------------------------------------------ AWARDS
def _star_pts(cx, cy, r1, r2, n=5, rot=-90):
    pts = []
    for j in range(2 * n):
        r = r1 if j % 2 == 0 else r2; a = math.radians(rot + j * 180 / n)
        pts.append(f"{cx + r*math.cos(a):.1f},{cy + r*math.sin(a):.1f}")
    return " ".join(pts)


def award_svg(shape, c1, c2, ink=None, zine=False, size=170):
    """Original rosette / star / medal, drawn in SVG (viewBox 200x220)."""
    sw = (5 if zine else 3) if ink else 0
    st = f' stroke="{ink}" stroke-width="{sw}" stroke-linejoin="round"' if ink else ""
    parts = ""
    if shape == "rosette":
        tails = (f'<path d="M80 118 L56 206 L77 192 L92 210 L106 128 Z" fill="{c2}"{st}/>'
                 f'<path d="M120 118 L144 206 L123 192 L108 210 L94 128 Z" fill="{c1}"{st}/>')
        bumps = "".join(f'<circle cx="{100 + 64*math.cos(math.radians(a)):.1f}" cy="{86 + 64*math.sin(math.radians(a)):.1f}" r="17" fill="{c1}"{st}/>' for a in range(0, 360, 24))
        core = (f'<circle cx="100" cy="86" r="66" fill="{c1}"/>'
                f'<circle cx="100" cy="86" r="48" fill="{c2}"{st}/>'
                f'<circle cx="100" cy="86" r="40" fill="none" stroke="#FFFFFF" stroke-width="3" stroke-dasharray="2 7" stroke-linecap="round" opacity=".9"/>'
                f'<polygon points="{_star_pts(100, 88, 27, 11.5)}" fill="{c1}"{st}/>')
        parts = tails + bumps + core
    elif shape == "star":
        parts = (f'<polygon points="{_star_pts(100, 112, 92, 42)}" fill="{c1}" stroke="{ink or c1}" stroke-width="{max(sw, 10) if not ink else sw}" stroke-linejoin="round"/>'
                 f'<polygon points="{_star_pts(100, 114, 52, 24)}" fill="{c2}" opacity=".9"/>'
                 f'<path d="M150 30 l4 -12 l4 12 l12 4 l-12 4 l-4 12 l-4 -12 l-12 -4z" fill="{c2}"{st}/>'
                 f'<path d="M34 54 l3 -8 l3 8 l8 3 l-8 3 l-3 8 l-3 -8 l-8 -3z" fill="{c1}"{st}/>')
    else:  # medal
        parts = (f'<path d="M62 8 L96 96 L120 96 L86 8 Z" fill="{c2}"{st}/>'
                 f'<path d="M138 8 L104 96 L80 96 L114 8 Z" fill="{c1}"{st}/>'
                 f'<circle cx="100" cy="142" r="64" fill="{c1}"{st}/>'
                 f'<circle cx="100" cy="142" r="46" fill="{c2}"{st}/>'
                 f'<polygon points="{_star_pts(100, 145, 30, 13)}" fill="{c1}"{st}/>')
    if zine and ink:   # hard offset shadow, Locked Hour style
        sh = re.sub(r'fill="#[0-9A-Fa-f]+"', 'fill="' + ink + '"', parts)
        parts = '<g transform="translate(7 7)">' + sh + "</g>" + parts
    return f'<svg class="awsvg" width="{size}" height="{size*1.1:.0f}" viewBox="0 0 200 220" xmlns="http://www.w3.org/2000/svg" overflow="visible">{parts}</svg>'


def awards_slide(t, f, x, surface, post, i):
    T = TOK[t]; items = [it if isinstance(it, dict) else {"text": it} for it in f["items"]]
    head = _head({"kicker": f.get("kicker"), "title": f.get("title")})
    top = 410; shapes = ["rosette", "star", "medal"]
    cols = 3 if len(items) in (5, 6) else 2
    cells = ""
    for j, it in enumerate(items):
        c1, c2 = T["awards"][j % len(T["awards"])]
        svg = award_svg(it.get("shape") or shapes[j % 3], c1, c2, T["award_ink"], t == "lockedhour", 172 if cols == 3 else 190)
        cells += f'<div class="card aw" style="width:calc((100% - {24*(cols-1)}px) / {cols})">{svg}<div class="awl">{md(it["text"])}</div></div>'
    note = f'<p class="small awnote">{md(f["note"])}</p>' if f.get("note") else ""
    art, _ = _ixart(top, f'<div class="awgrid">{cells}</div>{note}', ";display:flex;flex-direction:column;gap:20px")
    return head + art, bg_deco(t, surface, "_ix", None, i)


# ------------------------------------------------------------------ cover save-line
def _save_arrow(col):
    return (f'<svg width="92" height="64" viewBox="0 0 92 64" fill="none" stroke="{col}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">'
            f'<path d="M6 12 C26 4 46 8 52 22 C58 36 44 44 38 34 C32 24 52 14 66 26 C74 33 78 42 80 52"/>'
            f'<path d="M68 46 L80 54 L86 40"/></svg>')


def _inject_stamp(h, t, s, text, pos="tr"):
    surface = s.get("surface") or ("dark" if t == "hourback" else "light")
    ink = THEMES[t]["light"]["ink"]
    svg = feed.stamp_svg(t, 190, ink, "#FFFFFF", text=text if isinstance(text, str) else None)
    xy = {"tr": "right:0;top:-14px", "tl": "left:0;top:-14px", "br": "right:0;bottom:-6px", "bl": "left:0;bottom:-6px"}[pos]
    css = (f".vacc.ixstamp{{position:absolute;{xy};width:190px;height:190px;z-index:5;transform:rotate(-8deg)}}"
           ".vacc.ixstamp svg{width:190px;height:190px;display:block;filter:drop-shadow(0 14px 22px rgba(0,0,0,.18))}")
    h = h.replace("</style>", css + "</style>", 1)
    return re.sub(r'(<div class="visual" data-box data-vis="[^"]*">)', lambda m: m.group(1) + f'<div class="vacc art ixstamp">{svg}</div>', h, count=1)


def _inject_save_line(h, t, s, text):
    T = TOK[t]; surface = s.get("surface") or ("dark" if t == "hourback" else "light")
    col = T["save_dark"] if surface == "dark" else T["save"]
    face, fam, scale, style, wt = hand_font()
    css = (f"{face}.lead.saveline{{font-family:{fam};font-style:{style};font-weight:{wt};font-size:{44*scale:.0f}px;line-height:1.15;"
           f"letter-spacing:-.005em;color:{col};max-width:900px;margin-top:40px;display:flex;align-items:flex-end;gap:12px;"
           f"transform:rotate(-1.2deg);transform-origin:0 100%;text-wrap:balance}}"
           f".lead.saveline svg{{flex:none;margin-bottom:-14px}}")
    el = f'<p class="lead saveline" data-box><span>{md(text)}</span>{_save_arrow(T["arrow"])}</p>'
    h = h.replace("</style>", css + "</style>", 1)
    if '<div class="visual" data-box' in h:
        return h.replace('<div class="visual" data-box', el + '<div class="visual" data-box', 1)
    return h.replace('</div>\n<div class="ftr">', el + '</div>\n<div class="ftr">', 1)


# ------------------------------------------------------------------ CSS
def ix_css(t, surface):
    T = TOK[t]; zine = t == "lockedhour"
    return FTR_CSS + f"""
.ixcanvas{{z-index:0}}
.ixart{{position:absolute;left:0;right:0;bottom:0}}
.card.ixc{{position:absolute}}
.ch{{display:flex;align-items:center;gap:22px;padding:0 24px 0 22px}}
.disc{{flex:none;border-radius:50%;display:grid;place-items:center;font-family:'Inter Display';font-weight:900;letter-spacing:-.02em;line-height:1}}
.chl{{font:700 32px/1.2 Inter;color:var(--ink);text-wrap:balance}}
.an{{display:flex;align-items:center;gap:20px;padding:0 26px 0 30px}}
.anb{{min-width:0}}
.av{{font-family:var(--head);font-weight:var(--hw);font-size:54px;line-height:1;letter-spacing:-.02em;color:var(--ink)}}
.as{{font:600 26px/1.25 Inter;color:var(--muted);margin-top:8px}}
.ixnote{{position:absolute;margin:0}}
.stp{{padding:22px 26px 24px}}
.tm{{display:inline-block;font:800 26px/1 Inter;letter-spacing:.04em;padding:9px 13px 8px;border-radius:{'8px' if zine else '999px'};
  background:{T['chip_bg']};color:{T['chip_ink']};{'border:3px solid #141414;' if zine else ''}}}
.stx{{font:600 33px/1.28 Inter;color:var(--ink);margin-top:12px;text-wrap:pretty}}
.rv{{display:flex;flex-direction:column;overflow:hidden;padding:0}}
.rvbar{{flex:none;height:64px;display:flex;align-items:center;gap:10px;padding:0 28px;border-bottom:{'3px solid #141414' if zine else '2px solid var(--line)'};
  background:{'#FFD43B' if zine else {'fullyfunded': '#E8ECFF', 'hourback': '#FFEEDC', 'littlefold': '#FFEFC8'}[t]}}}
.rvbar i{{width:16px;height:16px;border-radius:50%;background:var(--ink);opacity:.22;display:block}}
.rvbar .label{{margin-left:12px;color:var(--ink);opacity:.8;font-size:21px}}
.rvp{{flex:1 1 0;display:flex;align-items:center;padding:34px 44px 38px;font:500 37px/1.46 Inter;color:var(--ink);text-wrap:pretty}}
.rvn{{flex:1 1 0;display:flex;flex-direction:column;justify-content:center;padding:44px 56px}}
.rva{{flex:1 1 0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:24px}}
.ixpill{{position:absolute;display:flex;align-items:center;gap:14px;font:800 24px/1 Inter;padding:15px 22px 15px 18px;border-radius:999px;
  background:{T['pill_bg']};color:{T['pill_ink']};{T['pill_extra']}white-space:nowrap}}
.ixpill .mt{{display:flex;gap:6px}}.ixpill .mt i{{display:block;width:12px;height:12px;border-radius:50%;background:currentColor;opacity:.28}}
.ixpill .mt i.on{{opacity:1}}
.ixpill .ph{{color:inherit;opacity:.85}}
.awgrid{{flex:1 1 0;min-height:0;display:flex;flex-wrap:wrap;justify-content:center;align-content:stretch;gap:24px}}
.aw{{height:calc((100% - 24px) / 2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:20px 22px 24px;text-align:center}}
.awsvg{{display:block;flex:none;overflow:visible}}
.awl{{font:650 30px/1.26 Inter;color:var(--ink);text-wrap:balance}}
.awnote{{flex:none;margin:0}}
"""


# ------------------------------------------------------------------ after the browser: downsample, pixelate, seam QA
def _pixelate(im, x0, y0, x1, y1, b):
    from PIL import Image
    reg = im.crop((x0, y0, x1, y1)); w, h = reg.size
    cw, ch = math.ceil(w / b), math.ceil(h / b)
    small = reg.resize((cw, ch), Image.BOX, reducing_gap=None)
    big = small.resize((cw * b, ch * b), Image.NEAREST).crop((0, 0, w, h))
    im.paste(big, (x0, y0)); return im


def finalize(jobs, cjobs, report_path, W_=W, H_=H):
    """Replaces render.py's resize loop. Plain slides: the exact same 2x -> LANCZOS -> 1080x1350 as before.
    Panorama groups: the 2x slides are joined into one strip and downsampled together, then cut, so every seam
    column is computed from continuous pixels. Reveal steps: the card is pixelated after downsampling.
    Seam QA (per seam, both sides, 2x and 1x): the slide pixels next to the edge must be identical to the canvas."""
    import json
    import numpy as np
    from PIL import Image
    groups = {}
    for j in jobs:
        g = (j.get("ix") or {}).get("group")
        if g:
            groups.setdefault(g, []).append(j)
        else:
            Image.open(j["png"]).convert("RGB").resize((W_, H_), Image.LANCZOS).save(j["final"], optimize=True)
    strips = {}
    for g, js in groups.items():
        js.sort(key=lambda j: j["ix"]["k"])
        ims = [Image.open(j["png"]).convert("RGB") for j in js]
        w2, h2 = ims[0].size
        strip = Image.new("RGB", (w2 * len(ims), h2))
        for k, im in enumerate(ims):
            strip.paste(im, (k * w2, 0))
        small = strip.resize((W_ * len(ims), H_), Image.LANCZOS)
        for k, j in enumerate(js):
            small.crop((k * W_, 0, (k + 1) * W_, H_)).save(j["final"], optimize=True)
        strips[g] = (np.asarray(strip).astype(int), js)
    for j in jobs:
        px = (j.get("ix") or {}).get("pixelate")
        if px:
            im = Image.open(j["final"]).convert("RGB"); _pixelate(im, *px).save(j["final"], optimize=True)

    rep = json.loads(Path(report_path).read_text()); by = {r["id"]: r for r in rep}
    seams = []
    for c in cjobs:
        g = c["group"]; big, js = strips[g]
        can2 = Image.open(c["png"]).convert("RGB")
        can1 = np.asarray(can2.resize((W_ * c["n"], H_), Image.LANCZOS)).astype(int); can2 = np.asarray(can2).astype(int)
        w2 = big.shape[1] // c["n"]
        for s in range(1, c["n"]):
            B2, B1 = SEAM_BAND * 2, SEAM_BAND
            d2 = int(np.abs(big[:, s*w2 - B2: s*w2 + B2] - can2[:, s*w2 - B2: s*w2 + B2]).max())
            left = np.asarray(Image.open(js[s - 1]["final"]).convert("RGB")).astype(int)
            right = np.asarray(Image.open(js[s]["final"]).convert("RGB")).astype(int)
            pair = np.concatenate([left[:, W_ - B1:], right[:, :B1]], axis=1)
            ref = can1[:, s*W_ - B1: s*W_ + B1]
            diff = np.abs(pair - ref)
            d1 = int(diff.max()); n1 = int((diff.sum(axis=2) > 0).sum())
            bgc = np.median(left[:, -1], axis=0)
            drawn = int((np.abs(left[:, -1] - bgc).sum(axis=1) > 60).sum())   # rows where drawn art crosses the seam
            info = dict(seam=f"{js[s-1]['id']} | {js[s]['id']}", max_diff_2x=d2, max_diff_1x=d1, diff_px_1x=n1,
                        rows_with_art_crossing=drawn, mean_step_between_edge_cols=round(float(np.abs(left[:, -1] - right[:, 0]).mean()), 2))
            seams.append(info)
            if d2 or d1:
                for jj in (js[s - 1], js[s]):
                    by[jj["id"]]["errors"].append(f"seam: {info['seam']} differs from the continuous canvas (max diff 2x {d2}, 1x {d1}, {n1} px)")
            by[js[s - 1]["id"]].setdefault("seams", []).append(info)
    Path(report_path).write_text(json.dumps(rep, indent=2))
    for info in seams:
        print(f"seam {'ok  ' if not (info['max_diff_2x'] or info['max_diff_1x']) else 'FAIL'} {info['seam']}: "
              f"max diff vs canvas 2x={info['max_diff_2x']} 1x={info['max_diff_1x']}, art crosses on {info['rows_with_art_crossing']} rows")
    return seams
