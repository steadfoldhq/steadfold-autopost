"""Feed aesthetic system (Oct 2026): brand stamp, per-brand palette rotation, and helpers for the 3x3 grid preview.

  stamp_svg(theme, size, ink, bg)    round rotating-text stamp ("FULLY FUNDED · MONEY, MADE CLEAR ·") around the mark.
                                     Cover field  "stamp": true  (or a custom string) on cover / ep-cover.
  cover_palette(theme, index)        one of 3-4 approved cover backgrounds, chosen by post index, so consecutive
                                     covers differ. Cover field  "palette_index": <post number>.
  episode_deep(theme, index)         the same idea for ep-cover's deep colour.
  rotation(theme, start, count)      the palette names for a run of posts (for planning a week).
"""
from .themes import THEMES, MARKS

TAGLINE = {"fullyfunded": "MONEY, MADE CLEAR", "lockedhour": "ONE HOUR AT A TIME",
           "hourback": "GET YOUR EVENINGS BACK", "littlefold": "SMALL DAYS, GENTLY"}

# Approved cover backgrounds. "light" entries recolour the light surface; "dark" uses the brand's own dark surface.
PALETTES = {
    "fullyfunded": [("cloud", "light", "#F5F7FF"), ("peach paper", "light", "#FFF3EC"), ("cobalt", "dark", None), ("cream", "light", "#F7F1E5")],
    "lockedhour": [("butter", "light", "#FFF4E0"), ("ink", "dark", None), ("sun", "light", "#FFE9B0"), ("blush", "light", "#FFEAF3")],
    "hourback": [("indigo", "dark", None), ("cream", "light", "#FFF8EF"), ("peach", "light", "#FFEBDC"), ("lilac", "light", "#F2EFFF")],
    "littlefold": [("butter", "light", "#FFF8E4"), ("blush", "light", "#FFF0F3"), ("sky", "light", "#EEF7FD"), ("berry", "dark", None)],
}
EP_DEEP = {"fullyfunded": ["#16206B", "#0E1440", "#1E2C8F"], "lockedhour": ["#151413", "#2A2118", "#1D1A26"],
           "hourback": ["#3A2240", "#2E2550", "#4A2A3A"], "littlefold": ["#7A2149", "#5E1F3F", "#8A2A4F"]}


def cover_palette(theme, index):
    name, surface, bg = PALETTES[theme][int(index) % len(PALETTES[theme])]
    return {"name": name, "surface": surface, "bg": bg}


def episode_deep(theme, index):
    return EP_DEEP[theme][int(index) % len(EP_DEEP[theme])]


def rotation(theme, start=0, count=9):
    return [cover_palette(theme, start + k)["name"] for k in range(count)]


def stamp_svg(theme, size=200, ink="#0E1440", bg="#FFFFFF", text=None):
    """Circular text around the brand mark. All text >= 20 px at size >= 200 (render.js min-font)."""
    T = THEMES[theme]
    txt = (text or f"{T['name'].upper()} · {TAGLINE[theme]} · ").replace("&", "&amp;")
    s = 220; r = 86                                           # viewBox units; text sits on radius r
    path = f"M{s/2},{s/2} m-{r},0 a{r},{r} 0 1,1 {2*r},0 a{r},{r} 0 1,1 -{2*r},0"
    circ = 2 * 3.14159 * r
    fs = 20 * s / size                                        # keep the rendered size at 20 px
    mark = (MARKS / T["mark"]).as_uri()
    return (f'<svg class="stampsvg" width="{size}" height="{size}" viewBox="0 0 {s} {s}" xmlns="http://www.w3.org/2000/svg" '
            f'xmlns:xlink="http://www.w3.org/1999/xlink">'
            f'<defs><path id="stp-{theme}" d="{path}"/></defs>'
            f'<circle cx="{s/2}" cy="{s/2}" r="{s/2-2}" fill="{bg}" stroke="{ink}" stroke-width="2.5"/>'
            f'<circle cx="{s/2}" cy="{s/2}" r="{r-20}" fill="none" stroke="{ink}" stroke-width="1.5" stroke-dasharray="2 6" stroke-linecap="round" opacity=".6"/>'
            f'<text font-family="DejaVu Sans Mono, monospace" font-weight="700" font-size="{fs:.1f}" fill="{ink}" letter-spacing="1">'
            f'<textPath href="#stp-{theme}" xlink:href="#stp-{theme}" textLength="{circ - 6:.0f}" lengthAdjust="spacingAndGlyphs">{txt}</textPath></text>'
            f'<image href="{mark}" xlink:href="{mark}" x="{s/2-38}" y="{s/2-38}" width="76" height="76"/></svg>')
