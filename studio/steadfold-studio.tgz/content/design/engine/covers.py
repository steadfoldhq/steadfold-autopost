"""Cover visuals (v2.1). One hero object per cover, drawn in each brand's own style.
Every visual renders inside .visual > .vart; fit.js scales .vart down (never up) so the art can
never collide with a long title/lead, and QA fails if it had to shrink below 60%."""
import hashlib
from .markup import md
from .visuals import clock_lh, sun_hb, icon
from . import littlefold as LF

COVER_VISUALS = {
    "fullyfunded": ["stub", "lookup", "timeline", "bignum", "split"],
    "lockedhour": ["stamp", "timeline", "receipt", "beforeafter", "torn", "clock"],
    "hourback": ["phone", "beforeafter", "chat", "doc", "sun"],
    "littlefold": LF.COVER_TYPES,
}
DEFAULT_VISUAL = {"fullyfunded": "split", "lockedhour": "clock", "hourback": "sun", "littlefold": "arch"}
ACCENTS = {"clock", "sun"}


def visual_type(theme, f):
    v = f.get("visual") or {}
    return v.get("type") or DEFAULT_VISUAL[theme]


def _seed(*parts):
    return int(hashlib.md5("|".join(map(str, parts)).encode()).hexdigest()[:8], 16)


def zigzag(top=True, bottom=True, teeth=26, depth=14):
    """clip-path polygon with torn/zig-zag top and/or bottom edges (percent x, px y)."""
    pts = []
    if top:
        for i in range(teeth + 1):
            pts.append(f"{i*100/teeth:.2f}% {depth if i % 2 else 0}px")
    else:
        pts += ["0% 0px", "100% 0px"]
    if bottom:
        for i in range(teeth, -1, -1):
            pts.append(f"{i*100/teeth:.2f}% calc(100% - {depth if i % 2 else 0}px)")
    else:
        pts += ["100% 100%", "0% 100%"]
    return "polygon(" + ",".join(pts) + ")"


ZINE_OUTLINE = ("filter:drop-shadow(3px 0 0 #141414) drop-shadow(-3px 0 0 #141414) drop-shadow(0 3px 0 #141414) "
                "drop-shadow(0 -3px 0 #141414) drop-shadow(9px 9px 0 #141414)")


def cover_css(t):
    if t == "littlefold":
        return LF.cover_css()
    common = """
.visual{position:relative}
.vart{position:absolute;left:0;right:0;bottom:0;transform-origin:50% 100%}
.vacc{position:absolute;right:0;top:-6px;width:118px;height:118px;z-index:3}
.vacc svg{width:118px;height:auto;display:block}
.vchips{display:flex;flex-direction:column;align-items:flex-start;gap:18px}
.vside{position:absolute;left:0;bottom:0;z-index:4}
"""
    if t == "fullyfunded":
        return common + """
.stub{width:700px;padding:0;overflow:hidden;transform:rotate(-2deg);margin-left:auto}
.stub .shd{background:#2B3FE0;color:#fff;display:flex;justify-content:space-between;align-items:center;padding:24px 34px}
.stub .shd .label{color:#fff}.stub .shd span:last-child{font:700 24px Inter;opacity:.85}
.stub .rows{padding:12px 34px 6px}
.sr{display:flex;justify-content:space-between;align-items:baseline;gap:20px;padding:16px 0;border-bottom:2px solid #E8ECFF;font:600 30px/1.2 Inter;color:#0E1440}
.sr .amt{font-variant-numeric:tabular-nums;font-weight:800}
.sr.x .amt{text-decoration:line-through;text-decoration-color:#FF6A3D;text-decoration-thickness:5px;color:#4B5178;font-weight:600}
.sr .new{font:800 30px Inter;color:#C2410C;margin-left:14px;font-variant-numeric:tabular-nums}
.perf{border-top:3px dashed #C9D0F2;margin:4px 34px 0}
.sr.tot{border:0;padding:20px 34px 26px;font:800 32px Inter}.sr.tot .amt{font-family:'Inter Display';font-size:52px;letter-spacing:-.02em;color:#2B3FE0}
.lookup{padding:30px 36px}
.lookup .lh{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.lookup .lh .label{color:#4B5178}
.lk{width:100%;border-collapse:collapse;font:600 30px/1.2 Inter;color:#0E1440}
.lk th{font:800 20px/1 Inter;letter-spacing:.12em;text-transform:uppercase;color:#4B5178;text-align:left;padding:10px 18px}
.lk td{padding:20px 18px;border-top:2px solid #E8ECFF;font-variant-numeric:tabular-nums}
.lk .r{text-align:right}
.lk tr.fade td{opacity:.38}
.lk tr.on td{background:#FF6A3D;color:#fff;font-weight:800;border-top-color:#FF6A3D}
.lk tr.on td:first-child{border-radius:14px 0 0 14px}.lk tr.on td:last-child{border-radius:0 14px 14px 0}
.ptr{display:inline-block;font:800 20px/1 Inter;letter-spacing:.1em;text-transform:uppercase;background:#0E1440;color:#fff;padding:10px 14px;border-radius:999px}
.tl{padding:34px 36px 30px}
.tl .label{color:#4B5178}
.tlrow{position:relative;display:flex;margin-top:26px}
.tlrow:before{content:"";position:absolute;left:4%;right:4%;top:62px;height:6px;border-radius:6px;background:#D9DEF5}
.tp{flex:1 1 0;display:flex;flex-direction:column;align-items:center;text-align:center;position:relative;min-width:0}
.tp .w{font:800 21px/1 Inter;letter-spacing:.12em;text-transform:uppercase;color:#4B5178;height:34px}
.tp .d{width:34px;height:34px;border-radius:50%;background:#2B3FE0;border:6px solid #F5F7FF;box-sizing:content-box;margin-top:6px}
.tp.on .d{background:#FF6A3D;width:46px;height:46px;margin-top:0;box-shadow:0 0 0 8px rgba(255,106,61,.22)}
.tp .l{font:700 24px/1.25 Inter;color:#0E1440;margin-top:14px;text-wrap:balance;padding:0 6px}
.tp .a{font:800 36px/1.1 'Inter Display';color:#2B3FE0;margin-top:6px;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.tp.on .a{color:#C2410C}
.bn{padding-bottom:6px}
.bn .n{font:800 260px/.86 'Inter Display';letter-spacing:-.05em;color:#2B3FE0;font-variant-numeric:tabular-nums}
.bn .n small{font-size:.38em;letter-spacing:-.02em;margin-left:.04em}
.bn .bar{width:180px;height:14px;border-radius:14px;background:#FF6A3D;margin:26px 0 22px}
.bn .c{font:700 38px/1.25 Inter;color:#0E1440;max-width:760px;text-wrap:balance}
"""
    if t == "lockedhour":
        return common + f"""
.zc{{background:#fff;border:3px solid #141414;border-radius:16px;box-shadow:9px 9px 0 #141414;position:relative}}
.claim{{width:820px;padding:38px 44px 70px;transform:rotate(-1.2deg)}}
.claim .label{{color:#4D463E}}
.claim .q{{font:900 54px/1.1 'Inter Display';letter-spacing:-.03em;color:#141414;margin-top:16px;text-wrap:balance}}
.stamp{{position:absolute;right:6px;bottom:-14px;transform:rotate(-7deg);background:#FFD43B;border:6px solid #141414;box-shadow:12px 12px 0 #141414;
  padding:16px 30px 14px;text-align:center;border-radius:10px}}
.stamp b{{display:block;font:900 76px/1 'Inter Display';letter-spacing:.04em;color:#141414}}
.stamp span{{display:block;font:800 22px/1.2 Inter;letter-spacing:.1em;text-transform:uppercase;margin-top:8px;color:#141414}}
.hour .hl2{{display:inline-block;font:800 22px/1 Inter;letter-spacing:.14em;text-transform:uppercase;background:#fff;border:3px solid #141414;padding:9px 13px;border-radius:8px;margin-bottom:12px}}
.hbar{{display:flex;height:150px;border:3px solid #141414;border-radius:14px;overflow:hidden;box-shadow:9px 9px 0 #141414;background:#fff}}
.hbar.dim{{height:104px;box-shadow:6px 6px 0 #141414}}
.hseg{{min-width:0;border-right:3px solid #141414;display:flex;flex-direction:column;justify-content:center;padding:0 18px;overflow:hidden}}
.hseg:last-child{{border-right:0}}
.hseg b{{font:900 30px/1.05 'Inter Display';color:inherit;white-space:nowrap;overflow:hidden;text-overflow:clip}}
.hseg i{{font:800 21px/1 Inter;font-style:normal;margin-top:8px;opacity:.85;white-space:nowrap}}
.hbar.dim .hseg b{{font-size:24px}}
.hseg.nar{{padding:0 10px}}.hseg.nar b{{white-space:normal;font-size:22px;line-height:1.05}}
.hrow+.hrow{{margin-top:30px}}
.hticks{{display:flex;justify-content:space-between;font:800 22px/1 Inter;margin-top:20px;color:#4D463E;font-variant-numeric:tabular-nums}}
.rcwrap{{{ZINE_OUTLINE};width:560px;margin-left:auto;transform:rotate(2.2deg)}}
.rc{{background:#fff;clip-path:{zigzag()};padding:44px 40px 46px}}
.rc .hd{{font:900 34px/1.1 'Inter Display';text-align:center;letter-spacing:.02em;text-transform:uppercase}}
.rc .sb{{font:700 21px/1.3 Inter;text-align:center;color:#4D463E;margin-top:8px;letter-spacing:.06em;text-transform:uppercase}}
.rc .rl{{border-top:3px dashed #141414;margin:20px 0 6px}}
.rr{{display:flex;justify-content:space-between;align-items:baseline;gap:16px;font:700 27px/1.25 Inter;padding:9px 0}}
.rr span:first-child{{min-width:0}}
.rr b{{font:900 24px/1 Inter;letter-spacing:.06em;white-space:nowrap;padding:6px 10px;border:3px solid #141414;border-radius:6px}}
.rr b.ok{{background:#FFD43B}}.rr b.fail{{background:#FF5CA8}}.rr b.meh{{background:#fff}}
.rc .tot{{display:flex;justify-content:space-between;font:900 36px/1 'Inter Display';margin-top:12px}}
.rc .bc{{height:46px;margin-top:22px;background:repeating-linear-gradient(90deg,#141414 0 3px,transparent 3px 7px,#141414 7px 12px,transparent 12px 15px,#141414 15px 16px,transparent 16px 21px)}}
.tornwrap{{{ZINE_OUTLINE};width:860px;transform:rotate(-1.5deg);position:relative}}
.torn{{background:#FFFDF6;clip-path:{zigzag(top=True, bottom=False, teeth=34, depth=16)};padding:62px 52px 46px}}
.torn .big{{font:900 124px/.95 'Inter Display';letter-spacing:-.04em;color:#141414;text-wrap:balance}}
.torn .sub{{font:700 32px/1.3 Inter;color:#4D463E;margin-top:20px;text-wrap:balance}}
.tape{{position:absolute;top:-14px;left:50%;width:200px;height:52px;margin-left:-100px;background:rgba(255,92,168,.82);transform:rotate(-4deg);z-index:2;border:3px solid #141414}}
.ba{{display:flex;flex-direction:column;gap:0}}
.ba .zc{{width:760px;padding:30px 36px 34px}}
.ba .zc.a{{transform:rotate(-1.6deg)}}.ba .zc.b{{background:#FFD43B;transform:rotate(1.2deg);align-self:flex-end}}
.ba .tagz{{display:inline-block;font:800 21px/1 Inter;letter-spacing:.14em;text-transform:uppercase;padding:9px 12px;border:3px solid #141414;border-radius:8px;background:#fff;margin-bottom:16px}}
.ba .zc.b .tagz{{background:#FF5CA8}}
.ba .li{{display:flex;gap:14px;align-items:flex-start;font:700 32px/1.25 Inter;margin-top:12px}}
.ba .zc.a .li{{color:#4D463E}}
.ba .li .ic{{flex:none;margin-top:2px}}
.ba .zc.a .li .ic{{color:#D6246E}}
.ba .arr{{flex:none;width:76px;height:76px;margin:-22px 0 -22px 360px;transform:rotate(90deg);z-index:2;border-radius:50%;background:#FF5CA8;border:3px solid #141414;box-shadow:4px 4px 0 #141414;display:grid;place-items:center;color:#141414}}
.clockwrap{{display:flex;justify-content:flex-end}}
.clockwrap svg{{display:block}}
"""
    # hourback (indigo cover)
    return common + """
.phn{position:relative;flex:none;width:260px;height:563px;border-radius:58px;background:#2A2238;padding:14px;box-shadow:0 40px 70px -30px rgba(10,6,40,.75),inset 0 0 0 3px #4A4060}
.phn .scr{position:relative;width:100%;height:100%;border-radius:45px;overflow:hidden;background:#FFF8EF}
.phn .scr img{width:100%;height:100%;object-fit:cover;display:block}
.phn .notch{position:absolute;top:26px;left:50%;width:96px;height:28px;margin-left:-48px;border-radius:20px;background:#2A2238;z-index:2}
.ring{position:absolute;width:92px;height:92px;margin:-46px 0 0 -46px;border-radius:50%;border:7px solid #FF8A3D;box-shadow:0 0 0 6px rgba(255,138,61,.28);z-index:3}
.ui{padding:66px 18px 18px;display:flex;flex-direction:column;gap:12px;height:100%}
.ui .ut{font:800 22px/1.15 Poppins;color:#2A2238;padding:0 6px}
.ui .ur{background:#fff;border-radius:16px;padding:14px 14px;font:600 20px/1.3 Inter;color:#2A2238;box-shadow:0 6px 14px -8px rgba(42,34,56,.3)}
.ui .ur.hi{background:#FFEEDC}
.phonewrap{display:flex;justify-content:flex-end}
.pill{display:flex;align-items:center;gap:14px;font:700 26px/1.2 Inter;padding:16px 26px 16px 16px;border-radius:999px;background:#FFF8EF;color:#2A2238;
  box-shadow:0 18px 30px -16px rgba(26,18,80,.6);max-width:480px;text-wrap:balance}
.pill .d{flex:none;width:36px;height:36px;border-radius:50%;display:grid;place-items:center;color:#fff}
.hba{display:flex;align-items:center}
.hba .bc{flex:1 1 0;min-width:0;border-radius:28px;padding:28px 28px 30px}
.hba .bc.a{background:#E9E5F7;transform:rotate(-2.5deg);color:#6B6380}
.hba .bc.b{background:#fff;transform:rotate(1.8deg);box-shadow:0 34px 60px -30px rgba(10,6,40,.7)}
.hba .tg{display:inline-block;font:800 20px/1 Inter;letter-spacing:.14em;text-transform:uppercase;padding:10px 14px;border-radius:999px;margin-bottom:16px}
.hba .a .tg{background:#D6D0EC;color:#5A5270}.hba .b .tg{background:#5E54C9;color:#fff}
.hba .ml{font:500 26px/1.4 'DejaVu Sans Mono',monospace;white-space:pre-wrap;word-break:break-word;opacity:.9}
.hba table{width:100%;border-collapse:collapse;font:600 28px/1.25 Inter;color:#2A2238}
.hba td{padding:12px 6px;border-top:2px solid #F1E3CF}.hba tr:first-child td{border-top:0}
.hba td.r{text-align:right;font-weight:800;font-variant-numeric:tabular-nums}
.hba .arr{flex:none;width:78px;height:78px;margin:0 -20px;z-index:2;border-radius:50%;background:#FF8A3D;color:#fff;display:grid;place-items:center;box-shadow:0 12px 24px -10px rgba(0,0,0,.4)}
.chat{display:flex;flex-direction:column;gap:18px;width:820px;margin-left:auto}
.cb{max-width:640px;font:500 28px/1.38 Inter;padding:20px 26px;border-radius:30px;box-shadow:0 22px 40px -24px rgba(10,6,40,.7);text-wrap:pretty}
.cb.you{align-self:flex-end;background:#FFC94D;color:#2A2238;border-bottom-right-radius:8px}
.cb.ai{align-self:flex-start;background:#FFF8EF;color:#2A2238;border-bottom-left-radius:8px;display:flex;gap:16px;align-items:flex-start}
.cb.ai img{width:44px;height:44px;flex:none;margin-top:-2px}
.cb b{color:#5E54C9}
.docw{position:relative;width:640px;transform:rotate(-2deg)}
.doc{background:#fff;border-radius:22px;padding:30px 34px 36px;box-shadow:0 40px 70px -30px rgba(10,6,40,.75)}
.doc .dt{display:flex;align-items:center;gap:12px;font:800 24px/1.2 Poppins;color:#2A2238;padding-bottom:16px;border-bottom:2px solid #F1E3CF;margin-bottom:10px}
.doc .dt i{width:30px;height:36px;border-radius:5px;background:#5E54C9;display:block;flex:none}
.dl{position:relative;font:500 25px/1.5 Inter;color:#655A6E;padding:5px 0}
.dl.ph2{height:18px;border-radius:9px;background:#F1ECF6;margin:16px 0}
.dl mark{background:#FFC94D;color:#2A2238;padding:2px 6px;border-radius:6px;font-weight:700;-webkit-box-decoration-break:clone;box-decoration-break:clone}
.note{position:absolute;left:100%;margin-left:30px;top:50%;transform:translateY(-50%) rotate(2deg);white-space:nowrap;font:800 23px/1 Inter;background:#FF8A3D;color:#fff;padding:12px 16px;border-radius:999px;box-shadow:0 12px 24px -10px rgba(0,0,0,.4)}
.note:before{content:"";position:absolute;right:100%;top:50%;width:26px;height:3px;background:#FF8A3D}
.sunwrap{display:flex;justify-content:flex-end}
"""


# ------------------------------------------------------------------ FULLY FUNDED
def ff_split(v):
    parts = v.get("parts") or [{"name": "Needs", "pct": 50, "amount": "$1,000"}, {"name": "Wants", "pct": 30, "amount": "$600"}, {"name": "Future you", "pct": 20, "amount": "$400"}]
    cols = ["#2B3FE0", "#FF6A3D", "#0E1440"]
    bar = "".join(f'<div style="flex:{p["pct"]} 1 0;background:{cols[i%3]}">{p["pct"]}%</div>' for i, p in enumerate(parts))
    tiles = "".join(f'<div class="tile"><div class="nm"><i style="background:{cols[i%3]}"></i>{md(p["name"])}</div><div class="amt">{md(p["amount"])}</div></div>' for i, p in enumerate(parts))
    return (f'<div class="card split" style="position:relative"><div class="hd"><div class="label" style="color:var(--muted)">{md(v.get("label","Example paycheque"))}</div>'
            f'<div class="tot">{md(v.get("total","$2,000"))}</div></div><div class="sbar">{bar}</div><div class="tiles">{tiles}</div></div>')


def ff_stub(v):
    rows = ""
    for r in v.get("rows", []):
        new = f'<b class="new">{md(r["new"])}</b>' if r.get("new") else ""
        rows += f'<div class="sr{" x" if r.get("strike") else ""}"><span>{md(r["label"])}</span><span><span class="amt">{md(r["amount"])}</span>{new}</span></div>'
    tot = v.get("total")
    tot = f'<div class="perf"></div><div class="sr tot"><span>{md(tot[0])}</span><span class="amt">{md(tot[1])}</span></div>' if tot else ""
    return (f'<div class="card stub"><div class="shd"><span class="label">{md(v.get("label","Pay stub"))}</span><span>{md(v.get("period",""))}</span></div>'
            f'<div class="rows">{rows}</div>{tot}</div>')


def ff_lookup(v):
    cols = v.get("columns", [])
    hi = v.get("highlight_row"); fade = v.get("fade", True); n = len(v.get("rows", []))
    num = [i for i in range(1, len(cols))]
    th = "".join(f'<th class="{"r" if i in num else ""}">{md(c)}</th>' for i, c in enumerate(cols))
    trs = ""
    for ri, row in enumerate(v.get("rows", [])):
        cls = "on" if ri == hi else ("fade" if fade and n >= 4 and ri in (0, n - 1) else "")
        trs += f'<tr class="{cls}">' + "".join(f'<td class="{"r" if i in num else ""}">{md(c)}</td>' for i, c in enumerate(row)) + "</tr>"
    ptr = f'<span class="ptr">{md(v["pointer"])}</span>' if v.get("pointer") else ""
    return (f'<div class="card lookup"><div class="lh"><span class="label">{md(v.get("label",""))}</span>{ptr}</div>'
            f'<table class="lk"><tr>{th}</tr>{trs}</table></div>')


def ff_timeline(v):
    pts = ""
    for i, p in enumerate(v.get("points", [])):
        on = " on" if i == v.get("highlight", -1) or p.get("on") else ""
        pts += (f'<div class="tp{on}"><div class="w">{md(p.get("when",""))}</div><div class="d"></div>'
                f'<div class="l">{md(p.get("label",""))}</div>' + (f'<div class="a">{md(p["amount"])}</div>' if p.get("amount") else "") + "</div>")
    return f'<div class="card tl"><span class="label">{md(v.get("label",""))}</span><div class="tlrow">{pts}</div></div>'


def ff_bignum(v):
    unit = f'<small>{md(v["unit"])}</small>' if v.get("unit") else ""
    return f'<div class="bn"><div class="n">{md(v.get("number",""))}{unit}</div><div class="bar"></div><div class="c">{md(v.get("caption",""))}</div></div>'


# ------------------------------------------------------------------ LOCKED HOUR
LH_SEG = [("#FF5CA8", "#141414"), ("#FFD43B", "#141414"), ("#FFFFFF", "#141414"), ("#141414", "#FFF4E0")]


def _segs(segs, dim=False):
    out = ""
    for i, s in enumerate(segs):
        a, b, lab = s[0], s[1], s[2] if len(s) > 2 else ""
        bg, fg = (("#FFFFFF", "#4D463E") if dim else LH_SEG[i % 4])
        if dim and i % 2:
            bg = "#F3E9D6"
        narrow = (b - a) < 15
        out += (f'<div class="hseg{" nar" if narrow else ""}" style="flex:{max(1,b-a)} 1 0;background:{bg};color:{fg}"><b>{md(lab)}</b>'
                f'<i>{a}–{b}{"" if narrow else " min"}</i></div>')
    return out


def lh_timeline(v):
    rows = ""
    if v.get("before"):
        rows += f'<div class="hrow"><span class="hl2">{md(v.get("before_label","Before"))}</span><div class="hbar dim">{_segs(v["before"], True)}</div></div>'
    rows += (f'<div class="hrow"><span class="hl2" style="background:#FFD43B">{md(v.get("label","The hour"))}</span>'
             f'<div class="hbar">{_segs(v.get("segments") or [[0,50,"Deep work"],[50,60,"Break"]])}</div></div>')
    ticks = "".join(f"<span>{m}</span>" for m in ("0", "15", "30", "45", "60 min"))
    return f'<div class="hour">{rows}<div class="hticks">{ticks}</div></div>'


def lh_stamp(v):
    sub = f'<span>{md(v["verdict"])}</span>' if v.get("verdict") else ""
    return (f'<div style="position:relative;padding-bottom:40px"><div class="zc claim"><span class="label">{md(v.get("label","The claim"))}</span>'
            f'<div class="q">“{md(v.get("myth",""))}”</div></div>'
            f'<div class="stamp"><b>{md(v.get("stamp","CHECKED"))}</b>{sub}</div></div>')


def lh_receipt(v):
    rows = ""
    for it in v.get("items", []):
        it = it if isinstance(it, dict) else {"text": it}
        val = f'<b class="{it.get("state","meh")}">{md(it["value"])}</b>' if it.get("value") else ""
        rows += f'<div class="rr"><span>{md(it["text"])}</span>{val}</div>'
    tot = v.get("total")
    tot = f'<div class="rl"></div><div class="tot"><span>{md(tot[0])}</span><span>{md(tot[1])}</span></div>' if tot else ""
    chips = _lh_stickers(v.get("stickers", []))
    rc = (f'<div class="rcwrap"><div class="rc"><div class="hd">{md(v.get("label","Receipt"))}</div>'
          + (f'<div class="sb">{md(v["sub"])}</div>' if v.get("sub") else "") + f'<div class="rl"></div>{rows}{tot}<div class="bc"></div></div></div>')
    return f'<div style="display:flex;justify-content:flex-end">{rc}</div>', chips


def lh_torn(v):
    return (f'<div class="tornwrap"><div class="tape"></div><div class="torn"><div class="big">{md(v.get("text","DAY 1 (AGAIN)"))}</div>'
            + (f'<div class="sub">{md(v["sub"])}</div>' if v.get("sub") else "") + "</div></div>")


def lh_beforeafter(v):
    def items(xs, ic):
        return "".join(f'<div class="li">{icon(ic, 30, 3.2)}<span>{md(x)}</span></div>' for x in xs)
    return (f'<div class="ba"><div class="zc a"><span class="tagz">{md(v.get("before_label","Before"))}</span>{items(v.get("before", []), "x")}</div>'
            f'<div class="arr">{icon("arrow", 36, 3)}</div>'
            f'<div class="zc b"><span class="tagz">{md(v.get("after_label","After"))}</span>{items(v.get("after", []), "check")}</div></div>')


def _lh_stickers(st):
    cols = ["#FF5CA8", "#FFFFFF", "#FFD43B"]; rot = [-4, 3, -2]
    return ('<div class="vchips">' + "".join(f'<div class="sticker" style="background:{cols[i%3]};transform:rotate({rot[i%3]}deg)">{md(s)}</div>'
                                             for i, s in enumerate(st)) + "</div>") if st else "<div></div>"


def lh_clock(v, pid=""):
    prog = v.get("progress")
    if prog is None:
        prog = 0.25 + (_seed(pid) % 4) * 0.15
    st = v.get("stickers") or []
    return f'<div class="clockwrap">{clock_lh(430, float(prog))}</div>', _lh_stickers(st)


# ------------------------------------------------------------------ HOURBACK
def _hb_pills(chips):
    dots = ["#FF8A3D", "#5E54C9", "#2A2238"]
    return ('<div class="vchips">' + "".join(f'<div class="pill"><span class="d" style="background:{dots[i%3]}">{icon("check" if i < 2 else "x", 22, 3)}</span>{md(c)}</div>'
                                             for i, c in enumerate(chips)) + "</div>") if chips else "<div></div>"


def hb_phone(v, img_uri=None):
    if img_uri:
        scr = f'<img src="{img_uri}" alt="" style="object-position:{v.get("focus",[50,0])[0]}% {v.get("focus",[50,0])[1]}%">'
    else:
        rows = "".join(f'<div class="ur{" hi" if i == v.get("screen_highlight", -1) else ""}">{md(x)}</div>' for i, x in enumerate(v.get("screen", [])))
        scr = f'<div class="ui"><div class="ut">{md(v.get("screen_title",""))}</div>{rows}</div>'
    ring = ""
    if v.get("ring"):
        x, y = v["ring"]
        ring = f'<span class="ring" style="left:{x}%;top:{y}%"></span>'
    return (f'<div class="phonewrap"><div class="phn"><div class="scr">{scr}</div><div class="notch"></div>{ring}</div></div>',
            _hb_pills(v.get("chips", [])))


def hb_beforeafter(v):
    before = "\n".join(v.get("before", []))
    after = v.get("after", [])
    rows = ""
    for r in after:
        r = r if isinstance(r, (list, tuple)) else str(r).split(" | ")
        rows += "<tr>" + "".join(f'<td class="{"r" if j == len(r) - 1 and len(r) > 1 else ""}">{md(c)}</td>' for j, c in enumerate(r)) + "</tr>"
    return (f'<div class="hba"><div class="bc a"><span class="tg">{md(v.get("before_label","Before"))}</span><div class="ml">{md(before)}</div></div>'
            f'<div class="arr">{icon("arrow", 36, 3)}</div>'
            f'<div class="bc b"><span class="tg">{md(v.get("after_label","After"))}</span><table>{rows}</table></div></div>')


def hb_chat(v, mark_uri):
    out = ""
    for b in v.get("bubbles", []):
        if b.get("from") == "ai":
            out += f'<div class="cb ai"><img src="{mark_uri}" alt=""><div>{md(b["text"], ph=True)}</div></div>'
        else:
            out += f'<div class="cb you">{md(b["text"], ph=True)}</div>'
    return f'<div class="chat">{out}</div>'


def hb_doc(v):
    out = ""
    for ln in v.get("lines", []):
        if ln == "" or ln is None:
            out += '<div class="dl ph2"></div>'; continue
        ln = ln if isinstance(ln, dict) else {"text": ln}
        t = md(ln["text"])
        if ln.get("hl"):
            t = f"<mark>{t}</mark>"
        note = f'<span class="note">{md(ln["note"])}</span>' if ln.get("note") else ""
        out += f'<div class="dl">{t}{note}</div>'
    return (f'<div class="docw"><div class="doc"><div class="dt"><i></i>{md(v.get("title","Document"))}</div>{out}</div></div>')


def hb_sun(v):
    return f'<div class="sunwrap">{sun_hb(470)}</div>', _hb_pills(v.get("chips", []))


# ------------------------------------------------------------------ dispatcher
def render_cover_visual(t, v, pid, mark_uri, img_uri=None):
    k = v.get("type") or DEFAULT_VISUAL[t]
    if k == "none":
        return ""
    if k not in COVER_VISUALS[t]:
        raise ValueError(f"cover visual '{k}' is not available for {t}; use one of {COVER_VISUALS[t]}")
    fn = {
        ("fullyfunded", "split"): ff_split, ("fullyfunded", "stub"): ff_stub, ("fullyfunded", "lookup"): ff_lookup,
        ("fullyfunded", "timeline"): ff_timeline, ("fullyfunded", "bignum"): ff_bignum,
        ("lockedhour", "stamp"): lh_stamp, ("lockedhour", "timeline"): lh_timeline, ("lockedhour", "receipt"): lh_receipt,
        ("lockedhour", "torn"): lh_torn, ("lockedhour", "beforeafter"): lh_beforeafter,
        ("hourback", "beforeafter"): hb_beforeafter, ("hourback", "doc"): hb_doc, ("hourback", "sun"): hb_sun,
    }.get((t, k))
    if t == "littlefold":
        art = LF.render_visual(k, v)
    elif k == "clock":
        art = lh_clock(v, pid)
    elif k == "phone":
        art = hb_phone(v, img_uri)
    elif k == "chat":
        art = hb_chat(v, mark_uri)
    else:
        art = fn(v)
    side = ""
    if isinstance(art, tuple):
        art, side = art
        side = f'<div class="vside">{side}</div>' if side and side != "<div></div>" else ""
    acc = ""
    if v.get("accent") in ACCENTS:
        acc = f'<div class="vacc art">{clock_lh(118, 0.4) if v["accent"] == "clock" else sun_hb(118)}</div>'
    return f'<div class="visual" data-box data-vis="{k}">{acc}<div class="vart art">{art}</div>{side}</div>'
