#!/usr/bin/env python3
"""3x3 profile-grid preview: check how the next 9 covers sit together before scheduling.

usage:  python3 grid_preview.py NEWEST.png ... OLDEST.png --theme fullyfunded --out grid.png
  Give up to 9 slide-1 PNGs, newest first (newest = top-left, as on the profile).
  Writes grid.png: a phone-sized mock (1170 px wide = a 390 pt phone at 3x) of the profile grid.
  The grid shows the centre 3:4 crop of each 4:5 post, as the app does now. Also writes grid@1x.png
  (390 px wide), roughly what the eye sees on a real phone: if a hook is unreadable there, it is unreadable.
  Under the grid it prints each tile's average colour and flags neighbours that look alike (same row or column).
"""
import argparse, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from engine.themes import THEMES, MARKS, FONTS  # noqa: E402

PW, GAP = 1170, 3


def font(n, w="SemiBold"):
    return ImageFont.truetype(str(FONTS / f"Inter-{w}.ttf"), n)


def crop34(im):
    w, h = im.size; cw = round(h * 3 / 4)
    return im.crop(((w - cw) // 2, 0, (w - cw) // 2 + cw, h)) if cw < w else im


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tiles", nargs="+"); ap.add_argument("--theme", required=True, choices=list(THEMES))
    ap.add_argument("--out", default="grid.png"); ap.add_argument("--title", default=None)
    a = ap.parse_args()
    tiles = [Image.open(p).convert("RGB") for p in a.tiles[:9]]
    T = THEMES[a.theme]
    tw = (PW - 2 * GAP) // 3; th = round(tw * 4 / 3)
    head = 470
    out = Image.new("RGB", (PW, head + 3 * th + 2 * GAP + 40), (255, 255, 255))
    d = ImageDraw.Draw(out)
    # status bar + profile header (no invented numbers)
    d.text((60, 40), "9:41", fill=(0, 0, 0), font=font(40))
    d.text((PW // 2, 120), T["handle"].lstrip("@"), fill=(0, 0, 0), font=font(44, "Bold"), anchor="mm")
    av = Image.open(MARKS / T["mark"]).convert("RGBA").resize((200, 200), Image.LANCZOS)
    ring = Image.new("RGBA", (232, 232), (0, 0, 0, 0)); ImageDraw.Draw(ring).ellipse((0, 0, 231, 231), outline=(220, 220, 225), width=4, fill=(250, 250, 252))
    ring.alpha_composite(av, (16, 16)); out.paste(ring, (60, 170), ring)
    d.text((330, 230), T["name"], fill=(0, 0, 0), font=font(46, "Bold"))
    d.text((330, 296), a.title or "Grid preview · next 9 posts", fill=(110, 110, 120), font=font(34, "Medium"))
    for k, x in enumerate((0, PW // 3, 2 * PW // 3)):
        d.rectangle((x + 40, head - 18, x + PW // 3 - 40, head - 14), fill=(0, 0, 0) if k == 0 else (235, 235, 238))
    means = []
    for i, im in enumerate(tiles):
        r, c = divmod(i, 3)
        t = crop34(im).resize((tw, th), Image.LANCZOS)
        out.paste(t, (c * (tw + GAP), head + r * (th + GAP)))
        means.append(np.asarray(t).reshape(-1, 3).mean(0))
    out.save(a.out, optimize=True)
    small = out.resize((390, round(out.height * 390 / PW)), Image.LANCZOS)
    small.save(str(Path(a.out).with_name(Path(a.out).stem + "@1x.png")), optimize=True)
    for i, m in enumerate(means):
        print(f"tile {i+1}: {Path(a.tiles[i]).parent.name}/{Path(a.tiles[i]).name}  avg rgb {tuple(int(v) for v in m)}")
    for i in range(len(means)):
        for j in (i + 1, i + 3):
            if j < len(means) and (j != i + 1 or i % 3 != 2) and np.abs(means[i] - means[j]).sum() < 24:
                print(f"  look-alike neighbours: tile {i+1} and tile {j+1} (vary the palette_index or cover visual)")
    print(f"-> {a.out}")


if __name__ == "__main__":
    main()
