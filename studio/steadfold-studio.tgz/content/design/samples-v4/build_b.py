#!/usr/bin/env python3
"""Look B v4: edge-to-edge condensed serif headline (auto-fitted, leading .88) with fat pills, a big halftone cut-out
overlapping the headline, a bigger handwritten save-line, rotating stamp. Two colour variants per page:
  -a  pastel ground with tomato-red accent words      -b  bold saturated ground, high-contrast cream type."""
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v4")
from lib import *  # noqa

MARKS = D / "assets" / "marks"
INK = "#4A1D24"
TOMATO = "#E2412B"
CREAM = "#FFF4E2"
BUTTER, PINK, PERI = "#FCEFC4", "#F5C9CF", "#C7D0F7"

PAGES = {
    "hb": dict(brand="Hourback", mark="hourback.png", handle="@hourbackhq", tag="GET YOUR EVENINGS BACK",
               kicker="AI prompts · part 1", obj="ht-point.png", flip=True, obj_w=500, obj_x=560, obj_y=930, rot=-8,
               words=["These", "AI", "prompts", "give", "you", "your", ("evening", 1), ("back.", 2)],
               save="save this for tonight"),
    "lh": dict(brand="Locked Hour", mark="lockedhour.png", handle="@lockedhourhq", tag="ONE HOUR AT A TIME",
               kicker="the focus fix", obj="ht-clock.png", obj_w=380, obj_x=650, obj_y=900, rot=10,
               words=["This", ("one-hour", 1), ("rule", 1), "is", "quietly", "changing", ("everything.", 2)],
               save="save this for Monday"),
    "ff": dict(brand="Fully Funded", mark="fullyfunded.png", handle="@fullyfundedhq", tag="MONEY, MADE CLEAR",
               kicker="money habits", obj="ht-piggy.png", obj_w=450, obj_x=600, obj_y=940, rot=-7,
               words=["These", "money", "moves", ("rich", 1), ("families", 1), "never", ("skip.", 2)],
               save="save before payday"),
    "lf": dict(brand="Littlefold", mark="littlefold.png", handle="@littlefoldhq", tag="SMALL DAYS, GENTLY",
               kicker="for new parents", obj="ht-shoe.png", obj_w=400, obj_x=640, obj_y=940, rot=9,
               words=["The", "little", "things", "that", "make", "the", ("first", 1), ("week", 1), ("home", 2), "easier."],
               save="save for the 3 am feeds"),
}

# variant palettes: bg, headline ink, pill1 (bg, text), pill2 (bg, text), save colour, stamp centre, chip ink
VARIANTS = {
    "hb": {"a": dict(bg=PERI, ink=INK, p1=(BUTTER, TOMATO), p2=(PINK, INK), save=TOMATO, centre=BUTTER, chip=INK),
           "b": dict(bg="#2C3BD1", ink=CREAM, p1=("#FF5A3C", CREAM), p2=(BUTTER, "#2C3BD1"), save=BUTTER, centre="#FF5A3C", chip=CREAM)},
    "lh": {"a": dict(bg=BUTTER, ink=INK, p1=(PERI, TOMATO), p2=(PINK, INK), save=TOMATO, centre=PERI, chip=INK),
           "b": dict(bg="#E8442C", ink=CREAM, p1=(BUTTER, "#B5241A"), p2=("#1B1416", BUTTER), save=BUTTER, centre=BUTTER, chip=CREAM)},
    "ff": {"a": dict(bg=PINK, ink=INK, p1=(BUTTER, TOMATO), p2=(PERI, INK), save=TOMATO, centre=BUTTER, chip=INK),
           "b": dict(bg="#0E5A44", ink=CREAM, p1=(BUTTER, "#0E5A44"), p2=("#FF8FA8", "#3A0E18"), save=BUTTER, centre="#FF8FA8", chip=CREAM)},
    "lf": {"a": dict(bg=BUTTER, ink=INK, p1=(PINK, TOMATO), p2=(PERI, INK), save=TOMATO, centre=PINK, chip=INK),
           "b": dict(bg="#E9407F", ink=CREAM, p1=(BUTTER, "#A11850"), p2=("#3A0E2A", "#FFD6E5"), save=BUTTER, centre=BUTTER, chip=CREAM)},
}


def stamp(c, v, size=206):
    txt = f"{c['brand'].upper()} · {c['tag']} · "
    s = 220; r = 84
    path = f"M{s/2},{s/2} m-{r},0 a{r},{r} 0 1,1 {2*r},0 a{r},{r} 0 1,1 -{2*r},0"
    fs = 20.5 * s / size
    mark = (MARKS / c["mark"]).as_uri()
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 {s} {s}"><defs><path id="sp" d="{path}"/></defs>'
            f'<circle cx="{s/2}" cy="{s/2}" r="{s/2-2}" fill="#FFFBF2" stroke="{INK}" stroke-width="2.4"/>'
            f'<circle cx="{s/2}" cy="{s/2}" r="{r-19}" fill="{v["centre"]}" stroke="{INK}" stroke-width="1.6"/>'
            f'<text font-family="Inter" font-weight="800" font-size="{fs:.1f}" fill="{INK}" letter-spacing="1.2">'
            f'<textPath href="#sp" textLength="{2 * math.pi * r - 8:.0f}" lengthAdjust="spacingAndGlyphs">{txt}</textPath></text>'
            f'<image href="{mark}" x="{s/2-34}" y="{s/2-34}" width="68" height="68"/></svg>')


def arrow(col):
    return (f'<svg width="170" height="130" viewBox="0 0 170 130" style="overflow:visible"><path d="M10,30 C70,10 130,40 150,108 '
            f'M150,108 L124,86 M150,108 L160,76" fill="none" stroke="{col}" stroke-width="7" stroke-linecap="round" '
            f'stroke-linejoin="round"/></svg>')


def title_html(words):
    out = []
    for w in words:
        if isinstance(w, tuple):
            out.append(f'<span class="p{w[1]}">{w[0]}</span>')
        else:
            out.append(w)
    return " ".join(out)


FIT = """<script>document.fonts.ready.then(()=>{for(const t of document.querySelectorAll('.title')){
 let lo=110,hi=230;const maxH=+t.dataset.maxh;for(let i=0;i<14;i++){const m=(lo+hi)/2;t.style.fontSize=m+'px';
 const ok=t.scrollWidth<=t.clientWidth+1&&t.scrollHeight<=maxH&&[...t.querySelectorAll('span')].every(s=>s.getClientRects().length===1);
 if(ok)lo=m;else hi=m;}t.style.fontSize=Math.floor(lo)+'px';}
 const sl=document.querySelector('.slide').getBoundingClientRect();
 for(const sp of document.querySelectorAll('.title.over span')){const r=sp.getBoundingClientRect();const h=r.height;
  const d=document.createElement('div');d.className='pill '+sp.className;d.setAttribute('data-noqa','');
  const t=r.top+h*0.20,b=r.bottom-h*0.06;
  d.style.cssText=`position:absolute;left:${r.left-sl.left}px;top:${t-sl.top}px;width:${r.width}px;height:${b-t}px;border-radius:${(b-t)/2}px`;
  document.querySelector('.pills').appendChild(d);}
});</script>"""


def css(v):
    return f"""
.slide{{width:1080px;height:1350px;background:{v['bg']}}}
.paper{{position:absolute;inset:0;opacity:.30;mix-blend-mode:multiply;
  background-image:radial-gradient(rgba(40,20,20,.12) 1px,transparent 1.2px);background-size:7px 7px}}
.chip{{position:absolute;left:84px;top:92px;display:flex;align-items:center;gap:12px;font-family:Inter;font-weight:700;
  font-size:28px;color:{v['chip']};letter-spacing:-.01em}}
.chip img{{width:50px;height:50px;border-radius:50%;background:#FFFBF2;padding:3px}}
.kick{{position:absolute;left:84px;top:164px;font-family:Inter;font-weight:700;font-size:25px;letter-spacing:.18em;
  text-transform:uppercase;color:{v['chip']};opacity:.85}}
.title{{position:absolute;left:72px;width:936px;top:300px;font-family:Instrument;font-weight:400;color:{v['ink']};
  font-size:170px;line-height:.88;letter-spacing:-.03em;word-spacing:-.02em}}
.title span{{border-radius:999px;padding:0 .18em .05em;margin:0 -.05em;font-style:italic;white-space:nowrap;
  -webkit-box-decoration-break:clone}}
.pill.p1{{background:{v['p1'][0]}}} .pill.p2{{background:{v['p2'][0]}}}
.title.over .p1{{color:{v['p1'][1]}}} .title.over .p2{{color:{v['p2'][1]}}}
.stamp{{position:absolute;right:96px;top:60px;transform:rotate(-14deg);filter:drop-shadow(0 6px 12px rgba(30,10,14,.25))}}
.obj{{position:absolute;filter:drop-shadow(0 22px 30px rgba(30,10,14,.30))}}
.save{{position:absolute;left:84px;top:1140px;font-family:CaveatBrush;font-size:78px;color:{v['save']};transform:rotate(-5deg);
  transform-origin:left center;line-height:1;white-space:nowrap}}
.handle{{position:absolute;left:84px;bottom:76px;font-family:Inter;font-weight:600;font-size:22px;color:{v['chip']};opacity:.8;
  letter-spacing:.04em}}
"""


def cover(c, v):
    mark = (MARKS / c["mark"]).as_uri()
    obj = (PREP / c["obj"]).as_uri()
    flip = "scaleX(-1) " if c.get("flip") else ""
    t = title_html(c["words"])
    sw = 84 + 31 * len(c["save"])
    return (f'<style>{css(v)}</style><div class="slide"><div class="paper"></div>'
            f'<div class="chip"><img src="{mark}">{c["brand"]}</div><div class="kick">✦ {c["kicker"]}</div>'
            f'<div class="pills" data-noqa></div>'
            f'<div class="title over" data-maxh="690">{t}</div>'
            f'<img class="obj" data-noqa style="left:{c["obj_x"]}px;top:{c["obj_y"]}px;width:{c["obj_w"]}px;transform:{flip}rotate({c["rot"]}deg)" src="{obj}">'
            f'<div class="save">{c["save"]}</div>'
            f'<div data-noqa style="position:absolute;left:{min(sw, 560)}px;top:1060px">{arrow(v["save"])}</div>'
            f'<div class="stamp" data-noqa>{stamp(c, v)}</div>'
            f'<div class="handle">{c["handle"]}</div></div>{FIT}')


if __name__ == "__main__":
    jobs = []
    for k, c in PAGES.items():
        for vk, v in VARIANTS[k].items():
            jobs.append((cover(c, v), S3 / "covers-b" / f"{k}-cover-{vk}"))
    rep = render_many(jobs)
    json.dump(rep, open(S3 / "qa" / "report-b.json", "w"), indent=1)
    names = [f"{k}-cover-{vk}" for k in PAGES for vk in "ab"]
    contact_sheet([S3 / "covers-b" / f"{n}.png" for n in names], S3 / "covers-b" / "contact-sheet.png", cols=4,
                  label="Look B v4 · edge-to-edge covers, two colour variants per page (a = pastel + tomato, b = bold)")
