#!/usr/bin/env python3
"""SHOWCASE.png: every v3 set at phone size, labelled, on one board."""
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v4")
sys.path.insert(0, "/home/claude/content/video/src")
from lib import *  # noqa
from PIL import ImageDraw, ImageFont
import slowpan as SP

V = Path("/home/claude/content/video/out/samples-v4")
TW = 300                      # tile width (a feed post on a phone is ~390 pt wide; this board is a 3x-ish overview)
GAP, PAD = 22, 70
BG = "#F6F1EA"
f_h = ImageFont.truetype(str(FONTS / "InstrumentSerif-Regular.ttf"), 64)
f_hi = ImageFont.truetype(str(FONTS / "InstrumentSerif-Italic.ttf"), 64)
f_s = ImageFont.truetype(str(FONTS / "Inter-Medium.ttf"), 22)
f_t = ImageFont.truetype(str(FONTS / "InstrumentSerif-Regular.ttf"), 120)
f_l = ImageFont.truetype(str(FONTS / "Inter-SemiBold.ttf"), 18)


def tile(im, w=TW):
    im = im.convert("RGB")
    h = round(w * im.height / im.width)
    t = im.resize((w, h), Image.LANCZOS)
    m = Image.new("L", (w, h), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), radius=14, fill=255)
    return t, m


S3old = D / "samples-v3"
V3 = Path("/home/claude/content/video/out/samples-v3")
V = Path("/home/claude/content/video/out/samples-v4")
SECTIONS = [
    ("Look A", "NEW · Fully Funded glam glove · rhinestones, mansion bokeh, gold serif",
     [Image.open(S3 / "ff-finger-glam" / f"slide-{k:02d}.png") for k in range(1, 6)], None),
    ("Look A", "Fully Funded · bigger headline (186 / 150 px)",
     [Image.open(S3 / "ff-finger" / f"slide-{k:02d}.png") for k in range(1, 6)], None),
    ("Look A", "Littlefold · bigger headline",
     [Image.open(S3 / "lf-finger" / f"slide-{k:02d}.png") for k in range(1, 6)], None),
    ("Look B", "Edge-to-edge covers · a = pastel + tomato · b = bold",
     [Image.open(S3 / "covers-b" / f"{p}-cover-{v}.png") for p in ("hb", "lh", "ff") for v in "ab"], None),
    ("Look B", "Littlefold a/b · Look C Ep.01 (unchanged from v3)",
     [Image.open(S3 / "covers-b" / f"lf-cover-{v}.png") for v in "ab"] + [Image.open(S3old / "ff-ep01" / f"slide-{k:02d}.png") for k in (1, 3, 5, 6)], None),
    ("Slow-pan", "3 × 6 s on real photos + NEW bold alternative",
     [Image.fromarray(SP.still(V3 / f"fullyfunded-slowpan-0{k}.mp4", 1.0, (1080, 1350))) for k in (1, 2, 3)] +
     [Image.fromarray(SP.still(V / "fullyfunded-slowpan-bold.mp4", 1.0, (1080, 1350)))], None),
    ("Reel", "Littlefold silhouette · dip to warm black, no double exposure",
     [Image.open(V / "littlefold-silhouette-photo-cover.jpg")] +
     [Image.fromarray(SP.still(V / "littlefold-silhouette-photo.mp4", t, (1080, 1920))) for t in (3.6, 9.9, 11.6, 17.0)], 200),
]

W = PAD * 2 + 6 * TW + 5 * GAP
blocks = []
for tag, desc, ims, tw in SECTIONS:
    tw = tw or TW
    tiles = [tile(im, tw) for im in ims]
    h = max(t.height for t, _ in tiles)
    blocks.append((tag, desc, tiles, h, tw))
grid = Image.open(S3 / "grid-mock-vivid.png").convert("RGB")
gw = 560
grid = grid.resize((gw, round(gw * grid.height / grid.width)), Image.LANCZOS)

H = 300 + sum(110 + h + 50 for *_, h, _ in blocks) + 140 + grid.height + PAD
board = Image.new("RGB", (W, H), BG)
d = ImageDraw.Draw(board)
d.text((PAD, 70), "Samples v4", font=f_t, fill="#4A1D24")
d.text((PAD + 560, 132), "bigger type · vivid covers · glam glove · no double exposure", font=f_s, fill="#7A5A5E")
y = 260
for tag, desc, tiles, h, tw in blocks:
    d.text((PAD, y), tag, font=f_hi, fill="#A8606E")
    d.text((PAD + 250, y + 30), desc, font=f_s, fill="#3A2A2C")
    y += 100
    x = PAD
    for t, m in tiles:
        sh = Image.new("L", t.size, 0); ImageDraw.Draw(sh).rounded_rectangle((0, 0, t.width - 1, t.height - 1), 14, fill=70)
        board.paste((222, 210, 200), (x + 4, y + 8), sh)
        board.paste(t, (x, y), m)
        x += tw + GAP
    y += h + 60
d.text((PAD, y), "Grid", font=f_hi, fill="#A8606E")
d.text((PAD + 250, y + 30), "3×3 profile mock (centre 3:4 crop as the app shows it): planned, colourful, no look-alike neighbours",
       font=f_s, fill="#3A2A2C")
y += 100
board.paste(grid, (PAD, y))
notes = ["All imagery: Canva AI photos (see AI-IMAGES.md), placed",
         "full-bleed in a Canva design and exported at native size.",
         "",
         "Every slide: rendered 2160×2700, Lanczos to 1080×1350.",
         "Text ≥ 70 px from every edge (QA-checked).",
         "Video: H.264 CRF 17–18, text layer pixel-still,",
         "warm grade + fine grain, music −14 LUFS (Reel)."]
for k, s in enumerate(notes):
    d.text((PAD + gw + 60, y + 40 + k * 36), s, font=f_s, fill="#3A2A2C")
board.save(S3 / "SHOWCASE-v4.png", optimize=True)
print(board.size)
