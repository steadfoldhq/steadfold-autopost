"""samples-v3 helpers: 2x Playwright render -> Lanczos downsample, text-edge QA, photo prep (flat-field, halftone cut-outs).

render_many(jobs)  jobs = [(html, out_stem)], each slide 1080x1350 (or size=) rendered at deviceScaleFactor 2
                   (2160x2700), downsampled with LANCZOS, saved as <stem>.png + <stem>.jpg (q95) + QA dict.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageFilter

D = Path("/home/claude/content/design")
FONTS = D / "assets" / "fonts"
S3 = D / "samples-v4"
A = D / "samples-v3" / "assets"
PREP = D / "samples-v3" / "prep"
PREP4 = S3 / "prep"
PREP.mkdir(parents=True, exist_ok=True)
EDGE = 70


def font_css():
    f = lambda n: (FONTS / n).as_uri()
    return f"""
@font-face{{font-family:'Instrument';src:url({f('InstrumentSerif-Regular.ttf')});font-style:normal}}
@font-face{{font-family:'Instrument';src:url({f('InstrumentSerif-Italic.ttf')});font-style:italic}}
@font-face{{font-family:'Fraunces';src:url({f('Fraunces-Variable.ttf')});font-weight:100 900;font-style:normal}}
@font-face{{font-family:'Playfair';src:url({f('PlayfairDisplay-Variable.ttf')});font-weight:400 900}}
@font-face{{font-family:'Lora';src:url({f('Lora-Variable.ttf')});font-weight:400 700;font-style:normal}}
@font-face{{font-family:'Lora';src:url({f('Lora-Italic-Variable.ttf')});font-weight:400 700;font-style:italic}}
@font-face{{font-family:'Caveat';src:url({f('Caveat-Variable.ttf')});font-weight:400 700}}
@font-face{{font-family:'CaveatBrush';src:url({f('CaveatBrush-Regular.ttf')})}}
@font-face{{font-family:'Inter';src:url({f('Inter-Regular.ttf')});font-weight:400}}
@font-face{{font-family:'Inter';src:url({f('Inter-Medium.ttf')});font-weight:500}}
@font-face{{font-family:'Inter';src:url({f('Inter-SemiBold.ttf')});font-weight:600}}
@font-face{{font-family:'Inter';src:url({f('Inter-Bold.ttf')});font-weight:700}}
@font-face{{font-family:'Inter';src:url({f('Inter-ExtraBold.ttf')});font-weight:800}}
@font-face{{font-family:'Poppins';src:url({f('Poppins-Medium.ttf')});font-weight:500}}
@font-face{{font-family:'Poppins';src:url({f('Poppins-Bold.ttf')});font-weight:700}}
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{background:transparent}}
.slide{{position:relative;overflow:hidden;-webkit-font-smoothing:antialiased;text-rendering:geometricPrecision;
  font-synthesis:none}}
"""


QA_JS = """(EDGE) => {
  const s = document.querySelector('.slide'); const W = s.clientWidth, H = s.clientHeight;
  const out = {minEdge: 1e9, worst: null, minFont: 1e9, lines: 0, errs: []};
  const w = document.createTreeWalker(s, NodeFilter.SHOW_TEXT); let n;
  while ((n = w.nextNode())) {
    if (!n.textContent.trim()) continue;
    const el = n.parentElement; if (el.closest('[data-noqa]')) continue;
    const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || cs.display === 'none' || +cs.opacity === 0) continue;
    out.minFont = Math.min(out.minFont, parseFloat(cs.fontSize));
    const r = document.createRange(); r.selectNodeContents(n);
    for (const b of r.getClientRects()) {
      if (b.width < 1) continue; out.lines++;
      const d = Math.min(b.left, b.top, W - b.right, H - b.bottom);
      if (d < out.minEdge) { out.minEdge = d; out.worst = n.textContent.trim().slice(0, 30); }
      if (d < EDGE) out.errs.push(`edge ${d.toFixed(0)}px: "${n.textContent.trim().slice(0, 30)}"`);
    }
  }
  return out;
}"""


def render_many(jobs, size=(1080, 1350), jpg_q=95, keep2x=False):
    from playwright.sync_api import sync_playwright
    css = font_css()
    reports = {}
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": size[0], "height": size[1]}, device_scale_factor=2)
        for html, stem in jobs:
            stem = Path(stem); stem.parent.mkdir(parents=True, exist_ok=True)
            src = stem.with_suffix(".html")
            src.write_text(f"<!doctype html><html><head><meta charset='utf-8'><style>{css}</style></head>"
                           f"<body>{html}</body></html>")
            pg.goto(src.as_uri()); pg.evaluate("document.fonts.ready.then(()=>1)"); pg.wait_for_timeout(150)
            rep = pg.evaluate(QA_JS, EDGE)
            big = stem.with_name(stem.name + "@2x.png")
            pg.screenshot(path=str(big), clip={"x": 0, "y": 0, "width": size[0], "height": size[1]})
            im = Image.open(big).convert("RGB")
            assert im.size == (size[0] * 2, size[1] * 2), im.size
            sm = im.resize(size, Image.LANCZOS)
            sm.save(stem.with_suffix(".png"), optimize=True)
            sm.save(stem.with_suffix(".jpg"), quality=jpg_q, subsampling=0, optimize=True)
            if not keep2x:
                big.unlink()
            reports[str(stem)] = rep
            ok = "OK " if not rep["errs"] and rep["minEdge"] >= EDGE else "ERR"
            print(f"{ok} {stem.name}: min edge {rep['minEdge']:.0f}px ({rep['worst']}), min font {rep['minFont']:.0f}px")
        br.close()
    return reports


# ----------------------------------------------------------------------------- photo prep
def flatfield(src, out, target="#F0C9CF", bands=None, gamma_hand=1.0):
    """Make a studio photo's backdrop exactly `target`: fit a smooth quadratic surface to backdrop pixels (outer
    bands), divide it out and multiply by the target colour. The subject keeps its own shading."""
    im = np.asarray(Image.open(src).convert("RGB")).astype(np.float32) / 255.0
    h, w, _ = im.shape
    yy, xx = np.mgrid[0:h, 0:w]
    m = np.zeros((h, w), bool)
    m[: int(h * 0.12)] = True
    m[:, : int(w * 0.08)] = True
    m[:, -int(w * 0.08):] = True
    if bands is not None:
        m = bands(h, w)
    xs, ys = xx[m] / w, yy[m] / h
    Aq = np.stack([np.ones_like(xs), xs, ys, xs * xs, ys * ys, xs * ys], 1)
    Xf, Yf = xx / w, yy / h
    full = np.stack([np.ones_like(Xf), Xf, Yf, Xf * Xf, Yf * Yf, Xf * Yf], -1)
    tgt = np.array([int(target[i:i + 2], 16) for i in (1, 3, 5)], np.float32) / 255.0
    outim = np.empty_like(im)
    for c in range(3):
        coef, *_ = np.linalg.lstsq(Aq, im[..., c][m], rcond=None)
        surf = full @ coef
        outim[..., c] = im[..., c] / np.clip(surf, 0.05, None) * tgt[c]
    outim = np.clip(outim, 0, 1)
    Image.fromarray((outim * 255 + 0.5).astype(np.uint8)).save(out)
    return out


def _object_mask(gray, thr=238, close=9):
    """Foreground mask of an object shot on white: everything not connected to the border through near-white."""
    h, w = gray.shape
    bgish = (gray >= thr).astype(np.uint8)
    ff = bgish.copy() * 255
    mask = np.zeros((h + 2, w + 2), np.uint8)
    for x, y in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1), (w // 2, 0), (0, h // 2), (w - 1, h // 2), (w // 2, h - 1)]:
        if ff[y, x] == 255:
            cv2.floodFill(ff, mask, (x, y), 128)
    fg = (ff != 128).astype(np.uint8)
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close, close)))
    hh, ww = fg.shape; fl = fg.copy() * 255; mk = np.zeros((hh + 2, ww + 2), np.uint8)
    cv2.floodFill(fl, mk, (0, 0), 128); fg = (fl != 128).astype(np.uint8)  # fill interior holes
    n, lab, stats, _ = cv2.connectedComponentsWithStats(fg)
    if n > 1:
        keep = 1 + np.argsort(stats[1:, cv2.CC_STAT_AREA])[::-1]
        big = stats[keep[0], cv2.CC_STAT_AREA]
        fg = np.isin(lab, [k for k in keep if stats[k, cv2.CC_STAT_AREA] > big * 0.04]).astype(np.uint8)
    return fg


def halftone(gray, pitch=9.0, angle=45, ss=3, gamma=1.0, contrast=1.15):
    """Classic AM halftone (round dots on a rotated grid), computed at ss x supersample and box-downsampled so the
    dots are crisp but antialiased. gray: float 0..1 (1 = white). Returns float 0..1 ink coverage image."""
    h, w = gray.shape
    g = cv2.resize(gray, (w * ss, h * ss), interpolation=cv2.INTER_CUBIC)
    g = np.clip((g - 0.5) * contrast + 0.5, 0, 1) ** gamma
    H, W = g.shape
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    a = math.radians(angle); p = pitch * ss
    u = (xx * math.cos(a) + yy * math.sin(a)) / p
    v = (-xx * math.sin(a) + yy * math.cos(a)) / p
    du, dv = u - np.round(u), v - np.round(v)
    dist = np.sqrt(du * du + dv * dv)                       # 0 at dot centre .. ~0.707 at cell corner
    dark = 1.0 - g
    rad = np.sqrt(np.clip(dark, 0, 1) / math.pi) * 1.0      # dot radius giving area = darkness
    ink = (dist < rad).astype(np.float32)
    ink = cv2.resize(ink, (w, h), interpolation=cv2.INTER_AREA)
    return ink


def halftone_cutout(src, out, crop=None, pitch=8.0, border=18, ink="#1B1416", paper="#FFFFFF",
                    shadow=True, rehalftone=True, thr=238, max_side=1400, gamma=1.0, close=9):
    """Photo/print of an object on white -> B/W halftone sticker cut-out (RGBA): halftone dots inside, white paper
    border around the silhouette, soft drop shadow. Never upscales: output <= the crop's own pixel size."""
    im = Image.open(src).convert("RGB")
    if crop:
        im = im.crop(crop)
    if max(im.size) > max_side:
        s = max_side / max(im.size); im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
    g = np.asarray(im.convert("L")).astype(np.float32) / 255.0
    fg = _object_mask((g * 255).astype(np.uint8), thr, close)
    if rehalftone:
        gs = cv2.GaussianBlur(g, (0, 0), 2.2)               # melt any existing screen before re-screening
        cov = halftone(gs, pitch=pitch, gamma=gamma)
    else:
        cov = 1.0 - g
    pad = border * 3 + 40
    h, w = g.shape
    H, W = h + 2 * pad, w + 2 * pad
    fgp = np.zeros((H, W), np.uint8); fgp[pad:pad + h, pad:pad + w] = fg
    covp = np.zeros((H, W), np.float32); covp[pad:pad + h, pad:pad + w] = cov * fg
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * border + 1, 2 * border + 1))
    sticker = cv2.dilate(fgp, k).astype(np.float32)
    sticker = cv2.GaussianBlur(sticker, (0, 0), 1.2)
    sticker = np.clip((sticker - 0.5) * 3 + 0.5, 0, 1)
    ink_rgb = np.array([int(ink[i:i + 2], 16) for i in (1, 3, 5)], np.float32)
    pap = np.array([int(paper[i:i + 2], 16) for i in (1, 3, 5)], np.float32)
    rgb = pap[None, None, :] * (1 - covp[..., None]) + ink_rgb[None, None, :] * covp[..., None]
    alpha = sticker
    if shadow:
        sh = cv2.GaussianBlur(sticker, (0, 0), 14)
        M = np.float32([[1, 0, 10], [0, 1, 18]]); sh = cv2.warpAffine(sh, M, (W, H)) * 0.28
        a_out = alpha + sh * (1 - alpha)
        rgb = (rgb * alpha[..., None] + np.array([60, 30, 35], np.float32) * (sh * (1 - alpha))[..., None]) / np.clip(a_out[..., None], 1e-4, None)
        alpha = a_out
    ys, xs = np.where(alpha > 0.01)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgba = np.dstack([np.clip(rgb, 0, 255), alpha * 255])[y0:y1, x0:x1].astype(np.uint8)
    Image.fromarray(rgba, "RGBA").save(out)
    return out


def bw_grain(src, out, crop=None, contrast=1.08, grain=0.05, max_w=2000, tone=(0, 0, 0)):
    """Black-and-white photo panel with fine film grain (grain added at the file's own resolution)."""
    im = Image.open(src).convert("L")
    if crop:
        im = im.crop(crop)
    if im.width > max_w:
        s = max_w / im.width; im = im.resize((max_w, round(im.height * s)), Image.LANCZOS)
    a = np.asarray(im).astype(np.float32) / 255.0
    a = np.clip((a - 0.5) * contrast + 0.5, 0, 1)
    rng = np.random.default_rng(7)
    n = rng.normal(0, 1, a.shape).astype(np.float32)
    n = cv2.GaussianBlur(n, (0, 0), 0.6)
    a = np.clip(a + n * grain * (0.35 + 0.65 * (1 - np.abs(a - 0.5) * 2)), 0, 1)
    Image.fromarray((a * 255 + 0.5).astype(np.uint8)).convert("RGB").save(out, quality=96)
    return out


def contact_sheet(pngs, out, cols=None, tile_w=432, gap=24, bg="#EDE8E1", label=None, labels=None):
    from PIL import ImageDraw, ImageFont
    ims = [Image.open(p).convert("RGB") for p in pngs]
    cols = cols or len(ims)
    rows = math.ceil(len(ims) / cols)
    th = round(tile_w * ims[0].height / ims[0].width)
    head = 70 if label else 0
    lab_h = 34 if labels else 0
    W = cols * tile_w + (cols + 1) * gap
    H = head + rows * (th + lab_h) + (rows + 1) * gap
    sheet = Image.new("RGB", (W, H), bg)
    d = ImageDraw.Draw(sheet)
    f1 = ImageFont.truetype(str(FONTS / "Inter-Bold.ttf"), 30)
    f2 = ImageFont.truetype(str(FONTS / "Inter-Medium.ttf"), 20)
    if label:
        d.text((gap, 22), label, fill="#2A2224", font=f1)
    for i, im in enumerate(ims):
        r, c = divmod(i, cols)
        x = gap + c * (tile_w + gap); y = head + gap + r * (th + lab_h + gap)
        sheet.paste(im.resize((tile_w, th), Image.LANCZOS), (x, y))
        if labels:
            d.text((x, y + th + 6), labels[i], fill="#5A4E50", font=f2)
    sheet.save(out)
    return out
