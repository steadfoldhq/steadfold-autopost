#!/usr/bin/env python3
"""Look A: "Put a finger down if…" (dusty pink, mauve serif, real gloved-hand photos 5 -> 1, gold sparkles).
Two sets: Fully Funded (global money lines) and Littlefold (gentle parent lines, no medical content)."""
import random
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v4")
from lib import *  # noqa

MARKS = D / "assets" / "marks"
BG = "#F0C9CF"
MAUVE = "#A8606E"
DEEP = "#5C2B36"

SETS = {
    "ff-finger": dict(brand="Fully Funded", mark="fullyfunded.png", edition="money edition", lines=[
        "you’ve checked your balance before buying a coffee.",
        "you’ve said “I’ll start saving next month” more than once.",
        "a subscription you forgot about renewed this year.",
        "you’ve felt real relief when payday finally landed.",
    ], end="Still got a finger up? Good. That’s where saving starts."),
    "lf-finger": dict(brand="Littlefold", mark="littlefold.png", edition="new parent edition", lines=[
        "you’ve googled a baby noise at 3 am.",
        "you’ve eaten dinner standing up, one-handed.",
        "you’ve whispered “please sleep” like a little prayer.",
        "you’ve watched them sleep instead of sleeping.",
    ], end="Every finger down? You’re doing better than you think."),
}


def sparkle(x, y, s, rot=0, op=1.0):
    return (f'<svg data-noqa style="position:absolute;left:{x - s / 2}px;top:{y - s / 2}px;width:{s}px;height:{s}px;'
            f'transform:rotate({rot}deg);opacity:{op}" viewBox="-1 -1 2 2"><defs><linearGradient id="g{x}{y}" x1="0" y1="-1" x2="0" y2="1">'
            f'<stop offset="0" stop-color="#F6DE97"/><stop offset=".55" stop-color="#D9A845"/><stop offset="1" stop-color="#B98428"/></linearGradient></defs>'
            f'<path d="M0,-1 C0.09,-0.09 0.09,-0.09 1,0 C0.09,0.09 0.09,0.09 0,1 C-0.09,0.09 -0.09,0.09 -1,0 C-0.09,-0.09 -0.09,-0.09 0,-1Z" fill="url(#g{x}{y})"/></svg>')


CSS = f"""
.slide{{width:1080px;height:1350px;background:{BG}}}
.photo{{position:absolute;left:-60px;width:1200px;height:1500px;object-fit:cover;
  -webkit-mask-image:linear-gradient(to bottom,transparent 0,#000 200px)}}
.glow{{position:absolute;inset:0;background:radial-gradient(120% 70% at 50% 18%,rgba(255,240,242,.55),rgba(255,240,242,0) 60%),radial-gradient(140% 90% at 50% 110%,rgba(150,70,90,.10),rgba(150,70,90,0) 60%)}}
.grain{{position:absolute;inset:0;opacity:.05;mix-blend-mode:multiply}}
.head{{position:absolute;left:90px;right:90px;text-align:center;font-family:Playfair;font-weight:500;color:{MAUVE};
  letter-spacing:-.012em;line-height:.98}}
.head .if{{font-family:Instrument;font-style:italic;font-weight:400;letter-spacing:0}}
.sub{{position:absolute;left:110px;right:110px;text-align:center;font-family:Inter;font-weight:500;color:{DEEP};
  font-size:52px;line-height:1.2;letter-spacing:-.012em;text-wrap:balance}}
.tag{{position:absolute;left:0;right:0;text-align:center;font-family:Inter;font-weight:700;color:{MAUVE};font-size:26px;
  letter-spacing:.2em;text-transform:uppercase}}
.brand{{position:absolute;left:76px;bottom:80px;display:flex;align-items:center;gap:12px;padding:8px 20px 8px 10px;border-radius:999px;background:rgba(250,228,231,.92);box-shadow:0 4px 18px rgba(120,50,65,.12);font-family:Inter;font-weight:700;
  font-size:27px;color:{DEEP};letter-spacing:-.01em}}
.brand img{{width:46px;height:46px}}
.idx{{position:absolute;right:76px;bottom:80px;padding:12px 18px;border-radius:999px;background:rgba(250,228,231,.92);font-family:Inter;font-weight:600;font-size:24px;color:{MAUVE};letter-spacing:.08em}}
.end{{position:absolute;left:120px;right:120px;text-align:center;font-family:Caveat;font-weight:700;font-size:56px;color:{MAUVE};
  line-height:1.05;text-wrap:balance}}
"""


def slide(cfg, k):
    mark = (MARKS / cfg["mark"]).as_uri()
    fingers = 5 - k
    photo = (PREP / f"hand{fingers}.png").as_uri()
    rnd = random.Random(k * 7 + len(cfg["brand"]))
    sp = []
    if k == 0:
        top, pw = 330, 1140
        head = (f'<div class="tag" style="top:104px">✦ {cfg["edition"]} ✦</div>'
                f'<div class="head" style="top:150px;font-size:186px;left:70px;right:70px;letter-spacing:-.03em">Put a finger<br>down <span class="if">if…</span></div>')
        sp += [sparkle(118, 190, 104, 0), sparkle(964, 372, 78, 12), sparkle(930, 150, 40, 0, .9), sparkle(160, 470, 48, 8, .9), sparkle(880, 590, 34, 0, .8)]
    else:
        top, pw = 400, 1200
        head = (f'<div class="head" style="top:112px;font-size:150px;left:70px;right:70px;letter-spacing:-.028em;line-height:.94">Put a finger<br>down <span class="if">if…</span></div>'
                f'<div class="sub" style="top:{410}px;left:96px;right:96px;font-size:60px;line-height:1.14;font-weight:600">…{cfg["lines"][k - 1]}</div>')
        xs = [(116, 430), (968, 400), (962, 120), (110, 120)]
        rnd.shuffle(xs)
        for (x, y), s in zip(xs[:3], (84, 50, 60)):
            sp.append(sparkle(x, y, s, rnd.choice([0, 10, -8]), .95))
    end = f'<div class="end" style="top:600px;font-size:62px">{cfg["end"]}</div>' if k == 4 else ""
    if k == 4:
        top = 580
    left = -(pw - 1080) // 2
    return (f'<style>{CSS}</style><div class="slide">'
            f'<img class="photo" style="top:{top}px;left:{left}px;width:{pw}px;height:{round(pw * 1.25)}px" src="{photo}">'
            f'<div class="glow"></div>{head}{"".join(sp)}{end}'
            f'<div class="brand"><img src="{mark}">{cfg["brand"]}</div><div class="idx">{k + 1}/5</div></div>')


GLAM_CSS = """
.slide{{width:1080px;height:1350px;background:#2A1A0E}}
.gphoto{{position:absolute;left:-65px;top:0;width:1210px;height:1512px;object-fit:cover}}
.scrim{{position:absolute;inset:0;background:linear-gradient(180deg,rgba(28,16,6,.78) 0%,rgba(28,16,6,.55) 30%,rgba(28,16,6,.0) 56%),
  linear-gradient(0deg,rgba(28,16,6,.45) 0%,rgba(28,16,6,0) 18%)}}
.ghead{{position:absolute;left:70px;right:70px;text-align:center;font-family:Playfair;font-weight:500;letter-spacing:-.028em;line-height:.94;
  background:linear-gradient(180deg,#FFF6DF 0%,#F6DC9C 45%,#D7A646 100%);-webkit-background-clip:text;background-clip:text;color:transparent;
  filter:drop-shadow(0 4px 18px rgba(0,0,0,.45))}}
.ghead .if{{font-family:Instrument;font-style:italic;font-weight:400;letter-spacing:0}}
.gsub{{position:absolute;left:96px;right:96px;text-align:center;font-family:Inter;font-weight:600;color:#FFF4DE;font-size:58px;line-height:1.14;
  letter-spacing:-.012em;text-wrap:balance;text-shadow:0 2px 18px rgba(0,0,0,.6)}}
.gtag{{position:absolute;left:0;right:0;text-align:center;font-family:Inter;font-weight:700;color:#F6DC9C;font-size:26px;letter-spacing:.24em;
  text-transform:uppercase;text-shadow:0 2px 12px rgba(0,0,0,.6)}}
.gend{{position:absolute;left:110px;right:110px;text-align:center;font-family:Caveat;font-weight:700;font-size:64px;color:#F6DC9C;line-height:1.02;
  text-wrap:balance;text-shadow:0 2px 16px rgba(0,0,0,.65)}}
.gbrand{{position:absolute;left:76px;bottom:80px;display:flex;align-items:center;gap:12px;padding:8px 20px 8px 10px;border-radius:999px;
  background:rgba(255,246,223,.94);font-family:Inter;font-weight:700;font-size:27px;color:#3A2410}}
.gbrand img{{width:46px;height:46px}}
.gidx{{position:absolute;right:76px;bottom:80px;padding:12px 18px;border-radius:999px;background:rgba(255,246,223,.94);font-family:Inter;
  font-weight:600;font-size:24px;color:#8A6420;letter-spacing:.08em}}
"""
GLAM = dict(brand="Fully Funded", mark="fullyfunded.png", edition="the rich-life edition", lines=SETS["ff-finger"]["lines"],
            end="Still a finger up? Good. That’s where saving starts.")


def glam_slide(k):
    cfg = GLAM
    mark = (MARKS / cfg["mark"]).as_uri()
    photo = (S3 / "assets" / f"glove{5 - k}.png").as_uri()
    sp = []
    if k == 0:
        head = (f'<div class="gtag" style="top:104px">✦ {cfg["edition"]} ✦</div>'
                f'<div class="ghead" style="top:150px;font-size:186px">Put a finger<br>down <span class="if">if…</span></div>')
        sp += [sparkle(118, 190, 96, 0), sparkle(964, 372, 70, 12), sparkle(930, 150, 38, 0, .9)]
    else:
        head = (f'<div class="ghead" style="top:112px;font-size:150px">Put a finger<br>down <span class="if">if…</span></div>'
                f'<div class="gsub" style="top:420px">…{cfg["lines"][k - 1]}</div>')
        sp += [sparkle(112, 130, 70, 0, .95), sparkle(970, 380, 48, 10, .95)]
    end = f'<div class="gend" style="top:570px">{cfg["end"]}</div>' if k == 4 else ""
    geo = "top:-10px;left:-110px;width:1300px;height:1625px" if k == 4 else "top:0;left:-65px;width:1210px;height:1512px"
    return (f'<style>{GLAM_CSS.format()}</style><div class="slide">'
            f'<img class="gphoto" style="{geo}" src="{photo}"><div class="scrim"></div>{head}{"".join(sp)}{end}'
            f'<div class="gbrand"><img src="{mark}">{cfg["brand"]}</div><div class="gidx">{k + 1}/5</div></div>')


if __name__ == "__main__" and len(sys.argv) > 1 and sys.argv[1] == "glam":
    rep = render_many([(glam_slide(k), S3 / "ff-finger-glam" / f"slide-{k + 1:02d}") for k in range(5)])
    json.dump(rep, open(S3 / "qa" / "report-a-glam.json", "w"), indent=1)
    contact_sheet([S3 / "ff-finger-glam" / f"slide-{k:02d}.png" for k in range(1, 6)], S3 / "ff-finger-glam" / "contact-sheet.png",
                  label="Fully Funded · Put a finger down if… (glam rhinestone glove, mansion bokeh)")
elif __name__ == "__main__":
    jobs = []
    for key, cfg in SETS.items():
        for k in range(5):
            jobs.append((slide(cfg, k), S3 / key / f"slide-{k + 1:02d}"))
    rep = render_many(jobs)
    json.dump(rep, open(S3 / "qa" / "report-a.json", "w"), indent=1)
    for key, cfg in SETS.items():
        contact_sheet([S3 / key / f"slide-{k:02d}.png" for k in range(1, 6)], S3 / key / "contact-sheet.png",
                      label=f"{cfg['brand']} · Put a finger down if… (look A)")
