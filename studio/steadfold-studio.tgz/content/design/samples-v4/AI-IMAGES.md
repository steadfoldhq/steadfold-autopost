# AI imagery added in v4 (caption: "Images made with AI")
- Glam glove 5/4/3 fingers: Canva AI, MAHYE-WRxIg, MAHYEwAsyk4 (edited from it), MAHYE0sCkmc (edited from it).
- Glove 2 and 1 fingers: derived in code from the 3-finger photo (derive_gloves.py); only the background is rebuilt.
- Everything else is reused from samples-v3 (see ../samples-v3/AI-IMAGES.md).
Generic rhinestone glove only: no celebrity, name or likeness.
