#!/usr/bin/env python3
"""Canva credits ran out after 3 glove poses. Derive 2- and 1-finger poses from the 3-finger photo: remove whole raised
fingers (polygon masks) down to rounded knuckle stubs and rebuild the blurred bokeh behind them (inpaint at low res,
upsampled, plus matched grain). Only background pixels are synthesised; every glove pixel left is the original."""
import cv2, numpy as np
from PIL import Image
src = cv2.imread("assets/g-glove3.png")
H, W = src.shape[:2]

def finger_mask(poly, stub_c, stub_ax):
    m = np.zeros((H, W), np.uint8)
    cv2.fillPoly(m, [np.array(poly, np.int32)], 255)
    # keep a rounded knuckle stub: subtract an ellipse at the finger base
    cv2.ellipse(m, stub_c, stub_ax, 0, 0, 360, 0, -1)
    return m

MID = finger_mask([(750, 820), (900, 820), (900, 1310), (748, 1310)], (820, 1312), (62, 52))
RIGHT = finger_mask([(890, 880), (1060, 880), (1060, 960), (985, 1300), (880, 1300)], (930, 1300), (60, 48))

SIB = [cv2.imread("assets/g-glove4.png"), cv2.imread("assets/g-glove5.png")]

def bgmap(img):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    mu = cv2.blur(g, (21, 21)); sd = np.sqrt(np.maximum(cv2.blur(g * g, (21, 21)) - mu * mu, 0))
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    return (sd < 9) & (hsv[..., 1] > 70)          # smooth AND warm-gold = blurred background, not glove

def remove(mask, blur=3):
    m = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    base = src.copy()
    todo = m > 0
    for sib in SIB:
        ok = todo & cv2.erode(bgmap(sib).astype(np.uint8), np.ones((25, 25), np.uint8)).astype(bool)
        base[ok] = sib[ok]; todo &= ~ok
    print("borrowed", int((m > 0).sum() - todo.sum()), "of", int((m > 0).sum()), "px")
    src_save = src.copy(); m2 = (todo * 255).astype(np.uint8)
    s = 4
    small = cv2.resize(base, (W // s, H // s), interpolation=cv2.INTER_AREA)
    ms = cv2.resize(cv2.dilate(m2, np.ones((9, 9), np.uint8)), (W // s, H // s), interpolation=cv2.INTER_NEAREST)
    fill = cv2.inpaint(small, ms, 9, cv2.INPAINT_NS)
    fill = cv2.GaussianBlur(fill, (0, 0), blur)
    fill = cv2.resize(fill, (W, H), interpolation=cv2.INTER_CUBIC).astype(np.float32)
    bb = cv2.GaussianBlur(base.astype(np.float32), (0, 0), 2)
    fill = np.where((m2 > 0)[..., None], fill, bb)
    rng = np.random.default_rng(1)
    fill += rng.normal(0, 1.6, fill.shape).astype(np.float32)
    a = cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 2.5)[..., None]
    return np.clip(src * (1 - a) + fill * a, 0, 255).astype(np.uint8)

cv2.imwrite("assets/d-glove2.png", remove(MID))
BOTH = finger_mask([(750, 830), (1070, 830), (1070, 990), (1000, 1300), (750, 1300)], (820, 1306), (60, 50))
cv2.ellipse(BOTH, (938, 1298), (60, 48), 0, 0, 360, 0, -1)
cv2.imwrite("assets/d-glove1.png", remove(BOTH, blur=4))
for n in (2, 1):
    Image.open(f"assets/d-glove{n}.png").crop((400, 700, 1200, 1500)).save(f"qa/d-glove{n}-crop.png")

# v3 of the 1-finger pose: start from the good 2-finger image and replace the right finger with real background
# shifted in from just right of it (same depth, same bokeh), colour-matched and feathered.
two = cv2.imread("assets/d-glove2.png").astype(np.float32)
R = finger_mask([(888, 860), (1068, 860), (1068, 990), (1000, 1302), (875, 1302)], (938, 1300), (60, 46))
R = cv2.dilate(R, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (17, 17)))
import sys
dx, dy = int(sys.argv[1]) if len(sys.argv) > 1 else 235, int(sys.argv[2]) if len(sys.argv) > 2 else 0
shift = np.float32([[1, 0, -dx], [0, 1, -dy]])
patch = cv2.warpAffine(two, shift, (W, H), borderMode=cv2.BORDER_REFLECT)
ring = cv2.dilate(R, np.ones((41, 41), np.uint8)) & ~R
gain = two[ring > 0].mean(0) / np.maximum(patch[ring > 0].mean(0), 1)
patch = cv2.GaussianBlur(patch * gain, (0, 0), 3)
a = cv2.GaussianBlur(R.astype(np.float32) / 255, (0, 0), 12)[..., None]
one = np.clip(two * (1 - a) + patch * a, 0, 255).astype(np.uint8)
cv2.imwrite("assets/d-glove1.png", one)
Image.open("assets/d-glove1.png").crop((400, 700, 1200, 1500)).save(f"qa/d-glove1-crop-{dx}-{dy}.png")
