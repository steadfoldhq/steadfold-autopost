#!/usr/bin/env python3
"""Look B: bright editorial covers (saturated pastel solid, huge condensed serif in burgundy-brown with pastel pills,
red-orange handwritten save-line, rotating-text stamp, B/W halftone cut-out object)."""
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v3")
from lib import *  # noqa

MARKS = D / "assets" / "marks"
INK = "#4A1D24"
RED = "#D4553A"
BUTTER, PINK, PERI = "#FCEFC4", "#F5C9CF", "#C7D0F7"

COVERS = {
    "hb-cover": dict(brand="Hourback", mark="hourback.png", handle="@hourbackhq", bg=PERI, pill=BUTTER, pill2=PINK,
                     tag="GET YOUR EVENINGS BACK", kicker="AI prompts · part 1",
                     title='These AI prompts give you your <span class="p">evening</span> <span class="p2">back</span>',
                     save="save this for tonight", save_y=1000, obj="ht-point.png", obj_w=520, obj_x=500, obj_y=930, rot=-8, flip=True,
                     arrow="left"),
    "lh-cover": dict(brand="Locked Hour", mark="lockedhour.png", handle="@lockedhourhq", bg=BUTTER, pill=PERI, pill2=PINK,
                     tag="ONE HOUR AT A TIME", kicker="the focus fix",
                     title='This <span class="p">one-hour rule</span> is quietly changing <span class="p2">everything</span>',
                     save="save this for Monday", obj="ht-clock.png", obj_w=380, obj_x=640, obj_y=860, rot=9),
    "ff-cover": dict(brand="Fully Funded", mark="fullyfunded.png", handle="@fullyfundedhq", bg=PINK, pill=BUTTER, pill2=PERI,
                     tag="MONEY, MADE CLEAR", kicker="money habits",
                     title='These money moves <span class="p">rich families</span> never <span class="p2">skip</span>',
                     save="save before payday", obj="ht-piggy.png", obj_w=480, obj_x=570, obj_y=850, rot=-6),
    "lf-cover": dict(brand="Littlefold", mark="littlefold.png", handle="@littlefoldhq", bg=BUTTER, pill=PINK, pill2=PERI,
                     tag="SMALL DAYS, GENTLY", kicker="for new parents",
                     title='The little things that make the <span class="p">first week</span> <span class="p2">home</span> easier',
                     save="save for the 3 am feeds", obj="ht-shoe.png", obj_w=400, obj_x=630, obj_y=880, rot=8),
}


def stamp(c, size=236):
    txt = f"{c['brand'].upper()} · {c['tag']} · "
    s = 220; r = 84
    path = f"M{s/2},{s/2} m-{r},0 a{r},{r} 0 1,1 {2*r},0 a{r},{r} 0 1,1 -{2*r},0"
    circ = 2 * math.pi * r
    fs = 20.5 * s / size
    mark = (MARKS / c["mark"]).as_uri()
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 {s} {s}">'
            f'<defs><path id="sp" d="{path}"/></defs>'
            f'<circle cx="{s/2}" cy="{s/2}" r="{s/2-2}" fill="#FFFBF2" stroke="{INK}" stroke-width="2.4"/>'
            f'<circle cx="{s/2}" cy="{s/2}" r="{r-19}" fill="{c["pill"]}" stroke="{INK}" stroke-width="1.6"/>'
            f'<text font-family="Inter" font-weight="800" font-size="{fs:.1f}" fill="{INK}" letter-spacing="1.2">'
            f'<textPath href="#sp" textLength="{circ - 8:.0f}" lengthAdjust="spacingAndGlyphs">{txt}</textPath></text>'
            f'<image href="{mark}" x="{s/2-34}" y="{s/2-34}" width="68" height="68"/></svg>')


def arrow(direction="down"):
    # a loose hand-drawn arrow, stroke in the save-line red
    if direction == "left":
        d = "M150,20 C120,60 70,70 20,58 M20,58 L48,36 M20,58 L46,80"
    else:
        d = "M14,14 C60,18 104,46 118,104 M118,104 L96,82 M118,104 L128,74"
    return (f'<svg width="150" height="120" viewBox="0 0 160 120" style="overflow:visible">'
            f'<path d="{d}" fill="none" stroke="{RED}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>')


def doodles(c):
    # small burgundy line doodles: a starburst and two dots, plus a squiggle
    return (f'<svg data-noqa style="position:absolute;left:84px;top:236px" width="54" height="54" viewBox="-1 -1 2 2">'
            f'<path d="M0,-1 L0,1 M-1,0 L1,0 M-.7,-.7 L.7,.7 M-.7,.7 L.7,-.7" stroke="{INK}" stroke-width=".14" stroke-linecap="round"/></svg>'
            f'<svg data-noqa style="position:absolute;left:96px;top:{1030 if c.get('arrow') != 'left' else 1110}px" width="210" height="40" viewBox="0 0 210 40">'
            f'<path d="M4,20 C24,0 44,40 64,20 S104,0 124,20 S164,40 184,20" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round" opacity=".85"/></svg>')


CSS = f"""
.slide{{width:1080px;height:1350px}}
.paper{{position:absolute;inset:0;opacity:.35;mix-blend-mode:multiply;
  background-image:radial-gradient(rgba(74,29,36,.10) 1px,transparent 1.2px);background-size:7px 7px}}
.chip{{position:absolute;left:84px;top:96px;display:flex;align-items:center;gap:12px;font-family:Inter;font-weight:700;
  font-size:27px;color:{INK};letter-spacing:-.01em}}
.chip img{{width:48px;height:48px}}
.kick{{position:absolute;left:84px;top:170px;font-family:Inter;font-weight:700;font-size:24px;letter-spacing:.18em;
  text-transform:uppercase;color:{INK};opacity:.78}}
.title{{position:absolute;left:84px;width:900px;top:300px;font-family:Instrument;font-weight:400;color:{INK};
  font-size:156px;line-height:.98;letter-spacing:-.022em}}
.title.under{{color:transparent}} .title.over .p,.title.over .p2{{background:transparent!important}}
.title .p,.title .p2{{border-radius:999px;padding:0 .2em .02em;margin:0 -.04em;-webkit-box-decoration-break:clone;
  box-decoration-break:clone;font-style:italic}}
.stamp{{position:absolute;right:98px;top:84px;transform:rotate(-14deg);filter:drop-shadow(0 6px 10px rgba(74,29,36,.18))}}
.obj{{position:absolute;filter:drop-shadow(0 18px 26px rgba(74,29,36,.22))}}
.save{{position:absolute;left:96px;font-family:CaveatBrush;font-size:62px;color:{RED};transform:rotate(-4deg);
  transform-origin:left center;line-height:1}}
.handle{{position:absolute;left:84px;bottom:84px;font-family:Inter;font-weight:600;font-size:22px;color:{INK};opacity:.75;
  letter-spacing:.04em}}
"""


def cover(key, c):
    mark = (MARKS / c["mark"]).as_uri()
    obj = (PREP / c["obj"]).as_uri()
    flip = "scaleX(-1) " if c.get("flip") else ""
    save_y = c.get("save_y", 1112)
    arr = (f'<div data-noqa style="position:absolute;left:{96 + 20 * len(c["save"]) + 30}px;top:{save_y - 50}px">{arrow("down")}</div>'
           if c.get("arrow") != "left" else "")
    return (f'<style>{CSS}.title .p{{background:{c["pill"]}}}.title .p2{{background:{c["pill2"]}}}</style>'
            f'<div class="slide" style="background:{c["bg"]}"><div class="paper"></div>'
            f'<img class="obj" style="left:{c["obj_x"]}px;top:{c["obj_y"]}px;width:{c["obj_w"]}px;transform:{flip}rotate({c["rot"]}deg)" src="{obj}">'
            f'<div class="chip"><img src="{mark}">{c["brand"]}</div>'
            f'<div class="kick">✦ {c["kicker"]}</div>'
            f'<div class="title under" data-noqa>{c["title"]}</div><div class="title over">{c["title"]}</div>'
            f'{doodles(c)}'
            f'<div class="save" style="top:{save_y}px">{c["save"]}</div>{arr}'
            f'<div class="stamp" data-noqa>{stamp(c)}</div>'
            f'<div class="handle">{c["handle"]}</div></div>')


if __name__ == "__main__":
    jobs = [(cover(k, c), S3 / "covers-b" / k) for k, c in COVERS.items()]
    rep = render_many(jobs)
    json.dump(rep, open(S3 / "qa" / "report-b.json", "w"), indent=1)
    contact_sheet([S3 / "covers-b" / f"{k}.png" for k in COVERS], S3 / "covers-b" / "contact-sheet.png",
                  label="Look B · bright editorial covers (Hourback, Locked Hour, Fully Funded, Littlefold)")
