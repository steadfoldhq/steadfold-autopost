# AI-generated imagery in samples v3 (caption: "Images made with AI")

All made with Canva AI image generation (Oct 15, 2026), exported at native size via canva_fetch.md. No real people, no logos.

| File (assets/) | Canva media | Used in |
|---|---|---|
| g-hand5..1.png (pink nitrile glove, 5/4/3/2/1 fingers) | MAHYEluxmoc, MAHYEshmz48, MAHYEubHdN8, MAHYEpSV9UE, MAHYEgPS6dM | ff-finger, lf-finger |
| g-clouds.png, g-wheat.png, g-forest.png, g-street.png | MAHYEpxk72s, MAHYEo9ACmk, MAHYEueCmfY, MAHYEmTWY-A | slow-pan carousel (street unused) |
| g-piggy.png, g-clock.png (B/W product shots, re-screened to halftone in code) | MAHYEk8Jxgg, MAHYEofeEM8 | ff-cover, lh-cover |
| halftone1.png, halftone2.png (sheet: pointing hand, OK hand, megaphone, clock, piggy, cup, baby shoe, hourglass) | fetched earlier today (pre-existing) | hb-cover (hand), lf-cover (shoe) |
| g-family.png, g-couple.png, g-father.png (vintage-style B/W "characters") | MAHYEm4CAwM, MAHYEsocWxA, MAHYEv91_KI | ff-ep01 |
| silhouette1.jpg (mother + toddler walking at dusk), g-shoulders.png (toddler on shoulders, meadow) | MAHYEmiEvjI, MAHYEuVoOm0 | Littlefold Reel |
