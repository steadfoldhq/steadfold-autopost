#!/usr/bin/env python3
"""Look C: royal burgundy editorial episode. Fully Funded Ep.01, the Benjamin Franklin codicil (facts and sources:
design/demos-episode/SOURCES.md + math.txt, reused unchanged). Deep oxblood with paper grain alternating with warm cream,
big Fraunces serif with Instrument italic words, Caveat labels, brush underlines, B/W grainy "character" photos."""
import re
import sys
sys.path.insert(0, "/home/claude/content/design/samples-v3")
from lib import *  # noqa

MARKS = D / "assets" / "marks"
OX, OX2, CREAM, INKC = "#7A1F22", "#5E1518", "#F2EEE8", "#2B1012"
ROSE = "#F2C3B3"
OUT = S3 / "ff-ep01"


def prep():
    rng = np.random.default_rng(3)
    n = rng.normal(0.5, 0.16, (2700, 2160)).astype(np.float32)
    n = cv2.GaussianBlur(n, (0, 0), 0.7)
    fib = cv2.GaussianBlur(rng.normal(0, 1, (2700, 2160)).astype(np.float32), (0, 0), 9) * 0.05   # paper mottling
    Image.fromarray(np.clip((n + fib) * 255, 0, 255).astype(np.uint8)).save(PREP / "grain.png")
    bw_grain(A / "g-family.png", PREP / "c-family.jpg")
    bw_grain(A / "g-couple.png", PREP / "c-couple.jpg")
    bw_grain(A / "g-father.png", PREP / "c-father.jpg")


def md(s, deep):
    s = re.sub(r"==(.+?)==", lambda m: f'<span class="ul">{m.group(1)}{brush(deep)}</span>', s)
    s = re.sub(r"\*(.+?)\*", r'<i>\1</i>', s)
    return s


def brush(deep):
    col = ROSE if deep else OX
    return (f'<svg data-noqa class="br" viewBox="0 0 400 30" preserveAspectRatio="none">'
            f'<path d="M6,20 C80,8 170,12 250,13 C310,14 360,10 394,15 C360,22 300,24 230,24 C150,25 70,27 8,26 Z" fill="{col}"/></svg>')


CSS = f"""
.slide{{width:1080px;height:1350px}}
.deep{{background:radial-gradient(120% 90% at 30% 20%,#8A2427,{OX} 55%,{OX2});color:{CREAM}}}
.light{{background:{CREAM};color:{INKC}}}
.grain{{position:absolute;inset:0;width:100%;height:100%;mix-blend-mode:overlay;opacity:.22;pointer-events:none}}
.light .grain{{opacity:.10;mix-blend-mode:soft-light}}
.lab{{position:absolute;left:96px;top:96px;font-family:Caveat;font-weight:700;font-size:64px;line-height:1}}
.deep .lab{{color:{ROSE}}} .light .lab{{color:{OX}}}
.serif{{font-family:Fraunces;font-variation-settings:'opsz' 144,'SOFT' 30,'WONK' 0;font-weight:420;letter-spacing:-.022em}}
.serif i{{font-family:Instrument;font-style:italic;font-weight:400;letter-spacing:-.005em;font-size:1.08em}}
.ul{{position:relative;white-space:nowrap;z-index:0}}
.ul .br{{position:absolute;left:-2%;width:104%;bottom:-.06em;height:.22em;z-index:-1}}
.big{{position:absolute;left:96px;right:96px;line-height:1.04}}
.sub{{position:absolute;left:96px;right:96px;font-family:Fraunces;font-variation-settings:'opsz' 24;font-weight:400;
  font-size:42px;line-height:1.32;letter-spacing:-.006em;text-wrap:pretty}}
.deep .sub{{color:#EBD9D3}} .light .sub{{color:#4A2A2C}}
.ph{{position:absolute;left:96px;right:96px;overflow:hidden;border-radius:4px}}
.ph img{{width:100%;height:100%;object-fit:cover;filter:sepia(.12) contrast(1.04)}}
.deep .ph{{box-shadow:0 0 0 2px rgba(242,238,232,.18)}}
.cap{{position:absolute;font-family:Caveat;font-weight:600;font-size:40px}}
.foot{{position:absolute;left:96px;right:96px;bottom:96px;display:flex;justify-content:space-between;
  font-family:'DejaVu Sans Mono',monospace;font-size:20px;letter-spacing:.14em;opacity:.78}}
.stat{{position:absolute;left:96px;right:96px;display:flex;align-items:baseline;gap:28px;
  border-top:2px solid rgba(242,238,232,.28);padding-top:22px}}
.light .stat{{border-top-color:rgba(43,16,18,.2)}}
.stat .n{{font-family:Fraunces;font-variation-settings:'opsz' 144;font-weight:380;font-size:120px;letter-spacing:-.03em;line-height:1}}
.stat .t{{font-family:Fraunces;font-variation-settings:'opsz' 24;font-size:40px;line-height:1.25;opacity:.9}}
"""


def page(kind, k, body):
    grain = (PREP / "grain.png").as_uri()
    return (f'<style>{CSS}</style><div class="slide {kind}">{body}'
            f'<img class="grain" data-noqa src="{grain}">'
            f'<div class="foot"><span>© FULLY FUNDED · EP.01</span><span>{k}/6</span></div></div>')


def img(name):
    return (PREP / name).as_uri()


SLIDES = [
    ("deep", f'<div class="lab">Ep.01</div>'
             f'<div class="big serif" style="top:210px;font-size:88px">{md("Benjamin Franklin left money to two cities, *on purpose,* to grow for ==200 years.==", True)}</div>'
             f'<div class="ph" style="top:760px;height:410px"><img src="{img("c-family.jpg")}" style="object-position:50% 45%"></div>'
             f'<div class="cap" style="right:110px;top:690px;color:{ROSE};transform:rotate(-3deg)">a story about time ↓</div>'),
    ("light", f'<div class="lab">June 1789.</div>'
              f'<div class="big serif" style="top:220px;font-size:100px">{md("A codicil to his will left *two cities* a ==gift.==", False)}</div>'
              f'<div class="stat" style="top:560px"><span class="n" style="color:{OX}">£1,000</span><span class="t">to<br>Boston</span></div>'
              f'<div class="stat" style="top:780px"><span class="n" style="color:{OX}">£1,000</span><span class="t">to<br>Philadelphia</span></div>'
              f'<div class="sub" style="top:1010px">Lent to young married tradespeople at 5% a year, and <i style="font-family:Instrument;font-size:1.12em">left to grow.</i></div>'),
    ("deep", f'<div class="lab">step 1.</div>'
             f'<div class="big serif" style="top:200px;font-size:92px">{md("He did the *maths* himself.", True)}</div>'
             f'<div class="sub" style="top:440px">At 5% a year, he expected each £1,000 to reach:</div>'
             f'<div class="stat" style="top:640px"><span class="n">£131,000</span><span class="t">after<br>100 years</span></div>'
             f'<div class="stat" style="top:860px"><span class="n">£4 million</span><span class="t">after<br>200 years</span></div>'),
    ("light", f'<div class="lab">By 1990.</div>'
              f'<div class="ph" style="top:200px;height:380px"><img src="{img("c-couple.jpg")}" style="object-position:50% 40%"></div>'
              f'<div class="stat" style="top:630px"><span class="n" style="color:{OX}">$4.5M</span><span class="t">about, in<br>Boston’s fund</span></div>'
              f'<div class="stat" style="top:850px"><span class="n" style="color:{OX}">$2M</span><span class="t">about, in<br>Philadelphia’s</span></div>'
              f'<div class="sub" style="top:1060px">Far less than his plan. Real growth is <i style="font-family:Instrument;font-size:1.12em">never a straight line.</i></div>'),
    ("deep", f'<div class="lab">step 2.</div>'
             f'<div class="big serif" style="top:250px;font-size:132px;text-align:center">{md("Time is the ==ingredient.==", True)}</div>'
             f'<div class="sub" style="top:570px;text-align:center">Not a big start. <i style="font-family:Instrument;font-size:1.12em">A long one.</i></div>'
             f'<div class="ph" style="top:730px;height:440px"><img src="{img("c-father.jpg")}" style="object-position:50% 45%"></div>'),
    ("light", f'<div class="lab">your move.</div>'
              f'<div class="big serif" style="top:210px;font-size:100px">{md("Start a pot for your ==kids.==", False)}</div>'
              f'<div class="stat" style="top:520px"><span class="n" style="color:{OX}">19,368</span><span class="t">by 18, from<br>50 a month</span></div>'
              f'<div class="sub" style="top:760px;font-size:46px">Example: 50 a month from birth at 6% a year. You’d put in 10,800.</div>'
              f'<div class="sub" style="top:1010px;font-size:30px;opacity:.75;line-height:1.35">Example math, not guaranteed. Before fees, tax and inflation. General education only, not financial advice.</div>'),
]

if __name__ == "__main__":
    prep()
    jobs = [(page(kind, i + 1, body), OUT / f"slide-{i + 1:02d}") for i, (kind, body) in enumerate(SLIDES)]
    rep = render_many(jobs)
    json.dump(rep, open(S3 / "qa" / "report-c.json", "w"), indent=1)
    contact_sheet([OUT / f"slide-{i:02d}.png" for i in range(1, 7)], OUT / "contact-sheet.png", cols=6, tile_w=360,
                  label="Fully Funded · Ep.01 Franklin (look C, royal burgundy editorial)")
