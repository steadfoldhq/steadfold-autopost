#!/usr/bin/env python3
"""Prepare Canva AI images for the v3 samples (see AI-IMAGES.md)."""
import sys; sys.path.insert(0, '/home/claude/content/design/samples-v3')
from lib import *
P = PREP
for n in []:
    flatfield(A / f"g-hand{n}.png", P / f"hand{n}.png", target="#F0C9CF")
halftone_cutout(A / "g-piggy.png", P / "ht-piggy.png", pitch=9, gamma=1.8)
halftone_cutout(A / "g-clock.png", P / "ht-clock.png", pitch=9)
# objects from the 2048 halftone sheets (quadrants), re-screened to one consistent dot pitch
q = lambda i, j: (j * 1024, i * 1024, j * 1024 + 1024, i * 1024 + 1024)
halftone_cutout(A / "halftone1.png", P / "ht-point.png", crop=q(0, 0), pitch=7)
halftone_cutout(A / "halftone1.png", P / "ht-ok.png", crop=q(0, 1), pitch=7)
halftone_cutout(A / "halftone1.png", P / "ht-megaphone.png", crop=q(1, 0), pitch=7)
halftone_cutout(A / "halftone2.png", P / "ht-cup.png", crop=q(0, 1), pitch=7)
halftone_cutout(A / "halftone2.png", P / "ht-shoe.png", crop=q(1, 0), pitch=7, close=41)
halftone_cutout(A / "halftone2.png", P / "ht-hourglass.png", crop=q(1, 1), pitch=7)
print("prep done")
