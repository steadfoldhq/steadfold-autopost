#!/usr/bin/env python3
"""Steadfold carousel design system v2 - renderer.

usage:  python3 render.py posts.json [--out DIR] [--highlight A|B|C] [--no-fail]
  posts.json = one post object, or {"posts": [ ... ]}   (schema: post.schema.json)
Writes  DIR/<post-id>/slide-NN.png (1080x1350), DIR/<post-id>/contact.png, DIR/contact-sheet.png, DIR/report.json
Exit 1 if any QA check fails (safe area, text overflow, collisions, highlight overlap, empty space, fonts).
"""
import argparse, json, os, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from engine.templates import slide_html  # noqa: E402
from engine.themes import THEMES, FONTS  # noqa: E402
from engine.covers import COVER_VISUALS, visual_type  # noqa: E402
from engine import interactive as IX  # noqa: E402  (interactive formats + cover save_line)
from collections import Counter

W, H = 1080, 1350


def font(size, w="Bold"):
    return ImageFont.truetype(str(FONTS / f"Inter-{w}.ttf"), size)


def validate(posts, base, soft=False):
    try:
        import jsonschema
        schema = json.loads((HERE / "post.schema.json").read_text())
        for p in posts:
            jsonschema.validate({k: v for k, v in p.items() if not k.startswith("_")}, schema)
    except ImportError:
        pass
    errs = []
    # cover variety: no more than 2 covers per brand in one batch may share the same hero visual
    sig = Counter()
    for p in posts:
        c = p["slides"][0]
        if c["template"] == "cover":
            vt = visual_type(p["theme"], c.get("fields", {}))
            if vt not in COVER_VISUALS[p["theme"]] + ["none"]:
                errs.append(f"{p['id']}: cover visual '{vt}' not available for {p['theme']} (use {COVER_VISUALS[p['theme']]})")
            if vt != "none":
                sig[(p["theme"], vt)] += 1
    for (th, vt), n in sig.items():
        if n > 2:
            errs.append(f"cover-variety: {n} {th} covers use the '{vt}' visual (max 2 per batch); vary cover.visual.type")
    # local images must exist
    for p in posts:
        for i, s in enumerate(p["slides"]):
            f = s.get("fields", {})
            srcs = []
            if s["template"] == "image" or (s["template"] == "output" and f.get("kind") == "image"):
                srcs.append(f.get("src"))
            if s["template"] == "cover" and (f.get("visual") or {}).get("img"):
                srcs.append(f["visual"]["img"])
            if s["template"] == "ep-cover" and (f.get("image") or {}).get("src"):
                srcs.append(f["image"]["src"])
            for src in srcs:
                if not src or not (Path(src) if Path(src).is_absolute() else base / src).exists():
                    errs.append(f"{p['id']} slide {i+1}: image not found: {src}")
            fb = f.get("freebie")
            if s["template"] == "cta" and isinstance(fb, dict) and fb.get("topic") and p.get("topic") and fb["topic"] != p["topic"]:
                errs.append(f"{p['id']}: cta.freebie topic '{fb['topic']}' does not match post topic '{p['topic']}'")
    for p in posts:  # house rules the schema can't express
        for i, s in enumerate(p["slides"]):
            blob = json.dumps({k: v for k, v in s.get("fields", {}).items() if k != "save_line"}).lower()   # cover save_line is the one allowed "save this"
            if s["template"] != "cta" and any(k in blob for k in ("save this", "send it to", "follow @", "link in bio", "pin this")):
                errs.append(f"{p['id']} slide {i+1}: save/send/follow/link lines belong on the cta slide only")
            if any(k in blob for k in ("not financial advice", "education only", "disclaimer")):
                errs.append(f"{p['id']} slide {i+1}: disclaimers go in the caption, not on slides")
        errs += IX.validate(p)
        if p["slides"][-1]["template"] != "cta":
            errs.append(f"{p['id']}: last slide must be the cta template")
    if errs:
        msg = "VALIDATION FAILED\n  - " + "\n  - ".join(errs)
        if not soft:
            raise SystemExit(msg)
        print(msg + "\n  (--no-fail: rendering anyway)", file=sys.stderr)



def strip(pngs, label=None, cell_w=360, gap=20, pad=28, bg=(236, 236, 240)):
    ims = [Image.open(p).convert("RGB") for p in pngs]
    ch = round(cell_w * H / W)
    top = 64 if label else pad
    out = Image.new("RGB", (pad * 2 + len(ims) * cell_w + (len(ims) - 1) * gap, top + ch + pad), bg)
    d = ImageDraw.Draw(out)
    if label:
        d.text((pad, 20), label, fill=(20, 20, 30), font=font(26, "ExtraBold"))
    for i, im in enumerate(ims):
        out.paste(im.resize((cell_w, ch), Image.LANCZOS), (pad + i * (cell_w + gap), top))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("posts"); ap.add_argument("--out", default=str(HERE / "out"))
    ap.add_argument("--highlight", choices=["A", "B", "C"]); ap.add_argument("--no-fail", action="store_true")
    a = ap.parse_args()
    data = json.loads(Path(a.posts).read_text())
    posts = data["posts"] if isinstance(data, dict) and "posts" in data else (data if isinstance(data, list) else [data])
    if a.highlight:
        for p in posts:
            p["highlight"] = a.highlight
    base = Path(a.posts).resolve().parent
    validate(posts, base, soft=a.no_fail)
    posts = [IX.expand(p) for p in posts]   # interactive macros -> concrete slides (plain posts unchanged)
    out = Path(a.out).resolve(); build = out / "_html"; build.mkdir(parents=True, exist_ok=True)
    for p in posts:
        p["_base"] = str(base); p["_imgdir"] = str(build / "img")
    jobs = []
    for p in posts:
        (out / p["id"]).mkdir(exist_ok=True)
        for i in range(len(p["slides"])):
            hp = build / f"{p['id']}-{i+1:02d}.html"
            hp.write_text(IX.slide_html(p, i))   # plain slides: exactly templates.slide_html
            jobs.append({"id": f"{p['id']}/{i+1:02d}", "html": str(hp), "png": str(build / f"{p['id']}-{i+1:02d}@2x.png"),
                         "final": str(out / p["id"] / f"slide-{i+1:02d}.png"), **IX.job_meta(p, i)})
    cjobs = IX.canvas_jobs(posts, build)   # panorama canvases: rendered once, wide, before the slides that slice them
    man = build / "manifest.json"
    man.write_text(json.dumps({"jobs": jobs, "report": str(out / "report.json")}))
    env = dict(os.environ, NODE_PATH=subprocess.run(["npm", "root", "-g"], capture_output=True, text=True).stdout.strip())
    if cjobs:
        (build / "canvas-manifest.json").write_text(json.dumps({"jobs": cjobs, "report": str(build / "canvas-report.json")}))
        if subprocess.run(["node", str(HERE / "engine" / "render.js"), str(build / "canvas-manifest.json")], env=env).returncode:
            raise SystemExit("renderer crashed (panorama canvas)")
    r = subprocess.run(["node", str(HERE / "engine" / "render.js"), str(man)], env=env)
    if r.returncode:
        raise SystemExit("renderer crashed")
    IX.finalize(jobs, cjobs, out / "report.json", W, H)  # 2x -> LANCZOS -> 1080x1350 (+ panorama strips, reveal pixelation, seam QA)
    rows = []
    for p in posts:
        pngs = sorted((out / p["id"]).glob("slide-*.png"))
        s = strip(pngs, f"{p['id']}  ·  {THEMES[p['theme']]['name']}  ·  highlight {p.get('highlight','A')}")
        s.save(out / p["id"] / "contact.png"); rows.append(s)
    sheet = Image.new("RGB", (max(r.width for r in rows), sum(r.height for r in rows)), (236, 236, 240))
    y = 0
    for r_ in rows:
        sheet.paste(r_, (0, y)); y += r_.height
    sheet.save(out / "contact-sheet.png", optimize=True)
    rep = json.loads((out / "report.json").read_text())
    bad = [x for x in rep if x["errors"]]
    print(f"\n{len(rep)} slides rendered, {len(bad)} failed QA -> {out}")
    if bad and not a.no_fail:
        sys.exit(1)


if __name__ == "__main__":
    main()
