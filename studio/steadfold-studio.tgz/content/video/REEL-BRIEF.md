# Reel brief (Oct 14 night build): one Reel per brand, posting Thu Oct 15 at 7:00 pm

Dharma's asks: Reels that look exactly like each brand's carousels, are readable on the first watch and fun to rewatch, and have apt, catchy music synced to the cuts. Everything must be right on the first pass, because Dharma reviews in the morning and the Reels post automatically at 7 pm.

## Inputs
- Engine: `/home/claude/content/video/src/vlab.py`. Read its docstring and `render()`, `contact_sheet()` and `preview()`.
- Reference Reel built to today's standard: `/home/claude/content/video/src/lf_safe_sleep.py` (Littlefold). Copy its structure:
  - the `.cam{transform:none!important}` line (it prevents text shimmer)
  - nothing moves after it lands: no `br=1` breathing, no shakes or flashes on body text
  - captions at y=1560
  - each idea on screen for at least 3 seconds
  - the final scene is the brand's CTA look
- Older Reel per brand, which shows that brand's theme CSS for vlab (reuse its colours, fonts, card and chip styles). These were built before the payoff-first rule, so **do not copy their structure**, which reads like a study report:
  - `ff_learning_bond.py` (Fully Funded)
  - `lh_phone_room.py` (Locked Hour)
  - `hb_potluck.py` (Hourback)
- The carousel this Reel is made from (same post, same facts): `/home/claude/content/week02/<brand>/posts.json` (slides) and `captions-v3.json` (caption). Rendered slides are in `/home/claude/content/week02/<brand>/out/<post-id>/slide-NN.png`; look at 2–3 of them to match the look.
- Standards (read before building):
  - `/home/claude/steadfold-library/current/guides/PAYOFF-FIRST.md`
  - `/home/claude/steadfold-library/current/guides/COPY-STANDARD.md`
  - copy-lint: `python3 /home/claude/steadfold-library/current/guides/copy-lint.py <file> --brand <brand>`
- Music: `python3 /home/claude/content/video/src/music.py <brand> <seconds> <out.wav>`. This is our own code-made bed at 120 BPM, so each beat lasts 0.5 s. Put every scene start on a 0.5 s boundary so cuts land on the beat.

## The Reel
- 1080×1920, 30 fps, **18 to 24 seconds** total, 5 to 7 scenes.
- **Scene 1, frame 0:** the payoff plus the action in "you" language, readable with the sound off, and the brand's highlight style on the key words. No logo intro, no "a study found".
- **Next scenes:** what to do, in 3 steps or fewer, with one idea per scene. Proof goes in **one** short line at most.
- **Last scene:** the brand's CTA look (save / send / follow). It must flow back into scene 1 when the Reel loops.
- **Text:** few words on screen, large type (at least 56 px for body text, 100 px or more for headlines), all inside the safe area (x 84–996, y 230–1450 for content; captions at y 1560). There's no voiceover, so captions carry the full sentence and on-screen text holds the key words.
- **Look:** the brand's carousel pieces only: same palette, fonts, cards, chips and highlighter. **No full-screen colour washes that the carousel doesn't use.** The dark or alternate background is allowed only where the carousel itself uses it (usually the CTA).
- **Motion:** brand-appropriate but never jittery. Locked Hour can be punchier (pop, whip, stamp on headlines). Fully Funded and Hourback stay clean (up, wipe, circle, push).
- **Facts:** only facts already in the shipped carousel and caption. Nothing new, no new numbers.

## Output (exact paths)
1. Code: `/home/claude/content/video/src/<brand-short>_reel_oct15.py`, using the same pattern as lf_safe_sleep.py.
2. Silent MP4: `/home/claude/content/video/out/<brand>-reel-oct15-silent.mp4`, plus a contact sheet in `/home/claude/content/video/qa/`.
3. Music bed (seconds = video length + 0.5): `/home/claude/content/video/audio/<brand>-reel-oct15-bed.wav`.
4. Final MP4 with music:
   ```
   ffmpeg -y -i silent.mp4 -i bed.wav -filter_complex "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart /home/claude/content/video/out/<brand>-reel-oct15.mp4
   ```
   The file must be under 19 MB.
5. Cover JPEG, 1080×1920, from scene 1 (quality 90): `/home/claude/content/video/out/<brand>-reel-oct15-cover.jpg`.
6. Reel caption: `/home/claude/content/video/out/<brand>-reel-oct15-caption.txt`.
   - Line 1 is the payoff plus the action.
   - Then 2–3 short lines with the steps.
   - Then "Save this for later." or a send prompt.
   - Then the brand's required short lines, copied from that carousel's caption (Fully Funded: "General education only, not financial advice." and "Source: canada.ca · Rules as of Oct 2026"; Hourback: its "Example made up…" line if the post shows an example; Locked Hour: any safety line in that caption).
   - Then 3–5 hashtags taken from the carousel caption.
   - copy-lint must PASS. To lint it, wrap the caption in a file as `CAPTION\n<<<\n...\n>>>`.
7. A first comment: `<brand>-reel-oct15-comment.txt`, one line, a question that invites a one-word reply.

## Checks before you report done (all must pass)
- Contact sheet: every frame readable at phone size; nothing overlaps or runs out of the safe area; scene 1 frame 0 has the payoff.
- The 2-slide test and the "people" test from PAYOFF-FIRST.md, applied to scenes 1–2.
- Audience desk: answer as the scroller (stop?), the "that's me" reader (save?) and the sender (who would they send it to?). If any answer is "no", fix it and re-render.
- `ffprobe`: 1080×1920, H.264 + AAC, 18–24 s, under 19 MB.
- Loudness is about −14 LUFS: `ffmpeg -i final.mp4 -af ebur128 -f null -`.

Report back in under 200 words: file paths, duration, size, scene list (one line each), caption first line, and anything you weren't sure about. Don't touch any other files, don't push to GitHub, and don't post anything.
