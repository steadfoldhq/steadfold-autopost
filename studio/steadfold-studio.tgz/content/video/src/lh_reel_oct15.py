#!/usr/bin/env python3
"""Locked Hour · 'Write one if-then plan' Reel (from lh-w2-01-five-rules; carousel Thu Oct 15 12:30 pm, Reel 7 pm).
23.0 s, 1080x1920, 30 fps, no voice. Music: music.py lockedhour bed (120 BPM); every cut sits on the 0.5 s grid.

Payoff-first shape (REEL-BRIEF.md, Oct 14):
  1 hook: payoff + action on frame 0 ("Reach more goals. Write one if-then plan." + the blank if-then card)
  2-4 the 3 steps from carousel slide 2, one per scene; the example sentence builds up across scenes 2-3
  5 what to expect (carousel slide 4): give it time, a missed day is fine
  6 CTA in the carousel's ink CTA look; its blank if-then card sits exactly where scene 1's card sits, so the
    loop is a match cut: "...Write it tonight." -> "Reach more goals. Write one if-then plan."

DESIGN RULE: built only from the carousel's zine pieces (theme CSS from lh_phone_room.py): cream #FFF4E0 with the
dot grid, ink #141414, yellow #FFD43B highlighter, pink #FF5CA8, white cards with thick ink borders and hard offset
shadows, Inter Display 900 headlines, yellow round step badges, receipt-style tags. Ink background only on the CTA,
like carousel slide 7. Punchy entrances (pop, whip, stamp) on headlines; nothing moves after it lands (no breathing,
no shakes, no flashes, static dot grid, .cam locked).
Every fact is from the shipped carousel + caption (Gollwitzer & Sheeran 2006: 94 tests; Lally 2010: 18 to 254 days;
Singh 2024: about 2 months typical; one miss didn't derail the habit)."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, "/home/claude/content/design")
from vlab import Video, words, el, caption, CHECK, MARKS  # noqa: E402
from engine.visuals import clock_lh  # noqa: E402  (read-only import, same timer as the carousel)

CREAM, INK, PINK, YEL, MUTED = "#FFF4E0", "#141414", "#FF5CA8", "#FFD43B", "#8A8173"

# ---- theme: exact Locked Hour CSS from lh_phone_room.py, plus the static pieces this Reel needs
THEME = """
:root{--bg:#FFF4E0;--ink:#141414;--pink:#FF5CA8;--yel:#FFD43B;--hl:#FFD43B;--hl-dark:#FFD43B;
 --prog-bg:rgba(20,20,20,.12);--prog-fg:#FF5CA8;--cap-bg:#141414;--cap-ink:#FFF4E0;--cap-r:14px;
 --cap-sh:8px 8px 0 #FF5CA8;--cap-bd:0;--strike:#FF5CA8}
.dark{--prog-bg:rgba(255,244,224,.25);--cap-bg:#FFF4E0;--cap-ink:#141414;--cap-sh:8px 8px 0 #FF5CA8}
.H{font-family:'Inter Display';font-weight:900;letter-spacing:-.04em;line-height:.98;color:var(--ink)}
.dark .H{color:#FFF4E0}
.B{font-family:Inter;font-weight:700;color:var(--ink);letter-spacing:-.01em}
.dark .B{color:#FFF4E0}
.dots{background-image:radial-gradient(rgba(20,20,20,.12) 2.4px,transparent 2.8px);background-size:30px 30px}
.dark .dots{background-image:radial-gradient(rgba(255,244,224,.10) 2.4px,transparent 2.8px)}
.card{background:#fff;border:6px solid #141414;box-shadow:12px 12px 0 #141414;border-radius:18px}
.dark .card{background:#FFF4E0;box-shadow:12px 12px 0 #FF5CA8}
.kick{display:inline-block;font:800 28px/1 Inter;letter-spacing:.13em;text-transform:uppercase;color:#141414;
 background:#FFD43B;border:4px solid #141414;padding:12px 18px 11px;border-radius:8px;box-shadow:5px 5px 0 #141414}
#tag{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:#FFF4E0;
 border:4px solid #141414;border-radius:999px;padding:6px 20px 6px 6px;font:800 26px/1 Inter;color:#141414}
#tag img{width:44px;height:44px;border-radius:50%}
#tag span{opacity:.7;font-weight:700}
/* Reel-specific, all carousel pieces */
.cam{transform:none!important}
.pat{background-position:0 0!important}
.mk{background-image:linear-gradient(#FFD43B,#FFD43B);background-repeat:no-repeat;background-position:0 86%;
 background-size:100% 50%;padding:0 .06em;margin:0 -.06em;-webkit-box-decoration-break:clone;box-decoration-break:clone}
.mkd{background:#FFD43B;color:#141414;border-radius:.12em;padding:0 .08em .02em;-webkit-box-decoration-break:clone;
 box-decoration-break:clone}
.badge{display:grid;place-items:center;width:132px;height:132px;border-radius:50%;background:#FFD43B;
 border:6px solid #141414;box-shadow:8px 8px 0 #141414;font:900 74px/1 'Inter Display';color:#141414}
.it{font:900 92px/1.08 'Inter Display';letter-spacing:-.035em;color:#141414}
.blank{display:inline-block;width:250px;height:.62em;border-bottom:9px solid #141414;vertical-align:baseline;margin:0 .08em}
.ex{font:700 68px/1.2 Inter;letter-spacing:-.015em;color:#141414}
.ex .old{color:#8A8173}
.ex b{font-weight:900}
.rtag{display:inline-block;font:900 56px/1 'Inter Display';letter-spacing:-.02em;text-transform:none;color:#141414;
 background:#FFD43B;border:6px solid #141414;box-shadow:8px 8px 0 #141414;border-radius:12px;padding:16px 26px 18px;
 white-space:nowrap}
.lab{display:inline-block;font:800 26px/1 Inter;letter-spacing:.14em;text-transform:uppercase;padding:10px 14px 9px;
 border:4px solid #141414;border-radius:8px;background:#fff;color:#141414}
.lab.p{background:#FF5CA8}
.myth{font:700 60px/1.2 Inter;color:#4D463E;letter-spacing:-.01em}
.truth{font:900 66px/1.1 'Inter Display';letter-spacing:-.03em;color:#141414}
"""
TAG = f'<div id="tag"><img src="{(MARKS / "lockedhour.png").as_uri()}">Locked Hour <span>· Receipts</span></div>'

X, W = 84, 912
CARD_Y = 930          # the blank if-then card: same box in scene 1 and the CTA (loop match cut)
IFTHEN = '<div class="it">When I<span class="blank"></span>,<br>then I<span class="blank"></span>.</div>'


def ifthen_card(dark=False):
    return f'<div class="card" style="padding:40px 48px 46px">{IFTHEN}</div>'


def step(n, head, t=0.0):
    return (el(f'<span class="badge">{n}</span>', X, 350, a="pop", t=t, d=0.4)
            + words(head, t=t + 0.15, st=0.07, wa="pop", d=0.36, cls="H",
                    style=f"position:absolute;left:{X}px;top:530px;width:{W}px;font-size:126px"))


v = Video("lockedhour", "reel-oct15", THEME, TAG)

# 1 · HOOK (0–3.5) payoff + action on frame 0, mirrors the carousel cover; receipt tag stamps in as the one proof line
v.scene(0, 3.5, "".join([
    el('<span class="kick">Do this tonight</span>', X, 330, a="none"),
    el('Reach more<br>goals. <span class="mk">Write one<br>if-then plan.</span>', X, 400, W, a="none", cls="H",
       style="font-size:128px"),
    el(ifthen_card(), X, CARD_Y, W, a="none"),
    el(f'<span class="rtag">{CHECK} Held up in 94 tests</span>', 418, 1200, a="stamp", t=0.55, d=0.34, rot=-4),
    caption("Reach more of your goals: write one if-then plan tonight.", t=0.25, y=1560),
]), tin="cut", bg=CREAM, pattern="dots")

# 2 · STEP 1 (3.5–7.5) the cue
v.scene(3.5, 7.5, "".join([
    step(1, "Pick a cue|you ==can't miss.=="),
    el('<div class="card ex" style="padding:40px 46px 44px"><span class="mk"><b>When</b></span> I sit down with '
       'coffee at 7:30,</div>', X, 870, W, a="up", t=0.75, d=0.42),
    caption("1. Pick a cue you can't miss: a time and a place.", t=0.2, y=1560),
]), tin="whip", bg=CREAM, pattern="dots")

# 3 · STEP 2 (7.5–11.5) the first move; the sentence from step 1 stays (muted) and the "then" half lands
v.scene(7.5, 11.5, "".join([
    step(2, "Name the|==first move.=="),
    el('<div class="card ex" style="padding:40px 46px 44px"><div class="old">When I sit down with coffee at 7:30,</div>'
       '<div data-a="up" data-t="0.85" data-d="0.42" style="margin-top:14px"><span class="mk"><b>then</b></span> I open '
       'the draft and type one line.</div></div>', X, 870, W, a="up", t=0.6, d=0.42),
    caption("2. Name the first move. Keep it small and physical.", t=0.2, y=1560),
]), tin="whip", bg=CREAM, pattern="dots")

# 4 · STEP 3 (11.5–15.5) the obstacle: a second if-then
v.scene(11.5, 15.5, "".join([
    step(3, "Plan for the|==obstacle.=="),
    el('<div class="card ex" style="padding:40px 46px 44px"><span class="mk"><b>If</b></span> my phone buzzes, '
       '<span class="mk"><b>then</b></span> I flip it face-down and keep typing.</div>', X, 870, W, a="up", t=0.75,
       d=0.42),
    caption("3. Plan for the obstacle with a second if-then.", t=0.2, y=1560),
]), tin="whip", bg=CREAM, pattern="dots")

# 5 · WHAT TO EXPECT (15.5–19.5) mirrors carousel slide 4; the myth gets struck through, the truth lands
v.scene(15.5, 19.5, "".join([
    el('<span class="kick">Day 22 of a 21-day challenge?</span>', X, 330, a="left", t=0.05),
    words("Give it time.|A ==missed day==|==is fine.==", t=0.15, st=0.07, wa="pop", d=0.36, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:{W}px;font-size:112px"),
    el('<div class="card" style="padding:34px 44px 40px"><span class="lab">Drop this</span>'
       '<div class="myth" style="margin-top:20px"><span class="strike" data-a="strike" data-t="1.25" data-d="0.35">'
       '21 days to a habit</span></div></div>', X, 810, W, a="up", t=0.7, d=0.42),
    el('<div class="card" style="padding:34px 44px 40px;background:#FFD43B"><span class="lab p">What held up</span>'
       '<div class="truth" style="margin-top:20px">About 2 months<br>is typical</div></div>', X, 1080, W, a="up",
       t=1.75, d=0.42),
    caption("Give it time: habits took 18 to 254 days, not 21. A missed day is fine.", t=0.2, y=1560),
]), tin="zoom", bg=CREAM, pattern="dots")

# 6 · CTA (19.5–23.0) carousel slide 7 look: ink + dots, timer, cream card with pink shadow. The blank if-then card
#     sits at scene 1's exact spot, so the loop cuts straight back into "Write one if-then plan."
v.scene(19.5, 23.0, "".join([
    el('One sentence.<br><span class="mkd">Write it tonight.</span>', X, 340, W, a="pop", t=0.05, d=0.4, cls="H",
       style="font-size:104px;line-height:1.08"),
    el(clock_lh(230, 0.75), 790, 560, a="pop", t=0.45, d=0.45),
    el(ifthen_card(dark=True), X, CARD_Y, W, a="up", t=0.3, d=0.42),
    el('<b style="color:#FFD43B">Save it.</b> Send it to a friend.<br>Follow <b style="color:#FFD43B">@lockedhourhq</b>',
       X, 1290, W, a="up", t=0.9, d=0.4, cls="B", style="font-size:56px;line-height:1.24"),
]), tin="circle", bg=INK, pattern="dots", origin="50% 55%", cls="dark")

if __name__ == "__main__":
    from vlab import render, contact_sheet, preview
    out = Path("/home/claude/content/video/out")
    qa = Path("/home/claude/content/video/qa")
    if "--preview" in sys.argv:
        dst = Path(sys.argv[sys.argv.index("--preview") + 1])
        preview(v, [0.0, 2.2, 6.0, 10.5, 14.5, 18.6, 21.2, 22.9], dst)
    else:
        import subprocess
        from PIL import Image
        cover_png = Path(sys.argv[1]) if len(sys.argv) > 1 else qa / "lockedhour-reel-oct15-cover.png"
        mp4 = render(v, out / "lockedhour-reel-oct15-silent.mp4", cover_t=2.2, cover_png=cover_png)
        Image.open(cover_png).convert("RGB").save(out / "lockedhour-reel-oct15-cover.jpg", quality=90)
        contact_sheet(mp4, qa / "lockedhour-reel-oct15-sheet.png")
        bed = Path("/home/claude/content/video/audio/lockedhour-reel-oct15-bed.wav")
        subprocess.run([sys.executable, str(Path(__file__).resolve().parent / "music.py"), "lockedhour",
                        f"{v.duration + 0.5}", str(bed)], check=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp4), "-i", str(bed), "-filter_complex",
                        "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]", "-map", "0:v", "-map", "[a]",
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
                        str(out / "lockedhour-reel-oct15.mp4")], check=True)
