#!/usr/bin/env python3
"""Fully Funded · 'Start the clock at birth' Reel (id ff-reel-1015-start-at-birth). Global, Content Standard v3.
17.0 s, 1080x1920, 30 fps, 5 scenes, no voice. Music: music2.py fullyfunded "warm" (calm lo-fi, chime hook on beat 1,
no impact hits); every scene starts on the 0.5 s grid (120 BPM), so each cut lands on a beat.

  1 0.0-3.5   hook on frame 0: "100 a month from birth" -> "≈ 645,000 by age 65" + "Example at 6% a year"
  2 3.5-7.5   the gap at 18: start at birth ≈ 38,700 vs start at 10 ≈ 12,300, same 100 a month
  3 7.5-11.0  the move: open a child or long-term investment account where you live; automate 100 a month
  4 11.0-14.0 the catch: example only; not guaranteed; before fees, tax and inflation
  5 14.0-17.0 cobalt CTA: "Know a new parent?" + "Send this to a new parent." -> loops into scene 1's answer

NUMBERS: all from ff_start_at_birth_math.py (100 at the end of each month, 6% a year compounded monthly).
The brief's "≈ 600,000 by 65" compounded the 18->65 leg yearly (599,077); with the monthly compounding the caption
states, the same pot is 645,306, so the Reel says ≈ 645,000 and every number uses one method.

DESIGN: the week-03 global carousel pieces (out/contact-sheet.png): #F5F7FF paper, cover slide's big cobalt circle
bottom-right + peach circle left, inner slides' lavender circle top-right + peach bottom-left, Inter Display 800 ink
headlines with the orange hand-drawn marker (highlight A) on 1-3 words, white cards with #DCE1FA borders, cobalt
number tiles, #C2410C kickers, navy label pill. Cobalt surface only on the CTA (the FF CTA look).
TONE (v3 s.5): soft rises, fades and gentle wipes only. No stamps, pops, shakes, flashes or whips.
Nothing moves after it lands (.cam locked). The #prog tracker stays hidden (vlab default)."""
import base64
import random
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from vlab import Video, words, el, caption, MARKS  # noqa: E402

BG, CO, INK, MUTED, OR, KICK = "#F5F7FF", "#2B3FE0", "#0E1440", "#4B5178", "#FF6A3D", "#C2410C"
LAV, PEACH, LINE = "#E8ECFF", "#FFD9C9", "#D9DEF5"


# ----------------------------------------------------------------------------- hand-drawn marker (highlight A)
def _smooth(pts):
    d = f"M{pts[0][0]:.1f} {pts[0][1]:.1f}"
    for i in range(1, len(pts) - 1):
        mx, my = (pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2
        d += f" Q{pts[i][0]:.1f} {pts[i][1]:.1f} {mx:.1f} {my:.1f}"
    return d + f" L{pts[-1][0]:.1f} {pts[-1][1]:.1f}"


def marker_svg(ratio, color=OR, seed=1, dark=False):
    """Python port of the carousel's markerA() (design/engine/highlight.js): an irregular filled marker swipe plus
    a thinner 'drag' stroke. ratio = width / height of the band. Returns a data: URI."""
    R = random.Random(seed).random
    h = 100.0
    w = ratio * h
    n = max(5, round(w / 78))
    tilt = (R() - 0.5) * h * 0.10
    top, bot = [], []
    for i in range(n + 1):
        x, t = i / n * w, i / n
        top.append([x, h * 0.08 + (R() - 0.5) * h * 0.14 + tilt * t])
        bot.insert(0, [x, h * 0.94 + (R() - 0.5) * h * 0.10 + tilt * t])
    pts = ([[h * 0.06, h * 0.30 + R() * h * 0.1]] + top[1:-1] + [[w - h * 0.02, h * 0.06 + tilt],
           [w + h * 0.04, h * 0.52 + tilt], [w - h * 0.05, h * 0.96 + tilt]] + bot[1:-1]
           + [[-h * 0.05, h * 0.82], [h * 0.06, h * 0.30]])
    y0 = h * (0.30 + R() * 0.12)
    y1 = y0 + (R() - 0.5) * h * 0.18 + tilt
    qy = (y0 + y1) / 2 + (R() - 0.5) * h * 0.2
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-8 -8 {w + 16:.1f} {h + 16:.1f}" '
           f'preserveAspectRatio="none" overflow="visible">'
           f'<path d="{_smooth(pts)}Z" fill="{color}" opacity="{1 if dark else .92}"/>'
           f'<path d="M{h * .2:.1f} {y0:.1f} Q{w * .5:.1f} {qy:.1f} {w - h * .15:.1f} {y1:.1f}" stroke="{color}" '
           f'stroke-width="{h * .34:.1f}" stroke-linecap="round" fill="none" opacity="{1 if dark else .55}"/></svg>')
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()


def mk(text, chars=None, seed=1, t=None, d=0.5, dark=False):
    """Orange marker behind `text` (ink stays ink, also on cobalt). t=None: already drawn at frame 0;
    else it wipes in gently from the left at local time t."""
    chars = chars or len(text)
    ratio = max(1.2, chars * 0.56 / 0.73)
    uri = marker_svg(ratio, OR, seed, dark)
    anim = f' data-a="hl" data-t="{t}" data-d="{d}"' if t is not None else ' style="--p:1"'
    return (f'<span class="mk{" dk" if dark else ""}"{anim}><span class="mkb" style="background-image:url({uri})">'
            f'</span><span class="mkt">{text}</span></span>')


THEME = f"""
:root{{--bg:{BG};--ink:{INK};--hl:{OR};--hl-dark:{OR};--prog-bg:rgba(14,20,64,.10);--prog-fg:{OR};
 --cap-bg:{INK};--cap-ink:#FFFFFF;--cap-r:20px;--cap-sh:0 18px 40px -18px rgba(14,20,64,.5);--cap-bd:0;--strike:{OR}}}
.dark{{--cap-bg:#FFFFFF;--cap-ink:{INK}}}
.cam{{transform:none!important}}
.H{{font-family:'Inter Display';font-weight:800;letter-spacing:-.035em;line-height:1.06;color:{INK}}}
.dark .H{{color:#fff}}
.deco{{position:absolute;border-radius:50%}}
.kick{{font:800 32px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:{KICK}}}
/* highlight A: the carousel's hand-drawn marker, band from .60em above the baseline to .13em below it */
.mk{{position:relative;display:inline-block;isolation:isolate;white-space:nowrap;line-height:1}}
.mk .mkt{{position:relative;z-index:1;color:{INK}}}
.mk .mkb{{position:absolute;z-index:0;left:-.03em;right:-.03em;top:.265em;height:.73em;background-repeat:no-repeat;
 background-size:100% 100%;mix-blend-mode:multiply;clip-path:inset(-20% calc((1 - var(--p,0)) * 104%) -20% -4%)}}
.mk.dk .mkb{{mix-blend-mode:normal}}
.card{{background:#fff;border:2px solid #DCE1FA;border-radius:28px;box-shadow:0 28px 50px -26px rgba(14,20,64,.30)}}
.big{{font:800 214px/.86 'Inter Display';letter-spacing:-.05em;color:{CO};white-space:nowrap}}
.big small{{font-size:.5em;letter-spacing:0;margin-right:.08em;vertical-align:.32em}}
.obar{{height:16px;border-radius:16px;overflow:hidden}}
.obar .fill{{height:100%;width:0;background:{OR};border-radius:16px}}
.ptr{{display:inline-block;font:800 32px/1 Inter;letter-spacing:.02em;background:{INK};color:#fff;padding:18px 26px;
 border-radius:999px;white-space:nowrap}}
.small{{font:600 32px/1.3 Inter;color:{MUTED}}}
.cmp{{padding:44px 44px 36px}}
.cr{{margin-bottom:40px}}
.cr .top{{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:18px}}
.cr .lb{{font:700 54px/1.1 Inter;color:{INK};letter-spacing:-.015em}}
.cr .v{{font:800 104px/1 'Inter Display';letter-spacing:-.04em;color:{CO}}}
.cr.b .v{{color:#7380EC}}
.cr .tr{{height:40px;border-radius:20px;background:{LAV};overflow:hidden}}
.cr .tr .fill{{height:100%;width:0;border-radius:20px;background:{CO}}}
.cr.b .tr .fill{{background:#8F9AF3}}
.cr .pd{{font:600 40px/1 Inter;color:{MUTED};margin-top:18px}}
.cfoot{{border-top:2px solid {LINE};padding-top:26px;font:800 26px/1.3 Inter;letter-spacing:.12em;text-transform:uppercase;
 color:{MUTED}}}
.stack{{display:flex;flex-direction:column;gap:28px}}
.step{{display:flex;align-items:center;gap:34px;padding:38px 40px 38px 36px}}
.badge{{flex:none;display:grid;place-items:center;width:112px;height:112px;border-radius:28px;background:{CO};color:#fff;
 font:800 60px/1 'Inter Display'}}
.step .tt{{font:800 60px/1.08 'Inter Display';letter-spacing:-.03em;color:{INK}}}
.step .sb{{font:500 44px/1.25 Inter;color:{MUTED};margin-top:12px}}
.ck{{display:flex;align-items:center;gap:30px;padding:36px 0;border-bottom:2px dashed {LINE};font:700 58px/1.18 Inter;
 color:{INK};letter-spacing:-.015em}}
.ck:last-child{{border-bottom:0}}
.ck svg{{flex:none}}
.ctac{{background:#fff;border-radius:40px;padding:56px 56px 60px;box-shadow:0 40px 80px -40px rgba(8,14,80,.6)}}
.ctac .ib{{display:grid;place-items:center;width:132px;height:132px;border-radius:32px;background:{OR};margin-bottom:40px}}
.ctac .tx{{font:800 88px/1.08 'Inter Display';color:{INK};letter-spacing:-.035em}}
.ctac .tx b{{color:{CO}}}
#tag{{position:absolute;left:96px;top:300px;display:flex;align-items:center;gap:12px;background:#fff;
 border-radius:999px;padding:6px 24px 6px 6px;font:800 28px/1 Inter;color:{INK};box-shadow:0 8px 20px -10px rgba(14,20,64,.5)}}
#tag img{{width:48px;height:48px;border-radius:50%}}
#tag span{{color:{MUTED};font-weight:700}}
"""
TAG = (f'<div id="tag"><img src="{(MARKS / "fullyfunded.png").as_uri()}">Fully Funded '
       f'<span>· How money grows</span></div>')
X, W = 96, 888
ARROW = (f'<svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="{CO}" stroke-width="2.8" '
         'stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15M13 6l6 6-6 6"/></svg>')
SEND = ('<svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" '
        'stroke-linejoin="round" stroke-linecap="round"><path d="M21 3L3 10.5l7.2 2.6L13 21z"/><path d="M21 3L10.2 13.1"/></svg>')


def cover_paper():
    """Carousel cover decor: big cobalt circle bottom-right, small peach circle left. Static."""
    return (el("", 560, 1150, 1100, a="none", cls="deco", style=f"height:1100px;background:{CO}")
            + el("", -150, 1060, 320, a="none", cls="deco", style=f"height:320px;background:{PEACH};opacity:.7"))


def inner_paper():
    """Carousel inner-slide decor: lavender circle top-right, peach circle bottom-left. Static."""
    return (el("", 620, -300, 760, a="none", cls="deco", style=f"height:760px;background:{LAV}")
            + el("", -260, 1480, 560, a="none", cls="deco", style=f"height:560px;background:#FBE6E1"))


def cobalt_paper():
    return (el("", 560, -330, 900, a="none", cls="deco", style="height:900px;background:#3547E6")
            + el("", -300, 1400, 700, a="none", cls="deco", style="height:700px;background:#2436C9"))


def kick(text, y=400, t=0.0, a="none"):
    return el(f'<span class="kick">{text}</span>', X, y, a=a, t=t, d=0.5)


def static_caption(text, y=1560):
    """On screen at frame 0 (sound-off readers)."""
    return el(f'<div class="words cap-w">{text}</div>', x=80, y=y, w=840, a="none", cls="cap")


def cap(text, t=0.25):
    return caption(text, t=t, y=1560)


def hook_block(y0=460):
    """Scene 1 / cover: the hook + the big number. Returns html (all static)."""
    return "".join([
        el(f'100 a month<br>{mk("from birth", seed=3)}', X, y0, W, a="none", cls="H", style="font-size:128px"),
        el('<span class="big"><small>≈</small>645,000</span>', X - 6, y0 + 312, W, a="none"),
        el('by age 65', X, y0 + 548, W, a="none", cls="H", style="font-size:96px"),
    ])


v = Video("fullyfunded", "reel-start-at-birth", THEME, TAG)

# 1 · HOOK (0–3.5): everything readable on frame 0; only the orange underline draws in, softly.
v.scene(0, 3.5, "".join([
    cover_paper(),
    kick("Start the clock at birth"),
    hook_block(460),
    el('<div class="obar" data-a="bar" data-t="0.3" data-d="0.7" data-w="100"><div class="fill"></div></div>',
       X, 1000, 200, a="none"),
    el('<span class="ptr">Example at 6% a year</span>', X, 1150, a="none"),
    el('<div class="small">Any currency.<br>Same math.</div>', X + 450, 1146, 300, a="none"),
    static_caption("100 a month from birth could grow to about 645,000 by 65. Example at 6% a year."),
]), tin="cut", bg=BG)

# 2 · THE GAP (3.5–7.5): same 100 a month, two start dates, value at 18. Bars grow in gently.
v.scene(3.5, 7.5, "".join([
    inner_paper(),
    kick("Same 100 a month", t=0.05, a="fade"),
    el(f'Start at birth:<br>{mk("over 3x more.", seed=5, t=0.9, d=0.6)}', X, 460, W, a="up", t=0.1, d=0.55,
       cls="H", style="font-size:112px"),
    el('<div class="card cmp">'
       '<div class="cr"><div class="top"><span class="lb">Start at birth</span><span class="v">38,700</span></div>'
       '<div class="tr" data-a="bar" data-t="0.75" data-d="1.0" data-w="100"><div class="fill"></div></div>'
       '<div class="pd">21,600 paid in</div></div>'
       '<div class="cr b"><div class="top"><span class="lb">Start at 10</span><span class="v">12,300</span></div>'
       '<div class="tr" data-a="bar" data-t="1.05" data-d="0.8" data-w="31.7"><div class="fill"></div></div>'
       '<div class="pd">9,600 paid in</div></div>'
       '<div class="cfoot">Value at 18 · example at 6% a year<br>Any currency. Same math.</div>'
       '</div>', X, 760, W, a="up", t=0.45, d=0.55),
    cap("Same 100 a month. Start at birth: about 38,700 at 18. Start at 10: about 12,300."),
]), tin="wipe", td=0.5, bg=BG)

# 3 · THE MOVE (7.5–11.0): carousel slide-2 step cards.
v.scene(7.5, 11.0, "".join([
    inner_paper(),
    kick("Your move · 10 minutes", t=0.05, a="fade"),
    el(f'Do it in<br>{mk("2 steps.", seed=7, t=0.8, d=0.5)}', X, 460, W, a="up", t=0.1, d=0.55, cls="H",
       style="font-size:120px"),
    el('<div class="stack">'
       '<div class="card step" data-a="up" data-t="0.5" data-d="0.55"><span class="badge">1</span><div>'
       '<div class="tt">Open a child or long&#8209;term investment account</div><div class="sb">Where you live.</div></div></div>'
       '<div class="card step" data-a="up" data-t="0.9" data-d="0.55"><span class="badge">2</span><div>'
       '<div class="tt">Automate 100 a month</div><div class="sb">Or whatever you can.</div></div></div>'
       '</div>', X, 770, W, a="none"),
    cap("Open a child or long-term investment account where you live. Automate 100 a month, or whatever you can."),
]), tin="wipe", td=0.5, bg=BG)

# 4 · THE CATCH (11.0–14.0): carousel catch-slide list.
v.scene(11.0, 14.0, "".join([
    inner_paper(),
    kick("The catch", t=0.05, a="fade"),
    el(f'Example only.<br>{mk("Not a promise.", seed=9, t=0.8, d=0.5)}', X, 460, W, a="up", t=0.1, d=0.55, cls="H",
       style="font-size:112px"),
    el('<div class="card" style="padding:8px 44px">'
       f'<div class="ck" data-a="up" data-t="0.55" data-d="0.5">{ARROW}<span>Returns aren\'t guaranteed</span></div>'
       f'<div class="ck" data-a="up" data-t="0.85" data-d="0.5">{ARROW}<span>Before fees, tax and inflation</span></div>'
       '</div>', X, 770, W, a="up", t=0.4, d=0.55),
    cap("Example only. Returns aren't guaranteed, and it's before fees, tax and inflation."),
]), tin="wipe", td=0.5, bg=BG)

# 5 · CTA (14.0–17.0): the FF cobalt CTA look. "Know a new parent?" loops into "100 a month from birth".
v.scene(14.0, 17.0, "".join([
    cobalt_paper(),
    el(f'Know a<br>{mk("new parent?", seed=11, t=0.3, d=0.5, dark=True)}', X, 440, 700, a="up", t=0.1, d=0.55,
       cls="H", style="font-size:120px"),
    el(f'<img src="{(MARKS / "fullyfunded.png").as_uri()}" style="width:170px;height:170px">', 814, 430, a="fade",
       t=0.4, d=0.6),
    el(f'<div class="ctac"><div class="ib">{SEND}</div><div class="tx"><b>Send this</b> to a new parent.</div></div>',
       X, 760, W, a="up", t=0.45, d=0.55),
    el('Follow @fullyfundedhq', X, 1310, W, a="fade", t=0.9, d=0.6, cls="H",
       style="font-size:64px;color:#fff;letter-spacing:-.025em"),
    cap("Send this to a new parent."),
]), tin="circle", td=0.6, bg=CO, origin="50% 50%", cls="dark")

SLUG = "fullyfunded-reel-start-at-birth"
V = Path("/home/claude/content/video")

if __name__ == "__main__":
    from vlab import render, contact_sheet, preview
    import subprocess
    import music2
    out, qa = V / "out", V / "qa"
    if "--preview" in sys.argv:
        preview(v, [0.0, 3.4, 5.6, 7.4, 9.9, 10.9, 12.9, 13.9, 14.3, 16.9], qa / f"{SLUG}-preview.png")
        sys.exit()
    silent = out / f"{SLUG}-silent.mp4"
    render(v, silent)
    contact_sheet(silent, qa / f"{SLUG}-sheet.png")
    dur = v.duration
    cuts = sorted({sc["s"] for sc in v.scenes if sc["s"] > 0})
    bed = V / f"audio/{SLUG}-bed.wav"
    music2.write(bed, music2.render("fullyfunded", "warm", dur + 0.3, cuts))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(bed), "-filter_complex",
                    "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]", "-map", "0:v", "-map", "[a]",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", str(dur), "-movflags", "+faststart",
                    str(out / f"{SLUG}.mp4")], check=True)
    print("done", dur, "s, cuts", cuts)
