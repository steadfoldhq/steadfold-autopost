#!/usr/bin/env python3
"""Littlefold Reel: "faceless silhouette story" (Oct 16 2026). An original, code-drawn dusk scene: a parent and a
toddler, seen from behind as silhouettes, walk hand in hand on a path towards a low sun. Short "letters to my
baby" lines fade in one at a time in the upper third. Quiet original music, no drums, no impacts.

Everything is drawn here in code (vector shapes -> masks): no photos, no real people, no faces.

Engine: slowpan.py (static text layer, sub-pixel background warps, grain + vignette in screen space). This file
adds three things on top, all periodic over the clip so the Reel loops exactly (frame N == frame 0):
  * a camera move that goes out and back (p = sin^2), instead of the engine's one-way ease,
  * a soft walking bob per figure (whole cycles over the clip),
  * fireflies drawn per frame (twinkle + wander, whole cycles over the clip).
Text: one PNG per line, overlaid by ffmpeg with alpha fades only (no transform, pixel-still).

    python3 lf_silhouette_letters.py          # Reel + cover + QA (contact sheet, ffprobe, loudness, jitter)
    python3 lf_silhouette_letters.py still    # quick background stills only (qa/lf-silhouette-stills.png)

Outputs  /home/claude/content/video/out/littlefold-silhouette-not-perfect.mp4 (+ -cover.jpg)
QA       /home/claude/content/video/qa/lf-silhouette-*.png, lf-silhouette-qa.json
"""
from __future__ import annotations

import json
import math
import multiprocessing as mp
import os
import re
import subprocess
import sys
import time
from pathlib import Path

import cv2
import numpy as np

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import slowpan as SP  # noqa: E402
import slowpan_bg as B  # noqa: E402
from slowpan import Scene, Move, FPS, REEL, BUILD, V  # noqa: E402
from slowpan_bg import Layer, hexrgb, smoothstep, fbm  # noqa: E402

OUT, QA = V / "out", V / "qa"
STEM = "littlefold-silhouette-not-perfect"
MARK = Path("/home/claude/content/design/assets/marks/littlefold.png")
OW, OH = REEL
T = 20.0                       # clip length (s): 6 bars at 72 BPM, so the music loops on the bar too
NF = int(round(T * FPS))

# ----------------------------------------------------------------------------- composition (output px)
HORIZON = 1334                 # low camera (toddler eye level): heads + joined hands sit against the glow
FEET = 1482                    # ground line under both figures
ADULT_X, CHILD_X = 452, 667    # feet centres
SUN = (572, 1340)              # half-set sun, right behind the joined hands
DUSK = [(0, "#1B1230"), (300, "#22153A"), (600, "#341A44"), (840, "#50214E"), (1000, "#7A2C5B"),
        (1120, "#A8405F"), (1210, "#D46A7C"), (1270, "#EE9285"), (1312, "#F9B27E"), (HORIZON, "#FFC783"),
        (1500, "#FFD49A")]     # deep plum -> Littlefold berry -> blush -> amber
SIL = "#150B17"                # silhouette ink (warm near-black plum)
CREAM = "#FFF1DE"

# ----------------------------------------------------------------------------- the words
# Drafts considered (parent -> child, written for parents; hopeful, never sad, guilt or bait):
#  A  I used to wonder if I'd be enough. / Then you held my finger. / You don't need perfect. / You need me, here.
#  B  Before you came, I worried I wouldn't know how. / Then you reached for my hand. / You never asked for perfect.
#  C  I worried I'd get it all wrong. / You didn't seem to mind. / You don't need perfect. / Just someone to walk with.
# Picked: the A arc (a worry that's resolved) + the walking picture ("your hand found mine", "one small step").
LINES = [
    "I used to wonder<br>if I’d be enough.",
    "Then your hand<br>found mine.",
    "You don’t need<br>perfect.",
    "Just me,<br>right here.",
    "One small step<br>at a time.",
]
HOLDS = [2.3, 2.0, 2.2, 2.0, 2.1, 2.35]    # full-opacity hold per item (s); the 6th is the end card
FADE_IN, FADE_OUT, GAP, LEAD = 0.5, 0.5, 0.12, 0.2


def timeline():
    """[(fade-in start, fade-in end, fade-out start, fade-out end)] per text item."""
    out, t = [], LEAD
    for h in HOLDS:
        out.append((t, t + FADE_IN, t + FADE_IN + h, t + FADE_IN + h + FADE_OUT))
        t += FADE_IN + h + FADE_OUT + GAP
    assert out[-1][3] <= T - 0.2, f"text runs to {out[-1][3]:.2f}s, clip is {T}s"
    assert all(b - a >= 2.0 - 1e-9 for _, a, b, _ in out), "every line must hold >= 2 s"
    return out


TEXT_CSS = f"""
.box{{position:absolute;left:100px;width:880px;top:380px;height:520px;display:flex;flex-direction:column;
 align-items:center;justify-content:center;text-align:center}}
.ln{{font:italic 500 74px/1.24 Lora;color:{CREAM};letter-spacing:-.004em;text-wrap:balance;
 text-shadow:0 2px 30px rgba(20,8,26,.55),0 0 3px rgba(20,8,26,.28)}}
.mk{{width:96px;height:96px;border-radius:50%;background:#FFD6E3;display:grid;place-items:center;margin-bottom:30px;
 box-shadow:0 8px 30px rgba(20,8,26,.45)}}
.mk img{{width:76px;height:76px}}
.brand{{font:500 76px/1.1 Lora;color:{CREAM};letter-spacing:-.01em;text-shadow:0 2px 30px rgba(20,8,26,.55)}}
.tag{{font:italic 500 50px/1.3 Lora;color:#FFE3EC;margin-top:18px;text-wrap:balance;
 text-shadow:0 2px 26px rgba(20,8,26,.6)}}
"""


def text_html():
    items = [f'<div class="box"><div class="ln">{s}</div></div>' for s in LINES]
    items.append(f'<div class="box"><div class="mk"><img src="{MARK.as_uri()}"></div><div class="brand">Littlefold</div>'
                 '<div class="tag">for the parents<br>learning as they go</div></div>')
    return items


# ----------------------------------------------------------------------------- drawing helpers
class Canvas:
    """Maps output px (x, y) to source-canvas px for a canvas of (w, h) at u source px per output px."""

    def __init__(self, w, h, u):
        self.w, self.h, self.u = w, h, u

    def X(self, x):
        return (np.asarray(x, np.float64) - OW / 2) * self.u + self.w / 2

    def Y(self, y):
        return (np.asarray(y, np.float64) - OH / 2) * self.u + self.h / 2

    def yrow(self):
        """Output-y of every canvas row."""
        return ((np.arange(self.h, dtype=np.float32) - self.h / 2) / self.u + OH / 2)[:, None]

    def xcol(self):
        return ((np.arange(self.w, dtype=np.float32) - self.w / 2) / self.u + OW / 2)[None, :]


def ramp_y(cv, stops):
    """Vertical gradient by output-y stops, interpolated in OKLab (slowpan_bg.ramp) -> (h, w, 3)."""
    y = cv.yrow()[:, 0]
    pos = np.array([p for p, _ in stops], np.float32)
    lut = B.ramp([((p - pos[0]) / (pos[-1] - pos[0]), c) for p, c in stops], 2048)
    idx = np.clip((y - pos[0]) / (pos[-1] - pos[0]) * 2047, 0, 2047).astype(np.int32)
    return np.repeat(lut[idx][:, None, :], cv.w, 1).astype(np.float32)


SH = 3                                     # cv2 sub-pixel bits


def _pts(cv, pts):
    p = np.stack([cv.X([q[0] for q in pts]), cv.Y([q[1] for q in pts])], 1)
    return np.round(p * (1 << SH)).astype(np.int32)


def chaikin(pts, it=3, closed=True):
    p = np.asarray(pts, np.float64)
    for _ in range(it):
        q = np.roll(p, -1, 0) if closed else p[1:]
        a = p if closed else p[:-1]
        new = np.empty((len(a) * 2, 2))
        new[0::2] = 0.75 * a + 0.25 * q
        new[1::2] = 0.25 * a + 0.75 * q
        p = new if closed else np.vstack([p[:1], new, p[-1:]])
    return p


def poly(m, cv, pts, smooth=3):
    cv2.fillPoly(m, [_pts(cv, chaikin(pts, smooth) if smooth else pts)], 1.0, cv2.LINE_AA, SH)


def ellipse(m, cv, c, rx, ry, ang=0.0):
    cv2.ellipse(m, (tuple(int(v) for v in _pts(cv, [c])[0])),
                (int(rx * cv.u * (1 << SH)), int(ry * cv.u * (1 << SH))), ang, 0, 360, 1.0, -1, cv2.LINE_AA, SH)


def capsule(m, cv, p0, r0, p1, r1):
    """Tapered limb: circles at both ends + the hull between them."""
    (x0, y0), (x1, y1) = p0, p1
    d = math.hypot(x1 - x0, y1 - y0) + 1e-6
    nx, ny = -(y1 - y0) / d, (x1 - x0) / d
    cv2.fillPoly(m, [_pts(cv, [(x0 + nx * r0, y0 + ny * r0), (x1 + nx * r1, y1 + ny * r1),
                               (x1 - nx * r1, y1 - ny * r1), (x0 - nx * r0, y0 - ny * r0)])], 1.0, cv2.LINE_AA, SH)
    ellipse(m, cv, p0, r0, r0)
    ellipse(m, cv, p1, r1, r1)


def limb(m, cv, joints):
    for (p0, r0), (p1, r1) in zip(joints, joints[1:]):
        capsule(m, cv, p0, r0, p1, r1)


def soften(m, u, merge=2.6, edge=0.85):
    """Round the joins (blur + re-threshold, like metaballs), then a soft optical edge."""
    b = cv2.GaussianBlur(m, (0, 0), merge * u)
    m = np.maximum(m, smoothstep(0.42, 0.58, b))
    return cv2.GaussianBlur(m, (0, 0), edge * u)


# ----------------------------------------------------------------------------- the two figures (seen from behind)
def adult_mask(cv, fx, fy):
    """Adult, 520 px tall, walking away; right arm reaches down-out to the child. Local coords: feet = (0, 0)."""
    m = np.zeros((cv.h, cv.w), np.float32)
    lean = 0.045                                          # upper body leans gently towards the child

    def P(x, y, keep=False):
        return (fx + x + (0 if keep else lean * max(0.0, -244 - y)), fy + y)
    ellipse(m, cv, P(2, -481), 29, 36, 8)                 # head, tilted a touch towards the child
    ellipse(m, cv, P(2, -488), 31, 33, 8)                 # hair (soft, rounded, neutral)
    ellipse(m, cv, P(2, -462), 26, 20, 5)                 # nape
    capsule(m, cv, P(1, -450), 12.5, P(0, -432), 15)      # neck
    poly(m, cv, [P(x, y) for x, y in [(-16, -444), (-36, -437), (-54, -427), (-64, -413), (-68, -394), (-64, -366),
                                      (-56, -330), (-50, -298), (-50, -270), (-54, -246), (-50, -230), (50, -230),
                                      (54, -246), (50, -270), (50, -298), (56, -330), (64, -366), (69, -392),
                                      (64, -413), (54, -427), (36, -437), (16, -444)]])
    limb(m, cv, [(P(-25, -244), 25), (P(-24, -130), 15), (P(-24, -92), 14), (P(-22, -20), 9.5)])  # planted leg
    ellipse(m, cv, P(-22, -9), 11.5, 10)                                                         # heel
    limb(m, cv, [(P(25, -244), 25), (P(30, -134), 15.5), (P(32, -98), 14.5), (P(34, -36), 9.5)])  # push-off leg
    ellipse(m, cv, P(35, -20), 11, 16, -4)                                                       # lifted sole
    limb(m, cv, [(P(-62, -404), 15.5), (P(-73, -306), 11.5), (P(-66, -218), 8.5)])  # free arm, soft elbow
    ellipse(m, cv, P(-64, -202), 9, 15, -8)
    limb(m, cv, [(P(62, -404), 15.5), (P(87, -318), 11.5), (P(112, -240, True), 8.5)])  # arm to the child's hand
    ellipse(m, cv, P(117, -228, True), 11, 13, -30)
    return soften(m, cv.u)


def child_mask(cv, fx, fy):
    """Toddler, 262 px tall (half the adult), big round head, short legs; left arm raised to the adult's hand."""
    m = np.zeros((cv.h, cv.w), np.float32)
    P = lambda x, y: (fx + x, fy + y)  # noqa: E731
    ellipse(m, cv, P(-1, -229), 28, 30, -8)               # head, tipped up towards the adult
    ellipse(m, cv, P(1, -259), 7, 5, -25)                 # little hair tuft
    ellipse(m, cv, P(6, -262), 4.5, 3.5, 20)
    ellipse(m, cv, P(-28, -226), 5, 8)                    # ears
    ellipse(m, cv, P(26, -224), 5, 8)
    capsule(m, cv, P(0, -205), 11, P(0, -192), 13)        # neck
    poly(m, cv, [P(x, y) for x, y in [(-14, -199), (-30, -192), (-38, -181), (-41, -160), (-42, -130), (-40, -110),
                                      (-34, -98), (34, -98), (40, -110), (42, -130), (41, -160), (38, -181),
                                      (30, -192), (14, -199)]])
    ellipse(m, cv, P(0, -100), 36, 19)                    # padded little bottom
    limb(m, cv, [(P(-15, -98), 16), (P(-17, -52), 12.5), (P(-18, -14), 10)])
    ellipse(m, cv, P(-19, -7), 12.5, 9)
    limb(m, cv, [(P(15, -98), 16), (P(18, -54), 12.5), (P(20, -22), 10)])
    ellipse(m, cv, P(21, -12), 11, 12)
    limb(m, cv, [(P(-32, -186), 11.5), (P(-62, -208), 9.5), (P(-88, -224), 7.5)])  # raised arm
    ellipse(m, cv, P(-94, -227), 8.5, 8.5)
    limb(m, cv, [(P(32, -186), 11.5), (P(52, -158), 9.5), (P(66, -132), 7.5)])     # balance arm, out a little
    ellipse(m, cv, P(70, -125), 8, 8.5)
    return soften(m, cv.u)


def figure_layer(cv, mask, name, bob):
    """Silhouette ink with a warm light-wrap on the inner edge, strongest near the sun (backlit)."""
    u = cv.u
    inner = mask - cv2.GaussianBlur(mask, (0, 0), 1.6 * u)
    edge = np.clip(inner * 2.0, 0, 1) * mask
    d = np.hypot(cv.xcol() - SUN[0], (cv.yrow() - SUN[1]) * 1.2)
    prox = np.exp(-(d / 230.0) ** 2)
    img = B.mix(np.ones((cv.h, cv.w, 3), np.float32) * hexrgb(SIL), hexrgb("#E8906E"), edge * prox * 0.55)
    L = Layer(img.astype(np.float32), mask.astype(np.float32), depth=0.9, name=name)
    L.bob = bob
    return L


def shadow(cv, mask, fx, fy, height, length=700, spread=1.5):
    """Long soft shadow cast towards the camera, radiating away from the sun (perspective: wider when nearer),
    blurring and fading with distance from the feet."""
    s = (fx - SUN[0]) / max(1.0, fy - SUN[1])             # direction away from the sun, per px of drop
    half = 140.0
    src = np.float32([[cv.X(fx - half), cv.Y(fy - height)], [cv.X(fx + half), cv.Y(fy - height)],
                      [cv.X(fx + half), cv.Y(fy)], [cv.X(fx - half), cv.Y(fy)]])
    tip = fx + s * length
    dst = np.float32([[cv.X(tip - half * spread), cv.Y(fy + length)], [cv.X(tip + half * spread), cv.Y(fy + length)],
                      [cv.X(fx + half), cv.Y(fy)], [cv.X(fx - half), cv.Y(fy)]])
    M = cv2.getPerspectiveTransform(src, dst)
    sh = cv2.warpPerspective(mask, M, (cv.w, cv.h), flags=cv2.INTER_LINEAR)
    dist = np.clip((cv.yrow() - fy) / length, 0, 1) * np.ones((1, cv.w), np.float32)
    out = np.zeros_like(sh)
    for lo, hi, sig in ((-1, 0.25, 2.5), (0.0, 0.6, 9), (0.35, 1.01, 22)):
        b = cv2.GaussianBlur(sh, (0, 0), sig * cv.u)
        w = smoothstep(lo, lo + 0.2, dist) * (1 - smoothstep(hi - 0.2, hi, dist)) if lo >= 0 else \
            1 - smoothstep(hi - 0.2, hi, dist)
        out = np.maximum(out, b * w)
    contact = np.zeros_like(sh)
    ellipse(contact, cv, (fx, fy - 1), 40 if height > 400 else 30, 7)
    contact = cv2.GaussianBlur(contact, (0, 0), 5 * cv.u)
    return np.clip(np.maximum(out * (0.72 - 0.5 * dist), contact * 0.8), 0, 1)


# ----------------------------------------------------------------------------- scene layers
def ridge(cv, rng, base, amp, cell):
    return base + amp * 2 * B._noise1d(cv.w, cell * cv.u, rng, octaves=4)


def scene_layers(w, h, u, seed=7):
    cv = Canvas(w, h, u)
    rng = np.random.default_rng(seed)
    yy, xx = cv.yrow(), cv.xcol()

    # ---- far: dusk sky, sun, a few stars, lit cloud streaks, two hazy far ridges with distant lights
    sky = ramp_y(cv, DUSK)
    d = np.hypot((xx - SUN[0]) / 1.0, (yy - SUN[1]) * 1.25)
    for sig, col, k in ((520, "#FF9C78", 0.30), (200, "#FFB86E", 0.50), (70, "#FFD9A0", 0.65)):
        g = np.exp(-(d / sig) ** 2)[..., None] * k
        sky = 1 - (1 - sky) * (1 - hexrgb(col) * g)
    disc = smoothstep(52, 44, d)[..., None]
    sky = B.mix(sky, hexrgb("#FFF2D6"), disc[..., 0] * 0.95)
    # cloud streaks: thin, long, lit from below in blush/amber, kept well under the text zone
    N = fbm(h, w, 90 * u, rng, octaves=5, aniso=9.0, gain=0.5)
    band = smoothstep(1035, 1110, yy) * (1 - smoothstep(1200, 1290, yy))
    dens = smoothstep(0.52, 0.70, N) * band
    lit = B.mix(hexrgb("#7E3560"), hexrgb("#FFB48A"), np.clip(smoothstep(1060, 1290, yy) * 1.0, 0, 1)
                * np.ones((1, w), np.float32))
    sky = B.mix(sky, lit, dens * 0.55)
    stars = np.zeros((h, w), np.float32)
    for _ in range(46):
        sx, sy = rng.uniform(0, OW), rng.uniform(40, 760)
        ellipse(stars, cv, (sx, sy), rng.uniform(0.7, 1.4), rng.uniform(0.7, 1.4))
    stars = cv2.GaussianBlur(stars, (0, 0), 0.7 * u) * (1 - smoothstep(500, 820, yy))
    sky = 1 - (1 - sky) * (1 - stars[..., None] * hexrgb("#FFF3E0") * 0.55)
    # far ridges (atmospheric: paler + warmer near the sun)
    warm = np.exp(-((xx - SUN[0]) / 420.0) ** 2)
    for base, amp, cell, col, pale in ((HORIZON - 14, 9, 260, "#8A3F62", 0.55), (HORIZON - 2, 7, 180, "#5A2A4A", 0.35)):
        r = ridge(cv, rng, base, amp, cell)
        a = smoothstep(r[None, :] - 0.8, r[None, :] + 0.8, yy)
        c = B.mix(np.ones((1, w, 3), np.float32) * hexrgb(col), hexrgb("#E39486"), warm * pale)
        sky = B.mix(sky, c, a)
    # distant lights on the far ridge (streetlights far off; never near the text)
    glow = np.zeros((h, w, 3), np.float32)
    for lx, ly, r, k in ((352, 1323, 1.8, 0.8), (402, 1327, 1.5, 0.6), (318, 1326, 1.4, 0.5), (742, 1324, 1.7, 0.8),
                         (790, 1321, 1.5, 0.6)):
        m = np.zeros((h, w), np.float32)
        ellipse(m, cv, (lx, ly), r, r)
        glow += (cv2.GaussianBlur(m, (0, 0), 1.0 * u) * k + cv2.GaussianBlur(m, (0, 0), 9 * u) * 6 * k)[..., None] \
            * hexrgb("#FFC978")
    sky = 1 - (1 - sky) * (1 - np.clip(glow, 0, 1))
    far = Layer(np.clip(sky, 0, 1).astype(np.float32), depth=0.2, name="far")

    # ---- mid: soft rounded tree clumps framing the left and right edges, low hedge at the horizon
    mm = np.zeros((h, w), np.float32)
    for side in (-1, 1):
        x0 = 0 if side < 0 else OW
        clumps = ([(60, 175, 95), (190, 120, 70), (290, 60, 46), (-10, 230, 110)] if side < 0 else
                  [(40, 205, 105), (165, 105, 62), (262, 70, 40), (110, 150, 70)])
        for dx, ht, rad in clumps:
            cx = x0 - side * (dx + rng.uniform(-12, 12))
            cy = HORIZON - ht * rng.uniform(0.9, 1.1)
            for _ in range(int(rad * 1.6)):              # leafy edge: many small discs in the envelope
                a_, rr_ = rng.uniform(0, 2 * np.pi), rad * np.sqrt(rng.uniform(0.0, 1.0))
                ex, ey = cx + rr_ * np.cos(a_) * 1.15, cy + rr_ * np.sin(a_) * 0.95
                ellipse(mm, cv, (ex, ey), rng.uniform(7, 16), rng.uniform(6, 14))
            ellipse(mm, cv, (cx, cy + rad * 0.15), rad * 0.95, rad * 0.8)
            poly(mm, cv, [(cx - 5, cy + rad * 0.5), (cx - 4, HORIZON + 30), (cx + 4, HORIZON + 30),
                          (cx + 5, cy + rad * 0.5)], smooth=0)                     # trunk
        poly(mm, cv, [(x0 + side * 30, HORIZON + 30), (x0 + side * 30, HORIZON - 34), (x0 - side * 150, HORIZON - 16),
                      (x0 - side * 360, HORIZON - 1), (x0 - side * 360, HORIZON + 30)], smooth=3)
    hedge = ridge(cv, rng, HORIZON + 3, 4, 70)
    mm = np.maximum(mm, smoothstep(hedge[None, :] - 0.8, hedge[None, :] + 0.8, yy) * (1 - smoothstep(HORIZON + 30,
                                                                                               HORIZON + 40, yy)))
    mm = cv2.GaussianBlur(np.clip(mm, 0, 1), (0, 0), 1.3 * u)
    leaf = fbm(h, w, 10 * u, rng, octaves=3) - 0.5
    rimt = np.clip(mm - cv2.GaussianBlur(mm, (0, 0), 3 * u), 0, 1) * 2.5
    mid_img = np.ones((h, w, 3), np.float32) * hexrgb("#24122A") * (1 + leaf[..., None] * 0.25)
    mid_img = B.mix(mid_img, hexrgb("#8A4458"), np.clip(rimt * warm * 0.6 + warm * 0.12, 0, 1))
    mid = Layer(mid_img.astype(np.float32), mm.astype(np.float32), depth=0.55, name="mid")

    # ---- ground: meadow + path (lit by the glow), grass blades, long shadows; same depth as the figures
    gnd = ramp_y(cv, [(HORIZON, "#6A3350"), (1400, "#43233D"), (FEET, "#2E1A2E"), (1700, "#201222"),
                      (1920, "#140B16"), (2200, "#100810")])
    tex = (fbm(h, w, 40 * u, rng, octaves=4, aniso=0.25) - 0.5) * 0.10 + (fbm(h, w, 160 * u, rng, octaves=3) - 0.5) * 0.08
    gnd = gnd * (1 + tex)[..., None]
    # path: perspective wedge from the sun's foot towards the camera, gentle S-bend, soft noisy edges
    depthf = np.clip((yy - HORIZON) / (OH - HORIZON), 0, 2)
    pc = SUN[0] + (560 - SUN[0]) * depthf + 26 * np.sin(depthf * 3.1)
    pw = 12 + 520 * depthf
    edge_n = (fbm(h, w, 18 * u, rng, octaves=3) - 0.5) * (6 + 40 * depthf)
    pm = smoothstep(pw + 6 + 10 * depthf, pw - 6 - 10 * depthf, np.abs(xx - pc) + edge_n) * smoothstep(HORIZON + 1,
                                                                                                      HORIZON + 6, yy)
    pcol = ramp_y(cv, [(HORIZON, "#E9A08A"), (1380, "#B8687A"), (FEET, "#7A4058"), (1700, "#4A2838"),
                       (2100, "#2A1622")])
    pcol = pcol * (1 + (fbm(h, w, 8 * u, rng, octaves=3, aniso=2.0) - 0.5)[..., None] * 0.10)
    gnd = B.mix(gnd, pcol, pm * 0.92)
    gnd = 1 - (1 - gnd) * (1 - hexrgb("#FF9E70") * (np.exp(-(np.hypot(xx - SUN[0], (yy - HORIZON) * 3.0) / 260) ** 2)
                                                  * 0.35)[..., None])
    # shadows (from both figures) on the ground
    am = adult_mask(cv, ADULT_X, FEET)
    cm = child_mask(cv, CHILD_X, FEET + 3)
    shd = np.maximum(shadow(cv, am, ADULT_X, FEET, 520), shadow(cv, cm, CHILD_X, FEET + 3, 262, length=560))
    gnd = B.mix(gnd, hexrgb("#120914"), shd * 0.85)
    # grass blades: along the horizon edge and the path edges, bigger when nearer
    gm = np.zeros((h, w), np.float32)
    for _ in range(2000):
        y0 = HORIZON + 2 + (OH + 60 - HORIZON) * rng.random() ** 2.2
        df = (y0 - HORIZON) / (OH - HORIZON)
        cx_ = SUN[0] + (560 - SUN[0]) * df + 26 * math.sin(df * 3.1)
        half = 12 + 520 * df
        x0 = rng.uniform(-40, OW + 40)
        if abs(x0 - cx_) < half * 0.85:
            continue                                   # keep the path itself clear
        if abs(x0 - ADULT_X) < 80 and abs(y0 - FEET) < 20 or abs(x0 - CHILD_X) < 50 and abs(y0 - FEET) < 20:
            continue
        hgt = (4 + 70 * df ** 1.15) * rng.uniform(0.5, 1.3)
        lean = rng.normal(0, 0.35) * hgt
        wid = max(0.9, 0.035 * hgt)
        poly(gm, cv, [(x0 - wid, y0), (x0 + lean * 0.5, y0 - hgt * 0.55), (x0 + lean, y0 - hgt),
                      (x0 + lean * 0.5 + wid * 0.4, y0 - hgt * 0.5), (x0 + wid, y0)], smooth=2)
    gm = cv2.GaussianBlur(gm, (0, 0), 0.6 * u)
    gnd = B.mix(gnd, hexrgb("#170C19"), np.clip(gm, 0, 1) * 0.92)
    ga = smoothstep(HORIZON + 0.5, HORIZON + 3, yy) * np.ones((1, w), np.float32)
    ground = Layer(np.clip(gnd, 0, 1).astype(np.float32), ga.astype(np.float32), depth=0.9, name="ground")

    # ---- figures (separate layers so each gets its own soft walking bob)
    nb = lambda f: max(1, round(f * T))  # noqa: E731  whole bob cycles over the clip
    adult = figure_layer(cv, am, "adult", (1.7, nb(0.75), 0.0))
    child = figure_layer(cv, cm, "child", (1.3, nb(1.0), 1.9))

    # ---- foreground: out-of-focus grass in the bottom corners (under the app's caption area)
    fm = np.zeros((h, w), np.float32)
    for _ in range(140):
        side = rng.choice([-1, 1])
        x0 = (rng.uniform(-40, 300) if side < 0 else rng.uniform(780, 1120))
        y0 = OH + 80
        hgt = rng.uniform(140, 380) * (1.0 - 0.5 * (min(abs(x0 - 540), 540) < 300))
        lean = rng.normal(0, 0.25) * hgt + side * 20
        wid = rng.uniform(4, 9)
        poly(fm, cv, [(x0 - wid, y0), (x0 + lean * 0.45, y0 - hgt * 0.55), (x0 + lean, y0 - hgt),
                      (x0 + lean * 0.45 + wid * 0.5, y0 - hgt * 0.5), (x0 + wid, y0)], smooth=2)
    fm = cv2.GaussianBlur(fm, (0, 0), 5.5 * u) * 0.95
    fg = Layer(np.ones((h, w, 3), np.float32) * hexrgb("#0E0711"), fm.astype(np.float32), depth=1.25, name="fg")
    return [far, mid, ground, adult, child, fg]


# ----------------------------------------------------------------------------- periodic background renderer
FIREFLIES = None


def make_fireflies(seed=21, n=24):
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(n):
        y = rng.uniform(1180, 1760)
        x = rng.uniform(30, 1050)
        if 380 < x < 760 and 900 < y < 1500:          # keep them off the figures
            x = rng.choice([rng.uniform(30, 360), rng.uniform(780, 1050)])
        near = (y - 1180) / 580
        out.append(dict(x=x, y=y, r=1.2 + 2.2 * near * rng.uniform(0.6, 1.2), g=4 + 8 * near,
                        k=int(rng.integers(2, 6)), ph=rng.uniform(0, 2 * np.pi),
                        ax=rng.uniform(6, 18), mx=int(rng.integers(1, 3)), px=rng.uniform(0, 2 * np.pi),
                        ay=rng.uniform(4, 12), my=int(rng.integers(1, 4)), py=rng.uniform(0, 2 * np.pi),
                        col=hexrgb(rng.choice(["#FFE7A3", "#FFD27A", "#FFF0C2"]))))
    return out


class LoopBG(SP.BG):
    """slowpan BG with a periodic camera (out and back), per-layer walking bob, and fireflies."""

    def matrix(self, t, depth, drift):
        sc, mv = self.sc, self.sc.move
        p = 0.5 - 0.5 * math.cos(2 * math.pi * t / T)
        z, ox, oy = mv.at(p, depth)
        ox, oy = ox * self.ow, oy * self.ow
        dw, dh = self.ow * self.ss, self.oh * self.ss
        fx, fy = mv.focus[0] * (dw - 1), mv.focus[1] * (dh - 1)
        csx, csy, cdx, cdy = (self.sw - 1) / 2, (self.sh - 1) / 2, (dw - 1) / 2, (dh - 1) / 2
        a = 1.0 / z
        return np.array([[a, 0, csx + (fx - cdx) + ox * self.ss - fx * a],
                         [0, a, csy + (fy - cdy) + oy * self.ss - fy * a]], np.float64)

    def raw(self, i):
        t = i / FPS
        dw, dh = self.ow * self.ss, self.oh * self.ss
        out = np.zeros((self.oh, self.ow, 3), np.float32)
        for rgba, L in self.packed:
            M = self.matrix(t, L.depth, L.drift)
            bob = getattr(L, "bob", None)
            if bob:
                amp, cyc, ph = bob
                dy = amp * math.sin(2 * math.pi * cyc * t / T + ph)         # output px, + = down
                M[1, 2] -= M[1, 1] * dy * self.ss
            w = cv2.warpAffine(rgba, M, (dw, dh), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP,
                               borderMode=cv2.BORDER_REFLECT101)
            w = cv2.resize(w, (self.ow, self.oh), interpolation=cv2.INTER_AREA).astype(np.float32) * (1 / 65535)
            c, a = np.clip(w[..., :3], 0, 1), np.clip(w[..., 3:], 0, 1)
            out = c + out * (1 - a)
        return self._fireflies(out, t)

    def _fireflies(self, f, t):
        M = self.matrix(t, 0.9, (0, 0))
        a, bx, by = M[0, 0], M[0, 2], M[1, 2]
        light = np.zeros_like(f)
        for q in FIREFLIES:
            sx = self.sw / 2 + (q["x"] + q["ax"] * math.sin(2 * math.pi * q["mx"] * t / T + q["px"]) - OW / 2) * self.ss
            sy = self.sh / 2 + (q["y"] + q["ay"] * math.sin(2 * math.pi * q["my"] * t / T + q["py"]) - OH / 2) * self.ss
            x = ((sx - bx) / a - (self.ss - 1) / 2) / self.ss            # canvas -> output px (sub-pixel)
            y = ((sy - by) / a - (self.ss - 1) / 2) / self.ss
            br = (0.5 + 0.5 * math.sin(2 * math.pi * q["k"] * t / T + q["ph"])) ** 2 * 0.85 + 0.15
            R = int(q["g"] * 3) + 2
            x0, y0 = int(x) - R, int(y) - R
            if x0 < 0 or y0 < 0 or x0 + 2 * R >= self.ow or y0 + 2 * R >= self.oh:
                continue
            gy, gx = np.mgrid[y0:y0 + 2 * R + 1, x0:x0 + 2 * R + 1].astype(np.float32)
            d2 = (gx - x) ** 2 + (gy - y) ** 2
            v = (np.exp(-d2 / (2 * q["r"] ** 2)) * 0.9 + np.exp(-d2 / (2 * q["g"] ** 2)) * 0.22) * br
            light[y0:y0 + 2 * R + 1, x0:x0 + 2 * R + 1] += v[..., None] * q["col"]
        return 1 - (1 - f) * (1 - np.clip(light, 0, 1))


SCENE = Scene(bg=scene_layers, text="", dur=T, move=Move(pan=0.022, push=0.028, focus=(0.53, 0.70)),
              grain=0.018, vignette=0.24, seed=16)
_W: dict = {}


def _work(i):
    return _W["bg"].frame(i, NF).tobytes()


def bg_frames(idx, procs=None):
    global FIREFLIES
    FIREFLIES = make_fireflies()
    t0 = time.time()
    bg = LoopBG(SCENE, REEL)
    print(f"  bg ready ({time.time() - t0:.0f}s, {len(bg.layers)} layers, source {bg.sw}x{bg.sh})", flush=True)
    _W["bg"] = bg
    procs = procs or max(1, os.cpu_count() or 1)
    with mp.get_context("fork").Pool(procs) as pool:
        yield from pool.imap(_work, idx, chunksize=2)


# ----------------------------------------------------------------------------- music: "tender" (gentler than warm)
def music_tender(seconds=T, seed=0):
    """music2's own instruments, slower and softer: 72 BPM, F major, I-V-vi-IV-I-V (6 bars = 20 s, so bar 6's C
    resolves into bar 1's F on every loop). Rolled e-piano, low pad, soft sine-ish bass, a music-box chime melody
    from beat 1 (the hook). NO drums, NO impact, NO riser, NO whooshes. The reverb tail past the end is wrapped
    onto the start, so the audio loops seamlessly too."""
    import music2 as M2
    M2.R = M2.rng(300 + seed)
    SR = M2.SR
    beat = 60 / 72
    bar = 4 * beat
    tail = 3.0
    n = int((seconds + tail) * SR)
    mus = np.zeros(n)
    root = M2.midi("F", 3)
    prog = [0, 4, 5, 3, 0, 4]
    mel = [  # (scale degree from F4, start beat, beats) per bar
        [(2, 0, 1.5), (4, 1.5, 0.5), (5, 2, 2)], [(4, 0, 1.5), (2, 1.5, 0.5), (1, 2, 2)],
        [(2, 0, 1.5), (4, 1.5, 0.5), (5, 2, 2)], [(3, 0, 1.5), (2, 1.5, 0.5), (1, 2, 2)],
        [(2, 0, 1.5), (4, 1.5, 0.5), (7, 2, 2)], [(6, 0, 1.5), (4, 1.5, 0.5), (1, 2, 2)]]
    nbars = int(round(seconds / bar))
    for b in range(nbars):
        t0 = b * bar
        deg = prog[b % len(prog)]
        ch = M2.triad(root, "major", deg)
        M2.put(mus, M2.pad([f * 2 for f in ch[:3]], bar + 0.6, 0.075, 1100, 0.9), t0)
        for k, f in enumerate(ch):                                   # rolled chord, beat 1
            M2.put(mus, M2.keys([f * 2], beat * 3.2, 0.15), t0 + 0.045 * k)
        for k, f in enumerate(ch[1:3]):                              # soft answer, beat 3
            M2.put(mus, M2.keys([f * 2], beat * 1.8, 0.07), t0 + 2 * beat + 0.05 * k)
        bf = M2.mhz(M2.scale_m(root - 12, "major", deg))
        M2.put(mus, M2.lp(M2.bass(bf, bar * 0.98, 0.17, drive=0.35), 400), t0)
        for dg, s, l in mel[b % len(mel)]:
            f = M2.mhz(M2.scale_m(root + 12, "major", dg))
            M2.put(mus, M2.chime(f * 2, l * beat + 1.2, 0.13), t0 + s * beat)
    mus = M2.verb(M2.hp(mus, 40), 2.6, 0.34, seed=5)
    mus = M2.lp(mus, 6500)
    loop = mus[:int(seconds * SR)].copy()
    t_len = len(mus) - len(loop)
    loop[:t_len] += mus[len(loop):]                                  # wrap the tail onto the start
    loop = np.tanh(loop / np.max(np.abs(loop)) * 1.3)                # gentle soft-saturation, lowers the crest
    loop /= np.max(np.abs(loop)) / 0.9
    d = int(0.011 * SR)
    right = np.concatenate([loop[-d:], loop[:-d]]) * 0.9 + loop * 0.1   # circular, so the loop stays seamless
    return np.stack([loop, right], 1)


# ----------------------------------------------------------------------------- render
def loudnorm_args(wav, lufs=-14.0, tp=-1.5):
    p = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(wav), "-af",
                        f"loudnorm=I={lufs}:TP={tp}:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = json.loads(re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", p.stderr, re.S).group(0))
    return (f"loudnorm=I={lufs}:TP={tp}:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
            f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:"
            f"linear=true")


def render(out_mp4, crf=21, maxrate="6M"):
    import music2 as M2
    BUILD.mkdir(parents=True, exist_ok=True)
    tl = timeline()
    texts = []
    for k, html in enumerate(text_html()):
        png = BUILD / f"{STEM}-text{k + 1}.png"
        texts.append(dict(png=png, alpha=SP.text_png(html, TEXT_CSS, REEL, png)))
    wav = BUILD / f"{STEM}-music.wav"
    M2.write(wav, music_tender())
    ln = loudnorm_args(wav)

    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OW}x{OH}",
           "-framerate", str(FPS), "-i", "-"]
    for tx in texts:
        cmd += ["-loop", "1", "-framerate", str(FPS), "-t", f"{T:.3f}", "-i", str(tx["png"])]
    cmd += ["-i", str(wav)]
    fl, last, windows, q = [], "0:v", [], []
    for k, (a0, a1, b0, b1) in enumerate(tl):
        fl.append(f"[{k + 1}:v]format=rgba,fade=t=in:st={a0:.4f}:d={FADE_IN:.4f}:alpha=1,"
                  f"fade=t=out:st={b0:.4f}:d={FADE_OUT:.4f}:alpha=1[t{k}]")
        fl.append(f"[{last}][t{k}]overlay=0:0:format=gbrp:eof_action=pass[o{k}]")
        last = f"o{k}"
        f_in, f_out = int(math.ceil(a1 * FPS)), int(math.floor(b0 * FPS))
        mid = (f_in + f_out) // 2
        wdw = dict(scene=k, frames=(f_in, f_out), lossless_frames=(mid - 12, mid + 12),
                   lossless=BUILD / f"{STEM}-qa{k + 1}.mkv")
        windows.append(wdw)
        q.append(wdw)
    fl.append(f"[{last}]split={1 + len(q)}[vf]" + "".join(f"[q{k}]" for k in range(len(q))))
    fl.append("[vf]scale=out_color_matrix=bt709:out_range=tv:flags=accurate_rnd+full_chroma_int,format=yuv420p[v]")
    for k, w in enumerate(q):
        a, b = w["lossless_frames"]
        fl.append(f"[q{k}]trim=start_frame={a}:end_frame={b},setpts=PTS-STARTPTS[Q{k}]")
    ai = len(texts) + 1
    fl.append(f"[{ai}:a]{ln},aresample=48000,afade=t=in:st=0:d=0.03,afade=t=out:st={T - 0.03:.3f}:d=0.03[a]")
    cmd += ["-filter_complex", ";".join(fl), "-map", "[v]", "-map", "[a]", "-frames:v", str(NF),
            "-c:v", "libx264", "-preset", "slow", "-crf", str(crf), "-maxrate", maxrate, "-bufsize", "12M",
            "-tune", "grain", "-x264-params", "keyint=600:min-keyint=600:scenecut=0:ipratio=1.0:pbratio=1.0:qcomp=0.8",
            "-profile:v", "high", "-pix_fmt", "yuv420p",
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
            "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2", "-t", f"{T:.3f}",
            "-movflags", "+faststart", str(out_mp4)]
    for k, w in enumerate(q):
        cmd += ["-map", f"[Q{k}]", "-c:v", "ffv1", "-level", "3", str(w["lossless"])]
    t0 = time.time()
    ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for k, fb in enumerate(bg_frames(range(NF))):
        ff.stdin.write(fb)
        if k % 60 == 0:
            print(f"  frame {k}/{NF} ({time.time() - t0:.0f}s)", flush=True)
    ff.stdin.close()
    if ff.wait() != 0:
        raise RuntimeError("ffmpeg failed")
    print(f"[{STEM}] {NF} frames, {Path(out_mp4).stat().st_size / 1e6:.1f} MB in {time.time() - t0:.0f}s")
    return dict(mp4=Path(out_mp4), texts=texts, windows=windows, total=T, size=REEL, timeline=tl)


# ----------------------------------------------------------------------------- cover
COVER_CSS = f"""
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{width:1080px;height:1920px;overflow:hidden}}
body{{background:#1B1230 url('BG') 0 0/1080px 1920px no-repeat}}
.chip{{position:absolute;left:50%;transform:translateX(-50%);top:330px;display:flex;align-items:center;gap:12px;
 background:#FFF8E4;border-radius:999px;padding:6px 26px 6px 6px;font:700 28px/1 Inter;color:#2C2A3A;
 box-shadow:0 10px 30px -10px rgba(10,4,14,.7);white-space:nowrap}}
.chip i{{width:48px;height:48px;border-radius:50%;background:#FFD6E3;display:grid;place-items:center}}
.chip img{{width:38px;height:38px}} .chip span{{opacity:.6;font-weight:600}}
.hook{{position:absolute;left:96px;width:888px;top:470px;text-align:center;font:italic 500 128px/1.08 Lora;
 color:{CREAM};letter-spacing:-.015em;text-shadow:0 4px 40px rgba(16,6,22,.6),0 0 3px rgba(16,6,22,.3)}}
.hook b{{font-weight:600;color:#FFE27E}}
"""
COVER_HTML = ('<div class="chip"><i><img src="MARK"></i>Littlefold <span>· for parents</span></div>'
              '<div class="hook">You don’t need<br><b>perfect.</b></div>')
MEASURE = r"""() => {const out=[];
 const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(tw.nextNode()){const n=tw.currentNode;if(!n.textContent.trim())continue;const rg=document.createRange();
  rg.selectNodeContents(n);for(const r of rg.getClientRects())out.push({t:n.textContent.trim(),x0:r.left,y0:r.top,
  x1:r.right,y1:r.bottom,fs:parseFloat(getComputedStyle(n.parentElement).fontSize)});}
 const c=document.querySelector('.chip').getBoundingClientRect();out.push({t:'chip',x0:c.left,y0:c.top,x1:c.right,y1:c.bottom,fs:0});
 return out;}"""


def cover(out_jpg, bg_frame):
    from playwright.sync_api import sync_playwright
    from PIL import Image
    import io
    bgp = BUILD / f"{STEM}-cover-bg.png"
    Image.fromarray(bg_frame).save(bgp)
    src = BUILD / f"{STEM}-cover.html"
    src.write_text(f"<!doctype html><html><head><meta charset='utf-8'><style>{SP_font()}"
                   f"{COVER_CSS.replace('BG', bgp.as_uri())}</style></head><body>"
                   f"{COVER_HTML.replace('MARK', MARK.as_uri())}</body></html>", encoding="utf-8")
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": OW, "height": OH}, device_scale_factor=1)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(300)
        boxes = pg.evaluate(MEASURE)
        Image.open(io.BytesIO(pg.screenshot(type="png"))).convert("RGB").save(out_jpg, "JPEG", quality=92,
                                                                              optimize=True)
        br.close()
    bad = [b for b in boxes if b["x0"] < 89.5 or b["x1"] > 990.5 or b["y0"] < 299.5 or b["y1"] > 1400.5]
    hook_fs = min(b["fs"] for b in boxes if b["t"] != "chip" and b["fs"] >= 100)
    ext = dict(x0=min(b["x0"] for b in boxes), x1=max(b["x1"] for b in boxes), y0=min(b["y0"] for b in boxes),
               y1=max(b["y1"] for b in boxes))
    return dict(jpg=str(out_jpg), safe_zone_ok=not bad, bad=bad, extent={k: round(v) for k, v in ext.items()},
                hook_font_px=hook_fs)


def SP_font():
    from engine.themes import font_css
    return font_css("littlefold")


def grid_test(cover_jpg, out_png):
    """Cover at 200 px wide (centre 3:4 profile grid + centre 4:5 feed), next to the last 3 Littlefold-page covers
    and today's other covers, so we can see it reads and differs."""
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.truetype("/home/claude/content/design/assets/fonts/Inter-Bold.ttf", 16)
    reels = Path("/home/claude/steadfold-autopost/media/reels")
    others = [reels / f for f in ("lf-reel-1015-safe-sleep-cover.jpg", "ff-reel-1015-start-at-birth-cover.jpg",
                                  "hb-reel-1015-parking-sign-cover.jpg")]
    paths = [Path(cover_jpg)] + [p for p in others if p.exists()]
    rows = []
    for label, ar in (("profile grid: centre 3:4 @200px", 4 / 3), ("feed: centre 4:5 @200px", 5 / 4)):
        ch = round(OW * ar)
        top = (OH - ch) // 2
        th = round(200 * ar)
        row = Image.new("RGB", (len(paths) * 212 + 12, th + 60), "#ffffff")
        d = ImageDraw.Draw(row)
        d.text((12, 8), label + "   (first = new Littlefold cover)", fill="#111", font=font)
        for i, p in enumerate(paths):
            im = Image.open(p).convert("RGB").resize((OW, OH)).crop((0, top, OW, top + ch)).resize((200, th),
                                                                                                 Image.LANCZOS)
            row.paste(im, (12 + i * 212, 32))
            d.text((12 + i * 212, th + 38), p.stem[:26], fill="#555", font=font)
        rows.append(row)
    sheet = Image.new("RGB", (rows[0].width, sum(r.height for r in rows) + 10), "#ffffff")
    y = 0
    for r in rows:
        sheet.paste(r, (0, y))
        y += r.height + 10
    sheet.save(out_png)
    return out_png


# ----------------------------------------------------------------------------- QA
def loudness(mp4):
    p = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(mp4), "-map", "0:a", "-af",
                        "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True)
    s = p.stderr[p.stderr.rfind("Summary:"):]
    I = float(re.search(r"I:\s+(-?[\d.]+) LUFS", s).group(1))
    tp = float(re.search(r"Peak:\s+(-?[\d.]+) dBFS", s).group(1))
    lra = float(re.search(r"LRA:\s+(-?[\d.]+) LU", s).group(1))
    return dict(integrated_lufs=I, true_peak_dbfs=tp, lra_lu=lra)


def loop_check(mp4):
    """Mean |last frame - first frame| (should be grain-level only: the move, bob and fireflies are periodic)."""
    a = SP.still(mp4, 0.0, REEL).astype(np.float32)
    b = SP.still(mp4, T - 1 / FPS - 0.001, REEL).astype(np.float32)
    c = SP.still(mp4, 1 / FPS, REEL).astype(np.float32)
    bl = lambda x: cv2.GaussianBlur(x, (0, 0), 2)  # noqa: E731
    return dict(last_vs_first=float(np.abs(bl(b) - bl(a)).mean()), frame1_vs_frame0=float(np.abs(bl(c) - bl(a)).mean()))


def detail_sheet(res, cover_jpg, out_png):
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.truetype("/home/claude/content/design/assets/fonts/Inter-Bold.ttf", 22)
    tl = res["timeline"]
    times = [(a1 + b0) / 2 for _, a1, b0, _ in tl]
    tw = 340
    th = round(tw * OH / OW)
    ims = [(f"{t:.1f}s", Image.fromarray(SP.still(res["mp4"], t, REEL))) for t in times]
    ims.append(("cover", Image.open(cover_jpg).convert("RGB")))
    sheet = Image.new("RGB", (len(ims) * (tw + 10) + 10, th + 50), "#1d1b22")
    d = ImageDraw.Draw(sheet)
    for k, (lab, im) in enumerate(ims):
        sheet.paste(im.resize((tw, th), Image.LANCZOS), (10 + k * (tw + 10), 40))
        d.text((10 + k * (tw + 10), 8), lab, fill="#fff", font=font)
    sheet.save(out_png)
    return out_png


def stills():
    """Fast look at the background alone (no text, no encode): frames at 0, T/4, T/2."""
    from PIL import Image
    global FIREFLIES
    FIREFLIES = make_fireflies()
    bg = LoopBG(SCENE, REEL)
    ims = [Image.fromarray(bg.frame(int(f * NF), NF)) for f in (0.0, 0.25, 0.5)]
    full = QA / "lf-silhouette-still-full.png"
    ims[0].save(full)
    crop = ims[0].crop((300, 900, 860, 1560))
    crop.save(QA / "lf-silhouette-still-figures.png")
    tw = 360
    sheet = Image.new("RGB", (3 * (tw + 8) + 8, round(tw * 16 / 9) + 16), "#222")
    for k, im in enumerate(ims):
        sheet.paste(im.resize((tw, round(tw * 16 / 9)), Image.LANCZOS), (8 + k * (tw + 8), 8))
    sheet.save(QA / "lf-silhouette-stills.png")
    print(QA / "lf-silhouette-stills.png")


def main():
    from vlab import contact_sheet
    OUT.mkdir(parents=True, exist_ok=True)
    QA.mkdir(parents=True, exist_ok=True)
    mp4 = OUT / f"{STEM}.mp4"
    res = render(mp4)
    jit = SP.jitter_check(res)
    pr = SP.probe(mp4)
    # cover: the scene at frame 0 (same picture people see first), with the hook
    global FIREFLIES
    FIREFLIES = make_fireflies()
    bgf = LoopBG(SCENE, REEL).frame(0, NF)
    cov = cover(OUT / f"{STEM}-cover.jpg", bgf)
    qa = dict(probe=pr, loudness=loudness(mp4), loop=loop_check(mp4), jitter=jit, cover=cov,
              timeline=[[round(x, 2) for x in r] for r in res["timeline"]],
              size_mb=round(mp4.stat().st_size / 1e6, 2))
    (QA / "lf-silhouette-qa.json").write_text(json.dumps(qa, indent=1, default=str))
    contact_sheet(mp4, QA / "lf-silhouette-contact.png", step=1.0, cols=10, tw=180)
    detail_sheet(res, OUT / f"{STEM}-cover.jpg", QA / "lf-silhouette-detail.png")
    grid_test(OUT / f"{STEM}-cover.jpg", QA / "lf-silhouette-grid200.png")
    print(json.dumps({k: v for k, v in qa.items() if k != "probe"}, indent=1, default=str))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "still":
        stills()
    else:
        main()
