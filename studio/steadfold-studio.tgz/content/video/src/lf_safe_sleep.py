#!/usr/bin/env python3
"""Littlefold · 'Alone. Back. Crib.' Reel #1 (from lf-03-safe-sleep-tonight, gate: SHIP). Sherbet theme.
~26.5 s, 1080x1920, 30 fps. Scene cuts synced to the real voiceover (Sarah, 25.3 s, starts at 0.30 s) from measured pauses.

DESIGN RULE (Dharma, Oct 14): the Reel is built from the SAME Sherbet pieces as the posts, so any single frame reads
as Littlefold: butter paper, soft pink + baby-blue circles and small stars, white cards, Lora with the yellow
highlighter under italic words, the yellow arch with the crib, step badges cycling yellow / pink / blue, orange ticks.
No full-screen colour washes. Only the last scene is bubblegum pink, exactly like the carousel's last slide.
Calm-happy motion: soft rises, fades and circle reveals. No shakes, slams or flashes.
Every fact is from the shipped carousel + littlefold/sources.md (PHAC Safe Sleep, Canadian Paediatric Society)."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, "/home/claude/content/design")
from vlab import Video, words, el, caption, CHECK, MARKS  # noqa: E402
from engine.themes import font_css  # noqa: E402
from engine.littlefold import ill_crib, mark_svg  # noqa: E402

BUTTER, WHITE, INK, MUTED = "#FFF8E4", "#FFFFFF", "#2C2A3A", "#6B6676"
PINK, PINK2, PINKSOFT, BUBBLE = "#D9497A", "#F5A3BD", "#FFE1EA", "#E25A86"
YEL, ORANGE, BLUE, BLUESOFT, BUTTER2 = "#FFE27E", "#FFA35C", "#7CC4EE", "#E3F3FD", "#FFF0CF"

THEME = font_css("littlefold") + f"""
:root{{--bg:{BUTTER};--hl:{YEL};--hl-dark:{YEL};--prog-bg:rgba(44,42,58,.10);--prog-fg:{PINK};
 --cap-bg:{WHITE};--cap-ink:{INK};--cap-r:28px;--cap-sh:0 22px 44px -24px rgba(110,52,78,.45);--cap-bd:0;--strike:{PINK}}}
.dark{{--prog-bg:rgba(255,255,255,.3);--prog-fg:{WHITE}}}
.H{{font-family:Lora;font-weight:500;letter-spacing:-.02em;line-height:1.06;color:{INK}}}
.H .w.hl,.H .hlx{{font-style:italic}}
.dark .H{{color:{WHITE}}}
.B{{font-family:Inter;font-weight:500;color:{INK};letter-spacing:-.01em}}
.kick{{font:700 28px/1 Inter;letter-spacing:.18em;text-transform:uppercase;color:#C2386A}}
.card{{background:{WHITE};border-radius:44px;box-shadow:0 46px 90px -56px rgba(110,52,78,.6),0 0 0 2px #F5E6C4}}
.row{{display:flex;align-items:center;gap:28px;padding:30px 40px;border-bottom:2px dashed #F3E3BE;font:500 50px/1.25 Inter;color:{INK}}}
.row:last-child{{border-bottom:0}}
.box{{flex:none;width:62px;height:62px;border-radius:50%;display:grid;place-items:center;font:700 34px/1 Inter}}
.box.not{{background:#FFE4EC;color:{PINK};border:2.5px solid #F2A7BE}}
.box.on{{background:{ORANGE};color:{WHITE}}}
.box.on.p{{background:{PINK2}}} .box.on.b{{background:{BLUE}}}
.badge{{display:grid;place-items:center;width:132px;height:132px;border-radius:50%;font:italic 600 70px/1 Lora;color:{INK}}}
.pill{{display:inline-flex;align-items:center;gap:18px;font:600 40px/1.2 Inter;padding:20px 34px 20px 20px;border-radius:999px;
 background:{WHITE};color:{INK};box-shadow:0 22px 40px -28px rgba(110,52,78,.5),0 0 0 2px #F5E6C4;white-space:nowrap}}
.pill .d{{flex:none;width:54px;height:54px;border-radius:50%;display:grid;place-items:center;background:{ORANGE};color:{WHITE};font-size:30px}}
.arch{{width:560px;height:700px;border-radius:280px 280px 40px 40px;background:{YEL};display:flex;flex-direction:column;
 align-items:center;justify-content:center;gap:12px;box-shadow:inset 0 0 0 12px rgba(255,255,255,.55)}}
.acap{{font:italic 500 44px/1.2 Lora;color:{INK};text-align:center;padding:0 50px}}
.deco{{position:absolute;border-radius:50%}}
.cta{{background:{WHITE};border-radius:44px;padding:54px 56px 60px;box-shadow:0 40px 80px -40px rgba(0,0,0,.45)}}
.cta .ib{{display:grid;place-items:center;width:96px;height:96px;border-radius:50%;background:{YEL};margin-bottom:34px}}
.cta .tx{{font:500 76px/1.12 Lora;color:{INK};letter-spacing:-.015em}}
.cta .tx b{{color:{PINK};font-weight:600;font-style:italic}}
.minarch{{width:250px;height:270px;border-radius:125px 125px 26px 26px;background:{BUTTER};display:flex;align-items:flex-end;
 justify-content:center;padding-bottom:26px}}
.cam{{transform:none!important}}
#tag{{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:{WHITE};
 border-radius:999px;padding:6px 22px 6px 6px;font:600 26px/1 Lora;color:{INK};
 box-shadow:0 12px 26px -16px rgba(110,52,78,.45),0 0 0 2px #F5E6C4}}
#tag img{{width:46px;height:46px;border-radius:50%;background:{BUTTER}}}
#tag span{{color:{MUTED};font:500 24px/1 Inter}}
"""
TAG = f'<div id="tag"><img src="{(MARKS / "littlefold.png").as_uri()}">Littlefold <span>· safe sleep</span></div>'
X = 84
STAR = ("<svg width='{w}' height='{w}' viewBox='0 0 24 24'><path d='M12 1 L14.6 9.4 L23 12 L14.6 14.6 L12 23 "
        "L9.4 14.6 L1 12 L9.4 9.4Z' fill='{c}'/></svg>")
# Same rotation as the carousel's inner slides: (big circle, small circle, star)
SETS = [(PINKSOFT, BLUESOFT, PINK2), (BLUESOFT, BUTTER2, BLUE), (BUTTER2, PINKSOFT, ORANGE)]


def paper(k):
    big, small, star = SETS[k % 3]
    return (el("", 1080 - 600, -340, 860, a="fade", t=0, d=0.5, cls="deco", style=f"height:860px;background:{big}")
            + el("", -230, 1500, 620, a="fade", t=0, d=0.5, cls="deco", style=f"height:620px;background:{small}")
            + el(STAR.format(w=40, c=star), 940, 330, a="pop", t=0.3, d=0.5)
            + el(STAR.format(w=30, c=YEL), 60, 1440, a="pop", t=0.5, d=0.5))


def badge(n, color):
    return el(f'<span class="badge" style="background:{color}">{n}</span>', X, 350, a="pop", t=0.05, d=0.45)


def rows(items, t0, gap=0.28):
    """t0 may be a list of per-row start times (synced to the voice)."""
    """items: (state, text) where state is 'not' or 'on' / 'on p' / 'on b'."""
    out = []
    for i, (st, tx) in enumerate(items):
        mark = "✕" if st == "not" else CHECK
        out.append(f'<div class="row" data-a="up" data-t="{t0[i] if isinstance(t0, list) else t0 + i * gap}" data-d="0.4">'
                   f'<span class="box {st}">{mark}</span><span>{tx}</span></div>')
    return "".join(out)


v = Video("littlefold", "safe-sleep", THEME, TAG)

# 1 · HOOK (0–3.8) "Before you put baby down tonight, three quick checks."   (mirrors the carousel cover)
v.scene(0, 3.55, "".join([
    paper(0),
    el('<span class="kick">Safe sleep · tonight</span>', X, 350, a="none"),
    words("Before you put|baby down:|==3 quick checks==", t=0, st=0.0, d=0.01, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:920px;font-size:112px"),
    el(f'<div class="arch">{ill_crib(380)}<div class="acap">Nothing in here<br>but baby</div></div>', 436, 800, a="up",
       t=0.35, d=0.6),
    el(f'<span class="pill"><span class="d">{CHECK}</span>Alone</span>', X, 980, a="up", t=0.9),
    el(f'<span class="pill"><span class="d" style="background:{PINK2}">{CHECK}</span>On their back</span>', X, 1090,
       a="up", t=1.05),
    el(f'<span class="pill"><span class="d" style="background:{BLUE}">{CHECK}</span>In a crib</span>', X, 1200, a="up",
       t=1.2),
    caption("Before you put baby down tonight, three quick checks.", t=0.3, y=1560),
]), tin="cut", bg=BUTTER)

# 2 · ALONE (3.8–8.4) "Alone. Nothing in the crib but baby. No blankets, pillows or toys."
v.scene(3.55, 9.05, "".join([
    paper(1),
    badge(1, YEL),
    words("==Alone.==", t=0.2, st=0.08, cls="H", style=f"position:absolute;left:{X}px;top:520px;font-size:170px"),
    el('Nothing in the crib but baby.', X, 740, 900, a="up", t=1.05, cls="H", style="font-size:64px"),
    el(f'<div class="card">{rows([("not", "Blankets"), ("not", "Pillows"), ("not", "Toys")], [3.0, 3.55, 4.1])}</div>',
       X, 880, 912, a="up", t=2.8, d=0.45),
    caption("Alone. Nothing in the crib but baby. No blankets, pillows or toys.", t=0.15, y=1560),
]), tin="push", bg=BUTTER)

# 3 · ON THEIR BACK (8.4–11.3) "On their back, for every sleep, naps too."
v.scene(9.05, 12.45, "".join([
    paper(2),
    badge(2, "#FFD6E3"),
    words("On their|==back.==", t=0.2, st=0.1, cls="H", style=f"position:absolute;left:{X}px;top:520px;"
          "width:920px;font-size:160px"),
    el(f'<div class="card">{rows([("on p", "Every sleep"), ("on p", "Naps too")], [1.1, 2.2])}</div>', X, 950, 700,
       a="up", t=0.9, d=0.45),
    caption("On their back, for every sleep, naps too.", t=0.15, y=1560),
]), tin="circle", bg=BUTTER, origin="50% 30%")

# 4 · IN A CRIB (11.3–17.2) "In a crib, cradle or bassinet, in the room where you sleep, for the first six months."
v.scene(12.45, 18.1, "".join([
    paper(0),
    badge(3, "#BFE4FA"),
    words("In a crib, cradle|or ==bassinet.==", t=0.2, st=0.08, cls="H",
          style=f"position:absolute;left:{X}px;top:520px;width:940px;font-size:112px"),
    el('<div class="card" style="padding:44px 48px;display:flex;align-items:center;gap:40px">'
       '<div style="flex:none;width:210px;text-align:center">'
       '<div data-a="count" data-t="3.5" data-d="0.9" data-from="0" data-to="6" data-fmt="{:,.0f}" '
       f'style="font:italic 500 160px/1 Lora;color:{PINK}">6</div>'
       f'<div style="font:700 26px/1 Inter;letter-spacing:.16em;color:{MUTED};margin-top:8px">MONTHS</div></div>'
       f'<div class="B" style="font-size:46px;line-height:1.28">In the room where you sleep, for the first 6 months.</div>'
       '</div>', X, 900, 912, a="up", t=2.0, d=0.5),
    caption("In a crib, cradle or bassinet, in the room where you sleep, for the first 6 months.", t=0.15, y=1560),
]), tin="wipe", bg=BUTTER)

# 5 · MOVE THEM (17.2–21.6) "Dozed off in the car seat or the swing? Move them to their crib."  (mirrors carousel slide 4)
v.scene(18.1, 22.2, "".join([
    paper(1),
    el('<span class="kick">Made for babies, not for sleep</span>', X, 350, a="left", t=0.05),
    words("Dozed off|somewhere else?|==Move them.==", t=0.1, st=0.07, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:940px;font-size:104px"),
    el(f'<div class="card">{rows([("not", "Car seat"), ("not", "Swing"), ("not", "Sofa"), ("on", "Their crib")], [0.9, 1.25, 1.6, 2.5])}</div>',
       X, 830, 912, a="up", t=0.7, d=0.45),
    caption("Dozed off in the car seat or the swing? Move them to their crib.", t=0.15, y=1560),
]), tin="push", bg=BUTTER)

# 6 · SAVE + SEND (21.6–26.5) "Save this, and send it to whoever puts baby down next."  (mirrors the carousel CTA slide)
v.scene(22.2, 27.0, "".join([
    el("", 1080 - 520, -320, 820, a="none", cls="deco", style="height:820px;background:#EB729A"),
    el("", -220, 1480, 560, a="none", cls="deco", style="height:560px;background:#D44C79"),
    el(STAR.format(w=44, c=YEL), 960, 330, a="pop", t=0.3, d=0.5),
    el('Same rules,<br>every sleep', X, 380, 560, a="up", t=0.05, cls="H", style=f"font-size:96px;color:{WHITE}"),
    el(f'<div class="minarch">{mark_svg(190)}</div>', 750, 350, a="pop", t=0.35, d=0.5),
    el('<div class="cta"><div class="ib"><svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#2C2A3A" '
       'stroke-width="2.4" stroke-linejoin="round"><path d="M6 3h12v18l-6-4.5L6 21z"/></svg></div>'
       '<div class="tx"><b>Save this</b> and send it to whoever puts baby down next.</div></div>',
       X, 720, 912, a="up", t=0.6, d=0.5),
    el('@littlefoldhq', X, 1250, a="fade", t=1.4, cls="B", style=f"font-size:40px;font-weight:700;color:{WHITE}"),
    el('General information only, not medical advice. Sources in the caption.', X, 1320, 912, a="fade", t=1.6,
       cls="B", style="font-size:30px;font-weight:600;color:#FFF3F7"),
]), tin="circle", bg=BUBBLE, origin="50% 50%", cls="dark")

if __name__ == "__main__":
    from vlab import render, contact_sheet, preview
    out = Path("/home/claude/content/video/out")
    qa = Path("/home/claude/content/video/qa")
    if "--preview" in sys.argv:
        preview(v, [1.6, 6.8, 10.6, 16.0, 21.2, 25.5], qa / "littlefold-safe-sleep-preview.png")
    else:
        mp4 = render(v, out / "littlefold-safe-sleep-silent.mp4", cover_t=2.2, cover_png=out / "littlefold-safe-sleep-cover.png")
        contact_sheet(mp4, qa / "littlefold-safe-sleep-sheet.png")
        voice = Path("/home/claude/content/video/audio/littlefold-safe-sleep-voice-sarah.mp3")
        if voice.exists():   # mux: voice at +0.30 s, loudness-normalised for phones (-14 LUFS), AAC 48 kHz
            import subprocess
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp4), "-i", str(voice), "-filter_complex",
                            "[1:a]adelay=300|300,loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,apad[a]",
                            "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
                            "-movflags", "+faststart", str(out / "littlefold-safe-sleep.mp4")], check=True)
