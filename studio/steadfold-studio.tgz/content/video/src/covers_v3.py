#!/usr/bin/env python3
"""Reel covers v3 (Content Standard v3 s.7): one dedicated 1080x1920 cover per Reel, rendered with the vlab engine and
each Reel's own brand CSS (imported read-only from its source script). No caption bar, no subtitles.
Hook 3-7 words at >= 110 px with the brand highlighter, one supporting visual, everything (chip included) inside
y 300-1400 and x 90-990, checked by measuring every text/visual box in the browser.

    python3 covers_v3.py            # all covers + qa/covers-v3-grid.png
"""
import io
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, "/home/claude/content/design")
from vlab import Video, el, W as VW, H as VH  # noqa: E402

V = Path("/home/claude/content/video")
OUT, QA = V / "out", V / "qa"
X = 96            # content left edge (safe zone x >= 90)
CW = 888          # content width (right edge 984)
CHIP_Y = 316      # brand chip top (>= 300)
SAFE = dict(x0=90, x1=990, y0=300, y1=1400)
COVER_CSS = (f"#tag{{top:{CHIP_Y}px!important;left:{X}px!important}}"
             ".ans .r{font-size:var(--fs,56px)!important;gap:24px}")


def ff_new():
    import ff_reel_start_at_birth as m
    inner = "".join([
        m.cover_paper(),
        m.kick("Start the clock at birth", y=410),
        m.hook_block(470),
        el('<div class="obar"><div class="fill" style="width:100%"></div></div>', X, 1010, 200, a="none"),
        el('<span class="ptr">Example at 6% a year</span>', X, 1160, a="none"),
        el('<div class="small">Any currency.<br>Same math.</div>', X + 450, 1156, 300, a="none"),
    ])
    return "fullyfunded", "start-at-birth", m.THEME, m.TAG, inner, m.BG, ""


def ff_old():
    """Existing Canada-series Learning Bond Reel (ff_reel_oct15.py): same facts as its scene 1 + carousel slide 3."""
    import ff_reel_start_at_birth as m
    import ff_reel_oct15 as o
    inner = "".join([
        m.cover_paper(),
        el('<span class="ptr" style="font-size:28px;padding:14px 22px">Canada series</span>', X, 404, a="none"),
        el('Get up to', X, 480, CW, a="none", cls="H", style="font-size:124px"),
        el('<span class="big" style="font-size:250px">$2,000</span>', X - 6, 620, CW, a="none"),
        el('<div class="obar"><div class="fill" style="width:100%"></div></div>', X, 862, 220, a="none"),
        el(f'for school. {m.mk("Free.", seed=4)}', X, 900, CW, a="none", cls="H", style="font-size:118px"),
        el('<div class="card" style="padding:30px 40px"><div style="font:600 46px/1.25 Inter;color:#0E1440">'
           'Born 2004 or later?<br><b style="color:#2B3FE0">Claim it in 3 steps.</b></div></div>', X, 1080, 700,
           a="none"),
    ])
    return "fullyfunded", "oct15", m.THEME, o.TAG.replace("Benefits you're owed", "Canada series"), inner, m.BG, ""


def lh():
    import lh_reel_oct15 as m
    inner = "".join([
        el('<span class="kick">Do this tonight</span>', X, 410, a="none"),
        el('Write one<br><span class="mk">if-then plan.</span>', X, 490, CW, a="none", cls="H",
           style="font-size:132px;line-height:1.02"),
        el(m.ifthen_card(), X, 860, CW - 16, a="none"),
    ])
    return "lockedhour", "oct15", m.THEME, m.TAG, inner, m.CREAM, "dots"


def hb():
    import hb_reel_oct15 as m
    inner = "".join([
        m.paper(),
        el('<span class="kick">Parking signs</span>', X, 410, a="none"),
        el(f'Never guess a<br>{m.hl("parking sign.")}', X, 470, CW, a="none", cls="H", style="font-size:114px"),
        el(f'<div class="photo" style="position:relative;padding:12px">{m.sign_crop(216, 85, 768, 1122, 290)}'
           '<span class="chip yel" style="position:absolute;left:-10px;bottom:-22px;transform:rotate(-3deg)">Example</span>'
           '</div>', X + 8, 790, a="none", rot=-1.5),
        el('<div class="card ans">'
           '<span class="chip ind">Tue 4:40 PM</span>'
           '<div class="r" style="margin-top:10px"><span>Park now?</span><b class="no">No</b></div>'
           '<div class="r"><span>From</span><b>6:00 PM</b></div>'
           '<div class="r"><span>Overnight</span><b>Permit</b></div>'
           '</div>', 432, 820, 548, a="none", rot=1.5, style="--fs:50px"),
        el(f'<span class="arrow">{m.ARROW}</span>', 376, 1000, a="none"),
    ])
    return "hourback", "oct15", m.THEME, m.TAG, inner, m.CREAM, ""


def lf():
    import lf_safe_sleep as m
    from engine.littlefold import ill_crib
    inner = "".join([
        m.el("", 1080 - 600, -340, 860, a="none", cls="deco", style=f"height:860px;background:{m.PINKSOFT}"),
        m.el("", -230, 1500, 620, a="none", cls="deco", style=f"height:620px;background:{m.BLUESOFT}"),
        el('<span class="kick">Safe sleep · tonight</span>', X, 410, a="none"),
        el('Before bed:<br><span class="hlx" style="--p:1">3 quick checks.</span>', X, 470, CW, a="none", cls="H",
           style="font-size:124px"),
        el(f'<div class="arch" style="width:470px;height:590px;border-radius:235px 235px 40px 40px">{ill_crib(330)}'
           '<div class="acap">Nothing in here<br>but baby</div></div>', (1080 - 470) // 2, 790, a="none"),
    ])
    return "littlefold", "oct15", m.THEME, m.TAG, inner, m.BUTTER, ""


COVERS = [ff_new, lh, hb, lf, ff_old]

MEASURE = r"""() => {
 const sc=document.querySelector('.scene'); const out=[];
 const add=(e,kind)=>{const r=e.getBoundingClientRect(); if(r.width<1||r.height<1)return;
   out.push({k:kind,cls:e.className&&e.className.baseVal===undefined?e.className:'svg',x0:r.left,y0:r.top,x1:r.right,y1:r.bottom,
   t:(e.textContent||'').trim().slice(0,30)});};
 const tw=document.createTreeWalker(sc,NodeFilter.SHOW_TEXT);
 while(tw.nextNode()){const n=tw.currentNode; if(!n.textContent.trim())continue; const rg=document.createRange();
   rg.selectNodeContents(n); for(const r of rg.getClientRects()) out.push({k:'text',x0:r.left,y0:r.top,x1:r.right,y1:r.bottom,
   t:n.textContent.trim().slice(0,30)});}
 sc.querySelectorAll('.card,.photo,.arch,img,.ptr,.big,.obar,.arrow,svg').forEach(e=>{if(!e.closest('.deco')&&!e.closest('.im'))add(e,'vis')});
 add(document.getElementById('tag'),'chip');
 return out;}"""


def render_all():
    from playwright.sync_api import sync_playwright
    from PIL import Image
    work = V / "build"
    work.mkdir(exist_ok=True)
    results = []
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": VW, "height": VH}, device_scale_factor=1)
        for fn in COVERS:
            brand, slug, theme, tag, inner, bg, pattern = fn()
            v = Video(brand, f"reel-{slug}-cover-v3", theme + COVER_CSS, tag)
            v.scene(0, 1.0, inner, tin="cut", bg=bg, pattern=pattern)
            src = work / f"{brand}-reel-{slug}-cover-v3.html"
            src.write_text(v.html(), encoding="utf-8")
            pg.goto(src.as_uri())
            pg.evaluate("document.fonts.ready.then(()=>1)")
            pg.wait_for_timeout(300)
            pg.evaluate("seek(0.5)")
            boxes = pg.evaluate(MEASURE)
            bad = [b for b in boxes if b["x0"] < SAFE["x0"] - 0.5 or b["x1"] > SAFE["x1"] + 0.5
                   or b["y0"] < SAFE["y0"] - 0.5 or b["y1"] > SAFE["y1"] + 0.5]
            ext = dict(x0=min(b["x0"] for b in boxes), x1=max(b["x1"] for b in boxes),
                       y0=min(b["y0"] for b in boxes), y1=max(b["y1"] for b in boxes))
            jpg = OUT / f"{brand}-reel-{slug}-cover-v3.jpg"
            Image.open(io.BytesIO(pg.screenshot(type="png"))).convert("RGB").save(jpg, "JPEG", quality=90)
            print(f"{jpg.name}: content x {ext['x0']:.0f}-{ext['x1']:.0f}, y {ext['y0']:.0f}-{ext['y1']:.0f} "
                  f"{'OK' if not bad else 'OUT OF SAFE ZONE: ' + json.dumps(bad[:4])}")
            results.append((jpg, not bad))
        br.close()
    return results


def grid(paths, out_png):
    """Each cover cropped to centre 3:4 (profile grid) and centre 4:5 (feed), shrunk to 200 px wide."""
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.truetype("/home/claude/content/design/assets/fonts/Inter-Bold.ttf", 18)
    rows = []
    for label, ar in (("profile grid: centre 3:4", 4 / 3), ("feed: centre 4:5", 5 / 4)):
        ch = round(VW * ar)
        top = (VH - ch) // 2
        th = round(200 * ar)
        row = Image.new("RGB", (len(paths) * 212 + 12, th + 40), "#ffffff")
        d = ImageDraw.Draw(row)
        d.text((12, 8), label, fill="#111", font=font)
        for i, p in enumerate(paths):
            im = Image.open(p).crop((0, top, VW, top + ch)).resize((200, th), Image.LANCZOS)
            row.paste(im, (12 + i * 212, 34))
        rows.append(row)
    sheet = Image.new("RGB", (rows[0].width, sum(r.height for r in rows) + 10), "#ffffff")
    y = 0
    for r in rows:
        sheet.paste(r, (0, y))
        y += r.height + 10
    sheet.save(out_png)
    return out_png


if __name__ == "__main__":
    res = render_all()
    grid([p for p, _ in res], QA / "covers-v3-grid.png")
    if not all(ok for _, ok in res):
        sys.exit("some covers are outside the safe zone")
