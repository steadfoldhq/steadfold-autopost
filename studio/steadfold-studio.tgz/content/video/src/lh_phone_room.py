#!/usr/bin/env python3
"""Locked Hour · 'Phone in another room?' (from lh-w2-02-phone-room, gate2 SHIP). 30 s, 1080x1920, no audio.
Format: Quiz-then-receipts (question hook -> retest reveal -> what helped -> honest part -> comment prompt).
Every fact below is from the shipped carousel / lockedhour/sources.md (Ward 2017, Ruiz Pardo 2022, Hartmann 2020,
Parry 2024, Castelo 2025)."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from vlab import Video, words, el, count, caption, CHECK, DOWN, MARKS  # noqa: E402

THEME = """
:root{--bg:#FFF4E0;--ink:#141414;--pink:#FF5CA8;--yel:#FFD43B;--hl:#FFD43B;--hl-dark:#FFD43B;
 --prog-bg:rgba(255,244,224,.7);--prog-fg:#FF5CA8;--cap-bg:#141414;--cap-ink:#FFF4E0;--cap-r:14px;
 --cap-sh:8px 8px 0 #FF5CA8;--cap-bd:0;--strike:#FF5CA8}
.dark{--cap-bg:#FFF4E0;--cap-ink:#141414;--cap-sh:8px 8px 0 #FF5CA8}
.H{font-family:'Inter Display';font-weight:900;letter-spacing:-.04em;line-height:.98;color:var(--ink)}
.dark .H{color:#FFF4E0}
.B{font-family:Inter;font-weight:700;color:var(--ink);letter-spacing:-.01em}
.dark .B{color:#FFF4E0}
.dots{background-image:radial-gradient(rgba(20,20,20,.12) 2.4px,transparent 2.8px);background-size:30px 30px}
.dark .dots{background-image:radial-gradient(rgba(255,244,224,.10) 2.4px,transparent 2.8px)}
.card{background:#fff;border:6px solid #141414;box-shadow:12px 12px 0 #141414;border-radius:18px}
.dark .card{box-shadow:12px 12px 0 #FF5CA8}
.chip{display:inline-block;font:900 50px/1 'Inter Display';letter-spacing:-.02em;color:#141414;border:6px solid #141414;
 box-shadow:8px 8px 0 #141414;border-radius:999px;padding:24px 44px 26px;background:#fff;white-space:nowrap}
.kick{display:inline-block;font:800 28px/1 Inter;letter-spacing:.13em;text-transform:uppercase;color:#141414;
 background:#FFD43B;border:4px solid #141414;padding:12px 18px 11px;border-radius:8px}
.row{display:flex;justify-content:space-between;align-items:baseline;padding:22px 30px;border-top:4px dashed #141414;
 font:600 40px/1.15 Inter;color:#141414}
.row b{font-weight:900;font-family:'Inter Display';font-size:44px;text-align:right}
#tag{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:#FFF4E0;
 border:4px solid #141414;border-radius:999px;padding:6px 20px 6px 6px;font:800 26px/1 Inter;color:#141414}
#tag img{width:44px;height:44px;border-radius:50%}
#tag span{opacity:.7;font-weight:700}
.stampbox{display:inline-block;border:12px solid #141414;background:#FF5CA8;padding:26px 40px 30px;border-radius:22px;
 box-shadow:16px 16px 0 #141414}
.barrow{margin-bottom:34px}
.barlab{display:flex;justify-content:space-between;font:700 40px/1.1 Inter;color:#FFF4E0;margin-bottom:14px}
.barlab b{font:900 52px/1 'Inter Display'}
.track{height:54px;border:5px solid #FFF4E0;border-radius:12px;overflow:hidden;background:#232323}
.fill{height:100%;width:0;background:#FF5CA8}
"""
TAG = (f'<div id="tag"><img src="{(MARKS / "lockedhour.png").as_uri()}">Locked Hour <span>· Receipts №02</span></div>')

v = Video("lockedhour", "phone-room", THEME, TAG)
X = 84
CREAM, INK, PINK, YEL = "#FFF4E0", "#141414", "#FF5CA8", "#FFD43B"

# 1 · HOOK (0–2.5): question readable on frame 0, answer chips pop, punch-in camera
v.scene(0, 2.5, "".join([
    el('<span class="kick">Quick question</span>', X, 340, a="none"),
    el('Phone in<br>another room.<br>Does it help<br>you <span class="hlx" data-a="hl" data-t="0.25" data-d="0.4">'
       'focus?</span>', X, 410, 900, a="none", cls="H", style="font-size:136px"),
    el('<span class="chip" style="background:#FFD43B">YES</span>', X, 1000, a="pop", t=0.45, d=0.42, br=1),
    el('<span class="chip" style="background:#FF5CA8">NO</span>', X + 300, 1000, a="pop", t=0.6, d=0.42, br=1),
    caption("Pick one. Then watch the retest.", t=0.95),
]), tin="punch", bg=CREAM, pattern="dots")

# 2 · THE CLAIM (2.5–5.5): case-file card on ink
rows = [("Who", "520 + 275 students"), ("Tested", "Memory, reasoning"), ("Phone", "Desk, bag or other room")]
card = ('<div style="background:#FF5CA8;border-bottom:6px solid #141414;padding:18px 30px;font:800 28px/1 Inter;'
        'letter-spacing:.12em;color:#141414;border-radius:12px 12px 0 0">CASE FILE · WARD ET AL. 2017</div>'
        + "".join(el(f'<div class="row" style="{"border-top:0" if i == 0 else ""}">{a}<b>{b}</b></div>', a="left",
                     t=0.5 + i * 0.18, d=0.35, style="position:relative") for i, (a, b) in enumerate(rows))
        + el('<div class="row" style="background:#FFD43B;border-radius:0 0 12px 12px">The claim<b>Phone nearby = '
             'lower scores</b></div>', a="pop", t=1.15, d=0.35, style="position:relative"))
v.scene(2.5, 5.5, "".join([
    words("The study|==everyone quotes.==", t=0.0, st=0.07, cls="H", style=f"position:absolute;left:{X}px;top:350px;"
          "width:900px;font-size:110px"),
    el(f'<div class="card" style="overflow:hidden">{card}</div>', X, 640, 900, a="up", t=0.25, d=0.4),
    caption("A phone on the desk lowered test scores. That's the famous claim.", t=1.35),
]), tin="whip", bg=INK, pattern="dots", cls="dark")

# 3 · THE RETEST (5.5–8.5): stamp slam + shake
v.scene(5.5, 8.5, "".join([
    words("Then others|ran it ==again.==", t=0.0, st=0.07, cls="H", style=f"position:absolute;left:{X}px;top:350px;"
          "width:900px;font-size:120px;--hl:#FF5CA8"),
    el('<span class="kick" style="background:#fff">2022 · direct retest</span>', X, 640, a="left", t=0.35),
    el('<div class="stampbox"><div class="H" style="font-size:124px;line-height:.92">NO<br>DIFFERENCE.</div></div>',
       X, 730, a="stamp", t=0.55, d=0.32, sh=0.85, rot=-4),
    el('<div class="card B" style="padding:24px 30px;font-size:42px;line-height:1.2">2020, Switzerland: '
       '<b style="font-weight:900">no overall effect on memory.</b></div>', X, 1130, 900, a="up", t=1.45),
]), tin="flash", bg=YEL, pattern="dots")

# 4 · BIG PICTURE (8.5–11.5): counter
v.scene(8.5, 11.5, "".join([
    el('<span class="kick">The big picture · Parry 2024</span>', X, 340, a="left", t=0.05),
    count(0, 56, "{:,.0f}", t=0.1, d=0.85, x=X - 10, y=380, cls="H",
          style="font-size:470px;line-height:1;color:#FF5CA8;-webkit-text-stroke:9px #141414;"
                "text-shadow:16px 16px 0 #141414"),
    words("studies pooled.|7,093 people.", t=0.55, st=0.06, cls="H", style=f"position:absolute;left:{X}px;top:860px;"
          "font-size:76px"),
    el(f'<span class="chip" style="font-size:40px;padding:18px 30px;background:#FFD43B">Working memory: '
       f'one small dip</span>', X, 1060, a="left", t=1.25),
    el('<span class="chip" style="font-size:40px;padding:18px 30px">Other mental skills: no effect</span>', X, 1170,
       a="left", t=1.5),
]), tin="zoom", bg=CREAM, pattern="dots")

# 5 · PIVOT QUESTION (11.5–14.0)
v.scene(11.5, 14.0, "".join([
    words("So what|==actually==|helped?", t=0.0, st=0.09, wa="pop", d=0.36, cls="H",
          style=f"position:absolute;left:{X}px;top:360px;width:900px;font-size:150px"),
    el('<span class="strike" data-a="strike" data-t="1.05" data-d="0.3">Not where it sits.</span>', X, 900, a="up",
       t=0.7, cls="H", style="font-size:84px"),
    el('<span style="background:#FFD43B;border:6px solid #141414;box-shadow:10px 10px 0 #141414;padding:6px 22px 14px;'
       'border-radius:12px">What it can reach.</span>', X, 1040, a="slam", t=1.4, d=0.3, sh=1.62, cls="H",
       style="font-size:92px"),
]), tin="whip", bg=PINK, pattern="dots")

# 6 · WHAT HELPED (14.0–18.0)
v.scene(14.0, 18.0, "".join([
    el('<span class="kick">Randomised trial · Castelo 2025</span>', X, 340, a="left", t=0.15),
    count(0, 467, "{:,.0f}", t=0.25, d=0.9, x=X - 10, y=390, cls="H",
          style="font-size:400px;line-height:1;color:#141414;text-shadow:16px 16px 0 #FF5CA8"),
    words("people blocked their|phone's internet. 2 weeks.", t=0.6, st=0.05, cls="H",
          style=f"position:absolute;left:{X}px;top:800px;width:900px;font-size:70px"),
    el(f'<span class="chip" style="font-size:42px;padding:18px 30px;background:#FFD43B">{CHECK} Calls on</span>', X,
       970, a="pop", t=1.2),
    el(f'<span class="chip" style="font-size:42px;padding:18px 30px;background:#FFD43B">{CHECK} Texts on</span>',
       X + 330, 970, a="pop", t=1.35),
    el('<div class="card B" style="padding:24px 30px;font-size:42px;line-height:1.22">Attention improved by about as '
       'much as <span class="hlx" data-a="hl" data-t="2.4" data-d="0.4" style="font-weight:900">10 years of '
       'age-related decline.</span></div>', X, 1110, 900, a="up", t=1.9),
]), tin="circle", bg=CREAM, pattern="dots", origin="50% 62%")

# 7 · THE HONEST PART (18.0–21.5): animated bars
bars = [("Assigned to block", "467", 100, "#FF5CA8"), ("Installed the blocker", "266", 57, "#FFD43B"),
        ("Kept it on 10+ of 14 days", "119", 25.5, "#FFF4E0")]
barhtml = "".join(
    f'<div class="barrow" data-a="up" data-t="{0.5 + i * 0.35}" data-d="0.35"><div class="barlab">{lab}<b>{val}</b>'
    f'</div><div class="track" data-a="bar" data-t="{0.65 + i * 0.35}" data-d="0.7" data-w="{w}">'
    f'<div class="fill" style="background:{c}"></div></div></div>' for i, (lab, val, w, c) in enumerate(bars))
v.scene(18.0, 21.5, "".join([
    el('<span class="kick">The honest part</span>', X, 340, a="left"),
    words("Most people|didn't ==stick to it.==", t=0.1, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:900px;font-size:112px"),
    el(barhtml, X, 690, 850, a="none"),
    caption("Even counting the quitters, attention still improved on average.", t=1.9),
]), tin="wipe", bg=INK, pattern="dots", cls="dark")

# 8 · YOUR HOUR (21.5–25.5): 60-minute bar fills
ticks = "".join(f'<span style="position:absolute;left:{p}%;transform:translateX(-{p}%);top:0">{m}</span>'
                for p, m in [(0, 0), (25, 15), (50, 30), (75, 45), (100, 60)])
v.scene(21.5, 25.5, "".join([
    el('<span class="kick" style="background:#fff">Your locked hour</span>', X, 340, a="left"),
    words("Data off.|==Calls on.==", t=0.1, st=0.14, wa="slam", d=0.3, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:900px;font-size:170px;--hl:#FF5CA8"),
    el('<div class="track" data-a="bar" data-t="0.8" data-d="1.8" data-w="100" style="height:84px;border:6px solid '
       '#141414;background:#fff;box-shadow:10px 10px 0 #141414;border-radius:16px"><div class="fill" style="background:'
       'repeating-linear-gradient(90deg,#FF5CA8 0 24.6%,#141414 24.6% 25%)"></div></div>', X, 820, 860, a="up", t=0.6),
    el(ticks, X, 932, 860, a="fade", t=0.7, cls="B", style="height:40px;font-size:30px;font-weight:800"),
    count(0, 60, "{:,.0f} min", t=0.8, d=1.8, x=X, y=990, cls="H", style="font-size:120px"),
    caption("Our 1-hour version of a 2-week trial.", t=1.6),
]), tin="flash", bg=YEL, pattern="dots")

# 9 · COMMENT PROMPT (25.5–30.0)
v.scene(25.5, 30.0, "".join([
    words("Be honest.", t=0.0, wa="slam", d=0.3, st=0.1, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;font-size:160px;color:#FF5CA8;-webkit-text-stroke:6px #141414"),
    words("Could you do|60 minutes with|==data off?==", t=0.45, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:550px;width:900px;font-size:100px"),
    el('<span class="chip" style="background:#FFD43B;font-size:46px">Yes, easily</span>', X, 900, a="pop", t=1.3, br=1),
    el('<span class="chip" style="background:#FF5CA8;font-size:46px">Not a chance</span>', X, 1018, a="pop", t=1.45, br=1),
    el('<span class="chip" style="font-size:46px">Trying it tomorrow</span>', X, 1136, a="pop", t=1.6, br=1),
    el(f'Comment yours {DOWN}', X, 1272, a="up", t=2.1, cls="H", style="font-size:64px", br=1),
    el('@lockedhourhq · sources in the caption', X, 1368, a="fade", t=2.4, cls="B", style="font-size:32px;opacity:.75"),
]), tin="zoom", bg=CREAM, pattern="dots")

if __name__ == "__main__":
    from vlab import render, contact_sheet
    out = Path("/home/claude/content/video/out")
    mp4 = render(v, out / "lockedhour-phone-room.mp4", cover_t=1.6, cover_png=out / "lockedhour-phone-room-cover.png")
    contact_sheet(mp4, Path("/home/claude/content/video/qa/lockedhour-phone-room-sheet.png"))
