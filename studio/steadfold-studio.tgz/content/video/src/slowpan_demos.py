#!/usr/bin/env python3
"""Slow-pan demos (Oct 15): 'Halloween carousel' style. A slow dreamy camera move on a code-made background, one
big static word / line on top, calm music (music2 'warm').

    python3 slowpan_demos.py            # Hourback Reel + 3 Fully Funded carousel video slides + QA sheet
    python3 slowpan_demos.py reel       # just the Reel        (slides | sheet | hooktest likewise)
    python3 slowpan_demos.py hooktest   # user-supplied background hook: one still image + one video clip

Outputs  /home/claude/content/video/out/slowpan/
  hourback-reel-slowpan-week.mp4      1080x1920, 14.5 s, 3 scenes (sky -> paper -> misty forest)
  fullyfunded-carousel-slowpan-0N.mp4 1080x1350, 6 s each, H.264 30 fps + AAC, seamless loop
QA       /home/claude/content/video/qa/slowpan-sheet.png  (+ slowpan-qa.json with the jitter numbers)
"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from slowpan import Scene, Move, render, jitter_check, still, probe, REEL, FEED, BUILD, V  # noqa: E402

OUT, QA = V / "out" / "slowpan", V / "qa"
MARKS = Path("/home/claude/content/design/assets/marks")

# ----------------------------------------------------------------------------- Hourback Reel (1080x1920)
HB_INK, HB_YEL, HB_KICK, HB_IND = "#2A2238", "#FFC94D", "#B4490A", "#5E54C9"
HB_CSS = f"""
.chip{{position:absolute;left:96px;top:316px;display:flex;align-items:center;gap:12px;background:#fff;
 border-radius:999px;padding:6px 24px 6px 6px;font:700 27px/1 Inter;color:{HB_INK};
 box-shadow:0 10px 26px -12px rgba(30,24,80,.55)}}
.chip img{{width:46px;height:46px;border-radius:50%}} .chip span{{opacity:.6}}
.H{{position:absolute;left:96px;width:900px;font-family:Poppins;font-weight:800;letter-spacing:-.025em;line-height:1.04}}
.Hw{{color:#fff;text-shadow:0 6px 44px rgba(30,24,80,.38),0 1px 2px rgba(30,24,80,.18)}}
.Hi{{color:{HB_INK}}}
.hl{{position:relative;display:inline-block;z-index:0;color:{HB_INK};text-shadow:none}}
.hl::before{{content:"";position:absolute;z-index:-1;left:-.07em;right:-.07em;top:.3em;bottom:.03em;background:{HB_YEL};
 border-radius:.26em .12em .24em .1em;transform:rotate(-.6deg)}}
.kick{{position:absolute;left:96px;font:800 30px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:{HB_KICK}}}
.card{{position:absolute;left:96px;width:888px;background:#fff;border-radius:34px;padding:46px 50px 50px;
 box-shadow:0 40px 70px -34px rgba(94,84,201,.45);border:2px solid #F3E6D3}}
.card .lab{{font:800 26px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#655A6E;margin-bottom:26px}}
.card p{{font:500 52px/1.32 Inter;color:{HB_INK};letter-spacing:-.01em}}
.card em{{font-style:normal;font-weight:700;color:{HB_KICK}}}
.sub{{position:absolute;left:96px;width:888px;font:600 44px/1.3 Inter;color:#655A6E}}
.pill{{position:absolute;left:96px;display:inline-flex;align-items:center;gap:18px;background:#fff;color:{HB_INK};
 font:700 44px/1 Inter;padding:16px 34px 16px 16px;border-radius:999px;box-shadow:0 20px 40px -20px rgba(20,14,60,.6)}}
.pill i{{display:grid;place-items:center;width:72px;height:72px;border-radius:50%;background:{HB_YEL}}}
.handle{{position:absolute;left:96px;font:700 40px/1 Inter;color:#fff;opacity:.92;text-shadow:0 2px 14px rgba(20,14,60,.5)}}
"""
HB_CHIP = f'<div class="chip"><img src="{(MARKS / "hourback.png").as_uri()}">Hourback <span>· Sunday reset</span></div>'
BOOKMARK = (f'<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="{HB_INK}" stroke-width="2.6" '
            'stroke-linejoin="round"><path d="M6 3h12v18l-6-4.5L6 21z"/></svg>')


def hourback_reel():
    s1 = Scene(bg=("sky", "hourback", 3), dur=5.0, move=Move(pan=0.032), css=HB_CSS, seed=1, text=(
        '<div class="H Hw" style="top:560px;font-size:150px">Your week,<br>planned in<br>'
          '<span class="hl">2 minutes.</span></div>'))
    s2 = Scene(bg=("paper", "hourback", 8), dur=5.0, move=Move(pan=0.0, push=0.035, focus=(0.5, 0.42)),
               css=HB_CSS, vignette=0.07, seed=2, text=(
        '<div class="kick" style="top:440px">The prompt · copy it</div>'
        + '<div class="H Hi" style="top:494px;font-size:96px">Paste this into<br>any AI chat:</div>'
        + '<div class="card" style="top:744px"><div class="lab">Your Sunday prompt</div><p>Here’s my week: '
          '<em>[paste your to-dos and appointments]</em>. Make a simple day-by-day plan. Put my hardest task in my '
          'best hours. Leave one evening free.</p></div>'
        + '<div class="sub" style="top:1300px">Tweak what it gives you. Done.</div>'))
    s3 = Scene(bg=("forest", "hourback", 5, dict(horizon=0.52)), dur=4.5, move=Move(pan=-0.03), css=HB_CSS,
               seed=3, text=(
        '<div class="H Hw" style="top:470px;font-size:140px">Save this<br>for <span class="hl">Sunday</span><br>'
          '<span class="hl">night.</span></div>'
        + f'<div class="pill" style="top:1010px"><i>{BOOKMARK}</i>Tap save</div>'
        + '<div class="handle" style="top:1330px">@hourbackhq</div>'))
    return [s1, s2, s3]


# ----------------------------------------------------------------------------- Fully Funded carousel (1080x1350)
FF_INK, FF_CO, FF_KICK = "#0E1440", "#2B3FE0", "#C2410C"
FF_CSS = f"""
.wrap{{position:absolute;left:0;right:0;text-align:center}}
.kick{{font:800 32px/1 Inter;letter-spacing:.18em;text-transform:uppercase}}
.word{{font-family:'Inter Display';font-weight:800;letter-spacing:-.045em;line-height:.92}}
.lt .kick{{color:rgba(255,255,255,.9);text-shadow:0 2px 16px rgba(14,20,64,.35)}}
.lt .word{{color:#fff;text-shadow:0 8px 60px rgba(14,20,64,.32),0 1px 2px rgba(14,20,64,.2)}}
.dk .kick{{color:{FF_KICK}}} .dk .word{{color:{FF_CO}}}
.foot{{position:absolute;left:0;right:0;top:1218px;display:flex;justify-content:center;align-items:center;gap:14px;
 font:700 28px/1 Inter}}
.foot img{{width:44px;height:44px;border-radius:50%}}
.lt .foot{{color:#fff;text-shadow:0 2px 12px rgba(14,20,64,.45)}} .dk .foot{{color:{FF_INK}}}
.foot b{{font-weight:700;opacity:.55;margin-left:10px}}
"""


def ff_slide(i, word, kicker, tone, size=300, top=420):
    foot = (f'<div class="foot"><img src="{(MARKS / "fullyfunded.png").as_uri()}">@fullyfundedhq'
            f'<b>{i} / 3</b></div>')
    return (f'<div class="{tone}" style="position:absolute;inset:0">'
            f'<div class="wrap kick" style="top:{top - 70}px">{kicker}</div>'
            f'<div class="wrap word" style="top:{top}px;font-size:{size}px">{word}</div>{foot}</div>')


def ff_slides():
    common = dict(dur=6.0, css=FF_CSS, loop=0.6)
    return [
        Scene(bg=("sky", "fullyfunded", 1), move=Move(pan=0.03), seed=11,
              text=ff_slide(1, "Start.", "Investing for your kid?", "lt", 300, 470), **common),
        Scene(bg=("paper", "fullyfunded", 4, dict(leak_strength=0.32)), move=Move(pan=0.0, push=0.035, focus=(0.5, 0.5)), vignette=0.07,
              seed=12, text=ff_slide(2, "Early.", "Time does the heavy lifting", "dk", 300, 470), **common),
        Scene(bg=("forest", "fullyfunded", 7, dict(horizon=0.60)), move=Move(pan=-0.03), seed=13,
              text=ff_slide(3, "Let it<br>grow.", "Then leave it alone", "lt", 230, 300), **common),
    ]


# ----------------------------------------------------------------------------- QA
def summarise(name, res, jit):
    pr = probe(res["mp4"])
    v = next(s for s in pr["streams"] if s["codec_name"] == "h264")
    a = next((s for s in pr["streams"] if s["codec_name"] == "aac"), None)
    return dict(file=str(res["mp4"]), size_mb=round(int(pr["format"]["size"]) / 1e6, 2),
                duration=round(float(pr["format"]["duration"]), 2), video=f'{v["width"]}x{v["height"]} '
                f'{v["codec_name"]} {v["r_frame_rate"]} {v["pix_fmt"]}',
                audio=(f'{a["codec_name"]} {a["sample_rate"]} Hz x{a["channels"]}' if a else None), jitter=jit)


def contact_sheet(reel, slides, out_png, qa):
    import cv2
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont
    font = ImageFont.truetype("/home/claude/content/design/assets/fonts/Inter-Bold.ttf", 22)
    small = ImageFont.truetype("/home/claude/content/design/assets/fonts/Inter-Medium.ttf", 19)
    rows = []

    def row(label, frames, tw):
        ims = [(lab, Image.fromarray(f).resize((tw, round(tw * f.shape[0] / f.shape[1])), Image.LANCZOS))
               for lab, f in frames]
        th = ims[0][1].height
        r = Image.new("RGB", (max(16 + len(ims) * (tw + 12), int(font.getlength(label)) + 32), th + 76), "#1d1b22")
        d = ImageDraw.Draw(r)
        d.text((16, 10), label, fill="#fff", font=font)
        for k, (lab, im) in enumerate(ims):
            x = 16 + k * (tw + 12)
            r.paste(im, (x, 44))
            d.text((x, 50 + th), lab, fill="#c9c4d6", font=small)
        return r

    T = [0.0, 2.5, 4.8, 5.0, 5.3, 7.5, 10.0, 12.2, 14.4]
    rows.append(row("Hourback Reel 1080x1920 · 14.5 s · sky -> paper -> misty forest (frame labels = seconds; "
                    "4.8-5.3 = the cut: text out, backgrounds cross-fade, text in)", [(f"{t:.1f}s", still(reel["mp4"], t, REEL)) for t in T], 200))
    fr = []
    for k, s in enumerate(slides):
        for t in (0.0, 3.0, 5.6):
            fr.append((f"slide {k + 1} · {t:.1f}s", still(s["mp4"], t, FEED)))
    rows.append(row("Fully Funded carousel video slides 1080x1350 · 6 s each, seamless loop (5.6 s = fading back "
                    "to frame 0)", fr, 196))
    # motion proof: slide 1, |frame 0 - frame 5.0 s| (background moved) vs text (unchanged)
    a, b = still(slides[0]["mp4"], 0.0, FEED).astype(np.int16), still(slides[0]["mp4"], 5.0, FEED).astype(np.int16)
    diff = np.clip(np.abs(a - b).max(-1) * 6, 0, 255).astype(np.uint8)
    diff = cv2.cvtColor(diff, cv2.COLOR_GRAY2RGB)
    a2, b2 = still(reel["mp4"], 0.0, REEL).astype(np.int16), still(reel["mp4"], 4.0, REEL).astype(np.int16)
    diff2 = cv2.cvtColor(np.clip(np.abs(a2 - b2).max(-1) * 6, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2RGB)
    rows.append(row("Motion proof |frame A - frame B| x6: the background moved, the text block is black = unchanged",
                    [("FF slide 1: 0 s vs 5 s", diff), ("Reel scene 1: 0 s vs 4 s", diff2)], 300))
    W = max(r.width for r in rows)
    lines = ["Jitter check: max per-pixel change between consecutive frames inside opaque text (core = alpha 255, "
             "eroded 2 px)."]
    for name, q in qa.items():
        for j in q["jitter"]:
            lines.append(f"  {name} scene {j['scene']}: lossless max {j.get('lossless_core_max')} "
                         f"({j.get('lossless_frames')} fr) · MP4 max {j['mp4_core_max']}, p99.9 "
                         f"{j['mp4_core_p999']:.1f}, mean {j['mp4_core_mean']:.3f} · bg moved (first vs mid frame) "
                         f"{j['bg_change_window']:.1f}")
        lines.append(f"  {name}: {q['video']} · {q['audio']} · {q['duration']} s · {q['size_mb']} MB")
    txt = Image.new("RGB", (W, 30 + 26 * len(lines)), "#1d1b22")
    d = ImageDraw.Draw(txt)
    for k, ln in enumerate(lines):
        d.text((16, 12 + 26 * k), ln, fill="#fff" if k == 0 else "#c9c4d6", font=small)
    rows.append(txt)
    sheet = Image.new("RGB", (W, sum(r.height for r in rows) + 8 * len(rows)), "#1d1b22")
    y = 0
    for r in rows:
        sheet.paste(r, (0, y))
        y += r.height + 8
    sheet.save(out_png)
    return out_png


def main(which):
    OUT.mkdir(parents=True, exist_ok=True)
    qa_json = QA / "slowpan-qa.json"
    qa = json.loads(qa_json.read_text()) if qa_json.exists() else {}
    runs = {}
    if which in ("all", "reel"):
        res = render(hourback_reel(), OUT / "hourback-reel-slowpan-week.mp4", REEL, music=("hourback", "warm"),
                     xfade=0.8, lufs=-14, persist=HB_CHIP, persist_css=HB_CSS)
        qa["hourback-reel"] = summarise("hourback-reel", res, jitter_check(res))
        runs["reel"] = res
    if which in ("all", "slides"):
        for k, sc in enumerate(ff_slides(), 1):
            res = render([sc], OUT / f"fullyfunded-carousel-slowpan-{k:02d}.mp4", FEED,
                         music=("fullyfunded", "warm", k), lufs=-20, maxrate="7M")
            qa[f"ff-slide-{k}"] = summarise(f"ff-slide-{k}", res, jitter_check(res))
            runs[f"s{k}"] = res
    qa_json.write_text(json.dumps(qa, indent=1, default=str))
    if which in ("all", "sheet", "reel", "slides"):
        reel = runs.get("reel") or dict(mp4=OUT / "hourback-reel-slowpan-week.mp4")
        slides = [runs.get(f"s{k}") or dict(mp4=OUT / f"fullyfunded-carousel-slowpan-{k:02d}.mp4") for k in (1, 2, 3)]
        if all(Path(x["mp4"]).exists() for x in [reel] + slides):
            print(contact_sheet(reel, slides, QA / "slowpan-sheet.png", qa))
    if which == "hooktest":
        img = Path("/home/claude/content/week02/hourback/samples/sample-parking-sign.jpg")
        clip = V / "out" / "hourback-reel-oct15-silent.mp4"
        txt = '<div style="position:absolute;top:560px;left:0;right:0;text-align:center;font:800 200px Poppins;' \
              'color:#fff;text-shadow:0 6px 40px rgba(0,0,0,.5)">Hook.</div>'
        for name, bg in (("image", img), ("video", clip)):
            res = render([Scene(bg=str(bg), text=txt, dur=4.0, move=Move(pan=0.03, parallax=False), loop=0.5)],
                         BUILD / f"hooktest-{name}.mp4", FEED, music=("fullyfunded", "warm"), lufs=-20)
            print(name, json.dumps(jitter_check(res)))
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "jitter"} for k, v in qa.items()}, indent=1))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "all")
