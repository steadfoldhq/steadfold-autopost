#!/usr/bin/env python3
"""Steadfold Viral Video Lab: code-rendered vertical videos (1080x1920, 30 fps, no audio).

How it works
  * A video is a list of scenes. Each scene is absolutely-positioned HTML with data attributes
    describing *when* and *how* each element animates (local scene time, seconds).
  * A small JS engine (`seek(t)`) puts every element into its exact state for time t, so frames are
    deterministic: Playwright calls seek(i/30), screenshots, and pipes JPEGs into ffmpeg.
  * Scene boundaries sit on a 0.5 s grid (120 BPM), so cuts land on the beat of any 120/60/240 BPM
    commercial track the owner adds in-app.

Element animation attributes (all times are local to the scene):
  data-a   in-animation: none|fade|up|down|left|right|pop|slam|stamp|blur|drop|words|count|type|bar|hl|strike|ripple|tick
  data-t   start time      data-d  duration (default .4)
  data-x   exit time       data-xa exit anim: fade|pop|up|left
  data-sh  shake at time   data-br breathe (1 = gentle pulse after entering)   data-rot base rotation (deg)
Scene attributes:
  data-s/data-e start/end (global), data-in cut|punch|whip|whipv|zoom|flash|circle|wipe|push, data-hold (show
  under the next scene's transition), data-o circle origin.
"""
import html as _html
import json
import re
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
CONTENT = Path("/home/claude/content")
sys.path.insert(0, str(CONTENT / "design"))
from engine.themes import font_css  # noqa: E402  (read-only import)

W, H, FPS = 1080, 1920, 30
MARKS = CONTENT / "design" / "assets" / "marks"

# ----------------------------------------------------------------------------- HTML helpers
_HL = re.compile(r"==(.+?)==")


def esc(s):
    return _html.escape(str(s), quote=False)


def words(text, t=0, st=0.06, wa="up", d=0.38, cls="", style=""):
    """Kinetic line(s): each word animates in with a stagger. ==x== = highlighter sweep. '|' = line break."""
    out = []
    for i, seg in enumerate(_HL.split(text)):
        hl = i % 2 == 1
        for part in re.split(r"(\|)", seg):
            if part == "|":
                out.append("<br>")
                continue
            for w in part.split():
                out.append(f'<span class="w{" hl" if hl else ""}">{esc(w)}</span>')
    return (f'<div class="words {cls}" data-a="words" data-t="{t}" data-st="{st}" data-wa="{wa}" '
            f'data-d="{d}" style="{style}">{" ".join(out)}</div>')


def el(inner, x=None, y=None, w=None, a="up", t=0, d=0.4, cls="", style="", **attrs):
    pos = "position:absolute;"
    if x is not None:
        pos += f"left:{x}px;"
    if y is not None:
        pos += f"top:{y}px;"
    if w is not None:
        pos += f"width:{w}px;"
    extra = "".join(f' data-{k}="{v}"' for k, v in attrs.items())
    return f'<div class="{cls}" data-a="{a}" data-t="{t}" data-d="{d}"{extra} style="{pos}{style}">{inner}</div>'


def count(frm, to, fmt="{:,.0f}", t=0, d=0.9, cls="", style="", x=None, y=None, w=None, **attrs):
    pos = "position:absolute;" + (f"left:{x}px;" if x is not None else "") + (f"top:{y}px;" if y is not None else "") \
        + (f"width:{w}px;" if w is not None else "")
    extra = "".join(f' data-{k}="{v}"' for k, v in attrs.items())
    return (f'<div class="{cls}" data-a="count" data-t="{t}" data-d="{d}" data-from="{frm}" data-to="{to}" '
            f"data-fmt='{fmt}'{extra} style=\"{pos}{style}\">{fmt.format(to)}</div>")


def caption(text, t=0.2, y=1268):
    """Burned-in caption band (sits inside the shared safe area, clear of right-rail buttons)."""
    return el(words(text, t=0, st=0.045, wa="fade", d=0.2, cls="cap-w"), x=80, y=y, w=840, a="up", t=t, d=0.3,
              cls="cap")


CHECK = ('<svg viewBox="0 0 24 24" width="1em" height="1em" style="vertical-align:-0.12em"><path d="M4 12.5l5 5L20 6.5" '
         'fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>')
DOWN = ('<svg viewBox="0 0 24 24" width="0.9em" height="0.9em" style="vertical-align:-0.1em"><path d="M12 3v17M5 13l7 7 7-7" '
        'fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>')
WARN = ('<svg viewBox="0 0 24 24" width="1em" height="1em" style="vertical-align:-0.14em"><path d="M12 3L2 21h20L12 3z" '
        'fill="currentColor"/><path d="M12 10v5M12 18v.5" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/></svg>')


class Video:
    def __init__(self, brand, name, theme_css, tag_html):
        self.brand, self.name, self.theme_css, self.tag_html = brand, name, theme_css, tag_html
        self.scenes = []

    def scene(self, s, e, inner, tin="cut", bg="var(--bg)", pattern="", td=0.28, origin="50% 50%", cls=""):
        self.scenes.append(dict(s=s, e=e, inner=inner, tin=tin, bg=bg, pattern=pattern, td=td, origin=origin,
                                cls=cls))

    @property
    def duration(self):
        return max(sc["e"] for sc in self.scenes)

    def html(self):
        secs = []
        for i, sc in enumerate(self.scenes):
            nxt = self.scenes[i + 1] if i + 1 < len(self.scenes) else None
            hold = nxt["td"] + 0.02 if nxt and nxt["tin"] in ("whip", "whipv", "circle", "wipe", "push", "zoom") else 0
            secs.append(
                f'<section class="scene {sc["cls"]}" data-s="{sc["s"]}" data-e="{sc["e"]}" data-in="{sc["tin"]}" '
                f'data-td="{sc["td"]}" data-hold="{hold}" data-o="{sc["origin"]}" style="z-index:{10 + i};'
                f'background:{sc["bg"]}"><div class="pat {sc["pattern"]}"></div><div class="cam">{sc["inner"]}</div>'
                f'</section>')
        segs = "".join(f'<div class="seg" data-s="{sc["s"]}" data-e="{sc["e"]}"><i></i></div>' for sc in self.scenes)
        return f"""<!doctype html><html><head><meta charset="utf-8"><style>{font_css()}{BASE_CSS}{self.theme_css}</style>
</head><body><div id="stage">{''.join(secs)}
<div id="chrome"><div id="prog">{segs}</div>{self.tag_html}</div><div id="flash"></div></div>
<script>window.DUR={self.duration};{ENGINE_JS}</script></body></html>"""


BASE_CSS = """
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1080px;height:1920px;overflow:hidden;background:#000}
#stage{position:relative;width:1080px;height:1920px;overflow:hidden;background:var(--bg)}
.scene{position:absolute;inset:0;display:none;overflow:hidden;transform-origin:50% 45%}
.cam{position:absolute;inset:0;transform-origin:50% 42%}
.pat{position:absolute;inset:-200px}
.words .w{display:inline-block;white-space:nowrap}
.words .w.hl{background-image:linear-gradient(var(--hl),var(--hl));background-repeat:no-repeat;
  background-position:0 88%;background-size:calc(var(--p,0)*100%) 46%;padding:0 .06em;margin:0 -.06em}
#chrome{position:absolute;inset:0;z-index:900;pointer-events:none}
#prog{display:none}
#prog .seg{flex:1;border-radius:4px;background:var(--prog-bg);overflow:hidden;box-shadow:0 0 0 1.5px rgba(0,0,0,.12)}
#prog .seg i{display:block;height:100%;width:0;background:var(--prog-fg)}
#flash{position:absolute;inset:0;background:#fff;opacity:0;z-index:950;pointer-events:none}
.cap{display:flex;justify-content:center;text-align:center}
.cap .words{display:inline-block;background:var(--cap-bg);color:var(--cap-ink);font:700 44px/1.28 Inter,sans-serif;
  padding:16px 28px 18px;border-radius:var(--cap-r);box-shadow:var(--cap-sh);border:var(--cap-bd);letter-spacing:-.01em}
.hlx{background-image:linear-gradient(var(--hl),var(--hl));background-repeat:no-repeat;
  background-position:0 88%;background-size:calc(var(--p,0)*100%) 46%;padding:0 .06em;margin:0 -.06em}
.dark .w.hl,.dark .hlx{background:none;color:var(--hl-dark)}
.strike{position:relative;display:inline-block}
.strike::after{content:"";position:absolute;left:-2%;top:52%;height:.12em;width:calc(var(--p,0)*104%);
  background:var(--strike);border-radius:.06em;transform:rotate(-3deg)}
"""

ENGINE_JS = r"""
const cl=x=>Math.max(0,Math.min(1,x));
const E={oc:x=>1-Math.pow(1-x,3),oq:x=>1-Math.pow(1-x,5),
 ob:x=>{const c1=2.0,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2)},
 oel:x=>x===0?0:x===1?1:Math.pow(2,-10*x)*Math.sin((x*10-.75)*(2*Math.PI)/3)+1};
const A={
 none:p=>({}),
 fade:p=>({o:p}),
 up:p=>({o:cl(p*2.5),ty:(1-E.oq(p))*80}),
 down:p=>({o:cl(p*2.5),ty:-(1-E.oq(p))*80}),
 left:p=>({o:cl(p*2.5),tx:-(1-E.oq(p))*160}),
 right:p=>({o:cl(p*2.5),tx:(1-E.oq(p))*160}),
 pop:p=>({o:cl(p*5),s:0.3+0.7*E.ob(p)}),
 slam:p=>({o:cl(p*6),s:1+1.4*(1-E.oq(p))}),
 stamp:p=>({o:cl(p*6),s:1+1.8*(1-E.oc(p)),r:-(1-E.oc(p))*16}),
 blur:p=>({o:cl(p*2),blur:(1-E.oc(p))*22,s:1.12-0.12*E.oc(p)}),
 drop:p=>({o:cl(p*4),ty:-(1-E.ob(p))*260}),
};
function fmt(f,v){ // python-ish "{:,.0f}" with prefix/suffix
 const m=f.match(/^(.*)\{:(,?)\.(\d)f\}(.*)$/); if(!m) return String(Math.round(v));
 let s=v.toFixed(+m[3]); if(m[2]){const [a,b]=s.split('.');s=a.replace(/\B(?=(\d{3})+(?!\d))/g,',')+(b?'.'+b:'');}
 return m[1]+s+m[4];}
function apply(el,st,base){
 const r=(st.r||0)+(+(el.dataset.rot||0));
 el.style.transform=`translate(${(st.tx||0).toFixed(1)}px,${(st.ty||0).toFixed(1)}px) rotate(${r.toFixed(2)}deg) scale(${(st.s??1).toFixed(4)})`;
 el.style.opacity=(st.o??1).toFixed(3);
 el.style.filter=st.blur>0.3?`blur(${st.blur.toFixed(1)}px)`:'none';
}
function animate(el,lt){
 const a=el.dataset.a,t0=+(el.dataset.t||0),d=+(el.dataset.d||0.4);
 const p=a==='none'?1:(d>0?cl((lt-t0)/d):(lt>=t0?1:0));
 let st={o:1};
 if(a==='words'){
  const ws=el.querySelectorAll('.w'),ss=+(el.dataset.st||0.06),wa=el.dataset.wa||'up';
  ws.forEach((w,i)=>{const pi=cl((lt-t0-i*ss)/d);apply(w,A[wa](pi),0);
   if(w.classList.contains('hl'))w.style.setProperty('--p',E.oc(cl((lt-t0-i*ss-d*0.6)/0.32)).toFixed(3));});
 } else if(a==='count'){
  const f=+el.dataset.from,to=+el.dataset.to;el.textContent=fmt(el.dataset.fmt,f+(to-f)*E.oq(p));
  st={o:cl(p*8),s:0.75+0.25*E.ob(cl(p*2.2))};
 } else if(a==='type'){
  if(!el.dataset.full)el.dataset.full=el.textContent;const full=el.dataset.full;
  const n=Math.floor(full.length*p);el.textContent=full.slice(0,n)+(p<1&&p>0?'▍':'');st={o:p>0?1:0};
 } else if(a==='bar'){
  const f=el.querySelector('.fill');if(f)f.style.width=(E.oc(p)*(+el.dataset.w||100)).toFixed(2)+'%';st={o:cl((lt-t0)*8+1)};
 } else if(a==='hl'||a==='strike'){
  el.style.setProperty('--p',E.oc(p).toFixed(3));st={o:1};
 } else if(a==='ripple'){
  st={o:lt<t0?0:(1-p)*0.9,s:0.2+1.6*E.oc(p)};
 } else if(a==='tick'){ // countdown digit: in then out within d
  const q=(lt-t0)/d;st=q<0||q>1?{o:0}:{o:q<0.8?1:cl((1-q)*5),s:1+0.9*(1-E.oq(cl(q*3)))};
 } else {
  st=Object.assign({o:1},A[a]?A[a](p):{});
 }
 if(el.dataset.x){const q=cl((lt-(+el.dataset.x))/0.22),xa=el.dataset.xa||'fade';
  if(q>0){st.o=(st.o??1)*(1-q);if(xa==='pop')st.s=(st.s??1)*(1-0.6*q);if(xa==='up')st.ty=(st.ty||0)-120*E.oc(q);
   if(xa==='left')st.tx=(st.tx||0)-400*E.oc(q);}}
 if(el.dataset.sh){const k=(lt-(+el.dataset.sh))/0.34;if(k>=0&&k<1){const amp=16*(1-k);
  st.tx=(st.tx||0)+amp*Math.sin(lt*95);st.ty=(st.ty||0)+amp*Math.cos(lt*71);}}
 if(el.dataset.br&&lt>t0+d){st.s=(st.s??1)*(1+0.035*Math.sin((lt-t0-d)*5.2));}
 apply(el,st);
}
function seek(t){
 let flash=0;
 document.querySelectorAll('.scene').forEach(sc=>{
  const s=+sc.dataset.s,e=+sc.dataset.e,hold=+(sc.dataset.hold||0);
  const vis=t>=s-1e-6&&t<e+hold;sc.style.display=vis?'block':'none';if(!vis)return;
  const lt=t-s,td=+(sc.dataset.td||0.28),p=cl(lt/td),q=E.oq(p),tin=sc.dataset.in;
  let tf='',fl='none',cp='none';
  if(tin==='whip'){tf=`translateX(${((1-q)*1080).toFixed(1)}px)`;if(p<1)fl=`blur(${((1-p)*26).toFixed(1)}px)`;}
  if(tin==='whipv'){tf=`translateY(${((1-q)*1920).toFixed(1)}px)`;if(p<1)fl=`blur(${((1-p)*26).toFixed(1)}px)`;}
  if(tin==='push'){tf=`translateY(${((1-q)*1920).toFixed(1)}px)`;}
  if(tin==='zoom'){tf=`scale(${(1+0.45*(1-q)).toFixed(4)})`;if(p<1)fl=`blur(${((1-p)*20).toFixed(1)}px)`;sc.style.opacity=cl(p*3);}
  if(tin==='punch'){const pp=cl(lt/0.5);tf=`scale(${(1+0.07*(1-E.oq(pp))).toFixed(4)})`;}
  if(tin==='circle')cp=`circle(${(E.oc(p)*150).toFixed(2)}% at ${sc.dataset.o})`;
  if(tin==='wipe')cp=`inset(0 ${((1-q)*100).toFixed(2)}% 0 0)`;
  if(tin==='flash'&&lt<0.17)flash=Math.max(flash,1-lt/0.17);
  sc.style.transform=tf;sc.style.filter=fl;sc.style.clipPath=cp;
  const cam=sc.firstElementChild.nextElementSibling;cam.style.transform=`scale(${(1+0.028*cl(lt/(e-s))).toFixed(4)})`;
  sc.firstElementChild.style.backgroundPosition=`${(lt*26).toFixed(1)}px ${(lt*-34).toFixed(1)}px`;
  sc.querySelectorAll('[data-a]').forEach(x=>animate(x,lt));
 });
 document.getElementById('flash').style.opacity=(flash*0.9).toFixed(3);
 document.querySelectorAll('#prog .seg').forEach(g=>{const s=+g.dataset.s,e=+g.dataset.e;
  g.firstElementChild.style.width=(cl((t-s)/(e-s))*100).toFixed(2)+'%';});
}
window.seek=seek;seek(0);
"""


# ----------------------------------------------------------------------------- render + QA
def render(video, out_mp4, cover_t=None, cover_png=None, fps=FPS):
    from playwright.sync_api import sync_playwright
    out_mp4 = Path(out_mp4)
    src = out_mp4.with_suffix(".html")
    work = Path(__file__).resolve().parent.parent / "build"
    work.mkdir(exist_ok=True)
    src = work / (out_mp4.stem + ".html")
    src.write_text(video.html(), encoding="utf-8")
    n = int(round(video.duration * fps))
    ff = subprocess.Popen(
        ["ffmpeg", "-y", "-loglevel", "error", "-f", "image2pipe", "-framerate", str(fps), "-c:v", "mjpeg", "-i", "-",
         "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", "-profile:v", "high",
         "-r", str(fps), "-movflags", "+faststart", "-an", str(out_mp4)], stdin=subprocess.PIPE)
    t0 = time.time()
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": W, "height": H}, device_scale_factor=1)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(300)
        for i in range(n):
            pg.evaluate(f"seek({i / fps:.5f})")
            ff.stdin.write(pg.screenshot(type="jpeg", quality=94))
        if cover_png is not None:
            pg.evaluate(f"seek({cover_t:.3f})")
            pg.screenshot(path=str(cover_png), type="png")
        br.close()
    ff.stdin.close()
    ff.wait()
    print(f"{out_mp4.name}: {n} frames in {time.time() - t0:.0f}s")
    return out_mp4


def contact_sheet(mp4, out_png, step=0.5, cols=8, tw=216):
    """Frames every `step` s -> labelled grid (thumbs at 216x384 = ~phone-in-feed size)."""
    from PIL import Image, ImageDraw, ImageFont
    import tempfile
    tmp = Path(tempfile.mkdtemp(dir=str(Path(out_png).parent)))
    subprocess.run(["ffmpeg", "-loglevel", "error", "-i", str(mp4), "-vf", f"fps={1 / step}", str(tmp / "f%03d.png")],
                   check=True)
    frames = sorted(tmp.glob("f*.png"))
    th = int(tw * 16 / 9)
    rows = (len(frames) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (tw + 8) + 8, rows * (th + 34) + 8), "#222")
    font = ImageFont.truetype(str(CONTENT / "design/assets/fonts/Inter-Bold.ttf"), 20)
    d = ImageDraw.Draw(sheet)
    for i, f in enumerate(frames):
        im = Image.open(f).convert("RGB").resize((tw, th), Image.LANCZOS)
        x, y = 8 + (i % cols) * (tw + 8), 8 + (i // cols) * (th + 34)
        sheet.paste(im, (x, y + 26))
        d.text((x, y + 2), f"{(i) * step:.1f}s", fill="#fff", font=font)
        f.unlink()
    tmp.rmdir()
    sheet.save(out_png)
    return out_png


def preview(video, times, out_png, tw=360):
    """Quick still check: screenshots at given times -> one labelled strip (no MP4)."""
    from playwright.sync_api import sync_playwright
    from PIL import Image, ImageDraw, ImageFont
    import io
    work = Path(__file__).resolve().parent.parent / "build"
    work.mkdir(exist_ok=True)
    src = work / f"{video.brand}-{video.name}-preview.html"
    src.write_text(video.html(), encoding="utf-8")
    th = int(tw * 16 / 9)
    cols = min(len(times), 6)
    rows = (len(times) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (tw + 8) + 8, rows * (th + 34) + 8), "#222")
    font = ImageFont.truetype(str(CONTENT / "design/assets/fonts/Inter-Bold.ttf"), 22)
    d = ImageDraw.Draw(sheet)
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu"])
        pg = br.new_page(viewport={"width": W, "height": H})
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(300)
        for i, t in enumerate(times):
            pg.evaluate(f"seek({t})")
            im = Image.open(io.BytesIO(pg.screenshot(type="png"))).convert("RGB").resize((tw, th), Image.LANCZOS)
            x, y = 8 + (i % cols) * (tw + 8), 8 + (i // cols) * (th + 34)
            sheet.paste(im, (x, y + 28))
            d.text((x, y + 2), f"{t:.2f}s", fill="#fff", font=font)
        br.close()
    sheet.save(out_png)
    return out_png
