#!/usr/bin/env python3
"""Steadfold slow-pan backgrounds, generated in code (no stock footage, no downloads).

Every generator returns a list of Layer objects (see slowpan.Layer): float32 images at SOURCE resolution
(output size x (1 + margin) x supersample), each with a parallax depth. The engine (slowpan.py) moves the layers
with subpixel-accurate resampling and adds film grain + vignette in screen space.

    sky(brand)      soft gradient sky + procedurally lit clouds (layered fBm noise), 3 layers
    paper(brand)    warm paper grain + light leak (+ optional bokeh), 2-3 layers
    forest(brand)   slow misty "forest-like" layered conifer silhouettes with valley fog, 6-7 layers
    blobs(brand)    abstract soft blobs (Littlefold Sherbet mesh), 3 layers
    bokeh / light_leak  extra layers usable on top of any of the above

Sizes are given in OUTPUT pixels and multiplied by `u` (source pixels per output pixel), so a generator looks the
same at any supersample factor. Colours are blended in OKLab for clean, non-muddy gradients.
"""
from __future__ import annotations

import cv2
import numpy as np

# ----------------------------------------------------------------------------- brand palettes (from themes.py)
PAL = {
    "fullyfunded": dict(
        sky=[(0.0, "#16228F"), (0.22, "#2436C9"), (0.46, "#5466EA"), (0.66, "#A9A6EE"), (0.80, "#FFC2A6"),
             (0.92, "#FFD9C9"), (1.0, "#FFE9DE")],
        sun=(0.72, 0.80, "#FFD2BC"), cloud_lit="#FFE6DA", cloud_shade="#4C5BD8", cloud_mid="#9AA3F2",
        paper="#FBF8F3", paper_tint="#FFF1E6", leak=["#FF8A5C", "#FFB08F", "#FFD7B8"],
        bokeh=["#FFE2D2", "#FFFFFF", "#DCE1FA"],
        fsky=[(0.0, "#1A2794"), (0.30, "#3A4DE0"), (0.55, "#8D96EE"), (0.72, "#F3BFB2"), (1.0, "#FFE3D6")],
        fsun=(0.62, 0.60, "#FFD7C4"), fog="#C9CDF6", trees=["#9EA6EE", "#6F7BE0", "#3E4CC4", "#1C2678", "#0E1440"]),
    "hourback": dict(
        sky=[(0.0, "#3B3196"), (0.18, "#5248BE"), (0.40, "#8C80E2"), (0.58, "#D2B9EC"), (0.72, "#FFC9A8"),
             (0.86, "#FFE2B4"), (1.0, "#FFF3DD")],
        sun=(0.30, 0.83, "#FFE7B0"), cloud_lit="#FFF1DE", cloud_shade="#5A50BF", cloud_mid="#B7A9EA",
        paper="#FFF6EA", paper_tint="#FFF0DC", leak=["#FF8A3D", "#FFC94D", "#FFB27A"],
        bokeh=["#FFE7B8", "#FFFFFF", "#FFD3A8"],
        fsky=[(0.0, "#2E2580"), (0.28, "#4F45B8"), (0.52, "#9C8DE0"), (0.68, "#F2B9B0"), (0.82, "#FFD7A8"),
              (1.0, "#FFEBC9")],
        fsun=(0.66, 0.64, "#FFE3B0"), fog="#D9CDEF", trees=["#B1A4E6", "#857AD6", "#5A50BF", "#332A7A", "#1E1846"]),
    "littlefold": dict(
        base="#FFF8E4", blobs=["#FFD6E3", "#FFA35C", "#BFE4FA", "#FFE27E", "#F7B6CB"],
        sky=[(0.0, "#BFE4FA"), (0.5, "#FFE4EC"), (1.0, "#FFF8E4")], sun=(0.5, 0.8, "#FFFFFF"),
        cloud_lit="#FFFFFF", cloud_shade="#E9B8CB", cloud_mid="#F6D9E4",
        paper="#FFF8E4", paper_tint="#FFF1D2", leak=["#FFA35C", "#FFD6E3", "#FFE27E"], bokeh=["#FFFFFF", "#FFD6E3"],
        fsky=[(0.0, "#BFE4FA"), (0.6, "#FFE4EC"), (1.0, "#FFF8E4")], fsun=(0.5, 0.6, "#FFFFFF"), fog="#FFE9F0",
        trees=["#F2C6D6", "#E59AB4", "#D9497A", "#A8325C", "#6E2440"]),
    "lockedhour": dict(
        sky=[(0.0, "#141414"), (0.5, "#2A2620"), (0.8, "#7A5E2A"), (1.0, "#FFD43B")], sun=(0.5, 0.9, "#FFD43B"),
        cloud_lit="#FFE9A8", cloud_shade="#232323", cloud_mid="#5A5040",
        paper="#FFF4E0", paper_tint="#FFE9C2", leak=["#FF5CA8", "#FFD43B", "#FFB04D"], bokeh=["#FFD43B", "#FFFFFF"],
        fsky=[(0.0, "#141414"), (0.6, "#3A3226"), (1.0, "#FFD43B")], fsun=(0.5, 0.7, "#FFE9A8"), fog="#5A5040",
        trees=["#4D463E", "#3A342C", "#262320", "#181614", "#0A0A0A"]),
}


# ----------------------------------------------------------------------------- colour helpers (sRGB <-> OKLab)
def hexrgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)], np.float32)


def _lin(c):
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _srgb(c):
    c = np.clip(c, 0, 1)
    return np.where(c <= 0.0031308, 12.92 * c, 1.055 * c ** (1 / 2.4) - 0.055)


def to_oklab(rgb):
    r, g, b = np.moveaxis(_lin(np.asarray(rgb, np.float64)), -1, 0)
    l_ = np.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b)
    m_ = np.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b)
    s_ = np.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b)
    return np.stack([0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_,
                     1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_,
                     0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_], -1)


def from_oklab(lab):
    L, a, b = np.moveaxis(np.asarray(lab, np.float64), -1, 0)
    l_ = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3
    m_ = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3
    s_ = (L - 0.0894841775 * a - 1.2914855480 * b) ** 3
    return _srgb(np.stack([4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_,
                           -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_,
                           -0.0041960863 * l_ - 0.7034186147 * m_ + 1.7076147010 * s_], -1)).astype(np.float32)


def ramp(stops, n):
    """n colours along a multi-stop gradient, interpolated in OKLab with smooth (cosine) easing per segment."""
    pos = np.array([p for p, _ in stops])
    labs = to_oklab(np.stack([hexrgb(c) for _, c in stops]))
    t = np.linspace(0, 1, n)
    i = np.clip(np.searchsorted(pos, t, side="right") - 1, 0, len(pos) - 2)
    f = np.clip((t - pos[i]) / np.maximum(pos[i + 1] - pos[i], 1e-6), 0, 1)
    f = 0.5 - 0.5 * np.cos(np.pi * f)
    return from_oklab(labs[i] * (1 - f)[:, None] + labs[i + 1] * f[:, None])


def mix(a, b, t):
    t = np.asarray(t, np.float32)
    if t.ndim == 2:
        t = t[..., None]
    return a * (1 - t) + b * t


def smoothstep(e0, e1, x):
    x = np.clip((x - e0) / (e1 - e0), 0, 1)
    return x * x * (3 - 2 * x)


# ----------------------------------------------------------------------------- noise
def value_noise(h, w, cell, rng, aniso=1.0):
    """Smooth value noise with features ~`cell` px tall and ~cell*aniso px wide (cubic-upsampled random grid)."""
    cx, cy = max(2, int(np.ceil(w / (cell * aniso)))) + 3, max(2, int(np.ceil(h / cell))) + 3
    grid = rng.random((cy, cx), dtype=np.float32)
    bw, bh = int(np.ceil(cx * cell * aniso)), int(np.ceil(cy * cell))
    big = cv2.resize(grid, (bw, bh), interpolation=cv2.INTER_CUBIC)
    oy = int(rng.integers(int(cell), max(int(cell) + 1, bh - h - int(cell))))
    ox = int(rng.integers(int(cell * aniso), max(int(cell * aniso) + 1, bw - w - int(cell * aniso))))
    return big[oy:oy + h, ox:ox + w]


def fbm(h, w, cell, rng, octaves=6, aniso=1.0, gain=0.5, lac=2.0, min_cell=1.5):
    """Fractal Brownian motion: octaves of value noise, normalised to roughly 0..1 around 0.5."""
    out = np.zeros((h, w), np.float32)
    amp, tot, c = 1.0, 0.0, float(cell)
    for _ in range(octaves):
        if c < min_cell:
            break
        out += amp * value_noise(h, w, c, rng, aniso)
        tot += amp
        amp *= gain
        c /= lac
    return out / tot


def soft_canvas(h, w, draw, down=8, blur=0.0):
    """Draw low-frequency shapes on a small canvas (fast), blur, and upsample smoothly to (h, w)."""
    sh, sw = max(4, h // down), max(4, w // down)
    can = draw(sh, sw, down)
    if blur > 0:
        can = cv2.GaussianBlur(can, (0, 0), blur / down)
    return cv2.resize(can, (w, h), interpolation=cv2.INTER_CUBIC)


# ----------------------------------------------------------------------------- layer container
class Layer:
    """One background plane. img: HxWx3 float32 (0..1); alpha: HxW float32 or None (opaque).
    depth: parallax multiplier for the camera move (1 = moves exactly with the camera move; 0 = still).
    drift: extra independent drift (dx, dy) as a fraction of output width per second (fog, light leaks).
    mode: 'normal' (alpha over) or 'screen' (light: img is added like light, alpha scales it)."""

    def __init__(self, img, alpha=None, depth=1.0, drift=(0.0, 0.0), mode="normal", name=""):
        self.img, self.alpha, self.depth, self.drift, self.mode, self.name = img, alpha, depth, drift, mode, name

    @property
    def shape(self):
        return self.img.shape[:2]


# ----------------------------------------------------------------------------- generators
def gradient_sky(h, w, stops, sun=None, u=1.0):
    col = ramp(stops, h)[:, None, :] * np.ones((1, w, 1), np.float32)
    if sun:
        sx, sy, scol = sun
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        d = np.sqrt(((xx - sx * w) / w) ** 2 + ((yy - sy * h) / w * 1.25) ** 2)
        g = np.exp(-(d / 0.55) ** 2) * 0.55 + np.exp(-(d / 0.16) ** 2) * 0.35
        c = hexrgb(scol)
        col = 1 - (1 - col) * (1 - c * g[..., None])        # screen the sun glow in
    return col.astype(np.float32)


def cloud_layer(h, w, u, rng, P, band=(0.08, 0.62), cover=0.52, cell=520, aniso=2.8, opacity=0.92,
                soft=0.16, sun=(0.7, 0.8), depth=1.0, name="clouds"):
    D = fbm(h, w, cell * u, rng, octaves=7, aniso=aniso, gain=0.47)
    D = (D - D.mean()) / (D.std() + 1e-6)
    yy = np.linspace(0, 1, h, dtype=np.float32)[:, None]
    vm = smoothstep(band[0] - 0.08, band[0] + 0.12, yy) * (1 - smoothstep(band[1] - 0.18, band[1] + 0.06, yy))
    macro = fbm(h, w, cell * 2.2 * u, rng, octaves=2, aniso=aniso * 0.7)
    macro = (macro - macro.mean()) / (macro.std() + 1e-6)
    thr = (0.5 - cover) * 2.2 - macro * 0.45
    dens = smoothstep(thr - soft * 2.5, thr + soft * 4, D) * vm
    # lighting: compare density with a copy shifted towards the sun (denser on the sun side = in shadow)
    sx, sy = sun[0] * w, sun[1] * h
    shift = 22 * u
    vx, vy = sx - w / 2, sy - h / 2
    n = np.hypot(vx, vy) + 1e-6
    M = np.float32([[1, 0, vx / n * shift], [0, 1, vy / n * shift]])
    Ds = cv2.warpAffine(D, M, (w, h), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
    light = np.clip(0.55 + (D - Ds) * 0.9, 0, 1)
    light = cv2.GaussianBlur(light, (0, 0), 3 * u)
    # clouds lower in the sky (nearer the sun's glow) are warmer
    warm = smoothstep(0.15, 0.75, yy) * np.ones((1, w), np.float32)
    lit, mid, shade = hexrgb(P["cloud_lit"]), hexrgb(P["cloud_mid"]), hexrgb(P["cloud_shade"])
    body = mix(mix(shade, mid, np.clip(light * 1.6, 0, 1)), lit, np.clip((light - 0.45) * 1.9, 0, 1))
    body = mix(body, mix(body, lit, 0.5), warm * 0.5)
    # thin edges glow (silver lining)
    edge = np.clip(dens * (1 - dens) * 4, 0, 1) * 0.25
    body = mix(body, lit, edge)
    alpha = cv2.GaussianBlur(dens, (0, 0), 1.2 * u) * opacity
    return Layer(body.astype(np.float32), alpha.astype(np.float32), depth=depth, name=name)


def sky(brand, w, h, u, seed=1, sun=None, clouds=True):
    """Soft gradient sky with two parallax cloud decks. Returns layers far -> near."""
    P = PAL[brand]
    rng = np.random.default_rng(seed)
    sun = sun or P["sun"]
    layers = [Layer(gradient_sky(h, w, P["sky"], sun, u), depth=0.25, name="sky")]
    if clouds:
        layers.append(cloud_layer(h, w, u, rng, P, band=(0.10, 0.70), cover=0.36, cell=760, aniso=2.6,
                                  opacity=0.55, soft=0.24, sun=sun[:2], depth=0.6, name="clouds-far"))
        layers.append(cloud_layer(h, w, u, rng, P, band=(0.34, 0.98), cover=0.36, cell=1000, aniso=2.2,
                                  opacity=0.88, soft=0.20, sun=sun[:2], depth=1.0, name="clouds-near"))
    return layers


def light_leak(brand, w, h, u, seed=2, strength=0.55, corner=(1.0, 0.0), depth=1.25, drift=(0.0, 0.0),
               tint=False):
    """Warm film light leak: big soft blooms of brand colour, added like light (screen). tint=True lays the warm
    glow over the picture as colour (for near-white paper, where screened light would be invisible)."""
    P = PAL[brand]
    rng = np.random.default_rng(seed)
    cols = [hexrgb(c) for c in P["leak"]]

    def draw(sh, sw, down):
        can = np.zeros((sh, sw, 3), np.float32)
        for k in range(5):
            cx = (corner[0] + rng.normal(0, 0.18)) * sw
            cy = (corner[1] + rng.uniform(0.0, 0.55) * (1 if corner[1] < 0.5 else -1)) * sh
            ax, ay = rng.uniform(0.25, 0.6) * sw, rng.uniform(0.15, 0.4) * sh
            m = np.zeros((sh, sw), np.float32)
            cv2.ellipse(m, (int(cx), int(cy)), (int(ax), int(ay)), float(rng.uniform(-40, 40)), 0, 360, 1.0, -1)
            can += m[..., None] * cols[k % len(cols)] * rng.uniform(0.35, 0.8)
        return can

    img = soft_canvas(h, w, draw, down=8, blur=240 * u)
    if tint:
        a = np.clip(img.max(-1), 0, None)
        col = img / np.maximum(a, 1e-4)[..., None]
        a = np.clip(a * strength, 0, 0.85)
        return Layer(np.clip(col, 0, 1).astype(np.float32), a.astype(np.float32), depth=depth, drift=drift,
                     name="light-leak")
    img = np.clip(img * strength, 0, 1)
    return Layer(img.astype(np.float32), None, depth=depth, drift=drift, mode="screen", name="light-leak")


def bokeh(brand, w, h, u, seed=3, n=26, rmin=14, rmax=64, strength=0.35, region=(0.0, 1.0), depth=1.5,
          mode="screen", drift=(0.0, 0.0)):
    """Out-of-focus highlights: soft discs with a faint bright rim (lens bokeh), sizes and brightness varied."""
    P = PAL[brand]
    rng = np.random.default_rng(seed)
    cols = [hexrgb(c) for c in P["bokeh"]]
    img = np.zeros((h, w, 3), np.float32)
    S = 4  # sub-pixel precision for cv2 drawing
    for i in range(n):
        r = rng.uniform(rmin, rmax) ** 1.0 * u
        cx, cy = rng.uniform(0, w), rng.uniform(region[0], region[1]) * h
        disc = np.zeros((h, w), np.float32)
        x0, y0, x1, y1 = int(max(0, cx - r * 1.6)), int(max(0, cy - r * 1.6)), int(min(w, cx + r * 1.6)), \
            int(min(h, cy + r * 1.6))
        if x1 <= x0 or y1 <= y0:
            continue
        sub = disc[y0:y1, x0:x1]
        c = (int((cx - x0) * (1 << S)), int((cy - y0) * (1 << S)))
        cv2.circle(sub, c, int(r * (1 << S)), 0.75, -1, cv2.LINE_AA, S)
        cv2.circle(sub, c, int(r * 0.93 * (1 << S)), 1.0, max(1, int(r * 0.07)), cv2.LINE_AA, S)
        sub[:] = cv2.GaussianBlur(sub, (0, 0), max(0.8, r * 0.05))
        b = rng.uniform(0.35, 1.0) * (0.6 if r > 0.7 * rmax * u else 1.0)
        img[y0:y1, x0:x1] += sub[..., None] * cols[i % len(cols)] * b
    img = np.clip(img * strength, 0, 1)
    if mode == "screen":
        return Layer(img, None, depth=depth, drift=drift, mode="screen", name="bokeh")
    a = np.clip(img.max(-1) / max(strength, 1e-6), 0, 1) * strength
    return Layer(np.ones_like(img) * cols[0], a, depth=depth, drift=drift, name="bokeh")


def paper(brand, w, h, u, seed=4, leak=True, bokeh_n=0, leak_strength=0.42):
    """Warm paper: tinted base, low-frequency mottling, fibres and fine tooth. Optional light leak + bokeh."""
    P = PAL[brand]
    rng = np.random.default_rng(seed)
    base, tint = hexrgb(P["paper"]), hexrgb(P["paper_tint"])
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    g = smoothstep(0.0, 1.0, (xx / w * 0.6 + yy / h * 0.4))
    img = mix(base, tint, g)
    mott = fbm(h, w, 360 * u, rng, octaves=5) - 0.5
    fib1 = fbm(h, w, 5 * u, rng, octaves=3, aniso=2.5) - 0.5
    fib2 = fbm(h, w, 7 * u, rng, octaves=2, aniso=0.2) - 0.5
    tooth = cv2.GaussianBlur(rng.standard_normal((h, w), dtype=np.float32), (0, 0), 0.8 * u)
    shade = 1 + mott * 0.06 + fib1 * 0.014 + fib2 * 0.01 + tooth * 0.014
    img = np.clip(img * shade[..., None], 0, 1)
    layers = [Layer(img.astype(np.float32), depth=0.6, name="paper")]
    if leak:
        layers.append(light_leak(brand, w, h, u, seed=seed + 10, strength=leak_strength, corner=(1.0, 0.0),
                                 depth=1.2, drift=(-0.002, 0.0), tint=True))
    if bokeh_n:
        layers.append(bokeh(brand, w, h, u, seed=seed + 20, n=bokeh_n, rmin=18, rmax=70, strength=0.22,
                            region=(0.0, 0.55), depth=1.6, mode="normal"))
    return layers


# --- forest -----------------------------------------------------------------------------------------------------
def _noise1d(n, cell, rng, octaves=4):
    out = np.zeros(n, np.float32)
    amp, tot = 1.0, 0.0
    c = cell
    for _ in range(octaves):
        k = int(np.ceil(n / c)) + 4
        g = rng.random(k).astype(np.float32)
        big = cv2.resize(g[None, :], (int(k * c), 1), interpolation=cv2.INTER_CUBIC)[0]
        off = int(rng.integers(0, max(1, len(big) - n)))
        out += amp * big[off:off + n]
        tot += amp
        amp *= 0.5
        c /= 2
    return out / tot - 0.5


def treeline_alpha(h, w, u, rng, base_y, tree_h, spacing, ridge_amp, ridge_cell, ss=2):
    """Coverage mask of a conifer treeline on a gentle ridge, drawn with polygons at ss x for anti-aliasing."""
    from PIL import Image, ImageDraw
    W2, H2 = w * ss, h * ss
    im = Image.new("L", (W2, H2), 0)
    d = ImageDraw.Draw(im)
    ridge = base_y + ridge_amp * _noise1d(w + 1, ridge_cell, rng) * 2
    lift = tree_h * 0.32   # the lower third of the trees is one solid mass (no gaps between trunks)
    pts = [(0, H2)] + [(x * ss, (ridge[x] - lift) * ss) for x in range(0, w + 1, 4)] + [(W2, H2)]
    d.polygon(pts, fill=255)
    x = -tree_h * 0.3
    while x < w + tree_h * 0.3:
        th = tree_h * rng.uniform(0.62, 1.12)
        hw = th * rng.uniform(0.12, 0.165)
        xi = int(np.clip(x, 0, w))
        yb = ridge[xi] + th * 0.08
        top = yb - th
        lean = rng.normal(0, 0.02) * th
        tiers = int(rng.integers(11, 18))
        left, right = [], []
        for k in range(1, tiers + 1):
            f = k / tiers
            y = top + th * 0.95 * f + rng.normal(0, th * 0.006)
            env = (0.08 + 0.92 * f ** 0.9)
            cxk = x + lean * (1 - f)
            for side, acc in ((-1, left), (1, right)):
                half = hw * env * rng.uniform(0.7, 1.18)
                acc += [(cxk + side * half, y + rng.uniform(0, th / tiers * 0.25)),
                        (cxk + side * half * rng.uniform(0.55, 0.78), y - th / tiers * rng.uniform(0.15, 0.35))]
        poly = [(x + lean, top - th * 0.02)] + left[:-1] + [(x - hw * 0.1, yb + th * 0.12),
                                                            (x + hw * 0.1, yb + th * 0.12)] + right[:-1][::-1]
        d.polygon([(px * ss, py * ss) for px, py in poly], fill=255)
        x += th * spacing * rng.uniform(0.35, 1.25)
    a = np.asarray(im, np.float32) / 255
    return cv2.resize(a, (w, h), interpolation=cv2.INTER_AREA), ridge


def fog_layer(h, w, u, rng, color, y0, y1, density=0.75, cell=260, aniso=5.0, depth=1.0, drift=(0.0, 0.0),
              name="fog"):
    """Horizontal mist band between y0 and y1 (fractions): wispy fBm, thickest in the middle-low of the band."""
    yy = np.linspace(0, 1, h, dtype=np.float32)[:, None]
    band = smoothstep(y0, y0 + (y1 - y0) * 0.45, yy) * (1 - smoothstep(y0 + (y1 - y0) * 0.6, y1, yy))
    N = fbm(h, w, cell * u, rng, octaves=6, aniso=aniso, gain=0.55)
    N = smoothstep(0.30, 0.72, N)
    a = np.clip(band * (0.35 + 0.65 * N) * density, 0, 1)
    img = np.ones((h, w, 3), np.float32) * hexrgb(color)
    return Layer(img, a.astype(np.float32), depth=depth, drift=drift, name=name)


def forest(brand, w, h, u, seed=5, horizon=0.50, sun=None):
    """Slow misty forest: gradient sky, a hazy far ridge, three conifer treelines (atmospheric perspective: far =
    paler, near = darkest), and drifting mist between them. Layers far -> near with rising parallax depth."""
    P = PAL[brand]
    rng = np.random.default_rng(seed)
    sun = sun or P["fsun"]
    fog = hexrgb(P["fog"])
    layers = [Layer(gradient_sky(h, w, P["fsky"], sun, u), depth=0.15, name="sky")]
    tc = [hexrgb(c) for c in P["trees"]]
    yy = np.linspace(0, 1, h, dtype=np.float32)[:, None]
    specs = [  # base_y, tree_h, spacing, ridge_amp, depth, colour idx, fog mix at foot, blur (output px)
        (horizon + 0.015, 0.050, 0.16, 0.045, 0.30, 0, 0.70, 2.2),
        (horizon + 0.075, 0.075, 0.16, 0.040, 0.45, 0, 0.65, 1.6),
        (horizon + 0.150, 0.110, 0.17, 0.035, 0.62, 1, 0.62, 1.1),
        (horizon + 0.250, 0.165, 0.18, 0.030, 0.82, 2, 0.55, 0.8),
        (horizon + 0.380, 0.250, 0.19, 0.025, 1.08, 3, 0.40, 1.4),
    ]
    for i, (by, th, sp, ra, dep, ci, fm, bl) in enumerate(specs):
        a, ridge = treeline_alpha(h, w, u, rng, by * h, th * h, sp, ra * h, 0.35 * w, ss=2)
        if bl > 0:
            a = cv2.GaussianBlur(a, (0, 0), bl * u)
        rtop = float(np.min(ridge)) / h
        # each treeline fades into the mist towards its foot (valley fog), and is paler the farther it is
        fadev = smoothstep(rtop - th * 0.7, rtop + th * 0.75, yy)
        far = (len(specs) - 1 - i) / (len(specs) - 1)
        c0 = mix(tc[ci], fog, far * 0.45)
        col = mix(c0, fog, fadev * fm) * np.ones((1, w, 1), np.float32)
        col = np.clip(col + (fbm(h, w, 90 * u, rng, octaves=3) - 0.5)[..., None] * 0.03, 0, 1)
        layers.append(Layer(col.astype(np.float32), a, depth=dep, name=f"trees-{i}"))
        # drifting mist in front of this treeline's foot
        layers.append(fog_layer(h, w, u, rng, P["fog"], rtop - th * 0.1, rtop + th * 1.6,
                                density=0.72 - 0.07 * i, cell=200 + 50 * i, depth=dep,
                                drift=((-1) ** i * 0.0022, 0.0), name=f"mist-{i}"))
    # a low ground haze over everything near the bottom
    layers.append(fog_layer(h, w, u, rng, P["fog"], 0.80, 1.25, density=0.55, cell=320, depth=1.15,
                            drift=(0.003, 0.0), name="ground-haze"))
    return _merge_static_pairs(layers)


def _merge_static_pairs(layers):
    """Keep layer count modest for speed: fold layers whose depth and drift are equal into one (alpha over)."""
    out = []
    for L in layers:
        if out and out[-1].depth == L.depth and out[-1].drift == L.drift and L.mode == "normal" \
                and out[-1].mode == "normal":
            P = out[-1]
            a1 = P.alpha if P.alpha is not None else np.ones(P.shape, np.float32)
            a2 = L.alpha if L.alpha is not None else np.ones(L.shape, np.float32)
            ao = a2 + a1 * (1 - a2)
            img = (L.img * a2[..., None] + P.img * (a1 * (1 - a2))[..., None]) / np.maximum(ao, 1e-6)[..., None]
            out[-1] = Layer(img.astype(np.float32), None if P.alpha is None else ao, P.depth, P.drift, "normal",
                            P.name + "+" + L.name)
        else:
            out.append(L)
    return out


def blobs(brand, w, h, u, seed=6, n=7):
    """Littlefold 'Sherbet' mesh: big soft organic blobs of pink / peach / baby blue / butter on butter paper,
    in two parallax planes, with a faint paper tooth."""
    P = PAL[brand]
    rng = np.random.default_rng(seed)
    base = np.ones((h, w, 3), np.float32) * hexrgb(P["base"])
    tooth = cv2.GaussianBlur(rng.standard_normal((h, w), dtype=np.float32), (0, 0), 0.8 * u)
    base = np.clip(base * (1 + tooth * 0.008 + (fbm(h, w, 300 * u, rng, 4) - 0.5) * 0.04)[..., None], 0, 1)
    layers = [Layer(base, depth=0.3, name="butter")]
    cols = [hexrgb(c) for c in P["blobs"]]
    for plane, (depth, k0, k1) in enumerate([(0.6, 0, n // 2 + 1), (1.15, n // 2 + 1, n)]):
        img = np.zeros((h, w, 3), np.float32)
        acc = np.zeros((h, w), np.float32)
        for k in range(k0, k1):
            col = cols[k % len(cols)]
            R = rng.uniform(0.22, 0.42) * w
            cx, cy = rng.uniform(-0.1, 1.1) * w, rng.uniform(-0.05, 1.05) * h
            ph = rng.uniform(0, 2 * np.pi, 4)
            amps = rng.uniform(0.05, 0.16, 4)

            def draw(sh, sw, down, R=R, cx=cx, cy=cy, ph=ph, amps=amps):
                th = np.linspace(0, 2 * np.pi, 180, endpoint=False)
                r = R * (1 + sum(amps[j] * np.sin((j + 2) * th + ph[j]) for j in range(4)))
                pts = np.stack([cx + r * np.cos(th), cy + r * np.sin(th) * 0.9], 1) / down
                m = np.zeros((sh, sw), np.float32)
                cv2.fillPoly(m, [np.round(pts * 16).astype(np.int32)], 1.0, cv2.LINE_AA, 4)
                return m

            m = soft_canvas(h, w, draw, down=8, blur=R * 0.22)
            m = np.clip(m, 0, 1) * rng.uniform(0.75, 0.95)
            img = img * (1 - m[..., None]) + col * m[..., None]
            acc = m + acc * (1 - m)
        img = img / np.maximum(acc, 1e-6)[..., None]
        layers.append(Layer(np.clip(img, 0, 1).astype(np.float32), acc.astype(np.float32), depth=depth,
                            drift=((-1) ** plane * 0.002, 0.0), name=f"blobs-{plane}"))
    return layers


def image_layers(path, w, h):
    """User-supplied still: cover-fit into the source canvas (centre crop), as one opaque layer."""
    im = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if im is None:
        raise FileNotFoundError(path)
    im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    return [Layer(cover_fit(im, w, h), depth=1.0, name="image")]


def cover_fit(im, w, h):
    ih, iw = im.shape[:2]
    s = max(w / iw, h / ih)
    nw, nh = int(np.ceil(iw * s)), int(np.ceil(ih * s))
    big = cv2.resize(im, (nw, nh), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
    x0, y0 = (nw - w) // 2, (nh - h) // 2
    return np.ascontiguousarray(big[y0:y0 + h, x0:x0 + w])


GENERATORS = {"sky": sky, "paper": paper, "forest": forest, "blobs": blobs}
