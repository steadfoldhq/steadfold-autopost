#!/usr/bin/env python3
"""Fully Funded Reel ff-reel-1015-start-at-birth: every number on screen and in the caption comes from here.
Worked example only, any currency, no outside figures. 6% a year, compounded monthly (0.5% a month),
100 paid in at the end of each month. Before fees, tax and inflation. Not guaranteed.

    python3 ff_start_at_birth_math.py
"""
P, RATE = 100, 0.06
r = RATE / 12                     # compounded monthly: 0.5% a month


def fv(months, pay=P):
    """Future value of `pay` at the end of every month for `months` months."""
    return pay * ((1 + r) ** months - 1) / r


def grow(x, months):
    return x * (1 + r) ** months


birth_18 = fv(18 * 12)            # 216 deposits
age10_18 = fv(8 * 12)             # 96 deposits
paid_birth, paid_10 = P * 216, P * 96
at_65 = grow(birth_18, (65 - 18) * 12)   # left untouched 18 -> 65, same 6% compounded monthly
at_65_annual = birth_18 * (1 + RATE) ** 47  # the brief's 599,000 used yearly compounding for this leg

print(f"Monthly rate: {r:.4%}")
print(f"Start at birth, 100 a month to 18: {birth_18:,.0f}  (paid in {paid_birth:,})")
print(f"Start at 10, 100 a month to 18:   {age10_18:,.0f}  (paid in {paid_10:,})")
print(f"Birth-to-18 pot left untouched to 65 (monthly compounding): {at_65:,.0f}")
print(f"  (same leg compounded yearly instead: {at_65_annual:,.0f}; not used, the caption says 'compounded monthly')")
print(f"Gap at 18: {birth_18 - age10_18:,.0f} more; {birth_18 / age10_18:.2f}x the money for "
      f"{paid_birth / paid_10:.2f}x the deposits")

# On-screen roundings
assert round(birth_18, -2) == 38_700
assert round(age10_18, -2) == 12_300
assert round(at_65, -3) == 645_000
assert round(at_65_annual, -3) == 599_000
print("On screen: 38,700 · 12,300 · 645,000 -> OK")
