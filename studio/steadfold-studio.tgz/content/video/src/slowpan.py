#!/usr/bin/env python3
"""Steadfold slow-pan video engine: a calm camera move on the BACKGROUND, a completely static TEXT layer on top.

Why it can't shimmer
  * The text is rendered ONCE per scene by Playwright into a 1080-wide PNG with alpha. It never goes through a
    transform, a resample or the camera: ffmpeg overlays the same PNG pixels at (0, 0) on every frame.
  * Only the background moves. Each background layer is generated at 2x supersample (plus a margin for the move),
    warped with a sub-pixel affine (cv2 bicubic, float32), then box-downsampled 2x (INTER_AREA) to the output size,
    so a slow 30-40 px pan glides smoothly instead of stepping pixel by pixel or pulsing in sharpness.
  * Film grain and the vignette live in screen space under the text. QA (jitter_check) proves it: in fully opaque
    text pixels, consecutive frames are bit-identical before encoding, and differ only by H.264 noise after.

Moves (Move): pan left/right, push-in (Ken Burns), parallax (layers move by their depth), with sine ease in/out.
Backgrounds: slowpan_bg generators (sky, paper, forest, blobs, light leak, bokeh), or a user file:
    Scene(bg="footage/clip.mp4", ...)   # any video ffmpeg can read: cover-fitted, looped if short, slow-panned
    Scene(bg="photos/lake.jpg", ...)    # any still image
    Scene(bg=lambda w, h, u: [...])     # any callable returning slowpan_bg.Layer objects

    from slowpan import Scene, Move, render
    render([Scene(bg=("sky", "hourback", 3), text=html, dur=5, move=Move(pan=0.03))], "out.mp4",
           size=(1080, 1920), music=("hourback", "warm"))
"""
from __future__ import annotations

import multiprocessing as mp
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import cv2
import numpy as np

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, "/home/claude/content/design")
import slowpan_bg as B  # noqa: E402

V = Path("/home/claude/content/video")
BUILD = V / "build" / "slowpan"
FPS = 30
REEL, FEED = (1080, 1920), (1080, 1350)
cv2.setNumThreads(1)  # we parallelise over frames instead


# ----------------------------------------------------------------------------- scene description
@dataclass
class Move:
    """Camera move over the scene. pan: total horizontal travel as a fraction of the output width (+ = camera
    pans right, so the picture slides left; - = pans left). push: zoom gained over the scene (0.03 = 1.00 -> 1.03).
    parallax: layers move by their depth (far layers less, near layers more); False = one flat plane.
    tilt: vertical travel (fraction of width). focus: zoom centre (fractions of the frame)."""
    pan: float = 0.03
    push: float = 0.0
    tilt: float = 0.0
    parallax: bool = True
    focus: tuple = (0.5, 0.45)

    def at(self, p, depth):
        d = depth if self.parallax else 1.0
        return 1.0 + self.push * p * d, self.pan * (p - 0.5) * d, self.tilt * (p - 0.5) * d


def ease(x):
    """Sine ease in-out: starts and ends at rest, no visible acceleration."""
    x = min(max(x, 0.0), 1.0)
    return 0.5 - 0.5 * np.cos(np.pi * x)


@dataclass
class Scene:
    bg: Any                    # ("sky"|"paper"|"forest"|"blobs", brand, seed[, kwargs]) | path | callable | layers
    text: str                  # HTML for the static text layer (absolute positioned; transparent page)
    dur: float = 6.0
    move: Move = field(default_factory=Move)
    css: str = ""              # extra CSS for the text page
    grain: float = 0.022       # film grain strength (std dev, 0..1 scale, before luma weighting)
    vignette: float = 0.16     # corner darkening
    loop: float = 0.0          # >0: last `loop` s cross-fade back to frame 0 so the clip loops seamlessly
    text_in: float = 0.0       # text fade-in (s) at the scene start (0 = on screen from frame 0)
    text_out: float = 0.0      # text fade-out (s) at the scene end
    ss: int = 2                # background supersample factor (video backgrounds use 1)
    margin: float = 0.12       # background over-scan for the move (total, both sides)
    seed: int = 0


# ----------------------------------------------------------------------------- background frame renderer
class BG:
    """Builds the layers for one scene and renders background frame i as float32 RGB at output size."""

    def __init__(self, scene: Scene, size):
        self.sc, self.size = scene, size
        self.shapes = None
        self.ow, self.oh = size
        self.video = None
        bg = scene.bg
        is_video = isinstance(bg, (str, Path)) and str(bg).lower().endswith((".mp4", ".mov", ".m4v", ".webm", ".mkv"))
        self.ss = 1 if is_video else scene.ss
        self.sw = int(round(self.ow * (1 + scene.margin) * self.ss / 2) * 2)
        self.sh = int(round(self.oh * (1 + scene.margin) * self.ss / 2) * 2)
        u = self.ss                                          # source px per output px at zoom 1
        if is_video:
            self.video = VideoSource(bg, self.sw, self.sh)
            self.layers = None
        elif isinstance(bg, (str, Path)):
            self.layers = B.image_layers(bg, self.sw, self.sh)
        elif callable(bg):
            self.layers = bg(self.sw, self.sh, u)
        elif isinstance(bg, tuple):
            kind, brand, seed, *kw = bg
            self.layers = B.GENERATORS[kind](brand, self.sw, self.sh, u, seed=seed, **(kw[0] if kw else {}))
        else:
            self.layers = list(bg)
        if self.layers is not None:
            self._premultiply()
        self._check_margin()
        yy, xx = np.mgrid[0:self.oh, 0:self.ow].astype(np.float32)
        r = np.sqrt(((xx - self.ow / 2) / (self.ow / 2)) ** 2 * 0.85 + ((yy - self.oh / 2) / (self.oh / 2)) ** 2 * 0.65)
        self.vig = (1 - scene.vignette * B.smoothstep(0.45, 1.25, r)).astype(np.float32)[..., None]
        self._f0 = None

    def _premultiply(self):
        """Store every layer as 4-channel premultiplied RGBA so one warp moves colour + coverage together."""
        self.packed = []
        for L in self.layers:
            a = L.alpha if L.alpha is not None else np.ones(L.shape, np.float32)
            # 16-bit premultiplied RGBA: half the memory of float32, still 256 levels per 8-bit step
            rgba = np.empty(L.shape + (4,), np.uint16)
            for c in range(3):
                rgba[..., c] = np.clip(L.img[..., c] * a * 65535 + 0.5, 0, 65535)
            rgba[..., 3] = np.clip(a * 65535 + 0.5, 0, 65535)
            L.img = L.alpha = None            # free the float copies
            self.packed.append((rgba, L))
        import gc
        gc.collect()

    def _check_margin(self):
        mv, sc = self.sc.move, self.sc
        depths = [L.depth for L in self.layers] if self.layers else [1.0]
        drifts = [abs(L.drift[0]) * sc.dur for L in self.layers] if self.layers else [0.0]
        need = max(abs(mv.pan) / 2 * (d if mv.parallax else 1) + dr for d, dr in zip(depths, drifts))
        need = max(need, max(abs(mv.tilt) / 2 * (d if mv.parallax else 1) for d in depths) * self.ow / self.oh)
        if need > sc.margin / 2 - 0.004:
            raise ValueError(f"move needs {need:.3f} of the width per side but margin gives {sc.margin / 2:.3f}")

    def matrix(self, t, depth, drift):
        """2x3 inverse map: output-ss pixel -> source pixel, for layer depth/drift at time t (sub-pixel exact)."""
        sc, mv = self.sc, self.sc.move
        p = ease(t / sc.dur)
        z, ox, oy = mv.at(p, depth)
        ox = ox * self.ow + drift[0] * self.ow * t
        oy = oy * self.ow + drift[1] * self.ow * t
        dw, dh = self.ow * self.ss, self.oh * self.ss
        fx, fy = mv.focus[0] * (dw - 1), mv.focus[1] * (dh - 1)
        csx, csy, cdx, cdy = (self.sw - 1) / 2, (self.sh - 1) / 2, (dw - 1) / 2, (dh - 1) / 2
        a = 1.0 / z
        bx = csx + (fx - cdx) + ox * self.ss - fx * a
        by = csy + (fy - cdy) + oy * self.ss - fy * a
        return np.array([[a, 0, bx], [0, a, by]], np.float64)

    def raw(self, i):
        """Background frame i (float32, 0..1), before grain/vignette."""
        t = i / FPS
        dw, dh = self.ow * self.ss, self.oh * self.ss
        if self.video is not None:
            src = self.video.frame(i)
            M = self.matrix(t, 1.0, (0, 0))
            w = cv2.warpAffine(src, M, (dw, dh), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP,
                               borderMode=cv2.BORDER_REFLECT101)
            return np.clip(w if self.ss == 1 else cv2.resize(w, (self.ow, self.oh), interpolation=cv2.INTER_AREA), 0, 1)
        out = np.zeros((self.oh, self.ow, 3), np.float32)
        for rgba, L in self.packed:
            M = self.matrix(t, L.depth, L.drift)
            w = cv2.warpAffine(rgba, M, (dw, dh), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP,
                               borderMode=cv2.BORDER_REFLECT101)
            if self.ss != 1:
                w = cv2.resize(w, (self.ow, self.oh), interpolation=cv2.INTER_AREA)
            w = w.astype(np.float32) * (1 / 65535)
            c, a = np.clip(w[..., :3], 0, 1), np.clip(w[..., 3:], 0, 1)
            if L.mode == "screen":
                out = 1 - (1 - out) * (1 - c)
            else:
                out = c + out * (1 - a)
        return out

    def frame(self, i, n):
        f = self.raw(i)
        sc = self.sc
        if sc.loop > 0:                         # seamless loop: fade back into frame 0 over the last `loop` s
            t, T = i / FPS, n / FPS
            w = B.smoothstep(T - sc.loop, T, t + 1 / FPS) if t > T - sc.loop - 1 / FPS else 0.0
            if w > 0:
                if self._f0 is None:
                    self._f0 = self.raw(0)
                f = f * (1 - w) + self._f0 * w
        f = f * self.vig
        if sc.grain > 0:                        # film grain: fresh every frame, soft clumps, strongest in mid-tones
            rng = np.random.default_rng(sc.seed * 100003 + i + 1000)
            g = cv2.GaussianBlur(rng.standard_normal((self.oh, self.ow), dtype=np.float32), (0, 0), 0.65)
            luma = f @ np.float32([0.2126, 0.7152, 0.0722])
            wgt = 0.35 + 2.6 * luma * (1 - luma)
            f = f + (g * wgt * sc.grain)[..., None]
        return np.clip(f * 255 + 0.5, 0, 255).astype(np.uint8)


class VideoSource:
    """User footage as a background: decoded by ffmpeg, cover-fitted + centre-cropped to the source canvas, 30 fps,
    looped if it is shorter than the scene. Frames are read sequentially."""

    def __init__(self, path, w, h):
        if not Path(path).is_file():
            raise FileNotFoundError(path)
        self.w, self.h, self.i = w, h, -1
        self.p = subprocess.Popen(
            ["ffmpeg", "-loglevel", "error", "-stream_loop", "-1", "-i", str(path), "-an", "-vf",
             f"fps={FPS},scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},format=rgb24",
             "-f", "rawvideo", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)  # killed on purpose
        self.cur = None

    def frame(self, i):
        while self.i < i:
            buf = self.p.stdout.read(self.w * self.h * 3)
            if len(buf) < self.w * self.h * 3:
                raise RuntimeError("background video ended unexpectedly")
            self.cur = np.frombuffer(buf, np.uint8).reshape(self.h, self.w, 3).astype(np.float32) / 255
            self.i += 1
        return self.cur

    def close(self):
        self.p.kill()


_W: dict = {}


def _work(i):
    return _W["bg"].frame(i, _W["n"]).tobytes()


def bg_frames(scene: Scene, size, procs=None, lo=0, hi=None):
    """Yield background frames lo..hi-1 (uint8 RGB bytes; indices may run past the scene edges for cross-fades),
    rendered in parallel across CPU cores for generated layers, sequentially for video footage."""
    t0 = time.time()
    bg = BG(scene, size)
    n = int(round(scene.dur * FPS))
    hi = n if hi is None else hi
    print(f"  bg ready ({time.time() - t0:.0f}s, {len(bg.layers or [])} layers, source {bg.sw}x{bg.sh})", flush=True)
    if bg.video is not None:
        for i in range(lo, hi):
            yield bg.frame(i, n).tobytes()
        bg.video.close()
        return
    _W.update(bg=bg, n=n)
    procs = procs or max(1, os.cpu_count() or 1)
    if procs == 1:
        for i in range(lo, hi):
            yield _work(i)
        return
    with mp.get_context("fork").Pool(procs) as pool:
        yield from pool.imap(_work, range(lo, hi), chunksize=2)


# ----------------------------------------------------------------------------- static text layer (Playwright)
TEXT_BASE = "*{box-sizing:border-box;margin:0;padding:0}html,body{background:transparent;overflow:hidden}"


def text_png(html, css, size, out_png):
    """Render the static text layer: transparent page, brand fonts, PNG with alpha. Returns the alpha array."""
    from playwright.sync_api import sync_playwright
    from engine.themes import font_css
    w, h = size
    page = (f"<!doctype html><html><head><meta charset='utf-8'><style>{font_css('littlefold')}{TEXT_BASE}"
            f"html,body{{width:{w}px;height:{h}px}}{css}</style></head><body>{html}</body></html>")
    src = Path(out_png).with_suffix(".html")
    src.write_text(page, encoding="utf-8")
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(250)
        pg.screenshot(path=str(out_png), type="png", omit_background=True)
        br.close()
    im = cv2.imread(str(out_png), cv2.IMREAD_UNCHANGED)
    return im[..., 3]


# ----------------------------------------------------------------------------- render (background pipe + ffmpeg)
def render(scenes, out_mp4, size=REEL, music=None, xfade=0.5, crf=19, maxrate="9M", lufs=-14.0,
           lossless_qa=True, procs=None, persist=None, persist_css="", text_gap=0.08):
    """Render scenes to an H.264/AAC MP4. Backgrounds cross-fade between scenes (`xfade` s, centred on the cut);
    each scene's text PNG is overlaid by ffmpeg, unchanged, with optional fades only at its edges.
    music = (brand, style[, seed]) -> music2.render; or a path to a wav; or None (silent track is still added).
    Text never double-exposes: the outgoing text fades out just before the cut and the incoming text fades in just
    after it (each over xfade/2 - text_gap s) while the backgrounds cross-fade underneath.
    persist = HTML for a layer that stays on screen, unchanged, for the whole video (e.g. the brand chip).
    Returns a dict with the text layers + static windows for jitter_check."""
    import music2
    out_mp4 = Path(out_mp4)
    BUILD.mkdir(parents=True, exist_ok=True)
    stem = out_mp4.stem
    W, H = size
    # global timeline: scene k occupies [start_k, start_k + dur_k); the cross-fade straddles each cut
    starts, t = [], 0.0
    for sc in scenes:
        starts.append(t)
        t += sc.dur
    total = t
    n_total = int(round(total * FPS))
    xf = xfade if len(scenes) > 1 else 0.0

    # 1) text layers
    texts = []
    for k, sc in enumerate(scenes):
        png = BUILD / f"{stem}-text{k + 1}.png"
        alpha = text_png(sc.text, sc.css, size, png)
        texts.append(dict(png=png, alpha=alpha))
    if persist:
        png = BUILD / f"{stem}-persist.png"
        texts.append(dict(png=png, alpha=text_png(persist, persist_css, size, png), persist=True))

    # 2) music
    wav = BUILD / f"{stem}-music.wav"
    if isinstance(music, (str, Path)):
        wav = Path(music)
    else:
        brand, style, *seed = music or ("hourback", "warm")
        cuts = [s for s in starts[1:]]
        music2.write(wav, music2.render(brand, style, total + 0.4, cuts, seed=(seed[0] if seed else 0)))

    # 3) ffmpeg graph: bg pipe -> overlay text k (fades at its edges) -> split: final mp4 + lossless QA windows
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
           "-framerate", str(FPS), "-i", "-"]
    for tx in texts:
        cmd += ["-loop", "1", "-framerate", str(FPS), "-t", f"{total:.3f}", "-i", str(tx["png"])]
    cmd += ["-i", str(wav)]
    fl, last = [], "0:v"
    windows = []
    for k, (sc, tx) in enumerate(zip(scenes, texts)):
        s0, s1 = starts[k], starts[k] + sc.dur
        fades = []
        a_in, a_out = s0, s1                                      # text fully visible within [a_in, a_out)
        fd = max(0.1, xf / 2 - text_gap)
        if k > 0:                                                 # fade in just after the cut
            fades.append(f"fade=t=in:st={s0 + text_gap:.4f}:d={fd:.4f}:alpha=1")
            a_in = s0 + text_gap + fd
        elif sc.text_in > 0:
            fades.append(f"fade=t=in:st=0:d={sc.text_in:.4f}:alpha=1")
            a_in = sc.text_in
        if k < len(scenes) - 1:                                   # fade out just before the cut
            fades.append(f"fade=t=out:st={s1 - text_gap - fd:.4f}:d={fd:.4f}:alpha=1")
            a_out = s1 - text_gap - fd
        elif sc.text_out > 0:
            fades.append(f"fade=t=out:st={s1 - sc.text_out:.4f}:d={sc.text_out:.4f}:alpha=1")
            a_out = s1 - sc.text_out
        chain = ",".join(["format=rgba"] + fades)
        fl.append(f"[{k + 1}:v]{chain}[t{k}]")
        nxt = f"o{k}"
        fl.append(f"[{last}][t{k}]overlay=0:0:format=gbrp:eof_action=pass[{nxt}]")
        last = nxt
        f_in, f_out = int(np.ceil(a_in * FPS)), int(np.floor(a_out * FPS))
        windows.append(dict(scene=k, frames=(f_in, f_out)))
    if persist:                                                   # on top, whole video, never faded
        k = len(scenes)
        fl.append(f"[{k + 1}:v]format=rgba[t{k}]")
        fl.append(f"[{last}][t{k}]overlay=0:0:format=gbrp:eof_action=pass[o{k}]")
        last = f"o{k}"
        windows.append(dict(scene=k, frames=(0, n_total), persist=True))
    q = []
    if lossless_qa:
        for k, wdw in enumerate(windows):
            a, b = wdw["frames"]
            a2, b2 = a + max(0, (b - a) // 2 - 12), min(b, a + max(0, (b - a) // 2 - 12) + 24)
            if wdw.get("persist") and len(starts) > 1:            # straddle the first cut
                c = int(round(starts[1] * FPS))
                a2, b2 = c - 12, c + 12
            wdw["lossless_frames"] = (a2, b2)
            wdw["lossless"] = BUILD / f"{stem}-qa{k + 1}.mkv"
            q.append((a2, b2, wdw["lossless"]))
    fl.append(f"[{last}]split={1 + len(q)}[vf]" + "".join(f"[q{k}]" for k in range(len(q))))
    fl.append("[vf]scale=out_color_matrix=bt709:out_range=tv:flags=accurate_rnd+full_chroma_int,format=yuv420p[v]")
    for k, (a, b, _) in enumerate(q):
        fl.append(f"[q{k}]trim=start_frame={a}:end_frame={b},setpts=PTS-STARTPTS[Q{k}]")
    ai = len(texts) + 1
    fl.append(f"[{ai}:a]loudnorm=I={lufs}:TP=-1.5:LRA=11,aresample=48000,"
              f"afade=t=out:st={max(0, total - 0.45):.3f}:d=0.45[a]")
    cmd += ["-filter_complex", ";".join(fl), "-map", "[v]", "-map", "[a]", "-frames:v", str(n_total),
            # Encoder tuned so the static text doesn't 'pump': no periodic keyframes (scenecut off, one GOP),
            # equal quality for I/P/B frames, grain tuning so moving grain doesn't steal bits from the text.
            # Measured on the Reel's prompt card: text-pixel outliers >8 levels dropped ~19x vs crf 20/g 60.
            "-c:v", "libx264", "-preset", "slow", "-crf", str(crf), "-maxrate", maxrate, "-bufsize", "18M",
            "-tune", "grain", "-x264-params", "keyint=600:min-keyint=600:scenecut=0:ipratio=1.0:pbratio=1.0:qcomp=0.8",
            "-profile:v", "high", "-pix_fmt", "yuv420p",
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
            "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2", "-t", f"{total:.3f}",
            "-movflags", "+faststart", str(out_mp4)]
    for k, (_, _, path) in enumerate(q):
        cmd += ["-map", f"[Q{k}]", "-c:v", "ffv1", "-level", "3", str(path)]
    t0 = time.time()
    ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    # 4) background frames. Around each cut, 2h frames blend the outgoing scene (rendered h frames past its end)
    #    into the incoming one (rendered from h frames before its start); the ease keeps both nearly at rest there.
    h = int(round(xf * FPS)) // 2
    tail = []
    for k, sc in enumerate(scenes):
        n = int(round(sc.dur * FPS))
        lo = -h if k > 0 else 0
        hi = n + h if k < len(scenes) - 1 else n
        print(f"[{stem}] scene {k + 1}/{len(scenes)}: {sc.dur}s", flush=True)
        for j, fb in zip(range(lo, hi), bg_frames(sc, size, procs, lo, hi)):
            if k > 0 and j < h:
                w = B.smoothstep(0.0, 1.0, (j + h + 0.5) / (2 * h))
                a = np.frombuffer(tail[j + h], np.uint8).astype(np.float32)
                b = np.frombuffer(fb, np.uint8).astype(np.float32)
                ff.stdin.write(np.clip(a * (1 - w) + b * w + 0.5, 0, 255).astype(np.uint8).tobytes())
            elif k < len(scenes) - 1 and j >= n - h:
                if j == n - h:
                    tail = []
                tail.append(fb)
            else:
                ff.stdin.write(fb)
    ff.stdin.close()
    if ff.wait() != 0:
        raise RuntimeError("ffmpeg failed")
    print(f"[{stem}] {n_total} frames, {total:.2f}s, {out_mp4.stat().st_size / 1e6:.1f} MB in "
          f"{time.time() - t0:.0f}s", flush=True)
    return dict(mp4=out_mp4, texts=texts, windows=windows, total=total, starts=starts, size=size)




# ----------------------------------------------------------------------------- QA
def _frames(path, size, yuv=False):
    """Stream decoded frames (uint8 RGB) one at a time, so QA never holds a whole video in memory."""
    W, H = size
    vf = "scale=in_color_matrix=bt709:in_range=tv:flags=accurate_rnd+full_chroma_int,format=rgb24" if yuv \
        else "format=rgb24"
    p = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-i", str(path), "-vf", vf, "-f", "rawvideo", "-"],
                         stdout=subprocess.PIPE)
    n = W * H * 3
    while True:
        buf = p.stdout.read(n)
        if len(buf) < n:
            break
        yield np.frombuffer(buf, np.uint8).reshape(H, W, 3)
    p.wait()


class _Diff:
    """Running stats of |frame[i] - frame[i-1]| over a pixel mask: max, mean, 99.9th percentile (histogram)."""

    def __init__(self, mask):
        self.mask, self.prev, self.hist, self.n = mask, None, np.zeros(256, np.int64), 0

    def add(self, fr):
        v = fr[self.mask].astype(np.int16)
        if self.prev is not None:
            self.hist += np.bincount(np.abs(v - self.prev).ravel(), minlength=256)[:256]
            self.n += 1
        self.prev = v

    def stats(self):
        tot = self.hist.sum()
        if not tot:
            return dict(max=None, mean=None, p999=None, pairs=self.n)
        cum = np.cumsum(self.hist)
        return dict(max=int(np.nonzero(self.hist)[0].max()), mean=float((self.hist * np.arange(256)).sum() / tot),
                    p999=float(np.searchsorted(cum, 0.999 * tot)), pairs=self.n)


def jitter_check(res):
    """Max per-pixel change between consecutive frames inside the text, per scene, over its static window.
    'core' = fully opaque text pixels (alpha 255) eroded by 2 px, so pure text colour, nothing blended.
    Lossless = the exact composited frames before H.264 (must be 0). MP4 = decoded final file (compression only).
    Also reports how much the background moved (mean |first - middle frame| of the window, blurred to
    remove grain), as proof the camera really moves."""
    out, track = [], []
    for wdw, tx in zip(res["windows"], res["texts"]):
        a = tx["alpha"]
        core = cv2.erode((a == 255).astype(np.uint8), np.ones((5, 5), np.uint8)) > 0
        bgm = cv2.dilate((a > 0).astype(np.uint8), np.ones((41, 41), np.uint8)) == 0
        r = dict(scene="persistent layer" if wdw.get("persist") else wdw["scene"] + 1, core_px=int(core.sum()),
                 frames=wdw["frames"])
        if "lossless" in wdw:
            d = _Diff(core)
            for fr in _frames(wdw["lossless"], res["size"]):
                d.add(fr)
            st = d.stats()
            r["lossless_core_max"], r["lossless_frames"] = st["max"], st["pairs"] + 1
        out.append(r)
        track.append((r, _Diff(core), bgm))
    first, last = {}, {}
    for i, fr in enumerate(_frames(res["mp4"], res["size"], yuv=True)):
        for k, (r, d, bgm) in enumerate(track):
            f0, f1 = r["frames"]
            if f0 <= i < f1:
                d.add(fr)
                if i == f0:
                    first[k] = cv2.GaussianBlur(fr.astype(np.float32), (0, 0), 3)
                if i == (f0 + f1) // 2:                     # mid-window (a looping slide is back at frame 0 by
                    last[k] = fr                            # its end, so compare with the middle)
    for k, (r, d, bgm) in enumerate(track):
        st = d.stats()
        r.update(mp4_core_max=st["max"], mp4_core_p999=st["p999"], mp4_core_mean=st["mean"])
        b1 = cv2.GaussianBlur(last[k].astype(np.float32), (0, 0), 3)
        r["bg_change_window"] = float(np.abs(b1 - first[k])[bgm].mean()) if bgm.any() else None
    return out


def still(mp4, t, size):
    W, H = size
    p = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(mp4), "-frames:v", "1", "-vf",
                        "scale=in_color_matrix=bt709:in_range=tv,format=rgb24", "-f", "rawvideo", "-"],
                       stdout=subprocess.PIPE, check=True)
    return np.frombuffer(p.stdout, np.uint8).reshape(H, W, 3)


def probe(mp4):
    import json
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "stream=codec_name,width,height,r_frame_rate,pix_fmt,sample_rate,channels:format=duration,size",
                        "-of", "json", str(mp4)], stdout=subprocess.PIPE, check=True)
    return json.loads(p.stdout)
