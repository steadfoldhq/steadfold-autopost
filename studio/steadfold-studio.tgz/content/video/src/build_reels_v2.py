#!/usr/bin/env python3
"""Re-render tonight's 4 Reels: no story-style progress tracker, v2 hook music + whooshes on every cut.
python3 build_reels_v2.py [brand ...]"""
import importlib, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from vlab import render  # noqa: E402
import music2  # noqa: E402

V = Path("/home/claude/content/video")
REELS = {  # brand: (module, style, voice file or None)
    "littlefold": ("lf_safe_sleep", "pop", V / "audio/littlefold-safe-sleep-voice-sarah.mp3"),
    "lockedhour": ("lh_reel_oct15", "cinematic", None),
    "fullyfunded": ("ff_reel_oct15", "pop", None),
    "hourback": ("hb_reel_oct15", "pop", None),
}


def build(brand):
    mod, style, voice = REELS[brand]
    v = importlib.import_module(mod).v
    silent = V / f"out/{brand}-reel-oct15-v2-silent.mp4"
    render(v, silent)
    dur = v.duration
    cuts = sorted({sc["s"] for sc in v.scenes if sc["s"] > 0})
    bed = V / f"audio/{brand}-reel-oct15-v2-bed.wav"
    music2.write(bed, music2.render(brand, style, dur + 0.3, cuts))
    out = V / f"out/{brand}-reel-oct15.mp4"
    if voice:
        fc = ("[1:a]adelay=300|300,aresample=48000,aformat=channel_layouts=stereo,"
              f"apad=whole_dur={dur},asplit=2[v][sc];[2:a]volume=0.32[bed];"
              "[bed][sc]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=300[d];"
              f"[v][d]amix=inputs=2:duration=longest:normalize=0,atrim=0:{dur},"
              "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]")
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(voice), "-i", str(bed),
               "-filter_complex", fc, "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a",
               "192k", "-t", str(dur), "-movflags", "+faststart", str(out)]
    else:
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(bed), "-filter_complex",
               "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]", "-map", "0:v", "-map", "[a]",
               "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", str(dur), "-movflags", "+faststart", str(out)]
    subprocess.run(cmd, check=True)
    print(brand, "done", dur, "s, cuts", cuts)


if __name__ == "__main__":
    for b in (sys.argv[1:] or REELS):
        build(b)
