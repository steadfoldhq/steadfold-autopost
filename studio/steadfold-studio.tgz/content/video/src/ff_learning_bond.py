#!/usr/bin/env python3
"""Fully Funded · 'Born in 2004 or later?' (from ff-w02-4-learning-bond, with gate2's 3 fixes applied:
9-word claim wording, $25 shown as separate, CRA wording for 'no contributions'). 28 s, 1080x1920, no audio.
Format: Call-out question -> number reveal -> receipts -> the catch -> who it's for -> comment prompt.
Facts: CRA 'Canada Learning Bond'; ESDC CLB brochure for 18-20 year olds; ESDC CLB income brackets (Jul 2025-Jun 2026)."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from vlab import Video, words, el, count, caption, CHECK, DOWN, MARKS  # noqa: E402

THEME = """
:root{--bg:#F5F7FF;--ink:#0E1440;--co:#2B3FE0;--or:#FF6A3D;--hl:#FFB08F;--hl-dark:#FF6A3D;
 --prog-bg:rgba(255,255,255,.62);--prog-fg:#FF6A3D;--cap-bg:#0E1440;--cap-ink:#FFFFFF;--cap-r:20px;
 --cap-sh:0 18px 40px -18px rgba(14,20,64,.5);--cap-bd:0;--strike:#FF6A3D}
.dark{--cap-bg:#FFFFFF;--cap-ink:#0E1440;--hl-dark:#FFB08F}
.H{font-family:'Inter Display';font-weight:800;letter-spacing:-.035em;line-height:1;color:var(--ink)}
.dark .H{color:#fff}
.B{font-family:Inter;font-weight:600;color:var(--ink);letter-spacing:-.01em;line-height:1.25}
.dark .B{color:#D3D9FF}
.grid{background-image:linear-gradient(rgba(43,63,224,.07) 2px,transparent 2px),
 linear-gradient(90deg,rgba(43,63,224,.07) 2px,transparent 2px);background-size:90px 90px}
.dark .grid{background-image:linear-gradient(rgba(255,255,255,.07) 2px,transparent 2px),
 linear-gradient(90deg,rgba(255,255,255,.07) 2px,transparent 2px)}
.pill{display:inline-block;font:800 28px/1 Inter;letter-spacing:.12em;text-transform:uppercase;color:#fff;
 background:#FF6A3D;padding:14px 22px 13px;border-radius:999px}
.card{background:#fff;border-radius:28px;box-shadow:0 30px 60px -28px rgba(14,20,64,.45);border:2px solid #DCE1FA}
.chip{display:inline-block;font:800 44px/1 'Inter Display';letter-spacing:-.02em;color:#0E1440;background:#fff;
 border-radius:999px;padding:24px 38px 26px;box-shadow:0 18px 36px -18px rgba(14,20,64,.55);white-space:nowrap}
.line{display:flex;align-items:baseline;justify-content:space-between;padding:26px 34px;font:600 40px/1.2 Inter;
 color:#0E1440;border-top:2px solid #E3E7FA}
.line b{font:800 72px/1 'Inter Display';letter-spacing:-.03em;color:#2B3FE0}
.step{display:flex;gap:26px;align-items:center;background:#fff;border-radius:24px;padding:26px 30px;
 box-shadow:0 22px 44px -26px rgba(14,20,64,.5);font:700 42px/1.2 Inter;color:#0E1440;margin-bottom:22px}
.step i{font-style:normal;flex:0 0 72px;height:72px;border-radius:50%;background:#2B3FE0;color:#fff;display:flex;
 align-items:center;justify-content:center;font:800 40px/1 'Inter Display'}
#tag{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:#fff;
 border-radius:999px;padding:6px 22px 6px 6px;font:800 26px/1 Inter;color:#0E1440;box-shadow:0 8px 20px -10px rgba(14,20,64,.5)}
#tag img{width:44px;height:44px;border-radius:50%}
#tag span{opacity:.6;font-weight:700}
"""
TAG = f'<div id="tag"><img src="{(MARKS / "fullyfunded.png").as_uri()}">Fully Funded <span>· Benefits you\'re owed</span></div>'

v = Video("fullyfunded", "learning-bond", THEME, TAG)
X = 84
BG, CO, NAVY, OR = "#F5F7FF", "#2B3FE0", "#0E1440", "#FF6A3D"

# 1 · HOOK (0–2.5): call-out question on frame 0
v.scene(0, 2.5, "".join([
    el('<span class="pill">Quick question</span>', X, 340, a="none"),
    el('Born in<br><span style="color:#FF6A3D">2004</span><br>or later?', X, 410, 900, a="none", cls="H",
       style="font-size:190px;line-height:.95"),
    words("Or raising a kid|who was?", t=0.5, st=0.07, cls="H",
          style=f"position:absolute;left:{X}px;top:990px;width:900px;font-size:80px;color:#D3D9FF"),
    caption("Read this before you turn 21.", t=1.05),
]), tin="punch", bg=CO, pattern="grid", cls="dark")

# 2 · THE NUMBER (2.5–5.5)
v.scene(2.5, 5.5, "".join([
    el('<span class="pill" style="background:#2B3FE0">Canada Learning Bond</span>', X, 340, a="left"),
    count(0, 2000, "${:,.0f}", t=0.15, d=1.0, x=X - 8, y=420, cls="H",
          style="font-size:250px;color:#2B3FE0;letter-spacing:-.05em"),
    el('<div style="height:20px;background:#FF6A3D;border-radius:10px"></div>', X, 715, 700, a="left", t=0.9, d=0.3),
    words("max per child, for kids from|==lower-income families.==", t=1.0, st=0.05, cls="H",
          style=f"position:absolute;left:{X}px;top:810px;width:900px;font-size:66px;line-height:1.1"),
    caption("Money for school after high school.", t=1.6),
]), tin="whip", bg=BG, pattern="grid")

# 3 · $0 (5.5–8.0)
v.scene(5.5, 8.0, "".join([
    el('$0', X - 10, 360, a="slam", t=0.0, d=0.3, cls="H", sh=0.25,
       style="font-size:420px;color:#FF6A3D;letter-spacing:-.06em"),
    words("you have to|put in.", t=0.35, st=0.08, cls="H",
          style=f"position:absolute;left:{X}px;top:800px;width:900px;font-size:120px"),
    el('<div class="B" style="font-size:40px;background:rgba(255,255,255,.1);border-radius:20px;padding:22px 28px;'
       'color:#fff">CRA: <b>"Personal contributions are not required."</b></div>', X, 1090, 900, a="up", t=1.0),
]), tin="flash", bg=NAVY, pattern="grid", cls="dark")

# 4 · HOW IT ADDS UP (8.0–11.5)
v.scene(8.0, 11.5, "".join([
    words("How it ==adds up.==", t=0.0, st=0.07, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;width:900px;font-size:116px"),
    el('<div class="card" style="overflow:hidden">'
       + el('<div class="line" style="border-top:0">First eligible year<b>$500</b></div>', a="left", t=0.45,
            style="position:relative")
       + el('<div class="line">Each later year, to age 15<b>+$100</b></div>', a="left", t=0.85,
            style="position:relative")
       + el('<div class="line" style="background:#2B3FE0;color:#fff;border:0">Maximum bond<b style="color:#fff">'
            '$2,000</b></div>', a="slam", t=1.35, d=0.28, sh=1.5, style="position:relative")
       + '</div>', X, 540, 900, a="up", t=0.2),
    el('$500 + 15 × $100 = $2,000. The $25 ESDC adds for opening costs is separate.', X, 1000, 900, a="fade", t=1.8,
       cls="B", style="font-size:34px;opacity:.75"),
    caption("One low-income year is enough for the first $500.", t=2.0),
]), tin="zoom", bg=BG, pattern="grid")

# 5 · THE CATCH (11.5–15.0)
v.scene(11.5, 15.0, "".join([
    el('<span class="pill">ESDC\'s own estimate</span>', X, 340, a="left", t=0.05),
    el('2 in 3', X - 8, 400, a="pop", t=0.1, d=0.45, cls="H", style="font-size:300px;letter-spacing:-.05em"),
    words("born 2004 or later are|eligible for $500+.", t=0.55, st=0.05, cls="H",
          style=f"position:absolute;left:{X}px;top:730px;width:900px;font-size:70px;line-height:1.1;color:#D3D9FF"),
    el('<span style="background:#FF6A3D;padding:8px 26px 16px;border-radius:18px;color:#0E1440">'
       'Eligible isn\'t paid.</span>', X, 940, a="slam", t=1.5, d=0.3, sh=1.62, cls="H", style="font-size:104px"),
    caption("It only lands once someone opens an RESP and asks for it.", t=2.0),
]), tin="circle", bg=CO, pattern="grid", cls="dark", origin="50% 55%")

# 6 · STEPS (15.0–18.5)
steps = ["Get the child a SIN", "Open an RESP that offers the bond", "Ask for the bond. Deposit nothing."]
v.scene(15.0, 18.5, "".join([
    words("No RESP,|==no bond.==", t=0.0, st=0.08, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;width:900px;font-size:130px"),
    el("".join(el(f'<div class="step"><i>{i + 1}</i>{s}</div>', a="left", t=0.55 + i * 0.4, d=0.35,
                  style="position:relative") for i, s in enumerate(steps)), X, 650, 900, a="none"),
    caption("Already have an RESP? Ask if the bond was requested.", t=1.9),
]), tin="whip", bg=BG, pattern="grid")

# 7 · MISSED IT? (18.5–22.5)
v.scene(18.5, 22.5, "".join([
    words("Missed it|as a kid?", t=0.0, st=0.08, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;width:900px;font-size:128px"),
    el('18–20', X - 8, 620, a="slam", t=0.7, d=0.3, sh=0.85, cls="H",
       style="font-size:300px;color:#fff;letter-spacing:-.05em;text-shadow:12px 12px 0 #0E1440"),
    words("Apply yourself, up to the|day before you turn 21.", t=1.25, st=0.05, cls="H",
          style=f"position:absolute;left:{X}px;top:960px;width:900px;font-size:62px;line-height:1.12"),
    caption("If you were born on or after Jan 1, 2004.", t=2.0),
]), tin="flash", bg=OR, pattern="grid")

# 8 · COMMENT PROMPT (22.5–27.0)
v.scene(22.5, 27.0, "".join([
    words("Which one|==are you?==", t=0.0, st=0.08, wa="slam", d=0.3, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;width:900px;font-size:150px"),
    el('<span class="chip" style="background:#FF6A3D;font-size:54px">Parent</span>', X, 700, a="pop", t=0.75, br=1),
    el('<span class="chip" style="font-size:54px">I\'m 18–20</span>', X, 830, a="pop", t=0.9, br=1),
    el('<span class="chip" style="font-size:54px">Sending it to someone</span>', X, 960, a="pop", t=1.05, br=1),
    el(f'Comment yours {DOWN}', X, 1120, a="up", t=1.45, cls="H", style="font-size:84px;color:#fff", br=1),
    el('Sources and rules in the caption · @fullyfundedhq', X, 1236, 900, a="fade", t=1.8, cls="B",
       style="font-size:32px"),
]), tin="zoom", bg=CO, pattern="grid", cls="dark")

if __name__ == "__main__":
    from vlab import render, contact_sheet
    out = Path("/home/claude/content/video/out")
    mp4 = render(v, out / "fullyfunded-learning-bond.mp4", cover_t=1.8,
                 cover_png=out / "fullyfunded-learning-bond-cover.png")
    contact_sheet(mp4, Path("/home/claude/content/video/qa/fullyfunded-learning-bond-sheet.png"))
