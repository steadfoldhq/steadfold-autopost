#!/usr/bin/env python3
"""Hourback · 'Your guest is celiac. Which dish is the problem?' (from hb-w02-5-potluck-menu; text task, so the
gate accepts the verbatim-run output policy). 29.5 s, 1080x1920, no audio.
Format: Spot-the-problem quiz -> reveal (with a twist) -> the prompt -> AI output excerpt -> check-this -> comment.
AI lines are verbatim excerpts from hourback/samples/runs (labelled 'AI output · excerpt · our own sample run')."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from vlab import Video, words, el, caption, CHECK, DOWN, WARN, MARKS  # noqa: E402

THEME = """
:root{--bg:#FFF8EF;--ink:#2A2238;--ind:#5E54C9;--or:#FF8A3D;--yel:#FFC94D;--hl:#FFC94D;--hl-dark:#FFC94D;
 --prog-bg:rgba(255,255,255,.7);--prog-fg:#FF8A3D;--cap-bg:#5E54C9;--cap-ink:#FFFFFF;--cap-r:26px;
 --cap-sh:0 18px 36px -18px rgba(94,84,201,.7);--cap-bd:0;--strike:#FF8A3D}
.dark{--cap-bg:#FFF8EF;--cap-ink:#2A2238}
.H{font-family:Poppins;font-weight:700;letter-spacing:-.025em;line-height:1.04;color:var(--ink)}
.dark .H{color:#fff}
.B{font-family:Inter;font-weight:600;color:var(--ink);letter-spacing:-.01em;line-height:1.25}
.dark .B{color:#E3DFFF}
.sun{background:radial-gradient(900px 700px at 85% 8%,rgba(255,201,77,.35),transparent 60%),
 radial-gradient(800px 800px at 0% 100%,rgba(255,138,61,.16),transparent 60%)}
.dark .sun{background:radial-gradient(900px 700px at 85% 8%,rgba(255,201,77,.22),transparent 60%),
 radial-gradient(800px 800px at 0% 100%,rgba(26,18,80,.35),transparent 60%)}
.pill{display:inline-block;font:800 28px/1 Inter;letter-spacing:.12em;text-transform:uppercase;color:#fff;
 background:#FF8A3D;padding:14px 22px 13px;border-radius:999px}
.card{background:#fff;border-radius:32px;box-shadow:0 30px 60px -28px rgba(94,84,201,.45);border:2px solid #F3E6D3}
.dish{display:flex;gap:20px;align-items:center;background:#fff;border-radius:30px;padding:24px 22px;width:432px;
 height:178px;box-shadow:0 24px 44px -26px rgba(94,84,201,.6);border:2px solid #F3E6D3}
.dish i{font-style:normal;flex:0 0 76px;height:76px;border-radius:50%;background:#5E54C9;color:#fff;display:flex;
 align-items:center;justify-content:center;font:700 40px/1 Poppins}
.dish b{display:block;font:700 36px/1.1 Poppins;color:#2A2238;letter-spacing:-.02em}
.dish small{display:block;font:600 30px/1.2 Inter;color:#655A6E;margin-top:6px}
.prompt{background:#fff;border-radius:30px;overflow:hidden;box-shadow:0 30px 60px -28px rgba(94,84,201,.55)}
.prompt .bar{background:#5E54C9;color:#fff;font:800 28px/1 Inter;letter-spacing:.14em;padding:20px 30px}
.prompt .txt{font:500 37px/1.42 'DejaVu Sans Mono',monospace;color:#2A2238;padding:28px 32px 32px;min-height:470px}
.flag{display:flex;gap:22px;align-items:flex-start;background:#fff;border-radius:24px;padding:22px 26px;margin-bottom:18px;
 box-shadow:0 20px 40px -26px rgba(94,84,201,.6);font:600 37px/1.25 Inter;color:#2A2238}
.flag em{font-style:normal;flex:0 0 58px;height:58px;border-radius:50%;background:#FF8A3D;color:#fff;display:flex;
 align-items:center;justify-content:center;font:700 32px/1 Poppins;margin-top:-4px}
.guest{display:inline-flex;gap:16px;align-items:center;background:#fff;border-radius:999px;padding:20px 32px 20px 20px;
 font:700 40px/1 Poppins;color:#2A2238;white-space:nowrap}
.guest i{font-style:normal;width:56px;height:56px;border-radius:50%;background:#FFC94D;display:flex;align-items:center;
 justify-content:center;font-size:34px;color:#2A2238}
.todo{display:flex;gap:20px;align-items:center;font:700 40px/1.2 Inter;color:#2A2238;background:#fff;border-radius:22px;
 padding:22px 26px;margin-bottom:18px;box-shadow:0 18px 36px -24px rgba(42,34,56,.5)}
.todo i{flex:0 0 46px;height:46px;border:5px solid #5E54C9;border-radius:12px}
.num{display:inline-flex;flex-direction:column;align-items:center;width:156px}
.num b{width:140px;height:140px;border-radius:50%;background:#5E54C9;color:#fff;display:flex;align-items:center;
 justify-content:center;font:700 80px/1 Poppins;box-shadow:0 18px 30px -16px rgba(94,84,201,.8)}
.num small{font:700 28px/1.1 Inter;color:#2A2238;margin-top:14px;text-align:center}
.timer{width:150px;height:150px;border-radius:50%;background:#FFC94D;border:8px solid #2A2238;display:flex;
 align-items:center;justify-content:center}
.tick{position:absolute;font:700 96px/1 Poppins;color:#2A2238;left:0;right:0;text-align:center;top:22px}
#tag{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:#fff;
 border-radius:999px;padding:6px 22px 6px 6px;font:700 26px/1 Inter;color:#2A2238;box-shadow:0 8px 20px -10px rgba(94,84,201,.6)}
#tag img{width:44px;height:44px;border-radius:50%}
#tag span{opacity:.6}
"""
TAG = f'<div id="tag"><img src="{(MARKS / "hourback.png").as_uri()}">Hourback <span>· Before → After</span></div>'

v = Video("hourback", "potluck", THEME, TAG)
X = 84
CREAM, IND, YEL, PEACH = "#FFF8EF", "#5E54C9", "#FFC94D", "#FFEEDC"

DISHES = [("A", "Chicken skewers", "soy marinade"), ("B", "Green salad", "oil + lemon"),
          ("C", "Roasted potatoes", "herb roasted"), ("D", "Apple crumble", "oat topping")]


def dish(i, d, t, a="pop"):
    L, name, sub = d
    return el(f'<div class="dish"><i>{L}</i><div><b>{name}</b><small>{sub}</small></div></div>',
              X + (i % 2) * 468, 850 + (i // 2) * 200, a=a, t=t, d=0.4)


# 1 · QUIZ HOOK (0–4.5): question on frame 0, dishes pop, 3-2-1 timer
v.scene(0, 4.5, "".join([
    el('<span class="pill">Quick quiz</span>', X, 340, a="none"),
    el('Your guest<br>is <span class="hlx" data-a="hl" data-t="0.2" data-d="0.4">celiac.</span><br>Which dish is<br>'
       'the problem?', X, 400, 920, a="none", cls="H", style="font-size:100px"),
    *[dish(i, d, 0.35 + i * 0.14) for i, d in enumerate(DISHES)],
    el('<div class="timer" style="position:relative">'
       + "".join(f'<div class="tick" data-a="tick" data-t="{1.75 + k * 0.9}" data-d="0.9">{n}</div>'
                 for k, n in enumerate("321")) + '</div>', X, 1268, a="pop", t=1.2),
    el('Lock in your answer.', X + 190, 1316, a="left", t=1.3, cls="H", style="font-size:56px"),
]), tin="punch", bg=CREAM, pattern="sun")

# 2 · REVEAL + TWIST (4.5–8.5)
v.scene(4.5, 8.5, "".join([
    el(f'<div class="dish" style="width:600px"><i style="background:#FF8A3D">A</i><div><b>Chicken skewers</b>'
       f'<small>soy marinade</small></div></div>', X, 350, a="slam", t=0.0, d=0.3, sh=0.3),
    words("Soy sauce usually|contains ==wheat.==", t=0.35, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:580px;width:920px;font-size:96px"),
    el(f'<div class="dish" style="width:600px"><i style="background:#FF8A3D">D</i><div><b>Apple crumble</b>'
       f'<small>oat topping</small></div></div>', X, 860, a="drop", t=1.55, d=0.45, sh=1.95),
    el('<span style="background:#FFC94D;color:#2A2238;padding:6px 22px 10px;border-radius:18px">Trick question: '
       'two of them.</span>', X, 1075, a="pop", t=2.0, cls="H", style="font-size:58px"),
    el('Regular oats are often cross-contaminated with wheat.', X, 1180, 900, a="up", t=2.4, cls="B",
       style="font-size:40px"),
]), tin="flash", bg=IND, pattern="sun", cls="dark")

# 3 · THE PROMPT (8.5–12.5): typewriter
PROMPT = ("I'm hosting a potluck for 9. Here's who's coming, their diets, and what they offered to bring: "
          "[guest list]. Plan one menu so everyone gets a full plate, give each dish to someone who offered it, "
          "and flag hidden ingredients to watch for.")
v.scene(8.5, 12.5, "".join([
    el('<span class="pill" style="background:#5E54C9">We asked an AI chat · our own sample run</span>', X, 340,
       a="left"),
    words("Paste the guest list.|==Ask for one menu.==", t=0.05, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:920px;font-size:84px"),
    el(f'<div class="prompt"><div class="bar">PROMPT · COPY IT FROM THE CAPTION</div>'
       f'<div class="txt"><span data-a="type" data-t="0.6" data-d="2.3">{PROMPT}</span></div></div>',
       X, 630, 900, a="up", t=0.3),
    caption("4 diets: vegan, celiac, nut allergy, halal.", t=2.5),
]), tin="whip", bg=CREAM, pattern="sun")

# 4 · AI OUTPUT EXCERPT (12.5–18.0)
FLAGS = ["Soy sauce usually contains wheat.", "Stock cubes and curry pastes can contain wheat.",
         "Regular oats are often cross-contaminated with wheat.",
         "Some people with tree-nut allergies avoid coconut, so ask Lena first.",
         "Vanilla extract contains alcohol. Ask Omar…"]
v.scene(12.5, 18.0, "".join([
    el('<span class="pill" style="background:#5E54C9">AI output · excerpt</span>', X, 340, a="left"),
    words("It flagged ==5 hidden|ingredients.==", t=0.05, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:920px;font-size:86px"),
    el("".join(el(f'<div class="flag"><em>{i + 1}</em><div>{f}</div></div>', a="left", t=0.55 + i * 0.42, d=0.35,
                  style="position:relative") for i, f in enumerate(FLAGS)), X, 640, 860, a="none"),
]), tin="zoom", bg=PEACH, pattern="sun")

# 5 · FULL PLATES (18.0–21.5)
GUESTS = [("Maya", "vegan"), ("Ben", "celiac"), ("Lena", "nut allergy*"), ("Omar", "halal*")]
v.scene(18.0, 21.5, "".join([
    words("Every guest got|==a full plate.==", t=0.0, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;width:920px;font-size:96px"),
    *[el(f'<span class="guest"><i>{CHECK}</i>{n} · {d}</span>', X, 600 + i * 118, a="left", t=0.5 + i * 0.22)
      for i, (n, d) in enumerate(GUESTS)],
    el('*once Lena OKs the coconut and Omar OKs the vanilla', X, 1080, 900, a="fade", t=1.5, cls="B",
       style="font-size:34px"),
    caption("A starting point. Not a safety check.", t=1.8),
]), tin="wipe", bg=IND, pattern="sun", cls="dark")

# 6 · CHECK THIS (21.5–25.0)
TODO = ["Confirm each allergy with the guest", "Read the label on anything store-bought",
        "Every dish gets its own serving spoon"]
v.scene(21.5, 25.0, "".join([
    el('<span class="pill" style="background:#2A2238">Check this</span>', X, 340, a="left"),
    words("Ask the ==guest,==|not the AI.", t=0.05, st=0.1, wa="slam", d=0.3, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:920px;font-size:124px;--hl:#FFF8EF"),
    el("".join(el(f'<div class="todo"><i></i>{s}</div>', a="left", t=0.9 + i * 0.3, d=0.32, style="position:relative")
               for i, s in enumerate(TODO)), X, 720, 900, a="none"),
    caption("Answers vary between AI chats. Always check.", t=2.0),
]), tin="flash", bg=YEL, pattern="sun")

# 7 · COMMENT PROMPT (25.0–29.0)
SHORT = ["Soy sauce", "Stock cubes", "Oats", "Coconut", "Vanilla"]
v.scene(25.0, 29.0, "".join([
    words("Which one|==surprised you?==", t=0.0, st=0.08, wa="slam", d=0.3, cls="H",
          style=f"position:absolute;left:{X}px;top:350px;width:920px;font-size:120px"),
    *[el(f'<div class="num"><b>{i + 1}</b><small>{s}</small></div>', X - 6 + i * 172, 690, a="pop", t=0.7 + i * 0.12,
         br=1) for i, s in enumerate(SHORT)],
    el(f'Comment the number {DOWN}', X, 960, a="up", t=1.6, cls="H", style="font-size:72px", br=1),
    el('Full prompt in the caption · @hourbackhq', X, 1070, 900, a="fade", t=2.0, cls="B", style="font-size:34px"),
]), tin="zoom", bg=CREAM, pattern="sun")

if __name__ == "__main__":
    from vlab import render, contact_sheet
    out = Path("/home/claude/content/video/out")
    mp4 = render(v, out / "hourback-potluck-quiz.mp4", cover_t=2.2, cover_png=out / "hourback-potluck-quiz-cover.png")
    contact_sheet(mp4, Path("/home/claude/content/video/qa/hourback-potluck-quiz-sheet.png"))
