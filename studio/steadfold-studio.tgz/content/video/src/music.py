#!/usr/bin/env python3
"""Steadfold original music beds, synthesized in code (royalty-free: we own every note).

Each brand gets a mood preset at 120 BPM (0.5 s per beat) so Reel scene cuts, which sit on
the 0.5 s grid, land on the beat. Output: 48 kHz stereo WAV.

    python3 music.py littlefold 28 out.wav
    python3 music.py all            # renders a 30 s preview per brand into ../audio/beds/
"""
import sys
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, fftconvolve

SR = 48000
BPM = 120
BEAT = 60 / BPM
RNG = np.random.default_rng(7)

NOTE = {n: i for i, n in enumerate(["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"])}


def hz(name, octave):
    return 440.0 * 2 ** ((NOTE[name] + 12 * (octave + 1) - 69) / 12)


def chord(root, octave, kind):
    iv = {"maj7": [0, 4, 7, 11], "min7": [0, 3, 7, 10], "add9": [0, 4, 7, 14], "sus2": [0, 2, 7, 12],
          "maj": [0, 4, 7, 12], "min": [0, 3, 7, 12], "6": [0, 4, 7, 9]}[kind]
    base = NOTE[root] + 12 * (octave + 1)
    return [440.0 * 2 ** ((base + i - 69) / 12) for i in iv]


def env_adsr(n, a=0.01, d=0.1, s=0.7, r=0.2):
    t = np.arange(n) / SR
    dur = n / SR
    e = np.ones(n) * s
    e[t < a] = t[t < a] / max(a, 1e-4)
    m = (t >= a) & (t < a + d)
    e[m] = 1 - (1 - s) * (t[m] - a) / max(d, 1e-4)
    rel = t > dur - r
    e[rel] *= np.clip((dur - t[rel]) / max(r, 1e-4), 0, 1)
    return e


def lowpass(x, cutoff, order=2):
    sos = butter(order, cutoff, btype="low", fs=SR, output="sos")
    return sosfilt(sos, x)


def highpass(x, cutoff, order=2):
    sos = butter(order, cutoff, btype="high", fs=SR, output="sos")
    return sosfilt(sos, x)


def pad(freqs, dur, bright=1800, detune=0.006):
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for f in freqs:
        for d in (-detune, 0, detune):
            ph = RNG.uniform(0, 2 * np.pi)
            saw = 2 * ((t * f * (1 + d) + ph / (2 * np.pi)) % 1) - 1
            out += saw
    out = lowpass(out, bright, 2) / (len(freqs) * 3)
    return out * env_adsr(n, a=0.35, d=0.4, s=0.85, r=0.5)


def soft_keys(freqs, dur, vel=0.5):
    """Electric-piano-ish: sine + soft 2nd harmonic, quick decay."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for f in freqs:
        out += np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t) * np.exp(-t * 6)
    return vel * out / len(freqs) * np.exp(-t * 2.2) * env_adsr(n, a=0.005, d=0.05, s=1, r=0.08)


def pluck(f, dur, vel=0.5, damp=0.996):
    """Karplus-Strong string pluck."""
    n = int(dur * SR)
    p = max(2, int(SR / f))
    buf = RNG.uniform(-1, 1, p)
    out = np.empty(n)
    for i in range(n):
        out[i] = buf[i % p]
        buf[i % p] = damp * 0.5 * (buf[i % p] + buf[(i + 1) % p])
    return vel * lowpass(out, 5000) * env_adsr(n, a=0.002, d=0.05, s=1, r=0.05)


def bass(f, dur, vel=0.6):
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) + 0.15 * np.sin(4 * np.pi * f * t)
    return vel * x * env_adsr(n, a=0.01, d=0.15, s=0.6, r=0.1)


def kick(vel=0.9):
    n = int(0.35 * SR)
    t = np.arange(n) / SR
    f = 110 * np.exp(-t * 18) + 45
    ph = 2 * np.pi * np.cumsum(f) / SR
    return vel * np.sin(ph) * np.exp(-t * 9)


def hat(vel=0.2, dur=0.06):
    n = int(dur * SR)
    t = np.arange(n) / SR
    return vel * highpass(RNG.uniform(-1, 1, n), 7000, 2) * np.exp(-t * 60)


def shaker(vel=0.12, dur=0.09):
    n = int(dur * SR)
    t = np.arange(n) / SR
    return vel * highpass(RNG.uniform(-1, 1, n), 4500, 2) * np.sin(np.pi * t / dur) ** 2


def clap(vel=0.35):
    n = int(0.25 * SR)
    t = np.arange(n) / SR
    noise = lowpass(highpass(RNG.uniform(-1, 1, n), 900), 6000)
    e = np.exp(-t * 22) + 0.6 * np.exp(-((t - 0.012) ** 2) / 1e-5) + 0.5 * np.exp(-((t - 0.024) ** 2) / 1e-5)
    return vel * noise * e


def crackle(n, amount=0.004):
    x = np.zeros(n)
    idx = RNG.integers(0, n, int(n / SR * 9))
    x[idx] = RNG.uniform(-1, 1, len(idx)) * 0.6
    return amount * 40 * highpass(x, 2000) + amount * lowpass(RNG.normal(0, 1, n), 1200)


def reverb(x, seconds=1.8, mix=0.25):
    n = int(seconds * SR)
    t = np.arange(n) / SR
    ir = RNG.normal(0, 1, n) * np.exp(-t * 3.2 / seconds)
    ir = lowpass(ir, 6000)
    ir /= np.sqrt(np.sum(ir ** 2))
    wet = fftconvolve(x, ir)[: len(x)]
    return (1 - mix) * x + mix * wet


def place(track, sig, at):
    i = int(at * SR)
    if i >= len(track):
        return
    j = min(len(track), i + len(sig))
    track[i:j] += sig[: j - i]


PRESETS = {
    # Littlefold: warm, happy, new-beginnings; plucks + soft keys, shaker, no hard drums
    "littlefold": dict(prog=[("F", 3, "add9"), ("C", 3, "add9"), ("D", 3, "min7"), ("A#", 2, "maj7")],
                       pad_bright=1600, keys=True, plucks=True, kick=False, clap=False, hats=False,
                       shaker=True, crackle=False, bass_vel=0.35, master=0.9),
    # Locked Hour: focused lo-fi, mellow keys, soft kick, vinyl crackle
    "lockedhour": dict(prog=[("D", 3, "min7"), ("A#", 2, "maj7"), ("F", 3, "maj7"), ("C", 3, "6")],
                       pad_bright=1100, keys=True, plucks=False, kick=True, clap=False, hats=True,
                       shaker=False, crackle=True, bass_vel=0.5, master=0.85),
    # Fully Funded: confident, upbeat, clean; plucks + claps on 2 and 4
    "fullyfunded": dict(prog=[("C", 3, "maj"), ("G", 2, "maj"), ("A", 2, "min7"), ("F", 2, "maj7")],
                        pad_bright=2200, keys=False, plucks=True, kick=True, clap=True, hats=True,
                        shaker=False, crackle=False, bass_vel=0.55, master=0.9),
    # Hourback: bright, playful, sunny; keys + plucks, light kick, shaker
    "hourback": dict(prog=[("G", 2, "maj7"), ("E", 2, "min7"), ("C", 3, "maj7"), ("D", 3, "6")],
                     pad_bright=2400, keys=True, plucks=True, kick=True, clap=False, hats=False,
                     shaker=True, crackle=False, bass_vel=0.45, master=0.9),
}


def render(brand, seconds):
    P = PRESETS[brand]
    n = int(seconds * SR)
    music = np.zeros(n)
    drums = np.zeros(n)
    bar = 4 * BEAT
    nbars = int(np.ceil(seconds / bar))
    for b in range(nbars):
        root, octv, kind = P["prog"][b % len(P["prog"])]
        t0 = b * bar
        fs = chord(root, octv, kind)
        place(music, 0.5 * highpass(pad([f * 2 for f in fs], bar + 0.4, P["pad_bright"] * 1.6), 220), t0)
        place(music, bass(hz(root, octv - 1), BEAT * 1.6, P["bass_vel"] * 0.55), t0)
        place(music, bass(hz(root, octv - 1), BEAT * 1.4, P["bass_vel"] * 0.45), t0 + 2 * BEAT)
        if P["keys"]:
            for k, beat in enumerate((0, 1.5, 2.5)):
                place(music, soft_keys([f * 4 for f in fs[1:]], BEAT * 1.4, 0.42 if k == 0 else 0.30), t0 + beat * BEAT)
        if P["plucks"]:
            arp = [fs[0] * 2, fs[1] * 2, fs[2] * 2, fs[3] * 2, fs[2] * 2, fs[1] * 2, fs[3] * 2, fs[2] * 2]
            for i, f in enumerate(arp):
                place(music, pluck(f * 2, BEAT * 0.9, 0.36 if i % 2 == 0 else 0.26), t0 + i * BEAT / 2)
        for beat in range(4):
            tb = t0 + beat * BEAT
            if P["kick"] and beat in (0, 2):
                place(drums, kick(0.55), tb)
            if P["clap"] and beat in (1, 3):
                place(drums, clap(0.28), tb)
            if P["hats"]:
                place(drums, hat(0.12), tb + BEAT / 2)
            if P["shaker"]:
                place(drums, shaker(0.10), tb)
                place(drums, shaker(0.07), tb + BEAT / 2)
    music = reverb(music, 2.2, 0.28)
    mix = music + 0.9 * drums
    if P["crackle"]:
        mix += crackle(n)
    # gentle intro/outro so loops and cuts never click
    fade = int(0.6 * SR)
    mix[:fade] *= np.linspace(0, 1, fade) ** 2
    mix[-fade:] *= np.linspace(1, 0, fade) ** 2
    mix = np.tanh(mix * 1.2) * P["master"]
    mix /= max(1e-6, np.max(np.abs(mix))) / 0.89
    # simple stereo width: tiny delay on the right channel
    d = int(0.012 * SR)
    right = np.concatenate([np.zeros(d), mix[:-d]]) * 0.92 + mix * 0.08
    return np.stack([mix, right], axis=1)


def write(path, stereo):
    wavfile.write(str(path), SR, (stereo * 32767).astype(np.int16))


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "all":
        out = Path(__file__).resolve().parent.parent / "audio" / "beds"
        out.mkdir(parents=True, exist_ok=True)
        for b in PRESETS:
            write(out / f"{b}-bed-preview.wav", render(b, 30))
            print("wrote", b)
    else:
        brand, secs, path = sys.argv[1], float(sys.argv[2]), sys.argv[3]
        write(path, render(brand, secs))
        print("wrote", path)
