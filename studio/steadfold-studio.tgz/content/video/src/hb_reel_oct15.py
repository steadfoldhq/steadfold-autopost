#!/usr/bin/env python3
"""Hourback · 'Never guess a parking sign again' Reel (from hb-w02-6-parking-sign; carousel posts Thu Oct 15 1 pm,
this Reel posts Thu Oct 15 7 pm). 23.0 s, 1080x1920, 30 fps, silent (music bed muxed separately at 120 BPM).

Built to the Oct 14 Reel brief (REEL-BRIEF.md), same pattern as lf_safe_sleep.py:
  1 payoff + action on frame 0, with the carousel cover's before -> after (example pole -> 'Park now? No')
  2 step 1 snap the whole pole · 3 step 2 paste the prompt with day + time · 4 step 3 find its quote on the sign
  5 the honest limit as a tip (check your city) · 6 send CTA on the indigo surface.
  Loop: the CTA's highlighted 'snap it.' sits at the exact y of scene 1's 'Snap it, ask' line (match cut).

DESIGN RULE: only the carousel's Sunroom pieces. Cream paper with the soft yellow / peach glows, Poppins 800 headlines
with the yellow marker highlight, white rounded cards, the orange step badge, the 'AI chat' window, the indigo 'AI
output' number chips, the yellow 'Example sign' chip, unticked indigo checkboxes. The indigo surface appears only on
the CTA, exactly like the carousel's last slide (this carousel's cover is the light surface, so scene 1 is cream).
Clean motion only (up, wipe, push, circle). Nothing moves after it lands: no breathing, shakes or flashes.
Every fact is from the shipped carousel + captions-v3.json. The sign is the made-up example sign from the post."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, "/home/claude/content/design")
from vlab import Video, el, caption, CHECK, MARKS  # noqa: E402
from engine.visuals import sun_hb  # noqa: E402  (read-only import, same sun-clock as the carousel CTA)

CREAM, IND, OR, YEL, INK, MUTED, KICK = "#FFF8EF", "#5E54C9", "#FF8A3D", "#FFC94D", "#2A2238", "#655A6E", "#B4490A"
SIGN = Path("/home/claude/content/week02/hourback/samples/sample-parking-sign.jpg").as_uri()   # 1200 x 1700

THEME = f"""
:root{{--bg:{CREAM};--ink:{INK};--ind:{IND};--or:{OR};--yel:{YEL};--hl:{YEL};--hl-dark:{YEL};
 --prog-bg:rgba(42,34,56,.12);--prog-fg:{OR};--cap-bg:{IND};--cap-ink:#FFFFFF;--cap-r:26px;
 --cap-sh:0 18px 36px -18px rgba(94,84,201,.7);--cap-bd:0;--strike:{OR}}}
.dark{{--cap-bg:{CREAM};--cap-ink:{INK};--prog-bg:rgba(255,255,255,.3);--prog-fg:{YEL}}}
.H{{font-family:Poppins;font-weight:800;letter-spacing:-.025em;line-height:1.04;color:var(--ink)}}
.dark .H{{color:#fff}}
.B{{font-family:Inter;font-weight:600;color:var(--ink);letter-spacing:-.01em;line-height:1.25}}
.dark .B{{color:#E3DFFF}}
/* carousel marker highlight: a tall yellow band behind the lower 2/3 of the line, ink stays ink (also on indigo) */
.hlx,.dark .hlx{{position:relative;display:inline-block;z-index:0;background:none;padding:0;margin:0;color:{INK}}}
.hlx::before{{content:"";position:absolute;z-index:-1;left:-.07em;top:.3em;bottom:.03em;
 width:calc(var(--p,0)*(100% + .14em));background:{YEL};border-radius:.26em .12em .24em .1em;transform:rotate(-.5deg)}}
.hlq{{background-image:linear-gradient({YEL},{YEL});background-repeat:no-repeat;background-position:0 85%;
 background-size:calc(var(--p,0)*100%) 72%;-webkit-box-decoration-break:clone;box-decoration-break:clone}}
.glow{{position:absolute;border-radius:50%;pointer-events:none}}
.kick{{font:800 30px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:{KICK}}}
.badge{{display:grid;place-items:center;width:112px;height:112px;border-radius:30px;background:{OR};color:#fff;
 font:800 64px/1 Poppins;box-shadow:0 18px 30px -16px rgba(180,73,10,.55)}}
.card{{background:#fff;border-radius:32px;box-shadow:0 28px 50px -26px rgba(94,84,201,.38);border:2px solid #F3E6D3}}
.chip{{display:inline-block;font:800 30px/1 Inter;letter-spacing:.12em;text-transform:uppercase;padding:14px 22px 13px;
 border-radius:999px;white-space:nowrap}}
.chip.ind{{background:{IND};color:#fff}}
.chip.yel{{background:{YEL};color:{INK};box-shadow:0 12px 22px -12px rgba(180,73,10,.6)}}
.ans{{padding:28px 36px 14px}}
.arrow{{display:grid;place-items:center;width:92px;height:92px;border-radius:50%;background:{OR};
 box-shadow:0 14px 26px -12px rgba(180,73,10,.6)}}
.ans .r{{display:flex;justify-content:space-between;align-items:baseline;font:600 56px/1.2 Inter;color:{INK};
 padding:18px 0;border-top:2px solid #F1E3CF}}
.ans .r:first-of-type{{border-top:0}}
.ans .r b{{font-weight:800}}
.ans .r b.no{{color:{KICK}}}
.win{{overflow:hidden}}
.win .bar{{height:72px;display:flex;align-items:center;gap:10px;padding:0 30px;background:#FFF1DF;border-bottom:2px solid #F1E3CF}}
.win .bar i{{width:18px;height:18px;border-radius:50%;background:{INK};opacity:.22;display:block}}
.win .bar span{{margin-left:12px;font:800 26px/1 Inter;letter-spacing:.14em;color:{INK};opacity:.8}}
.win .lab{{font:800 26px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:{MUTED};margin-bottom:22px}}
.win .bd{{padding:34px 36px 38px}}
.bub{{background:#FFF6EA;border-left:8px solid {OR};border-radius:16px;padding:24px 28px;font:500 56px/1.3 Inter;color:{INK}}}
.bub em{{font-style:normal;font-weight:700;color:{KICK}}}
.ln{{display:flex;gap:24px;align-items:flex-start;font:500 56px/1.3 Inter;color:{INK}}}
.ln .n{{flex:none;width:62px;height:62px;margin-top:6px;border-radius:12px;background:{IND};color:#fff;display:grid;
 place-items:center;font:800 34px/1 Inter}}
.photo{{background:#fff;border-radius:28px;padding:16px;box-shadow:0 30px 56px -26px rgba(94,84,201,.5);border:2px solid #F3E6D3}}
.photo .im{{position:relative;overflow:hidden;border-radius:16px}}
.photo .im img{{position:absolute;display:block}}
.pill{{display:inline-flex;align-items:center;gap:18px;font:700 56px/1 Inter;color:{INK};background:#fff;white-space:nowrap;
 padding:18px 32px 18px 18px;border-radius:999px;box-shadow:0 20px 36px -22px rgba(94,84,201,.6);border:2px solid #F3E6D3}}
.pill .d{{flex:none;width:64px;height:64px;border-radius:50%;display:grid;place-items:center;color:#fff;font-size:38px}}
.todo{{display:flex;gap:28px;align-items:center;font:600 58px/1.2 Inter;color:{INK};padding:30px 40px;border-top:2px solid #F1E3CF}}
.todo:first-child{{border-top:0}}
.todo i{{flex:0 0 58px;height:58px;border:6px solid {IND};border-radius:14px}}
.cta{{background:{CREAM};border-radius:40px;padding:48px 52px 52px;box-shadow:0 40px 80px -40px rgba(10,6,40,.6)}}
.cta .ib{{display:grid;place-items:center;width:104px;height:104px;border-radius:28px;background:{YEL};margin-bottom:30px}}
.cta .tx{{font:500 64px/1.18 Poppins;color:{INK};letter-spacing:-.015em}}
.cta .tx b{{color:{IND};font-weight:800}}
.cam{{transform:none!important}}
#tag{{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:#fff;
 border-radius:999px;padding:6px 22px 6px 6px;font:700 26px/1 Inter;color:{INK};box-shadow:0 8px 20px -10px rgba(94,84,201,.6)}}
#tag img{{width:44px;height:44px;border-radius:50%}}
#tag span{{opacity:.6}}
"""
TAG = f'<div id="tag"><img src="{(MARKS / "hourback.png").as_uri()}">Hourback <span>· Before → After</span></div>'
X, W = 84, 912
HEAD_Y = 386        # scene 1 headline top; line 4 ('Snap it, ask') sits at HEAD_Y + 3 lines
LINE = 104 * 1.04   # .H line-height at 104 px
ARROW = ('<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" '
         'stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h15M13 6l6 6-6 6"/></svg>')


def hl(text, t=None, d=0.4):
    """Yellow marker highlight. t=None -> already drawn (frame 0); else sweeps in at local time t."""
    if t is None:
        return f'<span class="hlx" style="--p:1">{text}</span>'
    return f'<span class="hlx" data-a="hl" data-t="{t}" data-d="{d}">{text}</span>'


def paper():
    """The carousel's light Sunroom background: yellow glow top-right, peach glow bottom-left (static)."""
    return ('<div class="glow" style="right:-360px;top:-380px;width:1100px;height:1100px;'
            'background:radial-gradient(#FFC94D55,transparent 62%)"></div>'
            '<div class="glow" style="left:-320px;bottom:-360px;width:980px;height:980px;'
            'background:radial-gradient(#FFEEDC,transparent 65%)"></div>')


def indigo():
    """The carousel's dark (CTA) surface."""
    return ('<div class="glow" style="inset:0;border-radius:0;background:linear-gradient(160deg,#6E64DD 0%,#5E54C9 45%,'
            '#4A40B8 100%)"></div><div class="glow" style="right:-260px;top:-300px;width:860px;height:860px;'
            'background:radial-gradient(rgba(150,140,255,.45),transparent 65%)"></div>')


def badge(n):
    return el(f'<span class="badge">{n}</span>', X, 330, a="pop", t=0.05, d=0.4)


def head(html, y=480, size=104, t=0.08):
    return el(html, X, y, W, a="up", t=t, d=0.45, cls="H", style=f"font-size:{size}px")


def sign_crop(x0, y0, w0, h0, width):
    """Crop of the example sign image (pixel box in the 1200x1700 source) shown at `width` px, no new files."""
    s = width / w0
    return (f'<div class="im" style="width:{width}px;height:{round(h0 * s)}px"><img src="{SIGN}" '
            f'style="width:{round(1200 * s)}px;left:{-round(x0 * s)}px;top:{-round(y0 * s)}px"></div>')


v = Video("hourback", "reel-oct15", THEME, TAG)

# 1 · PAYOFF + ACTION (0–4.0): headline + highlight fully drawn on frame 0, and the carousel cover's before -> after:
#     the made-up example pole (left) -> its answer for Tue 4:40 PM (right). Everything is static from frame 0.
v.scene(0, 4.0, "".join([
    paper(),
    el('<span class="kick">Parking signs</span>', X, 336, a="none"),
    el(f'Never guess<br>a parking<br>sign again.<br>{hl("Snap it, ask")}<br>{hl("one question.")}', X, HEAD_Y, W,
       a="none", cls="H", style="font-size:104px"),
    el(f'<div class="photo" style="position:relative;padding:12px">{sign_crop(216, 85, 768, 1122, 270)}'
       '<span class="chip yel" style="position:absolute;left:-18px;bottom:-22px;transform:rotate(-3deg)">Example</span>'
       '</div>', X, 990, a="none", rot=-1.5),
    el('<div class="card ans">'
       f'<span class="chip ind">Tue 4:40 PM</span>'
       f'<div class="r" style="margin-top:10px"><span>Park now?</span><b class="no">No</b></div>'
       f'<div class="r"><span>From</span><b>6:00 PM</b></div>'
       f'<div class="r"><span>Overnight</span><b>Permit</b></div>'
       '</div>', 420, 996, 576, a="none", rot=1.5),
    el(f'<span class="arrow">{ARROW}</span>', 352, 1150, a="none"),
    caption("Snap the whole pole and ask one question.", t=0.3, y=1560),
]), tin="cut", bg=CREAM)

# 2 · STEP 1 SNAP (4.0–7.5): the example pole, whole, straight on
# carousel crop [18, 5, 64, 66] % of the 1200x1700 sign -> x 216, y 85, 768 x 1122
v.scene(4.0, 7.5, "".join([
    paper(),
    badge(1),
    head(f'{hl("Snap", 0.55)} the<br>whole pole.', size=116),
    el(f'<span class="pill"><span class="d" style="background:{OR}">{CHECK}</span>1 photo</span>', X, 830, a="up", t=0.8),
    el(f'<span class="pill"><span class="d" style="background:{IND}">{CHECK}</span>Straight on</span>', X, 960, a="up",
       t=1.05),
    el(f'<div class="photo" style="position:relative">{sign_crop(216, 85, 768, 1122, 372)}'
       '<span class="chip yel" style="position:absolute;left:-26px;bottom:-22px;transform:rotate(-3deg)">Example sign</span>'
       '</div>', 592, 790, a="up", t=0.35, d=0.5, rot=1.5),
    caption("Step 1: one clear photo of the whole pole, straight on.", t=0.15, y=1560),
]), tin="push", bg=CREAM)

# 3 · STEP 2 PASTE (7.5–12.0): the exact prompt, day + time stand out
v.scene(7.5, 12.0, "".join([
    paper(),
    badge(2),
    head(f'Add your exact<br>{hl("day and time.", 0.55)}'),
    el('<div class="card win"><div class="bar"><i></i><i></i><i></i><span>AI CHAT</span></div><div class="bd">'
       '<div class="lab">Paste this · full prompt in the caption</div>'
       "<div class=\"bub\"><em>[photo of the sign]</em> It's <em>[day]</em>, <em>[time]</em>. Can I park here? If not, "
       "when can I, and for how long? Quote the part of the sign you're using.</div></div></div>",
       X, 760, W, a="up", t=0.35, d=0.5),
    caption("Step 2: paste this with your exact day and time. It's in the caption.", t=0.15, y=1560),
]), tin="wipe", bg=CREAM)

# 4 · STEP 3 CHECK THE QUOTE (12.0–16.0): its quote -> the same words on the sign
# top sign panel in the source image: x 296–904, y 136–474
v.scene(12.0, 16.0, "".join([
    paper(),
    badge(3),
    head(f'Find its quote<br>{hl("on the sign.", 0.55)}'),
    el('<div class="card win"><div class="bd" style="padding:30px 36px 34px"><div class="lab">AI output · our example</div>'
       f'<div class="ln"><span class="n">1</span><span>The top sign says <span class="hlq" data-a="hl" data-t="1.3" data-d="0.6">"NO STOPPING 7–9 AM 4–6 PM MON – FRI"</span>,…</span></div>'
       '</div></div>', X, 740, W, a="up", t=0.35, d=0.5),
    el(f'<div class="photo" style="position:relative">{sign_crop(296, 136, 608, 338, 520)}'
       '<span class="chip yel" style="position:absolute;right:-30px;bottom:-22px;transform:rotate(3deg)">Example sign</span>'
       '</div>', 280, 1100, a="up", t=1.0, d=0.5, rot=-1.5),
    caption("Step 3: find the words it quotes on the sign. No match? Don't rely on it.", t=0.15, y=1560),
]), tin="push", bg=CREAM)

# 5 · CITY TIP (16.0–19.0): what the sign may not say (the carousel's 'Check this' slide)
TODO = ["Holidays", "Street cleaning", "Snow routes", "When overnight starts"]
v.scene(16.0, 19.0, "".join([
    paper(),
    el('<span class="kick">Check this</span>', X, 336, a="up", t=0.05),
    head(f'Not on the sign?<br>{hl("Check your city.", 0.55)}', y=390),
    el('<div class="card">' + "".join(f'<div class="todo"><i></i>{s}</div>' for s in TODO) + '</div>',
       X, 690, W, a="up", t=0.35, d=0.5),
    caption("City rules for holidays, street cleaning and snow routes may not be on the sign.", t=0.15, y=1560),
]), tin="wipe", bg=CREAM)

# 6 · SEND CTA (19.0–23.0): the carousel's indigo last slide. The headline's 'snap it.' line sits at exactly the y of
#     scene 1's 'Snap it, ask' line, so the loop cuts from the highlighted 'snap it.' straight into 'Snap it, ask...'.
SEND = ('<svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="#2A2238" stroke-width="2.4" '
        'stroke-linecap="round" stroke-linejoin="round"><path d="M21 3 10.2 13.8M21 3l-6.6 18-4.2-7.2L3 9.6z"/></svg>')
v.scene(19.0, 23.0, "".join([
    indigo(),
    el(sun_hb(240), 756, 300, a="pop", t=0.3, d=0.5),
    el(f'Next confusing<br>sign: {hl("snap it.")}', X, round(HEAD_Y + 2 * LINE), W, a="up", t=0.05, d=0.45,
       cls="H", style="font-size:104px"),
    el(f'<div class="cta" style="padding:40px 48px 44px"><div class="ib" style="width:92px;height:92px;margin-bottom:24px">'
       f'{SEND}</div><div class="tx"><b>Send this</b> to the friend who just got a parking ticket.</div></div>',
       X, 862, W, a="up", t=0.45, d=0.5),
    el('<b style="color:#fff;font-weight:800">Free:</b> 25 everyday AI prompts, link in bio<br>'
       '<b style="color:#FFC94D;font-weight:800">Follow @hourbackhq</b>', X, 1316, W, a="fade", t=1.0, cls="B",
       style="font-size:46px;line-height:1.3"),
]), tin="circle", bg=IND, origin="50% 50%", cls="dark")

if __name__ == "__main__":
    from vlab import render, contact_sheet, preview
    out = Path("/home/claude/content/video/out")
    qa = Path("/home/claude/content/video/qa")
    if "--preview" in sys.argv:
        preview(v, [0.0, 2.0, 6.5, 11.0, 15.5, 18.5, 22.5], qa / "hb-reel-oct15-preview.png")
    else:
        import subprocess
        from PIL import Image
        build = Path(__file__).resolve().parent.parent / "build"
        build.mkdir(exist_ok=True)
        png = build / "hourback-reel-oct15-cover.png"
        mp4 = render(v, out / "hourback-reel-oct15-silent.mp4", cover_t=0.0, cover_png=png)   # cover = frame 0 payoff
        Image.open(png).convert("RGB").save(out / "hourback-reel-oct15-cover.jpg", "JPEG", quality=90)
        contact_sheet(mp4, qa / "hourback-reel-oct15-sheet.png")
        bed = Path("/home/claude/content/video/audio/hourback-reel-oct15-bed.wav")
        subprocess.run([sys.executable, str(Path(__file__).resolve().parent / "music.py"), "hourback",
                        f"{v.duration + 0.5}", str(bed)], check=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp4), "-i", str(bed), "-filter_complex",
                        "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]", "-map", "0:v", "-map", "[a]",
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
                        str(out / "hourback-reel-oct15.mp4")], check=True)
