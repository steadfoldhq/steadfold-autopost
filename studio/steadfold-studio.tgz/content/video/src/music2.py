#!/usr/bin/env python3
"""Steadfold Sound Studio v2: hook-first original music + sound design, synthesized in code.

Everything here is ours (no samples, no loops from anyone else), so it's copyright-safe on every platform.
Three styles, each built around a short, repeating melodic HOOK (the thing people hum):
  pop        bright plucked/bell hook, bouncy octave bass, claps on 2 & 4, swung hats
  cinematic  "ticking clock" ostinato, low brass braam on the downbeat, taiko hits, string swells, riser
  lofi       boom-bap groove, jazzy keys hook, vinyl crackle
  warm       (added Oct 14, Content Standard v3 s.5) calm, hopeful lo-fi: soft e-piano + pad, a mellow chime hook
             that starts on beat 1, brushed-soft kick/rim, faint crackle. NO frame-0 impact, no riser; cuts get
             only a faint airy swell. Opt-in by name only; no brand uses it by default.
Sound design synced to the video: an IMPACT on frame 0 (the hook lands with the headline) and a
WHOOSH into every scene cut you pass in.

    python3 music2.py <brand> <style> <seconds> <out.wav> [cut1,cut2,...]
    python3 music2.py demos            # 3 styles x 4 brands, 20 s each, into ../audio/beds/v2/
"""
import sys
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, fftconvolve

SR = 48000
BPM = 120
BEAT = 60 / BPM          # 0.5 s, so cuts on the 0.5 s grid land on the beat
BAR = 4 * BEAT
NOTES = {n: i for i, n in enumerate(["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"])}
MAJOR = [0, 2, 4, 5, 7, 9, 11]
MINOR = [0, 2, 3, 5, 7, 8, 10]


def rng(seed):
    return np.random.default_rng(seed)


R = rng(11)


def midi(note, octave):
    return NOTES[note] + 12 * (octave + 1)


def mhz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def lp(x, f, o=2):
    return sosfilt(butter(o, min(f, SR / 2 - 100), "low", fs=SR, output="sos"), x)


def hp(x, f, o=2):
    return sosfilt(butter(o, f, "high", fs=SR, output="sos"), x)


def bp(x, lo, hi, o=2):
    return sosfilt(butter(o, [lo, min(hi, SR / 2 - 100)], "band", fs=SR, output="sos"), x)


def env(n, a, d, s, r):
    t = np.arange(n) / SR
    dur = n / SR
    e = np.full(n, s, float)
    e[t < a] = t[t < a] / max(a, 1e-4)
    m = (t >= a) & (t < a + d)
    e[m] = 1 - (1 - s) * (t[m] - a) / max(d, 1e-4)
    rr = t > dur - r
    e[rr] *= np.clip((dur - t[rr]) / max(r, 1e-4), 0, 1)
    return e


def put(track, sig, at, gain=1.0):
    i = int(round(at * SR))
    if i >= len(track) or i + len(sig) <= 0:
        return
    s0 = max(0, -i)
    j = min(len(track), i + len(sig))
    track[max(i, 0):j] += gain * sig[s0:s0 + j - max(i, 0)]


def verb(x, sec=1.6, mix=0.22, seed=3):
    n = int(sec * SR)
    t = np.arange(n) / SR
    ir = rng(seed).normal(0, 1, n) * np.exp(-t * 3.5 / sec)
    ir = lp(ir, 7000)
    ir /= np.sqrt(np.sum(ir ** 2))
    return (1 - mix) * x + mix * fftconvolve(x, ir)[: len(x)]


def echo(x, time=0.375, fb=0.35, mix=0.25):
    d = int(time * SR)
    y = x.copy()
    for k in range(1, 4):
        y[d * k:] += (fb ** k) * x[: len(x) - d * k]
    return (1 - mix) * x + mix * y


# ---------------------------------------------------------------- instruments
def bell(f, dur, vel=0.5):          # FM bell: bright, catchy, cuts through phone speakers
    n = int(dur * SR)
    t = np.arange(n) / SR
    mod = np.sin(2 * np.pi * f * 3.5 * t) * 2.2 * np.exp(-t * 6)
    x = np.sin(2 * np.pi * f * t + mod) * np.exp(-t * 3.2)
    return vel * x * env(n, 0.002, 0.05, 1, 0.05)


def lead(f, dur, vel=0.4, bright=4200):   # soft square lead with vibrato
    n = int(dur * SR)
    t = np.arange(n) / SR
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t) * np.clip(t * 4, 0, 1)
    ph = np.cumsum(f * vib) / SR
    sq = np.sign(np.sin(2 * np.pi * ph)) * 0.6 + np.sin(2 * np.pi * ph) * 0.4
    return vel * lp(sq, bright) * env(n, 0.01, 0.08, 0.7, 0.06)


def pluck(f, dur, vel=0.5, damp=0.995, seed=0):
    n = int(dur * SR)
    p = max(2, int(SR / f))
    buf = rng(seed + int(f)).uniform(-1, 1, p)
    out = np.empty(n)
    for i in range(n):
        out[i] = buf[i % p]
        buf[i % p] = damp * 0.5 * (buf[i % p] + buf[(i + 1) % p])
    return vel * lp(out, 6000) * env(n, 0.002, 0.03, 1, 0.04)


def keys(freqs, dur, vel=0.4):      # warm e-piano chord
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = sum(np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t) * np.exp(-t * 5) for f in freqs)
    return vel * x / len(freqs) * np.exp(-t * 1.6) * env(n, 0.005, 0.05, 1, 0.1)


def pad(freqs, dur, vel=0.35, bright=2400, attack=0.4):
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for f in freqs:
        for dt in (-0.007, 0, 0.007):
            x += 2 * ((t * f * (1 + dt) + R.uniform()) % 1) - 1
    return vel * lp(x / (3 * len(freqs)), bright) * env(n, attack, 0.3, 0.9, 0.4)


def strings(freqs, dur, vel=0.35):
    n = int(dur * SR)
    t = np.arange(n) / SR
    vib = 1 + 0.003 * np.sin(2 * np.pi * 5 * t)
    x = np.zeros(n)
    for f in freqs:
        for dt in (-0.004, 0.004):
            ph = np.cumsum(f * (1 + dt) * vib) / SR
            x += 2 * (ph % 1) - 1
    return vel * lp(x / (2 * len(freqs)), 3000) * env(n, 0.6, 0.2, 0.9, 0.5)


def bass(f, dur, vel=0.5, drive=1.6):
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = np.tanh(drive * (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)))
    return vel * x * env(n, 0.005, 0.12, 0.65, 0.05)


def kick(vel=0.8, tight=9):
    n = int(0.4 * SR)
    t = np.arange(n) / SR
    f = 120 * np.exp(-t * 22) + 48
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * tight)
    click = hp(rng(1).uniform(-1, 1, n), 3000) * np.exp(-t * 300) * 0.3
    return vel * (x + click)


def snare(vel=0.5):
    n = int(0.3 * SR)
    t = np.arange(n) / SR
    body = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25)
    noise = bp(rng(2).uniform(-1, 1, n), 1500, 9000) * np.exp(-t * 18)
    return vel * (0.5 * body + noise)


def clap(vel=0.45):
    n = int(0.3 * SR)
    t = np.arange(n) / SR
    noise = bp(rng(3).uniform(-1, 1, n), 1000, 7000)
    e = sum(np.exp(-np.maximum(t - k * 0.011, 0) * 60) * (t >= k * 0.011) for k in range(3)) + 0.6 * np.exp(-t * 14)
    return vel * noise * e / 2


def hat(vel=0.18, open_=False):
    n = int((0.25 if open_ else 0.05) * SR)
    t = np.arange(n) / SR
    return vel * hp(rng(4).uniform(-1, 1, n), 8000) * np.exp(-t * (12 if open_ else 70))


def tick(vel=0.3, accent=False):     # clock tick
    n = int(0.03 * SR)
    t = np.arange(n) / SR
    x = bp(rng(5).uniform(-1, 1, n), 2500 if accent else 3500, 9000) * np.exp(-t * 400)
    return vel * x * (1.4 if accent else 1)


def taiko(vel=0.8):
    n = int(1.2 * SR)
    t = np.arange(n) / SR
    f = 75 * np.exp(-t * 6) + 42
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 3.5)
    skin = lp(rng(6).uniform(-1, 1, n), 1200) * np.exp(-t * 30)
    return vel * (body + 0.6 * skin)


def braam(f, dur=2.0, vel=0.6):      # low brass swell, the cinematic "BWAAM"
    n = int(dur * SR)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for m in (1, 2, 1.5):
        for dt in (-0.01, 0, 0.01):
            x += 2 * ((t * f * m * (1 + dt)) % 1) - 1
    cutoff = 300 + 2500 * np.clip(t / 0.4, 0, 1) * np.exp(-np.maximum(t - 0.4, 0) * 1.2)
    out = np.zeros(n)
    hop = 2048
    for i in range(0, n, hop):          # time-varying low-pass, block by block
        out[i:i + hop] = lp(x[i:i + hop], float(cutoff[i]))
    return vel * np.tanh(1.5 * out / 6) * env(n, 0.08, 0.4, 0.7, 0.6)


def impact(vel=0.9):                 # frame-0 hit: sub boom + transient + tail
    n = int(2.0 * SR)
    t = np.arange(n) / SR
    sub = np.sin(2 * np.pi * np.cumsum(55 * np.exp(-t * 2) + 28) / SR) * np.exp(-t * 2.2)
    crack = hp(rng(7).uniform(-1, 1, n), 1500) * np.exp(-t * 35)
    return vel * verb(sub + 0.5 * crack, 2.0, 0.35, seed=7)


def whoosh(dur=0.45, vel=0.35):       # rises INTO the cut, peaks exactly on it
    n = int(dur * SR)
    t = np.arange(n) / SR
    noise = rng(8).uniform(-1, 1, n)
    out = np.zeros(n)
    hop = 1024
    for i in range(0, n, hop):
        c = 600 + 7000 * (i / n) ** 2
        out[i:i + hop] = bp(noise[i:i + hop], c * 0.7, c * 1.3)
    return vel * out * (t / dur) ** 2


def riser(dur=2.0, vel=0.3):
    n = int(dur * SR)
    t = np.arange(n) / SR
    tone = np.sin(2 * np.pi * np.cumsum(200 + 900 * (t / dur) ** 2) / SR)
    noise = hp(rng(9).uniform(-1, 1, n), 2000) * (t / dur) ** 3
    return vel * (0.5 * tone + noise) * (t / dur) ** 2


def crackle(n, amount=0.004):
    x = np.zeros(n)
    idx = rng(10).integers(0, n, int(n / SR * 9))
    x[idx] = rng(11).uniform(-1, 1, len(idx)) * 0.6
    return amount * 40 * hp(x, 2000) + amount * lp(rng(12).normal(0, 1, n), 1200)


# ---------------------------------------------------------------- brand keys and hooks
BRANDS = {
    "littlefold": dict(key=("F", "major"), prog=[0, 4, 5, 3], default="pop"),
    "lockedhour": dict(key=("D", "minor"), prog=[0, 5, 2, 6], default="cinematic"),
    "fullyfunded": dict(key=("C", "major"), prog=[0, 4, 5, 3], default="pop"),
    "hourback": dict(key=("G", "major"), prog=[0, 5, 3, 4], default="pop"),
}
# Hooks as (scale degree, start in 8ths, length in 8ths) over 2 bars (16 eighths). Short, syncopated, repeatable.
HOOKS = {
    "pop": [(4, 0, 1), (4, 1, 1), (5, 2, 2), (4, 4, 1), (2, 5, 2), (0, 7, 1), (1, 8, 2), (2, 10, 1), (4, 11, 3), (2, 14, 2)],
    "cinematic": [(0, 0, 3), (2, 3, 1), (4, 4, 4), (3, 8, 3), (2, 11, 1), (1, 12, 4)],
    "lofi": [(4, 1, 1), (2, 2, 2), (4, 5, 1), (5, 6, 2), (4, 9, 1), (2, 10, 1), (1, 11, 2), (0, 13, 3)],
    "warm": [(2, 0, 2), (4, 2, 1), (5, 3, 2), (4, 5, 1), (2, 6, 2), (4, 8, 1), (5, 9, 1), (4, 10, 2), (2, 12, 4)],
}


def chime(f, dur, vel=0.2):        # the bell, rounded off: lower FM depth, low-passed, slower decay
    n = int(dur * SR)
    t = np.arange(n) / SR
    mod = np.sin(2 * np.pi * f * 2.0 * t) * 0.9 * np.exp(-t * 5)
    x = np.sin(2 * np.pi * f * t + mod) * np.exp(-t * 2.4)
    return vel * lp(x * env(n, 0.006, 0.05, 1, 0.08), 3600)


def scale_m(root_m, mode, degree):
    sc = MAJOR if mode == "major" else MINOR
    o, d = divmod(degree, 7)
    return root_m + 12 * o + sc[d]


def triad(root_m, mode, degree, seventh=True):
    return [mhz(scale_m(root_m, mode, degree + k)) for k in ((0, 2, 4, 6) if seventh else (0, 2, 4))]


def render(brand, style, seconds, cuts=(), seed=0):
    global R
    R = rng(100 + seed)
    B = BRANDS[brand]
    root, mode = B["key"]
    root_m = midi(root, 3)
    n = int(seconds * SR)
    mus, drm, sfx = np.zeros(n), np.zeros(n), np.zeros(n)
    nbars = int(np.ceil(seconds / BAR)) + 1
    for b in range(nbars):
        t0 = b * BAR
        deg = B["prog"][b % len(B["prog"])]
        ch = triad(root_m, mode, deg)
        bf = mhz(scale_m(root_m - 12, mode, deg))
        # --- harmony
        if style == "pop":
            put(mus, pad([f * 2 for f in ch], BAR + 0.3, 0.16, 3200, 0.05), t0)
            for e8 in (0, 3, 4, 6):  # bouncy octave bass
                put(mus, bass(bf * (2 if e8 in (3, 6) else 1), BEAT * 0.45, 0.42), t0 + e8 * BEAT / 2)
        elif style == "cinematic":
            put(mus, strings([f * 2 for f in ch[:3]], BAR + 0.5, 0.22), t0)
            put(mus, bass(bf, BAR * 0.9, 0.35, drive=1.2), t0)
            for e16 in range(16):  # ticking-clock ostinato (16ths), accent on beats
                put(drm, tick(0.22, accent=(e16 % 4 == 0)), t0 + e16 * BEAT / 4)
            for e8 in range(8):    # pulsing low string 8ths
                put(mus, pluck(bf * 2, BEAT * 0.45, 0.16, damp=0.99, seed=e8), t0 + e8 * BEAT / 2)
        elif style == "warm":
            put(mus, pad([f * 2 for f in ch[:3]], BAR + 0.3, 0.08, 1500, 0.3), t0)
            put(mus, keys([f * 2 for f in ch], BEAT * 2.4, 0.24), t0)
            put(mus, keys([f * 2 for f in ch], BEAT * 1.6, 0.14), t0 + 2.5 * BEAT)
            put(mus, bass(bf, BEAT * 1.8, 0.30, drive=0.7), t0)
            put(mus, bass(bf * 1.5, BEAT * 0.9, 0.20, drive=0.7), t0 + 2.5 * BEAT)
        else:  # lofi
            put(mus, keys([f * 2 for f in ch], BEAT * 1.8, 0.30), t0)
            put(mus, keys([f * 2 for f in ch], BEAT * 1.6, 0.20), t0 + 2.5 * BEAT)
            put(mus, bass(bf, BEAT * 1.4, 0.40, drive=1.0), t0)
            put(mus, bass(bf * 1.5, BEAT * 0.8, 0.30, drive=1.0), t0 + 2.5 * BEAT)
        # --- drums
        for beat in range(4):
            tb = t0 + beat * BEAT
            if style == "pop":
                if beat in (0, 2):
                    put(drm, kick(0.65), tb)
                if beat in (1, 3):
                    put(drm, clap(0.42), tb)
                put(drm, hat(0.10), tb + BEAT * 0.55)   # swung off-beat
                put(drm, hat(0.06), tb)
            elif style == "cinematic":
                if beat == 0 and b % 2 == 0:
                    put(drm, taiko(0.55), tb)
                if beat == 2 and b % 2 == 1:
                    put(drm, taiko(0.45), tb + BEAT / 2)
            elif style == "warm":
                if beat == 0 or (beat == 2 and b % 2 == 1):
                    put(drm, kick(0.30, tight=8), tb + (BEAT / 2 if beat == 2 else 0))
                if beat in (1, 3):
                    put(drm, snare(0.10), tb + 0.02)
                put(drm, hat(0.035), tb + BEAT * 0.58)
            else:
                if beat == 0 or (beat == 2 and b % 2 == 1):
                    put(drm, kick(0.6, tight=7), tb + (BEAT / 2 if beat == 2 else 0))
                if beat in (1, 3):
                    put(drm, snare(0.32), tb + 0.02)
                put(drm, hat(0.07), tb + BEAT * 0.58)
        # --- the HOOK, every 2 bars, an octave up so phones hear it; 2nd time slightly varied
        if b % 2 == 0:
            for k, (dg, s8, l8) in enumerate(HOOKS[style]):
                if b % 4 == 2 and k == len(HOOKS[style]) - 1:
                    dg += 2                      # variation on the answer phrase
                f = mhz(scale_m(root_m + 12, mode, dg))
                at = t0 + s8 * BEAT / 2
                dur = l8 * BEAT / 2 + 0.05
                if style == "pop":
                    put(mus, bell(f * 2, dur + 0.4, 0.30), at)
                    put(mus, pluck(f, dur, 0.18, seed=k), at)
                elif style == "cinematic":
                    put(mus, lead(f, dur + 0.2, 0.16, 2600), at)
                elif style == "warm":
                    put(mus, chime(f * 2, dur + 0.6, 0.20), at)
                else:
                    put(mus, bell(f, dur + 0.3, 0.22), at)
    # --- sound design synced to the picture
    if style == "warm":   # soft landing instead of an impact: one rounded chime chord, then airy swells on cuts
        for k, f in enumerate(triad(root_m + 24, mode, 0, seventh=False)):
            put(sfx, chime(f, 1.6, 0.09), 0.0 + 0.03 * k)
        for c in cuts:
            if 0.6 < c < seconds - 0.3:
                put(sfx, lp(whoosh(0.5, 0.06), 2500), c - 0.5)
    else:
        put(sfx, impact(0.75), 0.0)
    if style == "cinematic":
        put(sfx, braam(mhz(root_m - 12), 2.2, 0.45), 0.0)
    for c in (cuts if style != "warm" else ()):
        if 0.6 < c < seconds - 0.3:
            w = whoosh(0.45, 0.22)
            put(sfx, w, c - 0.45)
    if seconds > 8 and style != "warm":
        put(sfx, riser(1.5, 0.12), seconds - 4.5)
    # --- mix
    mus = verb(mus, 1.8 if style == "cinematic" else (1.6 if style == "warm" else 1.3), 0.28 if style == "warm" else 0.24)
    if style == "pop":
        mus = echo(mus, BEAT * 0.75, 0.3, 0.18)
    # sidechain-style pump on pop: duck music a little on each kick
    if style == "pop":
        t = np.arange(n) / SR
        pump = 1 - 0.25 * np.exp(-((t % BEAT) * 12))
        mus *= pump
    mix = hp(mus, 35) + drm + sfx
    if style == "lofi":
        mix = lp(mix, 9000) + crackle(n)
    if style == "warm":
        mix = lp(mix, 7500) + crackle(n, 0.0018)
    fade = int(0.4 * SR)
    mix[-fade:] *= np.linspace(1, 0, fade) ** 2
    mix = np.tanh(mix * 1.15)
    mix /= max(1e-6, np.max(np.abs(mix))) / 0.9
    d = int(0.011 * SR)
    right = np.concatenate([np.zeros(d), mix[:-d]]) * 0.9 + mix * 0.1
    return np.stack([mix, right], 1)


def write(path, st):
    wavfile.write(str(path), SR, (st * 32767).astype(np.int16))


if __name__ == "__main__":
    if sys.argv[1] == "demos":
        out = Path(__file__).resolve().parent.parent / "audio" / "beds" / "v2"
        out.mkdir(parents=True, exist_ok=True)
        for brand in BRANDS:
            for style in ("pop", "cinematic", "lofi"):
                write(out / f"{brand}-{style}.wav", render(brand, style, 20, cuts=[4, 8, 12, 16]))
                print("wrote", brand, style)
    else:
        brand, style, secs, path = sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4]
        cuts = [float(c) for c in sys.argv[5].split(",")] if len(sys.argv) > 5 and sys.argv[5] else []
        write(path, render(brand, style, secs, cuts))
        print("wrote", path)
