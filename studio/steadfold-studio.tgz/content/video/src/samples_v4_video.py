#!/usr/bin/env python3
"""samples-v3 videos on REAL photographic backgrounds (Canva AI photos, fetched at native resolution).

  (a) Fully Funded 3-slide video carousel, 1080x1350, 6 s each, Halloween slow-pan style:
      "Start." (pastel clouds) / "Early." (wheat field, golden hour) / "Let it grow." (misty pine forest).
  (b) Littlefold silhouette Reel rebuilt on the real silhouette photos: same LINES, same "tender" music and text
      timing as lf_silhouette_letters.py; slow push-in per photo, cross-fade walk -> shoulders -> walk (loops),
      text pixel-still, warm grade, fine screen-space grain. 1080x1920, 20 s, -14 LUFS.

Text layers are rendered at deviceScaleFactor 2 and Lanczos-downsampled (sharper than the engine's 1x default).

    python3 samples_v3_video.py ff | lf | all
Outputs: /home/claude/content/video/out/samples-v3/
"""
from __future__ import annotations

import io
import json
import math
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, "/home/claude/content/design")
import slowpan as SP  # noqa: E402
from slowpan import Scene, Move, FPS, REEL, FEED  # noqa: E402

V = Path("/home/claude/content/video")
OUT = V / "out" / "samples-v4"
ASSETS = Path("/home/claude/content/design/samples-v3/assets")
PREP = Path("/home/claude/content/design/samples-v3/prep")
MARKS = Path("/home/claude/content/design/assets/marks")
FONTS = Path("/home/claude/content/design/assets/fonts")
OUT.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------------------------- 2x text layer
def text_png_2x(html, css, size, out_png):
    from playwright.sync_api import sync_playwright
    from engine.themes import font_css
    w, h = size
    extra = (f"@font-face{{font-family:'Instrument';src:url({(FONTS / 'InstrumentSerif-Regular.ttf').as_uri()})}}"
             f"@font-face{{font-family:'Instrument';font-style:italic;src:url({(FONTS / 'InstrumentSerif-Italic.ttf').as_uri()})}}")
    page = (f"<!doctype html><html><head><meta charset='utf-8'><style>{font_css('littlefold')}{extra}{SP.TEXT_BASE}"
            f"html,body{{width:{w}px;height:{h}px}}{css}</style></head><body>{html}</body></html>")
    src = Path(out_png).with_suffix(".html")
    src.write_text(page, encoding="utf-8")
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": w, "height": h}, device_scale_factor=2)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(250)
        big = Image.open(io.BytesIO(pg.screenshot(type="png", omit_background=True))).convert("RGBA")
        br.close()
    big.resize((w, h), Image.LANCZOS).save(out_png)
    im = cv2.imread(str(out_png), cv2.IMREAD_UNCHANGED)
    return im[..., 3]


SP.text_png = text_png_2x


def grade(img, warm=(1.045, 1.0, 0.93), sat=1.06, lift=0.015):
    """Warm grade on float RGB 0..1."""
    g = img * np.array(warm, np.float32)
    lum = (g @ np.array([0.2126, 0.7152, 0.0722], np.float32))[..., None]
    g = lum + (g - lum) * sat
    return np.clip(g * (1 - lift) + lift, 0, 1)


def load(path, max_wh=None):
    im = cv2.cvtColor(cv2.imread(str(path), cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)
    if max_wh and (im.shape[1] > max_wh[0] or im.shape[0] > max_wh[1]):
        s = min(max_wh[0] / im.shape[1], max_wh[1] / im.shape[0])
        im = cv2.resize(im, (round(im.shape[1] * s), round(im.shape[0] * s)), interpolation=cv2.INTER_AREA)
    return im


# ----------------------------------------------------------------------------- (a) Fully Funded carousel
FF_CSS = """
.wrap{position:absolute;left:0;right:0;text-align:center}
.kick{font:700 30px/1 Inter;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.94);
 text-shadow:0 2px 18px rgba(20,16,30,.45)}
.word{font-family:Instrument;font-weight:400;letter-spacing:-.03em;line-height:.86;color:#fff;
 text-shadow:0 10px 70px rgba(20,16,30,.40),0 1px 3px rgba(20,16,30,.25)}
.word i{font-style:italic}
.foot{position:absolute;left:0;right:0;top:1200px;display:flex;justify-content:center;align-items:center;gap:14px;
 font:700 27px/1 Inter;color:#fff;text-shadow:0 2px 14px rgba(20,16,30,.5)}
.foot img{width:46px;height:46px;border-radius:50%;background:#fff;padding:3px}
.foot b{font-weight:600;opacity:.7;margin-left:10px}
"""


def ff_text(i, word, kicker, size, top):
    foot = f'<div class="foot"><img src="{(MARKS / "fullyfunded.png").as_uri()}">Fully Funded<b>{i} / 3</b></div>'
    return (f'<div class="wrap kick" style="top:{top - 80}px">{kicker}</div>'
            f'<div class="wrap word" style="top:{top}px;font-size:{size}px">{word}</div>{foot}')


def photo_layers(path, darken=0.0, warm=True):
    """slowpan bg callable: the photo cover-fitted into the engine's source canvas (never upscaled more than the
    canvas requires), with a gentle grade and an optional top/bottom darkening for text contrast."""
    def make(w, h, u):
        import slowpan_bg as B
        im = load(path).astype(np.float32) / 255
        im = B.cover_fit(im, w, h)
        if warm:
            im = grade(im, warm=(1.03, 1.0, 0.96), sat=1.05, lift=0.0)
        if darken:
            y = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
            shade = 1 - darken * (0.55 * np.exp(-((y - 0.42) / 0.22) ** 2) + 0.6 * np.clip((y - 0.8) / 0.2, 0, 1))
            im = im * shade
        return [B.Layer(np.ascontiguousarray(im), depth=1.0, name="photo")]
    return make


def ff_slides():
    common = dict(dur=6.0, css=FF_CSS, loop=0.6, ss=1, grain=0.018, vignette=0.18, margin=0.10)
    return [
        Scene(bg=photo_layers(ASSETS / "g-clouds.png", darken=0.18), move=Move(pan=0.05, parallax=False), seed=11,
              text=ff_text(1, "Start.", "Investing for your kid?", 330, 470), **common),
        Scene(bg=photo_layers(ASSETS / "g-wheat.png", darken=0.22), move=Move(pan=-0.05, parallax=False), seed=12,
              text=ff_text(2, "<i>Early.</i>", "Time does the heavy lifting", 330, 470), **common),
        Scene(bg=photo_layers(ASSETS / "g-forest.png", darken=0.12), move=Move(pan=0.05, parallax=False), seed=13,
              text=ff_text(3, "Let it<br><i>grow.</i>", "Then leave it alone", 270, 380), **common),
    ]


BOLD_CSS = """
.k{position:absolute;left:0;right:0;text-align:center;font:800 32px/1 Inter;letter-spacing:.24em;text-transform:uppercase;
 color:#FFE7B8;text-shadow:0 2px 18px rgba(8,10,30,.6)}
.w{position:absolute;left:0;right:0;text-align:center;font-family:'Inter Display';font-weight:900;letter-spacing:-.05em;
 line-height:.8;color:#fff;filter:drop-shadow(0 14px 50px rgba(8,10,30,.55))}
.w b{color:#FFC94D;font-weight:900}
.s{position:absolute;left:0;right:0;text-align:center;font:600 40px/1.2 Inter;color:#fff;text-shadow:0 2px 20px rgba(8,10,30,.6)}
.foot{position:absolute;left:0;right:0;top:1200px;display:flex;justify-content:center;align-items:center;gap:14px;
 font:700 27px/1 Inter;color:#fff;text-shadow:0 2px 14px rgba(20,16,30,.5)}
.foot img{width:46px;height:46px;border-radius:50%;background:#fff;padding:3px}
"""


def run_bold():
    foot = f'<div class="foot"><img src="{(MARKS / "fullyfunded.png").as_uri()}">Fully Funded</div>'
    txt = ('<div class="k" style="top:330px">The real secret?</div>'
           '<div class="w" style="top:410px;font-size:350px">TIME<b>.</b></div>'
           '<div class="s" style="top:820px">Not timing. Time.</div>' + foot)
    sc = Scene(bg=photo_layers(ASSETS / "g-street.png", darken=0.25), move=Move(pan=-0.05, push=0.03, parallax=False),
               seed=14, text=txt, css=BOLD_CSS, dur=6.0, loop=0.6, ss=1, grain=0.018, vignette=0.2, margin=0.10)
    out = OUT / "fullyfunded-slowpan-bold.mp4"
    res = SP.render([sc], out, FEED, music=("fullyfunded", "warm", 4), lufs=-16, crf=17, maxrate="9M")
    Image.fromarray(SP.still(out, 1.0, FEED)).save(OUT / "fullyfunded-slowpan-bold-cover.jpg", quality=95)
    sheet([out], FEED, OUT / "fullyfunded-slowpan-bold-contact.png", "Fully Funded · bold slow-pan alternative (6 s)")
    return dict(mp4=str(out), mb=round(out.stat().st_size / 1e6, 2), jitter=SP.jitter_check(res))


def run_ff():
    res_all = []
    for k, sc in enumerate(ff_slides(), 1):
        out = OUT / f"fullyfunded-slowpan-0{k}.mp4"
        res = SP.render([sc], out, FEED, music=("fullyfunded", "warm", k), lufs=-16, crf=17, maxrate="9M")
        jit = SP.jitter_check(res)
        res_all.append(dict(mp4=str(out), mb=round(out.stat().st_size / 1e6, 2), jitter=jit))
        # cover = frame at 1.0 s, saved crisp
        fr = SP.still(out, 1.0, FEED)
        Image.fromarray(fr).save(OUT / f"fullyfunded-slowpan-0{k}-cover.jpg", quality=95)
    sheet(sorted(OUT.glob("fullyfunded-slowpan-0?.mp4")), FEED, OUT / "fullyfunded-slowpan-contact.png",
          "Fully Funded · slow-pan video carousel (3 x 6 s, 1080x1350, real photo backgrounds)")
    (OUT / "fullyfunded-slowpan-qa.json").write_text(json.dumps(res_all, indent=1, default=str))
    return res_all


# ----------------------------------------------------------------------------- (b) Littlefold silhouette Reel
def run_lf():
    import lf_silhouette_letters as L
    L.STEM = "littlefold-silhouette-photo"
    L.OUT = OUT
    OW, OH = REEL
    T, NF = L.T, L.NF
    tl = L.timeline()
    cut = (tl[2][3] + tl[3][0]) / 2            # between line 3 fading out and line 4 fading in
    XF = 1.2
    A_img = load(ASSETS / "silhouette1.jpg", max_wh=(1440, 2560)).astype(np.float32) / 255   # Canva native ~1440x2560
    B_img = load(ASSETS / "g-shoulders.png").astype(np.float32) / 255
    A_img, B_img = grade(A_img), grade(B_img, warm=(1.035, 1.0, 0.95))
    rng = np.random.default_rng(5)
    yy, xx = np.mgrid[0:OH, 0:OW].astype(np.float32)
    vig = 1 - 0.22 * np.clip(((xx / OW - 0.5) ** 2 + (yy / OH - 0.5) ** 2) / 0.5, 0, 1) ** 1.3
    top = 1 - 0.18 * np.exp(-((yy / OH - 0.33) / 0.16) ** 2)                 # soft shade behind the text band
    shade = (vig * top)[..., None]

    def view(img, p, focus):
        h, w = img.shape[:2]
        base = max(OW / w, OH / h)
        s = base * (1.0 + 0.075 * p)
        fx, fy = focus
        cx, cy = w * fx, h * fy
        M = np.float32([[s, 0, OW * fx - s * cx], [0, s, OH * fy - s * cy]])
        return cv2.warpAffine(img, M, (OW, OH), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)

    def ease(x):
        x = min(max(x, 0.0), 1.0)
        return 0.5 - 0.5 * math.cos(math.pi * x)

    def frames(idx):
        for i in idx:
            t = i / FPS
            pa = ease(t / cut)
            pb = ease((t - cut) / (T - cut))
            fa = view(A_img, pa, (0.48, 0.80))
            fb = view(B_img, pb, (0.40, 0.78))
            # dip to warm black: A fades down to the cut, B fades up after it; the two photos never overlap
            if t < cut:
                fr = fa * (1 - L.smoothstep(cut - XF / 2, cut, t))
            else:
                fr = fb * L.smoothstep(cut, cut + XF / 2, t)
            dip = 1 - (L.smoothstep(cut - XF / 2, cut, t) if t < cut else 1 - L.smoothstep(cut, cut + XF / 2, t))
            fr = fr + np.array([0.10, 0.05, 0.03], np.float32) * (1 - dip) * 0.6
            fr = fr * shade
            n = rng.normal(0, 1, (OH // 2, OW // 2)).astype(np.float32)
            n = cv2.resize(n, (OW, OH), interpolation=cv2.INTER_LINEAR) * 0.022
            lum = fr.mean(-1, keepdims=True)
            fr = fr + n[..., None] * (0.4 + 0.6 * (1 - np.abs(lum - 0.5) * 2))
            yield (np.clip(fr, 0, 1) * 255 + 0.5).astype(np.uint8).tobytes()

    L.bg_frames = lambda idx, procs=None: frames(idx)
    mp4 = OUT / f"{L.STEM}.mp4"
    res = L.render(mp4, crf=18, maxrate="7M")
    jit = SP.jitter_check(res)
    f0 = np.frombuffer(next(frames([0])), np.uint8).reshape(OH, OW, 3)
    cov = L.cover(OUT / f"{L.STEM}-cover.jpg", f0)
    qa = dict(probe=SP.probe(mp4), loudness=L.loudness(mp4), jitter=jit, cover=cov,
              size_mb=round(mp4.stat().st_size / 1e6, 2), cut_s=round(cut, 2))
    (OUT / "littlefold-silhouette-photo-qa.json").write_text(json.dumps(qa, indent=1, default=str))
    sheet([mp4], REEL, OUT / "littlefold-silhouette-photo-contact.png",
          "Littlefold · silhouette Reel on real photos (20 s, 1080x1920)", times=[0.8, 3.6, 6.4, 9.6, 11.6, 14.4, 17.0, 19.4])
    print(json.dumps({k: v for k, v in qa.items() if k != "probe"}, indent=1, default=str))
    return qa


def sheet(mp4s, size, out, label, times=(0.5, 3.0, 5.5)):
    from PIL import ImageDraw, ImageFont
    tw = 300 if size == FEED else 220
    th = round(tw * size[1] / size[0])
    cells = [(m, t) for m in mp4s for t in times]
    cols = len(times) * len(mp4s) if size == FEED else len(times)
    rows = math.ceil(len(cells) / cols)
    W = cols * (tw + 12) + 12
    H = 60 + rows * (th + 40) + 12
    sh = Image.new("RGB", (W, H), "#EDE8E1")
    d = ImageDraw.Draw(sh)
    d.text((14, 16), label, fill="#222", font=ImageFont.truetype(str(FONTS / "Inter-Bold.ttf"), 24))
    f2 = ImageFont.truetype(str(FONTS / "Inter-Medium.ttf"), 16)
    for k, (m, t) in enumerate(cells):
        r, c = divmod(k, cols)
        fr = Image.fromarray(SP.still(m, t, size)).resize((tw, th), Image.LANCZOS)
        x, y = 12 + c * (tw + 12), 60 + r * (th + 40)
        sh.paste(fr, (x, y))
        d.text((x, y + th + 8), f"{Path(m).stem[-14:]} @ {t:.1f}s", fill="#555", font=f2)
    sh.save(out)


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("ff", "all"):
        print(json.dumps(run_ff(), indent=1, default=str))
    if which in ("lf", "all"):
        run_lf()
    if which in ("bold", "all"):
        print(json.dumps(run_bold(), indent=1, default=str))
