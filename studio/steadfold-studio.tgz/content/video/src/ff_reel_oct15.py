#!/usr/bin/env python3
"""Fully Funded · 'Get up to $2,000 for your kid's school. Free.' Reel (Thu Oct 15, 7 pm).
From the carousel ff-w02-4-learning-bond (posts Thu Oct 15, 12 pm). 23.0 s, 1080x1920, 30 fps, 6 scenes, no voice.
Music: music.py fullyfunded bed (120 BPM); every scene starts on the 0.5 s grid, so each cut lands on a beat.

Payoff-first shape (REEL-BRIEF.md, Oct 14), mirroring carousel slides 1, 2, 3, 2 (step 3 note), 5 and 7:
  1 payoff + action on frame 0: "Get up to $2,000 for your kid's school. Free." + "Claim it in 3 steps."
  2 the 3 steps on one card stack (carousel slide 2), so scenes 1-2 alone tell you what to do (2-slide test)
  3 what you get: $500 first, then $100 a year, maximum $2,000 (slide 3)
  4 already have an RESP? Ask if the bond was requested (slide 2, step 3 + caption line)
  5 turned 18? Claim it yourself, 18 to 20 (slide 5)
  6 cobalt CTA, slide 7's look: "Know a kid born since 2004?" -> loops into scene 1's answer "Get up to $2,000..."

DESIGN RULE: built only from the carousel's pieces: #F5F7FF paper with the lavender circle top-right and the
peach circle bottom-left, Inter Display 800 ink headlines with the orange marker (highlight style A) on key words,
rounded white cards, cobalt number tiles, orange kicker text, cobalt big numbers. Cobalt only on the CTA, like
slide 7. No grid, no washes. Clean motion only (up, wipe, circle, push). Nothing moves after it lands
(.cam locked, no breathing, no shakes, no flashes).
Facts: only what the shipped carousel + caption say (canada.ca, rules as of Oct 2026). No new numbers."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from vlab import Video, words, el, caption, CHECK, MARKS  # noqa: E402

# ---- theme: the exact CSS from ff_learning_bond.py ...
THEME = """
:root{--bg:#F5F7FF;--ink:#0E1440;--co:#2B3FE0;--or:#FF6A3D;--hl:#FFB08F;--hl-dark:#FF6A3D;
 --prog-bg:rgba(255,255,255,.62);--prog-fg:#FF6A3D;--cap-bg:#0E1440;--cap-ink:#FFFFFF;--cap-r:20px;
 --cap-sh:0 18px 40px -18px rgba(14,20,64,.5);--cap-bd:0;--strike:#FF6A3D}
.dark{--cap-bg:#FFFFFF;--cap-ink:#0E1440;--hl-dark:#FFB08F}
.H{font-family:'Inter Display';font-weight:800;letter-spacing:-.035em;line-height:1;color:var(--ink)}
.dark .H{color:#fff}
.B{font-family:Inter;font-weight:600;color:var(--ink);letter-spacing:-.01em;line-height:1.25}
.dark .B{color:#D3D9FF}
.grid{background-image:linear-gradient(rgba(43,63,224,.07) 2px,transparent 2px),
 linear-gradient(90deg,rgba(43,63,224,.07) 2px,transparent 2px);background-size:90px 90px}
.dark .grid{background-image:linear-gradient(rgba(255,255,255,.07) 2px,transparent 2px),
 linear-gradient(90deg,rgba(255,255,255,.07) 2px,transparent 2px)}
.pill{display:inline-block;font:800 28px/1 Inter;letter-spacing:.12em;text-transform:uppercase;color:#fff;
 background:#FF6A3D;padding:14px 22px 13px;border-radius:999px}
.card{background:#fff;border-radius:28px;box-shadow:0 30px 60px -28px rgba(14,20,64,.45);border:2px solid #DCE1FA}
.chip{display:inline-block;font:800 44px/1 'Inter Display';letter-spacing:-.02em;color:#0E1440;background:#fff;
 border-radius:999px;padding:24px 38px 26px;box-shadow:0 18px 36px -18px rgba(14,20,64,.55);white-space:nowrap}
.line{display:flex;align-items:baseline;justify-content:space-between;padding:26px 34px;font:600 40px/1.2 Inter;
 color:#0E1440;border-top:2px solid #E3E7FA}
.line b{font:800 72px/1 'Inter Display';letter-spacing:-.03em;color:#2B3FE0}
.step{display:flex;gap:26px;align-items:center;background:#fff;border-radius:24px;padding:26px 30px;
 box-shadow:0 22px 44px -26px rgba(14,20,64,.5);font:700 42px/1.2 Inter;color:#0E1440;margin-bottom:22px}
.step i{font-style:normal;flex:0 0 72px;height:72px;border-radius:50%;background:#2B3FE0;color:#fff;display:flex;
 align-items:center;justify-content:center;font:800 40px/1 'Inter Display'}
#tag{position:absolute;left:84px;top:240px;display:flex;align-items:center;gap:12px;background:#fff;
 border-radius:999px;padding:6px 22px 6px 6px;font:800 26px/1 Inter;color:#0E1440;box-shadow:0 8px 20px -10px rgba(14,20,64,.5)}
#tag img{width:44px;height:44px;border-radius:50%}
#tag span{opacity:.6;font-weight:700}
""" + """
/* ---- ... plus the carousel pieces (colours sampled from out/ff-w02-4-learning-bond/slide-0N.png) */
:root{--hl:#FF764C;--prog-bg:rgba(14,20,64,.10)}
.dark{--hl:#FD6B3F;--prog-bg:rgba(255,255,255,.28);--prog-fg:#FF6A3D}
.cam{transform:none!important}
/* orange marker, style A: band from 0.6em above the baseline to 0.13em below it, ink text on top */
.H .w.hl,.H .hlx,.dark .H .w.hl,.dark .H .hlx{display:inline-block;line-height:1;color:var(--ink);
 background-image:linear-gradient(var(--hl),var(--hl));background-repeat:no-repeat;background-position:0 67%;
 background-size:calc(var(--p,0)*100%) 74%;border-radius:.12em;padding:0 .14em;margin:0 -.14em}
.kick{font:800 30px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:#C13E08}
.deco{position:absolute;border-radius:50%}
.lead{font:600 58px/1.22 Inter;color:#0E1440;letter-spacing:-.012em}
.lead b{color:#2B3FE0;font-weight:800}
.mut{font:500 58px/1.24 Inter;color:#4A5077;letter-spacing:-.01em}
.mut b{color:#0E1440;font-weight:700}
.stack{display:flex;flex-direction:column;gap:24px}
.stp{display:flex;align-items:center;gap:34px;padding:30px 36px}
.stp .n{flex:none;display:grid;place-items:center;width:112px;height:112px;border-radius:28px;background:#2B3FE0;
 color:#fff;font:800 68px/1 'Inter Display';letter-spacing:-.03em}
.stp .t{font:800 68px/1.04 'Inter Display';letter-spacing:-.03em;color:#0E1440}
.ok{display:inline-flex;align-items:center;gap:20px;font:800 58px/1 'Inter Display';letter-spacing:-.02em;color:#0E1440;
 background:#fff;border-radius:999px;padding:18px 40px 18px 18px;box-shadow:0 22px 40px -26px rgba(14,20,64,.55);
 border:2px solid #DCE1FA;white-space:nowrap}
.ok i{display:grid;place-items:center;width:72px;height:72px;border-radius:50%;background:#FF6A3D;color:#fff;
 font-size:40px;font-style:normal}
.row{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:34px 40px;
 border-top:2px solid #E3E7FA;font:600 56px/1.15 Inter;color:#0E1440;letter-spacing:-.012em}
.row:first-child{border-top:0}
.row b{flex:none;font:800 96px/1 'Inter Display';letter-spacing:-.04em;color:#2B3FE0}
.row.tot{background:#2B3FE0;color:#fff;border:0}
.row.tot b{color:#fff}
.big{font:800 300px/.9 'Inter Display';letter-spacing:-.055em;color:#2B3FE0}
.uline{height:16px;border-radius:8px;overflow:hidden}
.uline .fill{height:100%;width:0;background:#FF6A3D;border-radius:8px}
.ctac{background:#fff;border-radius:40px;padding:60px 56px 64px;box-shadow:0 40px 80px -40px rgba(8,14,80,.6)}
.ctac .ib{display:grid;place-items:center;width:136px;height:136px;border-radius:32px;background:#FF6A3D;margin-bottom:44px}
.ctac .tx{font:800 84px/1.08 'Inter Display';color:#0E1440;letter-spacing:-.035em}
.ctac .tx b{color:#2B3FE0}
"""
TAG = f'<div id="tag"><img src="{(MARKS / "fullyfunded.png").as_uri()}">Fully Funded <span>· Benefits you\'re owed</span></div>'
X, W = 84, 912
BG, CO = "#F5F7FF", "#2B3FE0"
SEND = ('<svg width="66" height="66" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" '
        'stroke-linejoin="round" stroke-linecap="round"><path d="M21 3L3 10.5l7.2 2.6L13 21z"/><path d="M21 3L10.2 13.1"/></svg>')


def paper():
    """The carousel's light-slide decor: lavender circle top-right, peach circle bottom-left. Static."""
    return (el("", 660, -260, 760, a="none", cls="deco", style="height:760px;background:#E8ECFF")
            + el("", -250, 1470, 560, a="none", cls="deco", style="height:560px;background:#FBE6E1"))


def cobalt_paper():
    """Slide 7's decor: lighter cobalt circle top-right, darker one bottom-left."""
    return (el("", 560, -330, 900, a="none", cls="deco", style="height:900px;background:#3547E6")
            + el("", -300, 1400, 700, a="none", cls="deco", style="height:700px;background:#2436C9"))


def H(text, y, size, t=0.1, st=0.07, w=W):
    return words(text, t=t, st=st, cls="H", style=f"position:absolute;left:{X}px;top:{y}px;width:{w}px;"
                 f"font-size:{size}px")


def kick(text, y=352, t=0.0, a="none"):
    return el(f'<span class="kick">{text}</span>', X, y, a=a, t=t)


def static_caption(text, y=1560):
    """Scene 1's caption is already on screen at frame 0 (sound-off readers, and the cover)."""
    return el(f'<div class="words cap-w">{text}</div>', x=80, y=y, w=840, a="none", cls="cap")


def stp(n, title, t):
    return (f'<div class="card stp" data-a="up" data-t="{t}" data-d="0.42"><span class="n">{n}</span>'
            f'<span class="t">{title}</span></div>')


v = Video("fullyfunded", "reel-oct15", THEME, TAG)

# 1 · PAYOFF + ACTION (0–4.0). Mirrors the cover. Everything is on screen at frame 0, highlighter already drawn;
#     only the orange underline under $2,000 draws in (the carousel cover's underline).
v.scene(0, 4.0, "".join([
    paper(),
    kick("Benefits you're owed"),
    el('Get up to', X, 412, W, a="none", cls="H", style="font-size:120px"),
    el('$2,000', X, 540, W, a="none", cls="H big", style="font-size:278px"),
    el('<div class="uline" data-a="bar" data-t="0.25" data-d="0.45" data-w="100"><div class="fill"></div></div>',
       X, 812, 230, a="none"),
    el('for your kid\'s<br>school. <span class="hlx" style="--p:1">Free.</span>', X, 862, W, a="none", cls="H",
       style="font-size:120px;line-height:1.02"),
    el('<div class="card" style="padding:36px 40px"><div class="lead">Born 2004 or later, lower family income?<br>'
       '<b>Claim it in 3 steps.</b></div></div>', X, 1130, W, a="none"),
    static_caption("Get up to $2,000 for your kid's school, free. Here's how to claim it."),
]), tin="cut", bg=BG)

# 2 · THE 3 STEPS (4.0–9.0). Carousel slide 2: number tiles on white cards, one card per beat.
v.scene(4.0, 9.0, "".join([
    paper(),
    kick("How to claim it"),
    H("Claim it in|==3 steps.==", 412, 116, t=0.1),
    el('<div class="stack">' + stp(1, "Get your child a SIN", 0.6) + stp(2, "Open an RESP", 1.1)
       + stp(3, "Ask for the bond", 1.6) + '</div>', X, 690, W, a="none"),
    el(f'<span class="ok"><i>{CHECK}</i>No deposit needed</span>', X, 1310, a="up", t=2.3, d=0.45),
    caption("Get your child a SIN,|open an RESP that offers the bond,|then ask for the bond.", t=0.2, y=1560),
]), tin="push", bg=BG)

# 3 · WHAT YOU GET (9.0–12.5). Carousel slide 3's calculator card.
v.scene(9.0, 12.5, "".join([
    paper(),
    kick("What you get"),
    H("$500 first,|==then $100 a year.==", 412, 112, t=0.1, st=0.06),
    el('<div class="card" style="overflow:hidden">'
       '<div class="row" data-a="up" data-t="0.75" data-d="0.4">First eligible<br>year<b>$500</b></div>'
       '<div class="row" data-a="up" data-t="1.05" data-d="0.4">Each later eligible<br>year, up to age 15<b>+$100</b></div>'
       '<div class="row tot" data-a="up" data-t="1.4" data-d="0.4">Maximum<b>$2,000</b></div>'
       '</div>', X, 700, W, a="up", t=0.6, d=0.45),
    caption("$500 the first eligible year,|then $100 a year, up to $2,000.", t=0.2, y=1560),
]), tin="wipe", bg=BG)

# 4 · ALREADY HAVE AN RESP? (12.5–16.0). Slide 2's step-3 note + the caption's "only lands once someone asks".
v.scene(12.5, 16.0, "".join([
    paper(),
    kick("Already have an RESP?"),
    H("Ask if the bond|==was requested.==", 412, 112, t=0.1, st=0.06),
    el('<div class="card" style="padding:40px 44px"><div class="mut">It only lands once<br>'
       '<b>someone asks for it.</b></div></div>', X, 700, W, a="up", t=0.8, d=0.45),
    caption("Already have an RESP? Ask if the bond was requested.", t=0.2, y=1560),
]), tin="push", bg=BG)

# 5 · TURNED 18? (16.0–19.5). Carousel slide 5.
v.scene(16.0, 19.5, "".join([
    paper(),
    kick("Missed it as a kid?"),
    H("Turned 18?|==Claim it yourself.==", 412, 112, t=0.1, st=0.06),
    el('18–20', X, 690, W, a="up", t=0.6, d=0.45, cls="H big"),
    el('<div class="card" style="padding:38px 44px"><div class="mut">You can apply on your own until the day '
       'before you&nbsp;turn&nbsp;21.</div></div>', X, 1040, W, a="up", t=1.0, d=0.45),
    caption("Turned 18? You can apply yourself until the day before you turn 21.", t=0.2, y=1560),
]), tin="push", bg=BG)

# 6 · SEND + FOLLOW (19.5–23.0): slide 7's cobalt look. Its question loops straight into scene 1's answer.
v.scene(19.5, 23.0, "".join([
    cobalt_paper(),
    words("Know a kid|==born since 2004?==", t=0.15, st=0.06, cls="H",
          style=f"position:absolute;left:{X}px;top:410px;width:{W}px;font-size:104px;line-height:1.1"),
    el(f'<img src="{(MARKS / "fullyfunded.png").as_uri()}" style="width:170px;height:170px">', 820, 330, a="up",
       t=0.35, d=0.45),
    el(f'<div class="ctac"><div class="ib">{SEND}</div><div class="tx"><b>Send it</b> to a parent, or to anyone '
       '18 to 20.</div></div>', X, 700, W, a="up", t=0.6, d=0.5),
    el('Follow @fullyfundedhq', X, 1290, W, a="up", t=1.1, d=0.4, cls="H",
       style="font-size:64px;color:#fff;letter-spacing:-.025em"),
    caption("Send this to a parent,|or to anyone 18 to 20.", t=0.2, y=1560),
]), tin="circle", bg=CO, origin="50% 50%", cls="dark")

SLUG = "fullyfunded-reel-oct15"

if __name__ == "__main__":
    from vlab import render, contact_sheet, preview
    out = Path("/home/claude/content/video/out")
    qa = Path("/home/claude/content/video/qa")
    if "--preview" in sys.argv:
        dst = Path(sys.argv[sys.argv.index("--preview") + 1])
        preview(v, [0.0, 3.9, 6.9, 8.9, 12.4, 15.9, 19.4, 22.9], dst)
    else:
        import subprocess
        from PIL import Image
        cover_png = Path(sys.argv[1]) if len(sys.argv) > 1 else qa / f"{SLUG}-cover.png"
        mp4 = render(v, out / f"{SLUG}-silent.mp4", cover_t=1.0, cover_png=cover_png)
        Image.open(cover_png).convert("RGB").save(out / f"{SLUG}-cover.jpg", quality=90)
        contact_sheet(mp4, qa / f"{SLUG}-sheet.png")
        bed = Path("/home/claude/content/video/audio/fullyfunded-reel-oct15-bed.wav")
        subprocess.run([sys.executable, str(Path(__file__).resolve().parent / "music.py"), "fullyfunded",
                        f"{v.duration + 0.5}", str(bed)], check=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp4), "-i", str(bed), "-filter_complex",
                        "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a]", "-map", "0:v", "-map", "[a]",
                        "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart",
                        str(out / f"{SLUG}.mp4")], check=True)
