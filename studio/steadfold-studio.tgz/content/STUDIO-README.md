# Steadfold studio bundle: how scheduled agents rebuild the engine

The bundle is `claude/studio/steadfold-studio.tgz.b64.txt` in the Learning Lab project. Every script inside uses absolute paths under /home/claude, so extract it there.

## Setup (about 1 minute)
```bash
mkdir -p /home/claude && cd /home/claude
# Read claude/studio/steadfold-studio.tgz.b64.txt from the Projects tool into /tmp/studio.b64 first
base64 -d /tmp/studio.b64 > /tmp/studio.tgz && tar -xzf /tmp/studio.tgz -C /home/claude
# Fonts: Caveat, Caveat Brush, Kalam, Gochi Hand, Fraunces, Playfair Display and DM Serif Display (SIL OFL, with licence txt)
# live in the autopost repo's assets/fonts (kept out of this bundle to save project space). Clone the repo first, then:
mkdir -p content/design/assets/fonts && cp /home/claude/steadfold-autopost/assets/fonts/* content/design/assets/fonts/
# Inter, Lora and Poppins are copied from the system:
for f in $(fc-list : file | grep -iE "Inter|Lora|Poppins" | cut -d: -f1); do cp -n "$f" content/design/assets/fonts/ 2>/dev/null; done
ls content/design/assets/fonts | head
# Playwright: Chromium is at /opt/pw-browsers/chromium (never run "playwright install")
cd content/design && (npm ls playwright >/dev/null 2>&1 || npm i playwright) && python3 selftest.py
```
If a script asks for a font file with an exact name (for example `Inter-Bold.ttf` or `InterDisplay-Black.ttf`) and the system copy has a different name, copy or rename the closest weight to that name.

## Image reuse rule (Oct 16, 2026)
**Never reuse the same photo on two posts within 30 days or across pages.** Each post gets its own imagery; A/B colourways of one post count as one post (publish one of them). Log what goes where in the set's `IMAGE-USE.md` (example: `design/samples-v5/IMAGE-USE.md`) and check it before building.

## What's inside
- `content/design/`: the carousel engine.
  - `render.py` + `engine/` hold the templates, themes (fullyfunded, lockedhour, hourback, littlefold "Sherbet") and covers.
  - Run `python3 render.py --help`.
  - Reference build: `content/week03-global/fullyfunded/build.py` (3 global Fully Funded posts, Oct 2026).
- `content/video/src/`: the Reel engine.
  - `vlab.py` (read its docstring) renders HTML scenes to MP4.
  - `music2.py` makes the original music (styles: pop, cinematic, lofi and warm; warm is the calm default).
  - `covers_v3.py` makes grid-safe covers.
  - Reference Reels: `ff_reel_start_at_birth.py` (global, calm) and `lf_safe_sleep.py` (voice and captions).
- `content/video/REEL-BRIEF.md`: the Reel checklist. CONTENT-STANDARD-v3 overrides its length: 12–20 s.
- `steadfold-library/current/guides/`:
  - CONTENT-STANDARD-v3.md (wins over every other standard)
  - PAYOFF-FIRST.md
  - COPY-STANDARD.md
  - copy-lint.py (`python3 copy-lint.py <file> --brand <brand>`)
- `content/littlefold/`: Littlefold brand bible, posts and captions.

## Shipping to Instagram (autopost)
- Repo: github.com/steadfoldhq/steadfold-autopost. Attach it with add_repo (owner steadfoldhq, repo steadfold-autopost, access "push"), then clone it.
- Add posts to `schedule/posts.json` (sorted by publish_at). Images go in `media/<post-id>/01.jpg…` at 1080×1350, quality 92. Reels go in `media/reels/<id>.mp4` (under 19.5 MB) plus `<id>-cover.jpg`.
- Post entry format:
  - feed post: `{"id","account","publish_at":"YYYY-MM-DDTHH:MM:00-04:00","caption","first_comment","alt_text":"one string","images":["<id>/01.jpg",...]}`. Image paths have no `media/` prefix.
  - Reel: `"video":"reels/<id>.mp4","cover":"reels/<id>-cover.jpg"`, with no images.
- Before you push: `python3 -m unittest discover -s tests -q` must pass, and `python3 autopost.py --dry-run --now <first new publish_at>` must list your posts with no problems.
- Rules: at most 1 feed post and 1 Reel per account per day. Never edit or remove a post whose publish_at has passed. Never touch `state/`.
- Performance data, refreshed 4 times a day: `insights/latest.json` (per post: views, reach, saved, shares, likes, comment text) and `insights/history.jsonl`.

## Interactive formats (Oct 15, 2026)
These are formats that keep people swiping. They're written as slide entries in a normal post JSON and rendered by the same `python3 render.py posts.json --out DIR` command. The code is in `content/design/engine/interactive.py`. Posts that don't use these formats render exactly as before (checked: 73/73 existing slides are pixel-identical).

- **Demos:** `content/design/demos-interactive/` holds the demo build (`build.py`, which also keeps the example math in `math.txt`), `<format>/slide-NN.png` and `contact-sheet.png`.
- **Length:** these formats need 4–5 slides because the swipe is the point. That's an exception to CONTENT-STANDARD-v3 §6, so note the reason in `_build_notes`. Like week 03, there's no cta slide: the save/send line goes in the caption, so run with `--no-fail` and check that `report.json` shows 0 errors. The only validation message allowed is "last slide must be the cta template".
- **Extra QA these posts get automatically:**
  - Every text line must be at least 70 px from each slide edge. On these posts the footer sits 8 px higher so it clears that line.
  - Every panorama seam is compared with the continuous canvas at 2x and at 1x, and must match exactly (the build prints `seam ok … max diff 0`).
  - Seams come out exact because each panorama canvas is rendered once as a single wide image. Every slide then shows its own slice of that image, and the whole strip is downsampled together.

**1. Panorama.** One canvas is cut into `slides` slides. A path flows across the slide edges; each stop is a time chip plus a text card that stays inside its own slide. `objects` adds art that can straddle a seam (`clock`, `sun`, `mark`, `star`).
```json
{"template": "panorama", "fields": {"slides": 3, "kicker": "Minutes 0–10", "title": "The first 10 minutes ==are the hardest.==",
  "heads": [null, {"kicker": "Minutes 10–45", "title": "Then the noise ==goes quiet.=="}, {"kicker": "Minutes 45–60", "title": "Finish ==on purpose.=="}],
  "stops": [{"time": "0:00", "text": "Phone in another room. Timer on."}, {"time": "0:04", "text": "The itch to check. Let it pass."}],
  "per_slide": [1, 0, 1], "path": "wave", "objects": [{"art": "clock", "seam": 2, "size": 160, "progress": 0.75}]}}
```
- Give every slide a heading (title). With no heading, the top of that slide stays empty.
- Use at most 3 stops per slide. Stop text has a 60-character limit, but keep it to about 32 characters (2 short lines).

**2. Follow the line.** Slide 1 shows 3–5 choices. Coloured lines wind across the middle slides and end at each choice's answer on the last slide, where the same icon repeats beside it.
- Each line has its own colour. Wherever two lines cross, the later line passes over with a gap, so you can always tell which is which.
- The answers come out in a shuffled order, and no line ends level with where it started. Change `seed` for a different winding, or set `end_order` yourself.
- For Fully Funded, work out the numbers in code and label them as example math (see `demos-interactive/build.py`).
```json
{"template": "follow-the-line", "fields": {"kicker": "100 a month, until 65", "title": "Pick your ==starting age.==",
  "choices": [{"icon": "25", "label": "Start at 25", "answer": {"value": "199,149", "note": "You put in 48,000"}},
              {"icon": "35", "label": "Start at 35", "answer": {"value": "100,452", "note": "You put in 36,000"}},
              {"icon": "45", "label": "Start at 45", "answer": {"value": "46,204", "note": "You put in 24,000"}}],
  "middle": [{"kicker": "Follow your colour", "title": "Same 100. ==Different start.=="}, {"kicker": "Keep going", "title": "Time does the ==heavy lifting.=="}],
  "end": {"kicker": "At 65 · example math", "title": "Here's where ==it lands.==", "note": "Example at 6% a year, compounded monthly. Not guaranteed. …"},
  "seed": 3}}
```
- `icon` can be 1–3 characters or a single emoji.
- `middle` holds 1–3 slides, so the format makes 3–5 slides in total.

**3. Swipe to reveal.** One card goes from heavily pixelated to sharp over 3–5 slides, using our own rendered visuals only.
- `target.kind` is one of:
  - `prompt`: a chat card. `[brackets]` become placeholder chips.
  - `number`: a big-number card (`number`, `unit`, `label`).
  - `art`: a brand illustration (`sun`, `clock` or `mark`).
- `levels` sets the block size for each slide, ending in 0. The default for 4 steps is 40, 20, 10, 0.
```json
{"template": "swipe-to-reveal", "fields": {"kicker": "The 1 prompt that plans your week",
  "steps": [{"title": "Keep swiping ==to reveal.=="}, {"title": "Getting ==clearer…=="}, {"title": "Almost ==there.=="}, {"title": "Here it is. ==Copy it.=="}],
  "hint": "Keep swiping to reveal", "done_hint": "Paste into any AI chat. Fill the [brackets].",
  "target": {"kind": "prompt", "label": "AI chat · your week", "text": "Here's my week: [paste your calendar, deadlines and to-dos]. …"}}}
```

**4. Awards.** One slide with 4–6 rosettes, stars or medals, each drawn in SVG in the brand's colours, with a tiny relatable win under each. Each item is a string, or `{"text", "shape": "rosette|star|medal"}`, up to 40 characters. Keep them gentle, with no medical claims.
```json
{"template": "awards", "fields": {"kicker": "Today's awards", "title": "You earned ==every one.==",
  "items": ["Ate something warm", "Said yes to help", "Slept when someone else had the baby", "Laughed at 3 am"]}}
```

**5. Cover save-line.** An optional handwritten-style accent line under the lead, with a small hand-drawn arrow, up to 40 characters. It's the one "save this" allowed off the cta slide. It sits inside the cover's layout, so the overlap, safe-area and 70 px checks all cover it.
- Font: Caveat Brush, which is bundled (see Fonts below). If it's ever missing, the engine tries Caveat, then Kalam, Gochi Hand and the others, and finally falls back to Lora Italic.
```json
{"template": "cover", "fields": {"title": "100 a month: ==pick your age.==", "save_line": "save this for your next birthday", "visual": {"type": "timeline", "points": []}}}
```

## Fonts (bundled, Oct 15, 2026)
These live in `content/design/assets/fonts/`. All are SIL Open Font License, and each one's licence file (`<Family>-OFL.txt`) sits next to it. Keep the licence files with the fonts.
- **Caveat** (variable) and **Caveat Brush**: handwritten labels and the cover save-line.
- **Kalam** and **Gochi Hand**: spare handwriting faces.
- **Fraunces** (variable: weight, optical size, SOFT, WONK): the serif for episodes.
- **Playfair Display** and **DM Serif Display**: spare serifs.

Neither Fraunces nor Playfair comes with an italic, so italic words in episodes use the bundled Lora Italic. Never let the browser fake an italic or a bold.

## Editorial episodes (Oct 15, 2026)
This is a slower, magazine-style series ("Ep.01, Ep.02 …") with its own look:
- Paper grain, generated in code.
- Slides alternate deep and light: the cover is deep, then light, deep, and so on. A slide's `"surface": "deep" | "light"` overrides this.
- A large Fraunces serif, with an occasional Lora-italic word.
- Caveat handwritten labels, brush underlines and lots of whitespace.
- A tiny monospace `© Brand · Ep.01` signature.

Each brand has its own deep/light pair:

| Brand | Deep | Light |
|---|---|---|
| Fully Funded | deep cobalt `#16206B` | cream `#F7F1E5` |
| Locked Hour | ink `#151413` | butter `#FFF1C9` |
| Hourback | plum `#3A2240` | peach `#FFE6D3` |
| Littlefold | berry `#7A2149` | blush `#FCE5EB` |

The code is in `design/engine/episode.py`. Demos are in `design/demos-episode/`: `build.py`, `posts.json`, `SOURCES.md`, `contact-sheet.png` and one folder per post.

- **Markup in any text field:** `==words==` gives a brush underline, `*word*` gives an italic serif word, and `**bold**` gives bold.
- **Rules (QA-enforced):**
  - All text at least 90 px from every edge.
  - Body text at least 40 px.
  - At most 45 words a slide.
  - Large empty bands are allowed on these pages, up to 760 px.
- **Length:** an episode is 5–6 slides with no cta slide, so save/send goes in the caption. Render with `--no-fail` and check that `report.json` shows 0 errors, like the other demos.
- **Facts:** every fact needs a source in a SOURCES.md, and example math is labelled as example math.

```json
{"template": "ep-cover", "fields": {"label": "Ep.01", "title": "Benjamin Franklin left money to two cities, *on purpose*, to grow for ==200 years.==",
  "sub": "optional serif sub-line", "stamp": true, "palette_index": 0,
  "image": {"src": "photo.jpg", "position": "bottom", "height": 400, "crop": [0, 10, 100, 60], "focus": [50, 50]}}}
{"template": "ep-step", "fields": {"step": "step 1.", "title": "Give it a role.", "body": "Start with who it should be. *“You're a practical home cook…”*"}}
{"template": "ep-statement", "fields": {"label": "By 1990", "statement": "Time is the ==ingredient.==", "sub": "Not a big start. A long one.", "align": "center", "note": "optional handwritten note"}}
{"template": "ep-reframe", "fields": {"label": "reframe 1.", "instead": "I need motivation.", "say": "I need a start time."}}
{"template": "ep-handwritten", "fields": {"label": "note 1.", "line": "Let the small jobs wait.", "sub": "The dishes can sit."}}
```
- **ep-step:** the label defaults to `step N.`, counting only the ep-step slides.
- **ep-cover image:** a supplied PNG or JPG, never a stock photo. It gets a soft black-and-white treatment with grain, sits at the top or bottom, and is 300–620 px tall. Set `crop` to roughly the panel's own aspect ratio, so that nothing important gets trimmed.

## Feed aesthetic system (Oct 15, 2026)
The code is in `design/engine/feed.py`, and the preview tool is `design/grid_preview.py`.
- **Brand stamp:** a round badge with text running around the brand mark, such as "FULLY FUNDED · MONEY, MADE CLEAR ·". Add `"stamp": true` (or your own text) to a `cover` or `ep-cover`.
  - On normal covers it sits on a corner of the cover art: `"stamp_pos": "tr" | "tl" | "br" | "bl"`.
  - QA fails (`stamp-collision`) if it covers any text, so pick another corner or leave it off that cover.
  - The taglines are new drafts: MONEY, MADE CLEAR · ONE HOUR AT A TIME · GET YOUR EVENINGS BACK · SMALL DAYS, GENTLY. Change them in `feed.TAGLINE`.
- **Palette rotation:** each brand has 4 approved cover backgrounds (`feed.PALETTES`; one per brand uses the brand's dark surface). Set `"palette_index": <post number>` on a cover and consecutive covers come out different. `feed.rotation("fullyfunded", start, 9)` lists a week's colours. `ep-cover` rotates its deep colour the same way (`feed.EP_DEEP`).
- **Grid check before scheduling:** `python3 grid_preview.py newest.png … oldest.png --theme fullyfunded --out grid.png`.
  - It writes a phone-sized 3×3 profile mock using the app's centre 3:4 crop, plus `grid@1x.png` at real phone size.
  - It flags look-alike neighbours (tiles next to each other in a row or column with nearly the same average colour).
  - Example: `design/demos-episode/grid-fullyfunded.png` shows the current grid; 5 pairs of neighbours are flagged because every cover uses the same background. `grid-fullyfunded-rotated.png` is the same grid with rotation on the upcoming posts; 1 pair is flagged.

## Slow-pan video (Oct 15, 2026)
- `content/video/src/slowpan.py` + `slowpan_bg.py` (read the docstrings; demos in `slowpan_demos.py`). Background moves slowly (pan / push-in / parallax), text layer stays pixel-still. Backgrounds generated in code per brand (sky+clouds, warm paper + light leak, misty forest, Littlefold blobs, bokeh) or `bg=` your own image/video.
- Use for Reels (1080×1920) and for **carousel video slides** (1080×1350, 5–8 s, H.264+AAC, under 15 MB). Autopost accepts `.mp4` entries mixed into a post's `images` list (max 10 items); see the repo README.
