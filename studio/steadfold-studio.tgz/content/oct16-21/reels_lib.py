#!/usr/bin/env python3
"""Shared pieces for the Oct 16-18 Reels: brand palettes (v4 brand system), 2x text layers, photo backgrounds,
a 2x vlab renderer for kinetic Reels, dedicated cover rendering with safe-zone QA, and mux/QA helpers.

Every text layer and every kinetic frame is rendered by Chromium at deviceScaleFactor 2 and Lanczos-downsampled to
1080x1920 (brand-system v4 2x rule)."""
from __future__ import annotations

import io
import json
import math
import subprocess
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.dont_write_bytecode = True
VSRC = Path("/home/claude/content/video/src")
DESIGN = Path("/home/claude/content/design")
for p in (VSRC, DESIGN, DESIGN / "samples-v5"):
    sys.path.insert(0, str(p))
import slowpan as SP  # noqa: E402
import slowpan_bg as B  # noqa: E402
from slowpan import Scene, Move, REEL, FPS  # noqa: E402

HERE = Path(__file__).resolve().parent
OUT = HERE / "reels"
OUT.mkdir(exist_ok=True)
QA = HERE / "qa"
QA.mkdir(exist_ok=True)
PHOTOS = DESIGN / "samples-v3" / "assets"
MARKS = DESIGN / "assets" / "marks"
FONTS = DESIGN / "assets" / "fonts"

# ---------------------------------------------------------------- brand system v4 palettes (docs/brand-system-v4.md)
BR = {
    "fullyfunded": dict(name="Fully Funded", handle="@fullyfundedhq", mark="fullyfunded.png", bg="#F5F7FF", main="#2B3FE0",
                        acc="#FF6A3D", acc2="#FFB08F", ink="#0E1440", deep="#16206B", green="#1F7A4D", butter="#FFE7A3"),
    "littlefold": dict(name="Littlefold", handle="@littlefoldhq", mark="littlefold.png", bg="#FFF4E0", main="#FFD6E3",
                       acc="#D9497A", acc2="#FF8A70", ink="#2C2A3A", peach="#FFD3AE", butter="#FFE27E", deep="#7A2149"),
    "lockedhour": dict(name="Locked Hour", handle="@lockedhourhq", mark="lockedhour.png", bg="#FFE27A", main="#FFD43B",
                       acc="#FF5CA8", acc2="#E8336F", ink="#141414", cream="#FFF4E0"),
    "hourback": dict(name="Hourback", handle="@hourbackhq", mark="hourback.png", bg="#5E54C9", main="#5E54C9",
                     acc="#FFC94D", acc2="#FF8A3D", ink="#2A2238", cream="#FFF8EF"),
}


def mark(brand):
    return (MARKS / BR[brand]["mark"]).as_uri()


def fonts_css():
    from engine.themes import font_css
    from lib import font_css as lib_css
    return font_css("littlefold") + lib_css()


# ---------------------------------------------------------------- 2x static text layer for slowpan
def text_png_2x(html, css, size, out_png):
    from playwright.sync_api import sync_playwright
    w, h = size
    page = (f"<!doctype html><html><head><meta charset='utf-8'><style>{fonts_css()}{SP.TEXT_BASE}"
            f"html,body{{width:{w}px;height:{h}px;background:transparent}}{css}</style></head><body>{html}</body></html>")
    src = Path(out_png).with_suffix(".html")
    src.write_text(page, encoding="utf-8")
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": w, "height": h}, device_scale_factor=2)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(250)
        big = Image.open(io.BytesIO(pg.screenshot(type="png", omit_background=True))).convert("RGBA")
        br.close()
    assert big.size == (w * 2, h * 2), big.size
    big.resize((w, h), Image.LANCZOS).save(out_png)
    return cv2.imread(str(out_png), cv2.IMREAD_UNCHANGED)[..., 3]


SP.text_png = text_png_2x


# ---------------------------------------------------------------- photo backgrounds
def load(path):
    return cv2.cvtColor(cv2.imread(str(path), cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)


def photo_layers(path, darken=0.0, band=0.42, warm=(1.03, 1.0, 0.96), sat=1.04, crop=None, bw=False, tint=None):
    """slowpan bg callable: the photo cover-fitted into the over-scan canvas; optional soft shade behind the text
    band (centre `band` of height) and the lower third, for contrast."""
    def make(w, h, u):
        im = load(path)
        if crop:
            x0, y0, x1, y1 = crop
            im = im[y0:y1, x0:x1]
        im = im.astype(np.float32) / 255
        if bw:
            l = im @ np.array([0.2126, 0.7152, 0.0722], np.float32)
            im = np.repeat(l[..., None], 3, -1)
        im = B.cover_fit(im, w, h)
        im = im * np.array(warm, np.float32)
        lum = (im @ np.array([0.2126, 0.7152, 0.0722], np.float32))[..., None]
        im = np.clip(lum + (im - lum) * sat, 0, 1)
        if tint is not None:
            t = np.array([int(tint[i:i + 2], 16) for i in (1, 3, 5)], np.float32) / 255
            im = im * (0.82 + 0.18 * t)
        if darken:
            y = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
            shade = 1 - darken * (0.6 * np.exp(-((y - band) / 0.2) ** 2) + 0.55 * np.clip((y - 0.78) / 0.22, 0, 1))
            im = im * shade
        return [B.Layer(np.ascontiguousarray(im.astype(np.float32)), depth=1.0, name="photo")]
    return make


# ---------------------------------------------------------------- 2x vlab renderer (kinetic Reels)
def render_vlab_2x(video, out_mp4):
    from playwright.sync_api import sync_playwright
    out_mp4 = Path(out_mp4)
    src = HERE / "build" / (out_mp4.stem + ".html")
    src.parent.mkdir(exist_ok=True)
    src.write_text(video.html(), encoding="utf-8")
    n = int(round(video.duration * FPS))
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920",
                           "-framerate", str(FPS), "-i", "-", "-c:v", "libx264", "-preset", "slow", "-crf", "17",
                           "-pix_fmt", "yuv420p", "-profile:v", "high", "-movflags", "+faststart", "-an", str(out_mp4)],
                          stdin=subprocess.PIPE)
    t0 = time.time()
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=2)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(400)
        for i in range(n):
            pg.evaluate(f"seek({i / FPS:.5f})")
            im = Image.open(io.BytesIO(pg.screenshot(type="png"))).convert("RGB")
            ff.stdin.write(im.resize((1080, 1920), Image.LANCZOS).tobytes())
        br.close()
    ff.stdin.close()
    ff.wait()
    print(f"{out_mp4.name}: {n} frames (2x -> Lanczos) in {time.time() - t0:.0f}s", flush=True)
    return out_mp4


def add_music(silent, brand, out_mp4, cuts=(), seed=0):
    import music2
    dur = probe(silent)["dur"]
    wav = HERE / "build" / (Path(out_mp4).stem + "-music.wav")
    music2.write(wav, music2.render(brand, "warm", dur + 0.4, list(cuts), seed=seed))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(silent), "-i", str(wav), "-filter_complex",
                    f"[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,afade=t=out:st={max(0, dur - 0.45):.3f}:d=0.45[a]",
                    "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-ac", "2", "-shortest",
                    "-movflags", "+faststart", str(out_mp4)], check=True)
    return out_mp4


# ---------------------------------------------------------------- covers (dedicated, 2x, safe-zone QA)
MEASURE = r"""() => {
 const out=[]; const tw=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(tw.nextNode()){const n=tw.currentNode; if(!n.textContent.trim())continue; const el=n.parentElement;
   if(el.closest('[data-noqa]'))continue; const fs=parseFloat(getComputedStyle(el).fontSize);
   const rg=document.createRange(); rg.selectNodeContents(n);
   for(const r of rg.getClientRects()){ if(r.width<1)continue; out.push({x0:r.left,y0:r.top,x1:r.right,y1:r.bottom,fs:fs,
     hook:!!el.closest('.hook'),t:n.textContent.trim().slice(0,24)});}}
 return out;}"""


def render_cover(html, out_jpg, min_hook=120):
    """Dedicated 1080x1920 cover at 2x -> Lanczos. QA: all text inside x 90-990, y 300-1400; the .hook text >= min_hook px."""
    from playwright.sync_api import sync_playwright
    out_jpg = Path(out_jpg)
    src = HERE / "build" / (out_jpg.stem + ".html")
    src.parent.mkdir(exist_ok=True)
    src.write_text(f"<!doctype html><html><head><meta charset='utf-8'><style>{fonts_css()}"
                   f"html,body{{margin:0;width:1080px;height:1920px;overflow:hidden}}</style></head><body>{html}</body></html>",
                   encoding="utf-8")
    with sync_playwright() as pw:
        br = pw.chromium.launch(args=["--disable-gpu", "--font-render-hinting=none"])
        pg = br.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=2)
        pg.goto(src.as_uri())
        pg.evaluate("document.fonts.ready.then(()=>1)")
        pg.wait_for_timeout(300)
        boxes = pg.evaluate(MEASURE)
        big = Image.open(io.BytesIO(pg.screenshot(type="png"))).convert("RGB")
        br.close()
    big.resize((1080, 1920), Image.LANCZOS).save(out_jpg, quality=92, subsampling=0, optimize=True)
    errs = [f"out of safe zone: {b['t']!r} {b['x0']:.0f},{b['y0']:.0f}-{b['x1']:.0f},{b['y1']:.0f}" for b in boxes
            if b["x0"] < 90 or b["x1"] > 990 or b["y0"] < 300 or b["y1"] > 1400]
    hook = [b for b in boxes if b["hook"]]
    hook_px = min((b["fs"] for b in hook), default=0)
    if not hook or hook_px < min_hook:
        errs.append(f"hook font {hook_px}px < {min_hook}px")
    words = len(" ".join(dict.fromkeys(b["t"] for b in hook)).split())
    return dict(cover=str(out_jpg), hook_px=hook_px, hook_words=words, errors=errs)


# ---------------------------------------------------------------- QA helpers
def probe(mp4):
    j = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(mp4)],
                                  capture_output=True, text=True).stdout)
    v = [s for s in j["streams"] if s["codec_type"] == "video"][0]
    a = [s for s in j["streams"] if s["codec_type"] == "audio"]
    return dict(w=v["width"], h=v["height"], vcodec=v["codec_name"], acodec=a[0]["codec_name"] if a else None,
                dur=float(j["format"]["duration"]), mb=round(Path(mp4).stat().st_size / 1e6, 2))


def loudness(mp4):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(mp4), "-af", "ebur128", "-f", "null", "-"],
                       capture_output=True, text=True).stderr
    i = r.rfind("Integrated loudness")
    return float(r[i:].split("I:")[1].split("LUFS")[0]) if i >= 0 else None


def still(mp4, t):
    r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", str(mp4), "-frames:v", "1", "-f", "image2pipe",
                        "-vcodec", "png", "-"], capture_output=True)
    return Image.open(io.BytesIO(r.stdout)).convert("RGB")


def sheet(mp4, cover, out_png, times):
    from PIL import ImageDraw, ImageFont
    tw, th = 240, 427
    ims = [Image.open(cover).convert("RGB")] + [still(mp4, t) for t in times]
    labs = ["cover"] + [f"{t:.1f}s" for t in times]
    S = Image.new("RGB", (len(ims) * (tw + 10) + 10, th + 60), "#EDE8E1")
    d = ImageDraw.Draw(S)
    f = ImageFont.truetype(str(FONTS / "Inter-Medium.ttf"), 18)
    for i, (im, lab) in enumerate(zip(ims, labs)):
        S.paste(im.resize((tw, th), Image.LANCZOS), (10 + i * (tw + 10), 10))
        d.text((10 + i * (tw + 10), th + 22), lab, fill="#333", font=f)
    S.save(out_png)
    return out_png
