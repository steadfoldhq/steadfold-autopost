#!/usr/bin/env python3
"""Style self-test: renders ONE sample of every brand-system v4 style from a fresh extract, at 2x -> Lanczos,
and writes build/style-selftest/contact-sheet.png + results.json. Exit code 1 if any style fails to render.

    python3 /home/claude/content/oct16-21/style_selftest.py
"""
import json
import subprocess
import sys
import time
import traceback
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
D = Path("/home/claude/content/design")
for p in (D / "samples-v5", HERE):
    sys.path.insert(0, str(p))
OUT = HERE / "build" / "style-selftest"
OUT.mkdir(parents=True, exist_ok=True)
RES = {}


def step(name, fn):
    t0 = time.time()
    try:
        files = fn()
        RES[name] = dict(ok=True, files=[str(f) for f in files], s=round(time.time() - t0, 1))
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        RES[name] = dict(ok=False, error=repr(e)[:300])
    print(("OK  " if RES[name]["ok"] else "FAIL") + f" {name}", flush=True)


def feed_tiles():
    from lib import render_many
    import build_final as BF
    import build_mix as BM
    jobs = {"look-b-cover": BF.T["ff-b"], "glove-finger-down": BF.T["lh-glove"], "soft-countdown": BF.T["lf-count"],
            "ep01-bw-photo": BF.T["ff-ep"], "one-word-photo": BF.T["hb-offline"], "reframe-instead-say": BF.T["hb-reframe"],
            "emoji-meme": BF.T["lf-meme"], "sticky-note-list": BM.JOBS["lh-list"], "awards-tile": BF.T["lf-awards"]}
    rep = render_many([(h, OUT / k) for k, h in jobs.items()])
    bad = [k for k, v in rep.items() if v["errs"]]
    assert not bad, bad
    return [OUT / f"{k}.png" for k in jobs]


def templates():
    src = json.loads((D / "demos-interactive" / "posts.json").read_text())["posts"]
    keep = {p["id"]: p for p in src}
    posts = [
        {"id": "original-template", "theme": "fullyfunded", "highlight": "A", "slides": [
            {"template": "cover", "fields": {"kicker": "Self-test", "title": "The original ==simple template.=="}},
            {"template": "big-number", "fields": {"number": "25", "unit": "×", "label": "your yearly spending"}},
            {"template": "cta", "fields": {"title": "Save this."}}]},
        keep["panorama"], keep["follow-the-line"], keep["awards"], keep["swipe-to-reveal"],
        {"id": "episode", "theme": "lockedhour", "highlight": "A", "slides": [
            {"template": "ep-cover", "fields": {"label": "Ep.01", "title": "Not motivation. *A start time.*", "stamp": True}},
            {"template": "ep-reframe", "fields": {"label": "reframe 1.", "instead": "I need motivation.", "say": "I need a start time."}}]},
    ]
    t = OUT / "tpl"
    t.mkdir(exist_ok=True)
    (t / "posts.json").write_text(json.dumps({"_build_notes": "style self-test", "posts": posts}, indent=1))
    r = subprocess.run([sys.executable, str(D / "render.py"), str(t / "posts.json"), "--out", str(t), "--no-fail"],
                       capture_output=True, text=True, cwd=str(D))
    assert r.returncode == 0, r.stderr[-800:]
    rep = json.loads((t / "report.json").read_text())
    errs = [(x["id"], e) for x in rep for e in x["errors"]]
    assert not errs, errs
    pick = {"original-template": "slide-01", "panorama": "slide-02", "follow-the-line": "slide-02", "awards": "slide-02",
            "swipe-to-reveal": "slide-02", "episode": "slide-01"}
    return [t / k / f"{v}.png" for k, v in pick.items()]


def videos():
    import reels_lib as L
    import slowpan as SP
    from slowpan import Scene, Move
    from vlab import Video, el
    out = []
    # one-word slow-pan photo (2 s) + calm text (2 s): background moves, 2x text layer stays still
    css = ".w{position:absolute;left:0;right:0;top:600px;text-align:center;font-family:Instrument;font-size:300px;color:#fff}"
    for name, bg in (("slowpan-photo", L.photo_layers(L.PHOTOS / "g-forest.png", darken=0.3)), ("calm-text", ("paper", "lockedhour", 4))):
        mp4 = OUT / f"{name}.mp4"
        SP.render([Scene(bg=bg, text='<div class="w">Test.</div>', css=css.replace("#fff", "#141414") if name == "calm-text" else css,
                         dur=2.0, move=Move(pan=0.04, parallax=False), ss=1, margin=0.08)], mp4, L.REEL, music=("lockedhour", "warm"))
        L.still(mp4, 1.0).save(OUT / f"{name}.png")
        out.append(OUT / f"{name}.png")
    # kinetic (1 s at 2x)
    v = Video("lockedhour", "kin", ":root{--bg:#FFF4E0;--hl:#FFD43B;--prog-bg:transparent;--prog-fg:transparent}.cam{transform:none!important}"
              ".H{font-family:'Inter Display';font-weight:900;font-size:150px;line-height:1;color:#141414}", "")
    v.scene(0, 1.0, el("Kinetic<br>big text.", 84, 500, 912, a="up", t=0.0, d=0.4, cls="H"), bg="#FFF4E0")
    mp4 = L.render_vlab_2x(v, OUT / "kinetic.mp4")
    L.still(mp4, 0.9).save(OUT / "kinetic.png")
    out.append(OUT / "kinetic.png")
    # dedicated Reel cover with safe-zone QA
    cov = L.render_cover('<div style="position:absolute;inset:0;background:#5E54C9"></div><div class="hook" style="position:absolute;left:96px;'
                         'right:96px;top:500px;font:700 150px/1 Poppins;color:#fff">Reel cover test.</div>', OUT / "reel-cover.jpg")
    assert not cov["errors"], cov
    out.append(OUT / "reel-cover.jpg")
    return out


def sheet():
    from PIL import Image, ImageDraw, ImageFont
    files = [(k, Path(f)) for k, v in RES.items() if v["ok"] for f in v["files"]]
    tw, th, cols = 240, 300, 7
    rows = (len(files) + cols - 1) // cols
    S = Image.new("RGB", (cols * (tw + 12) + 12, rows * (th + 40) + 12), "#EDE8E1")
    d = ImageDraw.Draw(S)
    f = ImageFont.truetype(str(D / "assets/fonts/Inter-Medium.ttf"), 15)
    for i, (k, p) in enumerate(files):
        im = Image.open(p).convert("RGB")
        im.thumbnail((tw, th), Image.LANCZOS)
        r, c = divmod(i, cols)
        x, y = 12 + c * (tw + 12), 12 + r * (th + 40)
        S.paste(im, (x, y))
        d.text((x, y + th + 8), p.stem[:30], fill="#333", font=f)
    S.save(OUT / "contact-sheet.png")


if __name__ == "__main__":
    step("feed tiles (Look B, glove, countdown, Ep.01 photo, one-word photo, reframe, meme, sticky-note list, awards tile)", feed_tiles)
    step("render.py templates (original, panorama, follow-the-line, awards, swipe-to-reveal, episode)", templates)
    step("video (slow-pan photo, calm text, kinetic 2x, Reel cover)", videos)
    sheet()
    (OUT / "results.json").write_text(json.dumps(RES, indent=1))
    n = sum(v["ok"] for v in RES.values())
    print(f"{n}/{len(RES)} style groups rendered -> {OUT / 'contact-sheet.png'}")
    sys.exit(0 if n == len(RES) else 1)
