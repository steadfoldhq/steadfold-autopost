#!/usr/bin/env python3
"""Feed posts for the Oct 17-21 gaps + Littlefold's Small Wins No.1. Brand-system v4 styles:
  lh-1017-one-word-later     One Word No.1 (loud: big word + clean clock cut-out) -> sticky-note list (quiet)
  ff-1019-rich-habits-01     Rich Habits, Decoded No.1 (loud: Ep.01 B/W photo editorial, g-couple) -> 2 editorial slides
  ff-1020-pick-its-home      follow-the-line (quiet; render.py interactive template), example math from ff_math.py
  hb-1020-prompt-week-01     Prompt of the Week No.1 (quiet; swipe-to-reveal)
  lf-1021-small-wins-01      Small Wins No.1 (series cover) -> awards (quiet)
Custom slides: samples-v5/lib.render_many (2x -> Lanczos, 70 px edge QA). Template slides: render.py (2x -> Lanczos).
Output: out/<id>/NN.png + NN.jpg (1080x1350, q92)."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
D = Path("/home/claude/content/design")
sys.path.insert(0, str(D / "samples-v5"))
sys.path.insert(0, str(HERE))
from lib import render_many, bw_grain, _object_mask, A  # noqa: E402
import build_final as BF  # noqa: E402
import build_mix as BM  # noqa: E402
import ff_math as FM  # noqa: E402

OUT = HERE / "out"
OUT.mkdir(exist_ok=True)
PREP = HERE / "prep"
PREP.mkdir(exist_ok=True)
M = FM.M
N = lambda x: f"{x:,.0f}"  # noqa: E731
BASE = BF.BASE
chip = BF.chip


# ------------------------------------------------------------------ clean cut-out of the alarm clock (g-clock)
def clock_cutout():
    p = PREP / "clock-cut.png"
    im = cv2.cvtColor(cv2.imread(str(A / "g-clock.png")), cv2.COLOR_BGR2RGB)
    g = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY)
    fg = _object_mask(g, thr=243, close=11).astype(np.float32)
    a = cv2.GaussianBlur(fg, (0, 0), 1.1)                       # soft 1-2 px edge, no halo
    a = np.clip((a - 0.5) * 2.2 + 0.5, 0, 1)
    ys, xs = np.where(a > 0.01)
    rgba = np.dstack([im, (a * 255).astype(np.uint8)])[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    Image.fromarray(rgba, "RGBA").save(p)
    return p.as_uri()


def lh_later_cover():
    c = clock_cutout()
    return (f'<style>{BASE}.h{{position:absolute;left:70px;right:70px;top:250px;font-family:"Inter Display";font-weight:900;font-size:330px;'
            f'line-height:.86;letter-spacing:-.06em;color:#141414}} .h span{{background:linear-gradient(#FF5CA8,#FF5CA8) no-repeat 0 88%/100% 34%}}'
            f'.s{{position:absolute;left:84px;width:540px;top:650px;font:800 64px/1.1 Inter;color:#141414;letter-spacing:-.02em}}'
            f'.cl{{position:absolute;left:640px;top:640px;width:380px;transform:rotate(9deg);'
            f'filter:drop-shadow(0 26px 30px rgba(60,40,0,.22)) drop-shadow(0 4px 6px rgba(60,40,0,.14))}}'
            f'.lab{{position:absolute;left:84px;top:110px;padding:12px 22px;border-radius:8px;background:#141414;color:#FFE27A;'
            f'font:800 26px Inter;letter-spacing:.16em}} .sv{{position:absolute;left:84px;top:1020px;font-family:CaveatBrush;font-size:60px;color:#E8336F;transform:rotate(-3deg)}}</style>'
            f'<div class="slide" style="background:#FFE27A"><div data-noqa style="position:absolute;inset:0;background-image:radial-gradient(rgba(20,20,20,.10) 2.4px,transparent 2.8px);background-size:30px 30px"></div>'
            f'<div class="lab">ONE WORD · No.1</div><div class="h"><span>Later.</span></div>'
            f'<div class="s">Mid-hour thought? Write it down. Keep going.</div>'
            f'<img class="cl" data-noqa src="{c}"><div class="sv">save this for later ↷</div>'
            f'{chip("Locked Hour", "lockedhour.png", "#141414", "#FFE27A")}</div>')


LH_LATER = ["Reply to Sam", "Book the dentist", "Look up that recipe", "Check the bank app", "Then back to work"]


# ------------------------------------------------------------------ Fully Funded · Rich Habits, Decoded No.1
def ff_rich_cover():
    ph = PREP / "ff-couple-bw.jpg"
    bw_grain(A / "g-couple.png", ph, contrast=1.15, grain=.045)
    return BF.photo_editorial("#F5F7FF", "#0E1440", "#FF6A3D", "Rich Habits, Decoded · No.1",
                              "Before you buy, ask: <i>cost per use?</i>", ph.as_uri(), "Fully Funded", "fullyfunded.png",
                              size=128, photo_h=500, number=None, chipbg="#2B3FE0", chipink="#fff", note="a 240 coat can cost less →")


def ff_rich_math():
    a, b = M["ppu_a"], M["ppu_b"]
    row = lambda price, uses, per, col: (  # noqa: E731
        f'<div style="display:flex;justify-content:space-between;align-items:baseline;padding:34px 0;border-bottom:2px solid rgba(247,241,229,.25)">'
        f'<div style="font:500 52px/1.2 Inter;color:#F7F1E5">A {price} coat,<br>worn {uses} times</div>'
        f'<div style="font-family:Fraunces;font-weight:400;font-size:120px;line-height:1;color:{col}">{per:g}<span style="font-size:44px;font-family:Inter"> a wear</span></div></div>')
    return (f'<style>{BASE}.l{{position:absolute;left:90px;top:110px;font-family:Caveat;font-weight:700;font-size:62px;color:#FFB08F}}'
            f'.t{{position:absolute;left:90px;right:90px;top:200px;font-family:Fraunces;font-variation-settings:"opsz" 144;font-size:104px;line-height:1;letter-spacing:-.025em;color:#F7F1E5}}'
            f'.t i{{font-family:Instrument;color:#FFB08F}} .rows{{position:absolute;left:90px;right:90px;top:560px}}'
            f'.n{{position:absolute;left:90px;right:90px;top:1060px;font:500 40px/1.35 Inter;color:rgba(247,241,229,.8)}}</style>'
            f'<div class="slide" style="background:#16206B"><div class="l">example math.</div>'
            f'<div class="t">The cheap one costs <i>{b / a:g}× more</i> per wear.</div>'
            f'<div class="rows">{row(240, 120, a, "#FFB08F")}{row(60, 6, b, "#F7F1E5")}</div>'
            f'<div class="n">Example numbers. Price ÷ times you’ll really use it. Any currency. Same math.</div></div>')


def ff_rich_move():
    li = "".join(f'<div style="display:flex;gap:30px;margin:0 0 34px"><div style="flex:none;font-family:Fraunces;font-size:84px;line-height:1;color:#FF6A3D;width:56px">{i}</div>'
                 f'<div style="font:500 52px/1.25 Inter;color:#0E1440">{t}</div></div>'
                 for i, t in enumerate(["Guess how often you’ll really use it.", "Divide the price by that number.", "Compare per use, not per price tag."], 1))
    return (f'<style>{BASE}.l{{position:absolute;left:90px;top:110px;font-family:Caveat;font-weight:700;font-size:62px;color:#FF6A3D}}'
            f'.t{{position:absolute;left:90px;right:90px;top:200px;font-family:Fraunces;font-variation-settings:"opsz" 144;font-size:110px;line-height:1;letter-spacing:-.025em;color:#0E1440}}'
            f'.t i{{font-family:Instrument;color:#2B3FE0}} .li{{position:absolute;left:90px;right:90px;top:470px}}'
            f'.c{{position:absolute;left:90px;right:90px;top:900px;padding:34px 40px;border-radius:28px;background:#FFE7DC;font:500 44px/1.3 Inter;color:#0E1440}}'
            f'.c b{{color:#D2491F}}</style>'
            f'<div class="slide" style="background:#F7F1E5"><div class="l">the move.</div><div class="t">Next time, <i>divide first.</i></div>'
            f'<div class="li">{li}</div><div class="c"><b>The catch:</b> it only works if you really use it. Don’t stretch your budget for “quality”.</div></div>')


# ------------------------------------------------------------------ Littlefold · Small Wins No.1
def lf_wins_cover():
    return BF.T["lf-wins"].replace("SMALL WINS · No.3", "SMALL WINS · No.1").replace(
        "it counts ♡", "it counts ♡").replace("top:1150px;font-family:CaveatBrush", "top:1120px;font-family:CaveatBrush")


CUSTOM = {
    "lh-1017-one-word-later": [lh_later_cover, lambda: BM.paper_list("#FF5CA8", "#FFFDF2", "#141414", "#E85A1A", "lockedhour.png", "Locked Hour",
                                                                      "The later list:", LH_LATER)],
    "ff-1019-rich-habits-01": [ff_rich_cover, ff_rich_math, ff_rich_move],
    "lf-1021-small-wins-01": [lf_wins_cover],
}

# ------------------------------------------------------------------ render.py posts (quiet interactive templates)
TPL = {"_build_notes": "Oct 17-21 feed: follow-the-line and swipe-to-reveal need 4-5 slides (the swipe is the format; CONTENT-STANDARD-v3 s6 "
                       "exception, STUDIO-README 'Interactive formats'). No cta slide; save/send lives in the caption.", "posts": [
    {"id": "ff-1020-pick-its-home", "theme": "fullyfunded", "highlight": "A", "topic": "growth", "series": "Global", "slides": [
        {"template": "cover", "fields": {
            "palette_index": 2,
            "kicker": "Follow the line · example math",
            "title": "Same 10,000: ==pick its home.==",
            "lead": "Three places to leave it for 20 years. Follow your line to see where it lands.",
            "save_line": "save this before you move money",
            "visual": {"type": "timeline", "label": "10,000 · example over 20 years", "points": [
                {"when": "Today", "label": "10,000"}, {"when": "Year 10", "label": "Growing?"},
                {"when": "Year 20", "label": "Where it lands", "on": True}]}}},
        {"template": "follow-the-line", "fields": {
            "kicker": "10,000, left for 20 years",
            "title": "Pick its ==home.==",
            "choices": [{"icon": "0%", "label": "Cash at 0%", "answer": {"value": N(M["home_0"]), "note": "Still 10,000"}},
                        {"icon": "3%", "label": "Savings at 3%", "answer": {"value": N(M["home_3"]), "note": "You put in 10,000"}},
                        {"icon": "6%", "label": "Invested at 6%", "answer": {"value": N(M["home_6"]), "note": "You put in 10,000"}}],
            "middle": [{"kicker": "Follow your colour", "title": "Same 10,000. ==Different home.=="}],
            "end": {"kicker": "After 20 years · example math", "title": "Here's where ==it lands.==",
                    "note": "Example rates. Not guaranteed. The catch: investments can fall, for years. Money you need soon stays in savings. Any currency."},
            "seed": 5}}]},
    {"id": "hb-1020-prompt-week-01", "theme": "hourback", "highlight": "A", "topic": "prompts", "slides": [
        {"template": "cover", "fields": {
            "kicker": "Prompt of the Week · No.1",
            "title": "5 dinners, ==one list.==",
            "save_line": "save this for Sunday night",
            "visual": {"type": "doc", "title": "This week's dinners", "lines": [
                {"text": "Mon · Tray-bake chicken, 30 min", "hl": True}, "", "Tue · Veggie fried rice", "",
                "List: grouped by aisle"]}}},
        {"template": "swipe-to-reveal", "fields": {
            "kicker": "Prompt of the Week · No.1",
            "steps": [{"title": "Keep swiping ==to reveal.=="}, {"title": "Getting ==clearer…=="}, {"title": "Almost ==there.=="},
                      {"title": "Here it is. ==Copy it.=="}],
            "hint": "Keep swiping to reveal",
            "done_hint": "Paste into any AI chat. Fill the [brackets].",
            "target": {"kind": "prompt", "label": "AI chat · this week's dinners",
                       "text": "Plan 5 dinners for [number] people. Each one takes 30 minutes or less. We don't eat [foods]. "
                               "Use up [what's in the fridge] first. Then give me one shopping list, grouped by aisle."}}}]},
    {"id": "lf-1021-awards", "theme": "littlefold", "highlight": "A", "slides": [
        {"template": "cover", "fields": {"kicker": "Small wins", "title": "Tiny wins ==count.==", "visual": {"type": "arch", "ill": "crib", "caption": "Tiny wins count."}}},
        {"template": "awards", "fields": {
            "kicker": "Small wins · No.1",
            "title": "You earned ==every one.==",
            "items": ["Ate something warm", "Said yes to help", "Drank a full glass of water", "Laughed at 3 am",
                      "Stepped outside for a minute", "Asked one question at the check-up"]}}]},
]}


def to_jpg(png, jpg):
    Image.open(png).convert("RGB").save(jpg, quality=92, subsampling=0, optimize=True)


def main():
    # custom (2x html)
    jobs = []
    for pid, fns in CUSTOM.items():
        for i, fn in enumerate(fns, 1):
            jobs.append((fn(), OUT / pid / f"{i:02d}"))
    rep = render_many(jobs)
    bad = {k: v["errs"] for k, v in rep.items() if v["errs"]}
    # templates
    tpl = HERE / "tpl"
    tpl.mkdir(exist_ok=True)
    (tpl / "posts.json").write_text(json.dumps(TPL, indent=2, ensure_ascii=False))
    r = subprocess.run([sys.executable, str(D / "render.py"), str(tpl / "posts.json"), "--out", str(tpl), "--no-fail"],
                       capture_output=True, text=True, cwd=str(D))
    print(r.stdout[-1500:], r.stderr[-1500:])
    trep = json.loads((tpl / "report.json").read_text())
    terr = [(x["id"], e) for x in trep for e in x["errors"]]
    for pid in ("ff-1020-pick-its-home", "hb-1020-prompt-week-01"):
        (OUT / pid).mkdir(exist_ok=True)
        for p in sorted((tpl / pid).glob("slide-*.png")):
            shutil.copy(p, OUT / pid / f"{p.stem[-2:]}.png")
    shutil.copy(tpl / "lf-1021-awards" / "slide-02.png", OUT / "lf-1021-small-wins-01" / "02.png")
    for p in OUT.glob("*/[0-9][0-9].png"):
        to_jpg(p, p.with_suffix(".jpg"))
    print("custom QA errors:", bad)
    print("template QA errors:", terr)


if __name__ == "__main__":
    main()
