#!/usr/bin/env python3
"""The 17 new items (12 Reels at 19:00 Oct 16-18 + 5 feed posts), with captions, first comments and alt text.
Fully Funded numbers come from ff_math.py (shown values are rounded from it). AI-image posts say "Made with AI"."""
import ff_math as FM

M = FM.M
N = lambda x: f"{x:,.0f}"  # noqa: E731
DISC = "General education only, not financial advice."
LFMED = "General information only, not medical advice. Talk to your doctor, midwife or public health nurse."
AI = "Photo made with AI."
HBEX = "Example made up for this post. Try it on yours, and double-check anything important."
HBTIP = "Tip: remove personal details before you paste."


def t(day, hm):
    return f"2026-10-{day:02d}T{hm}:00-04:00"


ITEMS = [
    # ------------------------------------------------------------------ Oct 16 Reels
    dict(id="ff-reel-1016-fee", account="fullyfunded", publish_at=t(16, "19:00"), kind="reel", style="kinetic big text",
         caption=f"""A 1% yearly fee looks tiny. Over 30 years it can take about a sixth of your pot. Find yours this week.

Example: 200 a month for 30 years. At 6% a year: about {N(M['fee_gross'])}. With a 1% yearly fee: about {N(M['fee_1'])}. Same {N(M['fee_in'])} paid in.
Your move: open each investment or retirement account and look for "annual fee" or "expense ratio".
The catch: cheaper isn't always better. Compare funds that do the same job, and check for other costs too.

Save this, and send it to the friend who just opened a retirement account.

Example at 6% a year, compounded monthly. Not a promise. Real returns vary, before tax and inflation. Any currency. Same math.

Source: example math, no outside figures · As of Oct 2026

{DISC}

#investing #personalfinance #retirementplanning #moneytips #compoundinterest""",
         first_comment="Do you know your fee? Yes or no is perfect."),
    dict(id="lf-reel-1016-doing-better", account="littlefold", publish_at=t(16, "19:00"), kind="reel", style="silhouette (real photos)",
         caption="""You're doing better than you think. Read this on the long nights.

You fed them.
You held them.
You came back again, and again.

That's the whole job today.

Send this to a tired parent you love.

Photos made with AI.

#newparents #parenthood #newborn #motherhood #fatherhood""",
         first_comment="How are you really doing today? One word is enough."),
    dict(id="lh-reel-1016-quiet", account="lockedhour", publish_at=t(16, "19:00"), kind="reel", style="one-word slow-pan photo",
         caption=f"""Get one quiet hour tomorrow: turn on Do Not Disturb, then send one line first.

1. Send: "Heads down till 11. Call if it's urgent."
2. Turn on Do Not Disturb for 60 minutes.
3. Start. The messages will still be there at 11.

Most phones let you allow calls from favourites, so the people who really need you can still reach you.

Save this, send it to someone who answers every ping and follow @lockedhourhq.

{AI}

#focus #deepwork #productivity #studytips #habits""",
         first_comment="What time does your quiet hour start tomorrow? Just the time."),
    dict(id="hb-reel-1016-email-asks", account="hourback", publish_at=t(16, "19:00"), kind="reel", style="calm text",
         caption=f"""Get through a long email fast: paste it and ask for just the asks.

1. Paste the email into any AI chat.
2. Ask the prompt below.
3. Check each quote against the email, then reply to the asks.

PROMPT (copy and paste):
Here's an email: [paste it]. What is it asking me to do, and by when? One line per ask. Quote the sentence each ask comes from.

Save this for your next long email.

{HBTIP}

#emailtips #aitips #productivity #worklife #lifeadmin""",
         first_comment="Longest email you got this week: how many paragraphs? Just the number."),
    # ------------------------------------------------------------------ Oct 17
    dict(id="lh-1017-one-word-later", account="lockedhour", publish_at=t(17, "12:30"), kind="feed", style="One Word No.1 (big word + clean cut-out) + sticky-note list",
         images=2, caption=f"""Stay in your focus hour: when a new thought pops up, write it on a "later" list and keep going.

1. Keep a sticky note or scrap of paper next to you.
2. New thought? Write 3 or 4 words. Don't act on it.
3. When the hour ends, work through the list.

One Word is our new series: one word to carry into your next locked hour. This is No.1.

Save this, send it to the friend with 40 tabs open and follow @lockedhourhq.

{AI}

#focus #deepwork #productivity #studytips #timemanagement""",
         first_comment="What's the first thing on your later list right now? One word.",
         alt_text='A 2-slide zine post on butter yellow. Slide 1: a black label "One Word · No.1", the huge word "Later." with a pink highlighter stripe, the line "Mid-hour thought? Write it down. Keep going.", an alarm clock cut-out and the handwritten note "save this for later". Slide 2: a taped, lined sticky note on pink titled "The later list:" with ticks next to "Reply to Sam", "Book the dentist", "Look up that recipe", "Check the bank app" and "Then back to work".'),
    dict(id="ff-reel-1017-raise-half", account="fullyfunded", publish_at=t(17, "19:00"), kind="reel", style="one-word slow-pan photo",
         caption=f"""Got a raise? Save half of it, and enjoy the other half.

Example: a raise of 200 a month. Save 100 of it for 20 years and it could grow to about {N(M['raise_half_20'])}, from {N(M['raise_in_20'])} paid in.
Your move: set up the automatic transfer the day the raise lands, before you get used to the extra.
The catch: only save what you can keep up. A smaller amount you never stop beats a big one you cancel.

Save this for your next raise.

Example at 6% a year, compounded monthly. Not a promise. Real returns vary, before fees, tax and inflation. Any currency. Same math.

Source: example math, no outside figures · As of Oct 2026

{AI}

{DISC}

#personalfinance #savingmoney #investing #moneytips #careergrowth""",
         first_comment="If you got a raise tomorrow, what would you do first: save, spend or invest?"),
    dict(id="lf-reel-1017-one-job", account="littlefold", publish_at=t(17, "19:00"), kind="reel", style="calm text",
         caption="""Someone offers help? Give them one job.

"Let me know if you need anything" is kind, but it's hard to answer at 3 am. A clear job is easy to say yes to:
1. Bring dinner on Tuesday.
2. Fold one load of laundry.
3. Hold the baby while I shower.
4. Walk the dog.

Then let them do it their way.

Save this list, and send it to the friend who keeps asking how they can help.

#newparents #postpartum #newborn #parentingtips #firsttimeparents""",
         first_comment="What's the one job you'd hand out first? One word is perfect."),
    dict(id="lh-reel-1017-one-tab", account="lockedhour", publish_at=t(17, "19:00"), kind="reel", style="kinetic big text",
         caption="""Get more done in your next hour: close every tab but one.

1. Keep the one tab you need. Close the rest.
2. Opened a new one? Close it and go back.
3. Need something later? Jot it on paper.

One tab. One task. One hour.

Save this, try it tomorrow and follow @lockedhourhq.

#focus #deepwork #productivity #studytips #worksmarter""",
         first_comment="How many tabs do you have open right now? Just the number."),
    dict(id="hb-reel-1017-offline", account="hourback", publish_at=t(17, "19:00"), kind="reel", style="one-word slow-pan photo",
         caption=f"""Plan tomorrow in one prompt after 7 pm, then close the laptop.

1. Dump everything on your mind into any AI chat.
2. Ask the prompt below.
3. Check the plan, move anything that's wrong, and log off.

PROMPT (copy and paste):
Here's everything on my mind for tomorrow: [brain dump]. Pick my 3 must-dos and give me a rough schedule. Move the rest to later this week.

Save this for tonight.

{HBTIP}

{AI}

#eveningroutine #aitips #productivity #worklifebalance #planning""",
         first_comment="What time do you log off tonight? Just the time."),
    # ------------------------------------------------------------------ Oct 18
    dict(id="ff-reel-1018-beneficiary", account="fullyfunded", publish_at=t(18, "19:00"), kind="reel", style="calm text",
         caption=f"""Wrote a will? Check one more form this week: the beneficiary on each account.

In many countries, retirement accounts and life insurance follow their own beneficiary form, which may not be what your will says.
1. Log in to each retirement account and policy.
2. Find "beneficiary".
3. Name someone, plus a backup.
New baby, marriage or divorce? Update it.

The catch: rules differ where you live, and some plans let trustees decide. Check your country's official site or ask your provider.

Save this, and send it to whoever shares your paperwork.

Source: how beneficiary forms work in many countries; check your local rules · As of Oct 2026

{DISC}

#estateplanning #personalfinance #lifeinsurance #retirementplanning #newparents""",
         first_comment="Have you checked your beneficiary this year? Yes or no."),
    dict(id="lf-reel-1018-breathe", account="littlefold", publish_at=t(18, "19:00"), kind="reel", style="one-word slow-pan photo",
         caption=f"""When the crying won't stop and it's getting to you, it's OK to step away for a few minutes.

1. Lay baby on their back in their cot or crib.
2. Step out of the room. Breathe slowly.
3. Go back when you feel calmer.

Never shake a baby. If you can, call someone you trust to take a turn.
Crying that seems different, or a baby who seems unwell? Call your doctor, midwife or a health line.

Send this to a new parent.

Source: NHS-backed ICON guidance (iconcope.org) and the US CDC · As of Oct 2026

{LFMED}

{AI}

#newparents #newborn #babycrying #parentingtips #postpartum""",
         first_comment="Who's your call when you need a break? Just their first name or role."),
    dict(id="lh-reel-1018-start-ugly", account="lockedhour", publish_at=t(18, "19:00"), kind="reel", style="calm text",
         caption="""Stuck on the first line? Write it badly first.

1. Write 3 bad sentences.
2. Don't fix anything yet.
3. Now fix just one.

A bad draft gives you something to fix. A blank page doesn't.

Start ugly. Fix later. Save this for your next blank page and follow @lockedhourhq.

#writing #procrastination #focus #studytips #productivity""",
         first_comment="What are you putting off writing? One word."),
    dict(id="hb-reel-1018-school-email", account="hourback", publish_at=t(18, "19:00"), kind="reel", style="kinetic big text",
         caption=f"""Never miss a school date again: paste the newsletter and ask for the dates.

1. Paste the school email into any AI chat.
2. Ask the prompt below.
3. Check each line against the email, then add them to your calendar.

PROMPT (copy and paste):
Here's the school newsletter: [paste it]. List every date, what to bring and anything that needs a reply. One line each, earliest first.

Save this for the next newsletter, and send it to the other grown-up on pick-up duty.

{HBTIP}

{HBEX}

#parentinghacks #aitips #schoollife #familyorganization #momlife""",
         first_comment="How many school emails did you get this week? Just the number."),
    # ------------------------------------------------------------------ Oct 19-21 feed
    dict(id="ff-1019-rich-habits-01", account="fullyfunded", publish_at=t(19, "12:00"), kind="feed", style="Rich Habits No.1 (Ep.01 B/W photo editorial)",
         images=3, caption=f"""Before you buy, ask one question: what's the cost per use?

Divide the price by the times you'll really use it.
Example: a 240 coat worn 120 times is {M['ppu_a']:g} a wear. A 60 coat worn 6 times is {M['ppu_b']:g} a wear. The cheaper coat costs 5 times more per wear.
1. Guess how often you'll really use it.
2. Divide the price by that number.
3. Compare per use, not per price tag.

The catch: it only works if you really use it. Don't stretch your budget for "quality".

Rich Habits, Decoded is our new series: the quiet money habits wealthier families use, made simple. This is No.1.

Save this for your next big buy.

Source: example math, no outside figures · As of Oct 2026

{AI}

{DISC}

#personalfinance #moneytips #frugalliving #budgeting #moneyhabits""",
         first_comment="What's the best cost-per-use thing you own? One word.",
         alt_text='Fully Funded post, 3 slides. Slide 1: a black-and-white photo of an older couple laughing over dinner by candlelight, with the handwritten label "Rich Habits, Decoded · No.1" and the headline "Before you buy, ask: cost per use?" plus the note "a 240 coat can cost less". Slide 2, deep blue, labelled example math: "The cheap one costs 5× more per wear": a 240 coat worn 120 times is 2 a wear; a 60 coat worn 6 times is 10 a wear. Slide 3: "Next time, divide first" with 3 steps and the catch: it only works if you really use it.'),
    dict(id="ff-1020-pick-its-home", account="fullyfunded", publish_at=t(20, "12:00"), kind="feed", style="follow the line (quiet)",
         images=4, caption=f"""Same 10,000, left for 20 years: where it sits changes where it lands. Follow your line.

Example: at 0% it's still {N(M['home_0'])}. At 3% it's about {N(M['home_3'])}. At 6% it's about {N(M['home_6'])}.
Your move: check what each of your accounts pays this week.
The catch: invested money can fall, sometimes for years. Keep money you'll need in the next few years in cash savings, and invest only what can stay put.

Save this before you move money.

Example rates, compounded monthly. Not a promise. Real returns vary, before fees, tax and inflation. Any currency. Same math.

Source: example math, no outside figures · As of Oct 2026

{DISC}

#investing #personalfinance #savingmoney #compoundinterest #moneytips""",
         first_comment="Which line was yours: 0, 3 or 6?",
         alt_text=f'Fully Funded follow-the-line carousel, 4 slides, labelled example math. Cover: "Same 10,000: pick its home." with a timeline from today to year 20. Slides 2 and 3: three coloured lines start at "Cash at 0%", "Savings at 3%" and "Invested at 6%" and wind across the slides. Slide 4: where each lands after 20 years: 0% stays {N(M["home_0"])}, 3% grows to about {N(M["home_3"])}, 6% to about {N(M["home_6"])}, with the note that rates are examples, not guaranteed, investments can fall and money needed soon stays in savings.'),
    dict(id="hb-1020-prompt-week-01", account="hourback", publish_at=t(20, "13:00"), kind="feed", style="Prompt of the Week No.1 (swipe to reveal, quiet)",
         images=5, caption=f"""Plan 5 dinners and one shopping list with one prompt. Swipe to reveal it.

1. Fill the brackets: how many people, foods you skip, what's in the fridge.
2. Paste it into any AI chat.
3. Check the list against your cupboards, then shop once.

PROMPT (copy and paste):
Plan 5 dinners for [number] people. Each one takes 30 minutes or less. We don't eat [foods]. Use up [what's in the fridge] first. Then give me one shopping list, grouped by aisle.

Prompt of the Week is our new series: one prompt worth keeping, every week. This is No.1.

Save this for Sunday night.

{HBTIP}

#mealplanning #aitips #dinnerideas #familydinner #lifeadmin""",
         first_comment="What's for dinner tonight? One word.",
         alt_text='Hourback swipe-to-reveal carousel, 5 slides. Cover on indigo: "Prompt of the Week · No.1. 5 dinners, one list." with a note card listing example dinners and a shopping list grouped by aisle. Slides 2 to 4 show a chat card that goes from heavily pixelated to almost sharp, with "Keep swiping to reveal". Slide 5 shows the full prompt: plan 5 dinners for [number] people, 30 minutes or less each, no [foods], use up [what is in the fridge] first, then one shopping list grouped by aisle.'),
    dict(id="lf-1021-small-wins-01", account="littlefold", publish_at=t(21, "11:30"), kind="feed", style="Small Wins No.1 (series cover) + awards (quiet)",
         images=2, caption="""You drank warm tea today. That counts.

In the early weeks, the wins are small, and they still count:
Ate something warm. Said yes to help. Drank a full glass of water. Laughed at 3 am. Stepped outside for a minute. Asked one question at the check-up.

Small Wins is our new series: one gentle reminder that today counted. This is No.1.

Save this for a hard day, and send it to a new parent who needs a gold star.

#newparents #newborn #postpartum #motherhood #parenthood""",
         first_comment="What's your small win today? One word.",
         alt_text='Littlefold post, 2 slides in warm cream, pink and peach. Slide 1: a coral label "Small Wins · No.1", the headline "You drank warm tea today." with "warm" in pink italics, two soft paw-print drawings and the handwritten note "it counts". Slide 2: "You earned every one." with six award badges: Ate something warm, Said yes to help, Drank a full glass of water, Laughed at 3 am, Stepped outside for a minute, Asked one question at the check-up.'),
]
