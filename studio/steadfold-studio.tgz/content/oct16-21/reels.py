#!/usr/bin/env python3
"""Oct 16-18 Reels, 4 pages x 3 days, 19:00. Styles mixed per page and per day (brand-system v4):
    day     Fully Funded        Littlefold            Locked Hour           Hourback
    Oct 16  kinetic big text    silhouette photos     one-word slow-pan     calm text
    Oct 17  one-word slow-pan   calm text             kinetic big text      one-word slow-pan
    Oct 18  calm text           one-word slow-pan     calm text             kinetic big text
Photos (one post each, never reused): street=FF17, silhouette1+sil-lift+shoulders=LF16, forest=LH16, clouds=HB17,
wheat=LF18. Calm-text backgrounds are generated in code. Fully Funded numbers come from ff_math.py.

    python3 reels.py [id ...]       # build Reel(s) + cover + QA (default: all)
"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import reels_lib as L  # noqa: E402  (patches slowpan's text layer to 2x)
from reels_lib import BR, Scene, Move, mark, PHOTOS  # noqa: E402
import ff_math as FM  # noqa: E402
import slowpan as SP  # noqa: E402

M = FM.M
N = lambda x: f"{x:,.0f}"  # noqa: E731

# =========================================================================== shared slow-pan text CSS
def css_photo(b, word_font="Instrument", word_col="#FFFFFF", kick_col="#FFE7B8", card_bg="rgba(255,255,255,.94)",
              card_ink=None, body_font="Inter", hl=None):
    c = BR[b]
    card_ink = card_ink or c["ink"]
    hl = hl or c["acc"]
    return f"""
.c{{position:absolute;left:0;right:0;text-align:center}}
.k{{font:800 34px/1.1 Inter;letter-spacing:.2em;text-transform:uppercase;color:{kick_col};text-shadow:0 2px 18px rgba(10,10,20,.55)}}
.w{{font-family:{word_font};line-height:.86;letter-spacing:-.035em;color:{word_col};filter:drop-shadow(0 12px 46px rgba(10,10,20,.5))}}
.w i{{font-style:italic}}
.s{{left:96px;right:96px;font:600 58px/1.18 Inter;color:#fff;text-shadow:0 2px 20px rgba(10,10,20,.65);text-wrap:balance}}
.big{{left:84px;right:84px;font-family:Instrument;font-size:136px;line-height:.98;letter-spacing:-.02em;color:#fff;
 text-shadow:0 6px 40px rgba(10,10,20,.55);text-wrap:balance}}
.big i{{font-style:italic;color:{c.get('acc2', '#FFE7B8')}}}
.card{{position:absolute;left:84px;right:84px;background:{card_bg};border-radius:40px;padding:48px 54px 52px;color:{card_ink};
 box-shadow:0 24px 60px rgba(10,10,30,.28);font:600 58px/1.24 {body_font}}}
.card .lab{{display:inline-block;font:800 28px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:#fff;background:{hl};
 padding:12px 18px;border-radius:999px;margin-bottom:26px}}
.card .num{{font-family:Instrument;font-size:170px;line-height:1;color:{hl};letter-spacing:-.02em;margin:10px 0 6px}}
.card .fine{{font:600 40px/1.3 Inter;opacity:.78;margin-top:18px}}
.card ol{{list-style:none}} .card li{{margin:10px 0}} .card li b{{color:{hl}}}
.foot{{position:absolute;left:0;right:0;top:1330px;display:flex;justify-content:center;align-items:center;gap:14px;
 font:700 30px/1 Inter;color:#fff;text-shadow:0 2px 14px rgba(10,10,20,.55)}}
.foot img{{width:52px;height:52px;border-radius:50%;background:#fff;padding:3px}}
"""


def foot(b, extra=""):
    return f'<div class="foot"><img src="{mark(b)}">{BR[b]["name"]}{extra}</div>'


def photo_reel(b, photo, darken, scenes_html, css, moves, seeds=(1, 2, 3), crop=None, bw=False, durs=(5.0, 5.0, 5.5)):
    sc = []
    for k, (txt, mv) in enumerate(zip(scenes_html, moves)):
        ph = photo[k] if isinstance(photo, (list, tuple)) else photo
        dk = darken[k] if isinstance(darken, (list, tuple)) else darken
        sc.append(Scene(bg=L.photo_layers(PHOTOS / ph, darken=dk, crop=crop), text=txt, css=css, dur=durs[k], move=mv,
                        ss=1, grain=0.016, vignette=0.18, margin=0.08, seed=seeds[k],
                        loop=0.6 if k == len(scenes_html) - 1 else 0.0))
    return sc


def gen_reel(b, kind, scenes_html, css, moves, durs=(5.0, 5.0, 5.5), seeds=(1, 2, 3), kw=None):
    return [Scene(bg=(kind, b, seeds[k], kw or {}), text=t, css=css, dur=durs[k], move=mv, ss=2, grain=0.012,
                  vignette=0.10, margin=0.10, seed=seeds[k], loop=0.6 if k == len(scenes_html) - 1 else 0.0)
            for k, (t, mv) in enumerate(zip(scenes_html, moves))]


R = {}  # id -> dict(brand, style, build(), cover_html, times)

# =========================================================================== FULLY FUNDED
# ---- Oct 17 · one-word slow-pan photo (night street): the raise rule
ffc = css_photo("fullyfunded", kick_col="#FFB08F", hl="#2B3FE0")
R["ff-reel-1017-raise-half"] = dict(brand="fullyfunded", style="one-word slow-pan photo", photo="g-street.png", scenes=lambda: photo_reel(
    "fullyfunded", "g-street.png", [0.30, 0.42, 0.34],
    [f'<div class="c k" style="top:520px">Got a raise?</div><div class="c w" style="top:600px;font-size:380px">Half<i>.</i></div>'
     f'<div class="c s" style="top:980px">Save half of it.<br>Enjoy the other half.</div>{foot("fullyfunded")}',
     f'<div class="card" style="top:430px"><span class="lab">Example math</span><div>A raise of 200 a month.<br>Save 100 of it for 20&nbsp;years:</div>'
     f'<div class="num">≈ {N(M["raise_half_20"])}</div><div>You put in {N(M["raise_in_20"])}.</div>'
     f'<div class="fine">Example at 6% a year. Not guaranteed. Real returns vary. Any currency. Same math.</div></div>',
     f'<div class="c big" style="top:520px">Set it up the day the <i>raise lands.</i></div>'
     f'<div class="c s" style="top:930px">The catch: only save what you can keep up.</div>'
     f'<div class="c s" style="top:1120px;font-size:46px;opacity:.95">Save this for your next raise.</div>{foot("fullyfunded")}'],
    ffc, [Move(pan=-0.05, push=0.02, parallax=False), Move(pan=0.04, parallax=False), Move(pan=-0.04, push=0.03, parallax=False)]),
    cover=dict(kind="photo", photo="g-street.png", darken=0.34, kicker="Got a raise?", hook="Save <i>half</i> of every raise.",
               sub="Example math inside", word=None))

# ---- Oct 18 · calm text (code-made cobalt sky): beneficiary forms
ffsky = ffc + ".k{color:#FFE2D2}.big i{color:#FFB08F}"
R["ff-reel-1018-beneficiary"] = dict(brand="fullyfunded", style="calm text", scenes=lambda: gen_reel(
    "fullyfunded", "sky",
    [f'<div class="c k" style="top:430px">Wrote a will? Check this too</div>'
     f'<div class="c big" style="top:510px;font-size:150px">Your will may not <i>cover this.</i></div>'
     f'<div class="c s" style="top:900px">In many countries, retirement accounts and life insurance follow their own beneficiary form.</div>{foot("fullyfunded")}',
     f'<div class="card" style="top:430px"><span class="lab" style="background:#2B3FE0">This week</span><ol>'
     f'<li><b>1.</b> Log in to each account.</li><li><b>2.</b> Find “beneficiary”.</li><li><b>3.</b> Name someone, plus a backup.</li></ol>'
     f'<div class="fine">Rules differ where you live. Check your country’s official site.</div></div>',
     f'<div class="c big" style="top:470px">New baby? Married? Divorced? <i>Update it.</i></div>'
     f'<div class="c s" style="top:950px">Save this. Send it to whoever shares your paperwork.</div>{foot("fullyfunded")}'],
    ffsky, [Move(pan=0.03, push=0.02), Move(pan=-0.03), Move(pan=0.03, push=0.02)], seeds=(21, 22, 23)),
    cover=dict(kind="sky", hook="Your will may not <i>cover this.</i>", kicker="Check one form this week", sub="Retirement accounts · life insurance"))

# =========================================================================== LITTLEFOLD
# ---- Oct 16 · silhouette (real silhouette photos)
lfs = css_photo("littlefold", word_font="Instrument", kick_col="#FFE4EC") + """
.big{font-size:124px;color:#FFF4E0}.big i{color:#FFD6E3}
.foot{top:1230px}
"""
R["lf-reel-1016-doing-better"] = dict(brand="littlefold", style="silhouette (real photos)", photo="silhouette1.jpg + sil-lift.png + g-shoulders.png", scenes=lambda: photo_reel(
    "littlefold", ["silhouette1.jpg", "sil-lift.png", "g-shoulders.png"], [0.16, 0.16, 0.14],
    ['<div class="c big" style="top:420px">You’re doing better <i>than you think.</i></div>',
     '<div class="c big" style="top:380px">You fed them.<br>You held them.<br><i>You came back again.</i></div>',
     f'<div class="c big" style="top:400px">That’s the whole job <i>today.</i></div>'
     f'<div class="c s" style="top:760px;font-size:50px">Send this to a tired parent.</div>{foot("littlefold")}'],
    lfs, [Move(pan=0.0, push=0.05, parallax=False, focus=(0.48, 0.7)), Move(pan=0.0, push=0.05, parallax=False, focus=(0.4, 0.5)),
          Move(pan=0.0, push=0.05, parallax=False, focus=(0.4, 0.75))], seeds=(31, 32, 33)),
    cover=dict(kind="photo", photo="silhouette1.jpg", darken=0.16, hook="You’re doing better <i>than you think.</i>",
               kicker="For tired parents", sub=None, serif=True))

# ---- Oct 17 · calm text (Sherbet blobs): give helpers one job, sticky-note list
lfc = """
.c{position:absolute;left:0;right:0;text-align:center}
.k{display:inline-block;font:800 30px/1 Inter;letter-spacing:.16em;text-transform:uppercase;color:#fff;background:#D9497A;padding:14px 22px;border-radius:999px}
.big{left:84px;right:84px;font-family:Lora;font-weight:600;font-size:132px;line-height:1.0;letter-spacing:-.03em;color:#2C2A3A;text-wrap:balance}
.big i{color:#D9497A;font-weight:500}
.s{left:110px;right:110px;font:600 56px/1.22 Inter;color:#2C2A3A;text-wrap:balance}
.note{position:absolute;left:120px;width:840px;top:380px;height:900px;background:#FFFDF5;transform:rotate(-2deg);border-radius:6px;
 box-shadow:0 24px 44px rgba(90,40,40,.18);background-image:linear-gradient(#FFFDF5 170px,transparent 170px),
 repeating-linear-gradient(#FFFDF5 0 128px,rgba(217,73,122,.22) 128px 130px)}
.note:before{content:"";position:absolute;left:90px;top:0;bottom:0;width:2px;background:rgba(217,73,122,.4)}
.tape{position:absolute;left:420px;top:350px;width:240px;height:66px;background:rgba(255,214,227,.75);transform:rotate(3deg)}
.nt{position:absolute;left:120px;top:60px;font-family:CaveatBrush;font-size:96px;color:#D9497A;line-height:1}
.note ul{position:absolute;left:120px;right:30px;top:186px;list-style:none;font-family:Caveat;font-weight:700;font-size:74px;line-height:130px;color:#2C2A3A}
.note li span{color:#D9497A;margin-right:16px}
.foot{position:absolute;left:0;right:0;top:1330px;display:flex;justify-content:center;align-items:center;gap:14px;font:700 30px/1 Inter;color:#2C2A3A}
.foot img{width:52px;height:52px;border-radius:50%;background:#fff;padding:3px}
"""
LF_JOBS = ["Bring dinner on Tuesday", "Fold one load of laundry", "Hold the baby while I shower", "Walk the dog"]
R["lf-reel-1017-one-job"] = dict(brand="littlefold", style="calm text", scenes=lambda: gen_reel(
    "littlefold", "blobs",
    [f'<div class="c" style="top:420px"><span class="k">When someone offers help</span></div>'
     f'<div class="c big" style="top:520px">Give them <i>one job.</i></div>'
     f'<div class="c s" style="top:820px">“Let me know if you need anything” is kind. A clear job is easy to say yes to.</div>{foot("littlefold")}',
     '<div class="note"><div class="nt">Jobs to hand out:</div><ul>' + "".join(f'<li><span>✓</span>{j}</li>' for j in LF_JOBS)
     + '</ul></div><div class="tape"></div>',
     f'<div class="c big" style="top:470px;font-size:120px">Then let them <i>do it their way.</i></div>'
     f'<div class="c s" style="top:820px">Save this list for the next time someone asks.</div>{foot("littlefold")}'],
    lfc, [Move(pan=0.02, push=0.02), Move(pan=-0.02), Move(pan=0.02, push=0.02)], seeds=(41, 42, 43)),
    cover=dict(kind="blobs", hook="Someone offers help? <i>Give one job.</i>", kicker="Save this list"))

# ---- Oct 18 · one-word slow-pan photo (wheat): crying, ICON guidance (NHS)
lfw = css_photo("littlefold", kick_col="#FFE4EC", word_col="#FFF4E0", card_bg="rgba(255,248,228,.95)", hl="#D9497A") + \
    ".card{font-family:Lora;font-weight:600}.card li b{color:#D9497A}"
R["lf-reel-1018-breathe"] = dict(brand="littlefold", style="one-word slow-pan photo", photo="g-wheat.png", scenes=lambda: photo_reel(
    "littlefold", "g-wheat.png", [0.30, 0.36, 0.34],
    [f'<div class="c k" style="top:500px">When the crying won’t stop</div><div class="c w" style="top:580px;font-size:320px"><i>Breathe.</i></div>'
     f'<div class="c s" style="top:900px">It’s OK to step away for a few minutes.</div>{foot("littlefold")}',
     '<div class="card" style="top:430px"><span class="lab">If it’s getting to you</span><ol>'
     '<li><b>1.</b> Lay baby on their back in the cot or crib.</li><li><b>2.</b> Step out. Breathe slowly.</li>'
     '<li><b>3.</b> Go back when you feel calmer.</li></ol></div>',
     f'<div class="card" style="top:470px;text-align:center">Never shake a baby.<br>Call someone you trust to take a turn.'
     f'<div class="fine">From the NHS-backed ICON guidance.</div></div>'
     f'<div class="c s" style="top:1000px;font-size:48px">Send this to a new parent.</div>{foot("littlefold")}'],
    lfw, [Move(pan=0.05, parallax=False), Move(pan=-0.04, push=0.02, parallax=False), Move(pan=0.04, parallax=False)], seeds=(51, 52, 53)),
    cover=dict(kind="photo", photo="g-wheat.png", darken=0.32, kicker="When the crying won’t stop", hook="It’s OK to <i>step away.</i>",
               sub="Breathe. Then go back.", serif=True))

# =========================================================================== LOCKED HOUR
lhf = css_photo("lockedhour", word_font="'Inter Display';font-weight:900", word_col="#FFD43B", kick_col="#FF8CC2",
                card_bg="#FFF4E0", hl="#141414") + """
.card{border:6px solid #141414;box-shadow:14px 14px 0 #FF5CA8;border-radius:20px;font-family:Inter;font-weight:700}
.card .lab{background:#FFD43B;color:#141414;border:4px solid #141414;border-radius:8px}
.q{font:900 92px/1.05 'Inter Display';letter-spacing:-.03em;margin-top:6px}
.mk{background:linear-gradient(#FFD43B,#FFD43B) no-repeat 0 86%/100% 48%;padding:0 .06em}
.big{font-family:'Inter Display';font-weight:900;letter-spacing:-.04em;font-size:128px}
.big .mk{color:#141414}
"""
R["lh-reel-1016-quiet"] = dict(brand="lockedhour", style="one-word slow-pan photo", photo="g-forest.png", scenes=lambda: photo_reel(
    "lockedhour", "g-forest.png", [0.38, 0.4, 0.38],
    [f'<div class="c k" style="top:500px">The next 60 minutes</div><div class="c w" style="top:580px;font-size:300px">Quiet.</div>'
     f'<div class="c s" style="top:880px">Turn on Do Not Disturb for one hour.</div>{foot("lockedhour")}',
     '<div class="card" style="top:460px"><span class="lab">Send one line first</span>'
     '<div class="q">“Heads down till 11. <span class="mk">Call if it’s urgent.</span>”</div></div>',
     f'<div class="c big" style="top:470px">Then start. <span class="mk">It can wait.</span></div>'
     f'<div class="c s" style="top:930px">Save this for your next locked hour.</div>{foot("lockedhour")}'],
    lhf, [Move(pan=0.05, parallax=False), Move(pan=-0.04, push=0.02, parallax=False), Move(pan=0.04, push=0.02, parallax=False)], seeds=(61, 62, 63)),
    cover=dict(kind="photo", photo="g-forest.png", darken=0.4, kicker="The next 60 minutes", hook="One hour on <span class='mk'>Do Not Disturb.</span>",
               sub=None, lh=True))

lhp = """
.c{position:absolute;left:0;right:0;text-align:center}
.k{display:inline-block;font:800 30px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#141414;background:#FFD43B;border:4px solid #141414;padding:12px 18px;border-radius:8px;box-shadow:5px 5px 0 #141414}
.big{left:84px;right:84px;font-family:'Inter Display';font-weight:900;font-size:140px;line-height:.98;letter-spacing:-.045em;color:#141414;text-wrap:balance}
.mk{background:linear-gradient(#FFD43B,#FFD43B) no-repeat 0 86%/100% 50%;padding:0 .06em}
.pk{background:linear-gradient(#FF5CA8,#FF5CA8) no-repeat 0 86%/100% 50%;padding:0 .06em}
.s{left:110px;right:110px;font:700 56px/1.22 Inter;color:#141414;text-wrap:balance}
.card{position:absolute;left:84px;right:84px;background:#fff;border:6px solid #141414;box-shadow:14px 14px 0 #141414;border-radius:20px;padding:40px 46px}
.row{display:flex;gap:30px;align-items:center;font:800 64px/1.15 'Inter Display';letter-spacing:-.02em;color:#141414;margin:22px 0}
.bd{flex:none;display:grid;place-items:center;width:104px;height:104px;border-radius:50%;background:#FFD43B;border:6px solid #141414;font:900 58px/1 'Inter Display'}
.foot{position:absolute;left:0;right:0;top:1330px;display:flex;justify-content:center;align-items:center;gap:14px;font:800 30px/1 Inter;color:#141414}
.foot img{width:52px;height:52px;border-radius:50%;background:#fff;padding:3px;border:3px solid #141414}
"""
R["lh-reel-1018-start-ugly"] = dict(brand="lockedhour", style="calm text", scenes=lambda: gen_reel(
    "lockedhour", "paper",
    [f'<div class="c" style="top:420px"><span class="k">Stuck on the first line?</span></div>'
     f'<div class="c big" style="top:520px">Write it <span class="pk">badly</span> first.</div>'
     f'<div class="c s" style="top:860px">A bad draft is easier to fix than a blank page.</div>{foot("lockedhour")}',
     '<div class="card" style="top:420px"><div class="row"><span class="bd">1</span>Write 3 bad sentences.</div>'
     '<div class="row"><span class="bd">2</span>Don’t fix anything yet.</div><div class="row"><span class="bd">3</span>Now fix just one.</div></div>',
     f'<div class="c big" style="top:470px">Start ugly.<br><span class="mk">Fix later.</span></div>'
     f'<div class="c s" style="top:860px">Save this for your next blank page.</div>{foot("lockedhour")}'],
    lhp, [Move(pan=0.02, push=0.02), Move(pan=-0.02), Move(pan=0.02, push=0.02)], seeds=(71, 72, 73), kw=dict(leak_strength=0.5)),
    cover=dict(kind="paper", hook="Write it <span class='pk'>badly</span> first.", kicker="Stuck on the first line?"))

# =========================================================================== HOURBACK
hbp = """
.c{position:absolute;left:0;right:0;text-align:center}
.k{display:inline-block;font:800 30px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#2A2238;background:#FFC94D;padding:14px 22px;border-radius:999px}
.big{left:84px;right:84px;font-family:Poppins;font-weight:700;font-size:124px;line-height:1.04;letter-spacing:-.035em;color:#2A2238;text-wrap:balance}
.yl{background:linear-gradient(#FFC94D,#FFC94D) no-repeat 0 88%/100% 46%;padding:0 .06em}
.s{left:110px;right:110px;font:600 54px/1.24 Inter;color:#2A2238;text-wrap:balance}
.pc{position:absolute;left:84px;right:84px;background:#5E54C9;border-radius:40px;padding:46px 52px 52px;color:#fff;box-shadow:0 24px 50px rgba(60,40,140,.3);
 font:600 56px/1.3 Inter}
.pc .lab{display:inline-block;font:800 28px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#2A2238;background:#FFC94D;padding:12px 18px;border-radius:999px;margin-bottom:24px}
.pc .ph{color:#FFC94D}
.foot{position:absolute;left:0;right:0;top:1330px;display:flex;justify-content:center;align-items:center;gap:14px;font:700 30px/1 Inter;color:#2A2238}
.foot img{width:52px;height:52px;border-radius:50%;background:#fff;padding:3px}
"""
R["hb-reel-1016-email-asks"] = dict(brand="hourback", style="calm text", scenes=lambda: gen_reel(
    "hourback", "paper",
    [f'<div class="c" style="top:420px"><span class="k">That long email</span></div>'
     f'<div class="c big" style="top:520px">Long email? <span class="yl">Get just the asks.</span></div>'
     f'<div class="c s" style="top:860px">Paste it and ask one question.</div>{foot("hourback")}',
     '<div class="pc" style="top:400px"><span class="lab">Prompt · copy it</span><div>Here’s an email: <span class="ph">[paste it]</span>. '
     'What is it asking me to do, and by when? One line per ask. Quote the sentence each ask comes from.</div></div>',
     f'<div class="c big" style="top:470px">Then reply to <span class="yl">the asks.</span></div>'
     f'<div class="c s" style="top:800px">Check the quotes before you trust it. Remove personal details before you paste.</div>{foot("hourback")}'],
    hbp, [Move(pan=0.02, push=0.02), Move(pan=-0.02), Move(pan=0.02, push=0.02)], seeds=(81, 82, 83)),
    cover=dict(kind="paper", hook="Long email? <span class='yl'>Get just the asks.</span>", kicker="Prompt · copy it"))

hbo = css_photo("hourback", word_col="#FFFFFF", kick_col="#FFC94D", card_bg="#5E54C9", card_ink="#FFFFFF", hl="#FFC94D") + \
    ".card .lab{color:#2A2238}.ph{color:#FFC94D}.big i{color:#FFC94D}"
R["hb-reel-1017-offline"] = dict(brand="hourback", style="one-word slow-pan photo", photo="g-clouds.png", scenes=lambda: photo_reel(
    "hourback", "g-clouds.png", [0.30, 0.34, 0.30],
    [f'<div class="c k" style="top:500px">After 7 pm</div><div class="c w" style="top:580px;font-size:300px"><i>Offline.</i></div>'
     f'<div class="c s" style="top:880px">Plan tomorrow in one prompt. Then close the laptop.</div>{foot("hourback")}',
     '<div class="card" style="top:400px"><span class="lab">Prompt · copy it</span><div>Here’s everything on my mind for tomorrow: '
     '<span class="ph">[brain dump]</span>. Pick my 3 must-dos and give me a rough schedule. Move the rest to later this week.</div></div>',
     f'<div class="c big" style="top:520px">Lid down. <i>Evening back.</i></div>'
     f'<div class="c s" style="top:860px">Save this for tonight.</div>{foot("hourback")}'],
    hbo, [Move(pan=0.05, parallax=False), Move(pan=-0.04, push=0.02, parallax=False), Move(pan=0.04, push=0.02, parallax=False)], seeds=(91, 92, 93)),
    cover=dict(kind="photo", photo="g-clouds.png", darken=0.3, kicker="After 7 pm", hook="Plan tomorrow. <i>Then log off.</i>", sub=None, serif=True))

# =========================================================================== KINETIC (vlab, 2x)
from vlab import Video, el, words, count  # noqa: E402


def barel(col, x, y, w, t, d, pct):
    return (f'<div class="bar" data-a="bar" data-t="{t}" data-d="{d}" data-w="{pct}" style="position:absolute;left:{x}px;top:{y}px;'
            f'width:{w}px"><div class="fill" style="background:{col}"></div></div>')


def kin_ff():
    th = """
:root{--bg:#F5F7FF;--hl:#FFB08F;--hl-dark:#FFB08F;--prog-bg:transparent;--prog-fg:transparent}
.cam{transform:none!important}
.H{font-family:'Inter Display';font-weight:800;letter-spacing:-.045em;line-height:.98;color:#0E1440}
.dark .H{color:#fff}
.B{font:600 56px/1.25 Inter;color:#0E1440}.dark .B{color:#fff}
.kick{display:inline-block;font:800 30px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#fff;background:#2B3FE0;padding:14px 22px;border-radius:999px}
.dark .kick{background:#FF6A3D}
.pill{background:#FFB08F;border-radius:.14em;padding:0 .1em;-webkit-box-decoration-break:clone}
.bar{height:84px;border-radius:22px;background:rgba(43,63,224,.12);overflow:hidden}.bar .fill{height:100%;width:0;border-radius:22px}
.lab{font:700 48px/1.1 Inter;color:#0E1440;margin-bottom:16px}.val{font:800 92px/1 'Inter Display';letter-spacing:-.03em;color:#0E1440}
.fine{font:600 40px/1.3 Inter;color:#4A5180}
.card{background:#fff;border-radius:40px;padding:44px 50px;box-shadow:0 20px 50px rgba(20,30,120,.18)}
#tag{position:absolute;left:84px;top:300px;display:flex;align-items:center;gap:12px;background:#fff;border-radius:999px;padding:6px 22px 6px 6px;font:700 28px/1 Inter;color:#0E1440;box-shadow:0 6px 16px rgba(20,30,120,.12)}
#tag img{width:46px;height:46px;border-radius:50%}
"""
    tag = f'<div id="tag"><img src="{mark("fullyfunded")}">Fully Funded</div>'
    v = Video("fullyfunded", "fees", th, tag)
    X, W = 84, 912
    v.scene(0, 4.0, "".join([
        el('<span class="kick">200 a month · 30 years</span>', X, 420, a="none"),
        el('A 1% fee looks <span class="pill">tiny.</span>', X, 500, W, a="none", cls="H", style="font-size:168px"),
        el("It isn’t.", X, 900, W, a="up", t=1.0, d=0.5, cls="H", style="font-size:150px;color:#2B3FE0"),
        el('<span class="fine">Example math inside</span>', X, 1100, W, a="fade", t=1.6, d=0.5),
    ]), tin="cut", bg="#F5F7FF")
    v.scene(4.0, 8.5, "".join([
        el('<span class="kick">Example at 6% a year</span>', X, 420, a="up", t=0.05),
        el('<div class="lab">No yearly fee</div>', X, 540, W, a="up", t=0.2),
        barel("#2B3FE0", X, 610, W, 0.35, 1.0, 100),
        count(0, round(M["fee_gross"]), t=0.35, d=1.0, cls="val", x=X, y=710),
        el('<div class="lab">With a 1% yearly fee</div>', X, 880, W, a="up", t=1.1),
        barel("#FF6A3D", X, 950, W, 1.25, 1.0, round(100 * M["fee_1"] / M["fee_gross"], 2)),
        count(0, round(M["fee_1"]), t=1.25, d=1.0, cls="val", x=X, y=1050),
        el(f'<div class="fine">You put in {N(M["fee_in"])} either way. Not guaranteed. Before tax and inflation.</div>', X, 1210, W, a="fade", t=2.2, d=0.5),
    ]), tin="wipe", bg="#F5F7FF")
    v.scene(8.5, 12.5, "".join([
        el("That 1% costs about", X, 470, W, a="up", t=0.05, cls="H", style="font-size:104px"),
        el(f'<span class="pill">{N(round(M["fee_cost_1"], -3))}</span>', X, 600, W, a="up", t=0.35, d=0.5, cls="H", style="font-size:210px"),
        el(f'Roughly a sixth of the {N(M["fee_gross"])}.', X, 870, W, a="up", t=0.9, cls="B"),
        el('<div class="fine">Any currency. Same math.</div>', X, 1050, W, a="fade", t=1.5),
    ]), tin="wipe", bg="#F5F7FF")
    v.scene(12.5, 16.0, "".join([
        el('<span class="kick">Do this week</span>', X, 420, a="up", t=0.05),
        el("Find your fee.", X, 500, W, a="up", t=0.15, cls="H", style="font-size:150px"),
        el('Look for “annual fee” or “expense ratio” on each account.', X, 700, W, a="up", t=0.45, cls="B"),
        el('<div class="card B" style="color:#0E1440;font-size:48px">The catch: cheaper isn’t always better. Compare funds that do the same job.</div>',
           X, 920, W, a="up", t=0.85),
        el('Save this. Follow <b style="color:#FFB08F">@fullyfundedhq</b>', X, 1270, W, a="fade", t=1.3, cls="B", style="font-size:46px"),
    ]), tin="wipe", bg="#2B3FE0", cls="dark")
    return v


def kin_lh():
    th = """
:root{--bg:#FFF4E0;--hl:#FFD43B;--hl-dark:#FFD43B;--prog-bg:transparent;--prog-fg:transparent}
.cam{transform:none!important}.pat{background-position:0 0!important}
.dots{background-image:radial-gradient(rgba(20,20,20,.12) 2.4px,transparent 2.8px);background-size:30px 30px}
.H{font-family:'Inter Display';font-weight:900;letter-spacing:-.045em;line-height:.98;color:#141414}
.dark .H{color:#FFF4E0}
.B{font:700 56px/1.25 Inter;color:#141414}.dark .B{color:#FFF4E0}
.kick{display:inline-block;font:800 30px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#141414;background:#FFD43B;border:4px solid #141414;padding:12px 18px;border-radius:8px;box-shadow:5px 5px 0 #141414}
.mk{background:linear-gradient(#FFD43B,#FFD43B) no-repeat 0 86%/100% 50%;padding:0 .06em}
.pk{background:linear-gradient(#FF5CA8,#FF5CA8) no-repeat 0 86%/100% 50%;padding:0 .06em}
.dark .mk{color:#141414;background:#FFD43B;border-radius:.1em}
.win{background:#fff;border:6px solid #141414;border-radius:22px;box-shadow:14px 14px 0 #141414;overflow:hidden}
.tabs{display:flex;gap:8px;padding:16px 16px 0;background:#FFE27A;border-bottom:6px solid #141414;height:96px}
.tab{flex:none;width:118px;height:80px;border:4px solid #141414;border-bottom:0;border-radius:16px 16px 0 0;background:#fff;
 font:800 26px/76px Inter;text-align:center;color:#141414;overflow:hidden;white-space:nowrap}
.tab.on{width:260px;background:#FF5CA8}
.page{padding:40px 44px;font:700 52px/1.3 Inter;color:#141414;height:300px}
#tag{position:absolute;left:84px;top:300px;display:flex;align-items:center;gap:12px;background:#FFF4E0;border:4px solid #141414;border-radius:999px;padding:6px 20px 6px 6px;font:800 26px/1 Inter;color:#141414}
#tag img{width:44px;height:44px;border-radius:50%}
"""
    tag = f'<div id="tag"><img src="{mark("lockedhour")}">Locked Hour</div>'
    v = Video("lockedhour", "one-tab", th, tag)
    X, W = 84, 912
    labels = ["Mail", "News", "Shop", "Chat", "Video", "Maps"]

    def browser(close=True):
        tabs = '<div class="tab on">Your draft</div>'
        for i, lb in enumerate(labels):
            ex = f' data-x="{0.35 + i * 0.32:.2f}" data-xa="pop"' if close else ""
            tabs += f'<div class="tab" data-a="none"{ex}>{lb}</div>'
        return (f'<div class="win"><div class="tabs">{tabs}</div><div class="page">The one thing you meant to do'
                '<br><span class="mk">is right here.</span></div></div>')
    v.scene(0, 4.0, "".join([
        el('<span class="kick">Do this now</span>', X, 420, a="none"),
        el('Close every tab <span class="mk">but one.</span>', X, 500, W, a="none", cls="H", style="font-size:150px"),
        el(browser(close=False), X, 890, W, a="none"),
    ]), tin="cut", bg="#FFF4E0", pattern="dots")
    v.scene(4.0, 8.0, "".join([
        el('One tab.<br><span class="pk">One task.</span>', X, 440, W, a="pop", t=0.05, d=0.4, cls="H", style="font-size:150px"),
        el(browser(close=True), X, 890, W, a="none"),
    ]), tin="cut", bg="#FFF4E0", pattern="dots")
    v.scene(8.0, 12.0, "".join([
        el("Opened a new one?", X, 440, W, a="pop", t=0.05, d=0.4, cls="H", style="font-size:130px"),
        el('Close it. <span class="mk">Back to the one.</span>', X, 740, W, a="pop", t=0.6, d=0.4, cls="H", style="font-size:130px"),
        el('<span class="B">Need it later? Jot it on paper.</span>', X, 1120, W, a="up", t=1.2),
    ]), tin="pop" if False else "cut", bg="#FFF4E0", pattern="dots")
    v.scene(12.0, 15.5, "".join([
        el('One tab.<br><span class="mk">One hour.</span>', X, 440, W, a="pop", t=0.05, d=0.4, cls="H", style="font-size:170px"),
        el('Save this. Try it tomorrow.<br>Follow <b style="color:#FFD43B">@lockedhourhq</b>', X, 900, W, a="up", t=0.6, cls="B"),
    ]), tin="circle", bg="#141414", pattern="dots", cls="dark")
    return v


def kin_hb():
    th = """
:root{--bg:#FFF8EF;--hl:#FFC94D;--hl-dark:#FFC94D;--prog-bg:transparent;--prog-fg:transparent}
.cam{transform:none!important}
.H{font-family:Poppins;font-weight:700;letter-spacing:-.035em;line-height:1.04;color:#2A2238}
.dark .H{color:#fff}
.B{font:600 54px/1.28 Inter;color:#2A2238}.dark .B{color:#FFF8EF}
.kick{display:inline-block;font:800 30px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#2A2238;background:#FFC94D;padding:14px 22px;border-radius:999px}
.yl{background:linear-gradient(#FFC94D,#FFC94D) no-repeat 0 88%/100% 46%;padding:0 .06em}
.dark .yl{color:#2A2238;background:#FFC94D;border-radius:.12em}
.pc{background:#5E54C9;border-radius:40px;padding:44px 50px;color:#fff;font:600 54px/1.3 Inter;box-shadow:0 20px 44px rgba(60,40,140,.28)}
.pc .ph{color:#FFC94D}
.lab{display:inline-block;font:800 26px/1 Inter;letter-spacing:.14em;text-transform:uppercase;color:#2A2238;background:#FFC94D;padding:10px 16px;border-radius:999px;margin-bottom:20px}
.res{background:#fff;border-radius:36px;padding:34px 44px;box-shadow:0 16px 36px rgba(60,40,140,.16)}
.r{display:flex;gap:24px;font:600 52px/1.25 Inter;color:#2A2238;padding:16px 0;border-bottom:3px dashed #E4DDF5}
.r:last-child{border:0}.r b{flex:none;width:150px;color:#5E54C9}
.mail{background:#fff;border-radius:36px;padding:40px 44px;box-shadow:0 16px 36px rgba(60,40,140,.16)}
.ln{height:30px;border-radius:15px;background:#E9E4F7;margin:20px 0}
#tag{position:absolute;left:84px;top:300px;display:flex;align-items:center;gap:12px;background:#fff;border-radius:999px;padding:6px 22px 6px 6px;font:700 28px/1 Inter;color:#2A2238}
#tag img{width:46px;height:46px;border-radius:50%}
"""
    tag = f'<div id="tag"><img src="{mark("hourback")}">Hourback</div>'
    v = Video("hourback", "school-email", th, tag)
    X, W = 84, 912
    mail = ('<div class="mail"><div style="font:700 44px/1.2 Inter;color:#2A2238">School newsletter · Week 7</div>'
            + "".join(f'<div class="ln" style="width:{w}%"></div>' for w in (96, 88, 92, 70, 95, 84)) + '</div>')
    v.scene(0, 4.0, "".join([
        el('<span class="kick">The school email</span>', X, 420, a="none"),
        el('School email? <span class="yl">Get the dates.</span>', X, 500, W, a="none", cls="H", style="font-size:136px"),
        el(mail, X, 900, W, a="none"),
    ]), tin="cut", bg="#FFF8EF")
    v.scene(4.0, 8.5, "".join([
        el('<span class="lab">Prompt · copy it</span>', X, 400, a="up", t=0.05),
        el('<div class="pc">Here’s the school newsletter: <span class="ph">[paste it]</span>. List every date, what to bring and '
           'anything that needs a reply. One line each, earliest first.</div>', X, 480, W, a="up", t=0.2, d=0.5),
    ]), tin="wipe", bg="#FFF8EF")
    v.scene(8.5, 12.5, "".join([
        el('<span class="lab">What you get · example</span>', X, 400, a="up", t=0.05),
        el('<div class="res"><div class="r" data-a="up" data-t="0.25" data-d="0.4"><b>Thu</b>Picture day: clean shirt</div>'
           '<div class="r" data-a="up" data-t="0.6" data-d="0.4"><b>Fri</b>Trip form: reply by 9 am</div>'
           '<div class="r" data-a="up" data-t="0.95" data-d="0.4"><b>Mon</b>No school: staff day</div></div>', X, 480, W, a="none"),
        el('<span class="B" style="font-size:42px;color:#6A6080">Example made up for this post.</span>', X, 1120, W, a="fade", t=1.4),
    ]), tin="wipe", bg="#FFF8EF")
    v.scene(12.5, 16.0, "".join([
        el('Paste. Ask.<br><span class="yl">Add to calendar.</span>', X, 440, W, a="up", t=0.05, cls="H", style="font-size:130px"),
        el('Check it against the email before you rely on it.', X, 820, W, a="up", t=0.5, cls="B"),
        el('Save this for the next newsletter.<br>Follow <b style="color:#FFC94D">@hourbackhq</b>', X, 1100, W, a="up", t=0.9, cls="B"),
    ]), tin="wipe", bg="#5E54C9", cls="dark")
    return v


R["ff-reel-1016-fee"] = dict(brand="fullyfunded", style="kinetic big text", kinetic=kin_ff,
                             cover=dict(kind="kin", hook="A 1% fee looks <span class='pill'>tiny.</span>", kicker="200 a month · 30 years",
                                        sub="It isn’t. Example math inside."))
R["lh-reel-1017-one-tab"] = dict(brand="lockedhour", style="kinetic big text", kinetic=kin_lh,
                                 cover=dict(kind="kin", hook="Close every tab <span class='mk'>but one.</span>", kicker="Do this now"))
R["hb-reel-1018-school-email"] = dict(brand="hourback", style="kinetic big text", kinetic=kin_hb,
                                      cover=dict(kind="kin", hook="School email? <span class='yl'>Get the dates.</span>", kicker="The school email"))


# =========================================================================== covers (dedicated, hook inside y 300-1400)
def cover_html(rid):
    r = R[rid]
    b, cv = r["brand"], r["cover"]
    c = BR[b]
    chip = (f'<div style="display:inline-flex;align-items:center;gap:12px;background:#fff;border-radius:999px;padding:6px 24px 6px 6px;'
            f'font:700 30px/1 Inter;color:{c["ink"]}"><img src="{mark(b)}" style="width:50px;height:50px;border-radius:50%">{c["name"]}</div>')
    kick = cv.get("kicker")
    sub = cv.get("sub")
    if cv["kind"] == "photo":
        # photo cover: same photo as the Reel (one post), darkened behind the hook
        import cv2, numpy as np  # noqa: E401
        from PIL import Image
        im = L.load(PHOTOS / cv["photo"]).astype(np.float32) / 255
        import slowpan_bg as Bg
        im = Bg.cover_fit(im, 1080, 1920)
        y = np.linspace(0, 1, 1920, dtype=np.float32)[:, None, None]
        im = im * (1 - cv["darken"] * 1.2 * np.exp(-((y - 0.38) / 0.22) ** 2))
        p = L.HERE / "build" / f"{rid}-coverbg.jpg"
        p.parent.mkdir(exist_ok=True)
        Image.fromarray((np.clip(im, 0, 1) * 255).astype(np.uint8)).save(p, quality=96)
        font = "Instrument" if cv.get("serif") or b == "fullyfunded" else "'Inter Display';font-weight:900"
        if cv.get("lh"):
            font = "'Inter Display';font-weight:900"
        hl = {"fullyfunded": "#FFB08F", "littlefold": "#FFD6E3", "lockedhour": "#FFD43B", "hourback": "#FFC94D"}[b]
        return (f'<style>.hook i{{font-style:italic;color:{hl}}} .mk{{color:#141414;background:#FFD43B;border-radius:.1em;padding:0 .08em}}</style>'
                f'<div style="position:absolute;inset:0;background:url({p.as_uri()}) center/cover"></div>'
                f'<div style="position:absolute;left:96px;right:96px;top:340px;text-align:center">'
                f'<div style="margin-bottom:40px">{chip}</div>'
                + (f'<div style="font:800 34px/1.1 Inter;letter-spacing:.2em;text-transform:uppercase;color:{hl};text-shadow:0 2px 16px rgba(0,0,0,.5);margin-bottom:34px">{kick}</div>' if kick else "")
                + f'<div class="hook" style="font-family:{font};font-size:{170 if "Instrument" in font else 150}px;line-height:.98;letter-spacing:-.03em;color:#fff;'
                  f'text-shadow:0 8px 46px rgba(0,0,0,.5);text-wrap:balance">{cv["hook"]}</div>'
                + (f'<div style="margin-top:46px;font:600 54px/1.2 Inter;color:#fff;text-shadow:0 2px 18px rgba(0,0,0,.6)">{sub}</div>' if sub else "")
                + '</div>')
    # flat brand covers (calm text / kinetic)
    if b == "fullyfunded":
        if cv["kind"] == "sky":
            bg = "linear-gradient(180deg,#16228F 0%,#2436C9 30%,#5466EA 55%,#A9A6EE 72%,#FFC2A6 88%,#FFE9DE 100%)"
            ink, font, size, hlcss = "#fff", "Instrument", 190, ".hook i{font-style:italic;color:#FFB08F}"
        else:
            bg = "#F5F7FF"
            ink, font, size, hlcss = "#0E1440", "'Inter Display';font-weight:800", 178, ".pill{background:#FFB08F;border-radius:.14em;padding:0 .1em}"
        kcss = "color:#fff;background:#FF6A3D" if cv["kind"] == "sky" else "color:#fff;background:#2B3FE0"
    elif b == "littlefold":
        bg = ("radial-gradient(50% 40% at 0% 100%,#FFC9D6 0,transparent 70%),radial-gradient(45% 35% at 100% 95%,#FFD3AE 0,transparent 70%),"
              "radial-gradient(40% 30% at 95% 5%,#FFE27E 0,transparent 70%),#FFF4E0")
        ink, font, size, hlcss = "#2C2A3A", "Lora;font-weight:600", 150, ".hook i{color:#D9497A;font-weight:500}"
        kcss = "color:#fff;background:#D9497A"
    elif b == "lockedhour":
        bg = "#FFE27A" if cv["kind"] == "kin" else "#FFF4E0"
        ink, font, size, hlcss = "#141414", "'Inter Display';font-weight:900", 168, (
            ".mk{background:linear-gradient(#FFF4E0,#FFF4E0) no-repeat 0 86%/100% 50%;padding:0 .06em}" if cv["kind"] == "kin" else
            ".mk{background:linear-gradient(#FFD43B,#FFD43B) no-repeat 0 86%/100% 50%}") + \
            ".pk{background:linear-gradient(#FF5CA8,#FF5CA8) no-repeat 0 86%/100% 50%;padding:0 .06em}"
        kcss = "color:#141414;background:#FFD43B;border:4px solid #141414;box-shadow:5px 5px 0 #141414;border-radius:8px" if cv["kind"] != "kin" else \
            "color:#FFE27A;background:#141414;border-radius:8px"
    else:
        bg = "#5E54C9" if cv["kind"] == "kin" else "#FFF8EF"
        ink = "#fff" if cv["kind"] == "kin" else "#2A2238"
        font, size = "Poppins;font-weight:700", 150
        hlcss = ".yl{background:linear-gradient(#FFC94D,#FFC94D) no-repeat 0 88%/100% 46%;padding:0 .06em;color:#2A2238}" if cv["kind"] != "kin" else \
            ".yl{background:#FFC94D;color:#2A2238;border-radius:.12em;padding:0 .08em;-webkit-box-decoration-break:clone}"
        kcss = "color:#2A2238;background:#FFC94D"
    deco = ""
    if b == "lockedhour" and cv["kind"] != "kin":
        deco = ('<div style="position:absolute;inset:0;background-image:radial-gradient(rgba(20,20,20,.12) 2.4px,transparent 2.8px);'
                'background-size:30px 30px"></div>')
    return (f'<style>{hlcss}</style><div style="position:absolute;inset:0;background:{bg}"></div>{deco}'
            f'<div style="position:absolute;left:96px;right:96px;top:340px">'
            f'<div style="margin-bottom:46px">{chip}</div>'
            + (f'<div style="display:inline-block;font:800 32px/1 Inter;letter-spacing:.14em;text-transform:uppercase;padding:14px 22px;'
               f'border-radius:999px;{kcss};margin-bottom:46px">{kick}</div>' if kick else "")
            + f'<div class="hook" style="font-family:{font};font-size:{size}px;line-height:1.0;letter-spacing:-.04em;color:{ink};text-wrap:balance">{cv["hook"]}</div>'
            + (f'<div style="margin-top:50px;font:600 56px/1.2 Inter;color:{ink};opacity:.9">{sub}</div>' if sub else "")
            + '</div>')


# =========================================================================== build
def build(rid):
    r = R[rid]
    b = r["brand"]
    out = L.OUT / f"{rid}.mp4"
    cuts = []
    if "kinetic" in r:
        v = r["kinetic"]()
        silent = L.HERE / "build" / f"{rid}-silent.mp4"
        L.render_vlab_2x(v, silent)
        cuts = [sc["s"] for sc in v.scenes[1:]]
        L.add_music(silent, b, out, cuts=cuts, seed=len(rid))
        times = [0.0] + [s + 1.6 for s in [0] + cuts]
    else:
        scenes = r["scenes"]()
        res = SP.render(scenes, out, L.REEL, music=(b, "warm", len(rid) % 7), lufs=-14.0, crf=18, maxrate="9M")
        jit = SP.jitter_check(res)
        r["jitter"] = jit
        st = res["starts"]
        times = [0.0] + [s + 2.0 for s in st]
    cov = L.render_cover(cover_html(rid), L.OUT / f"{rid}-cover.jpg")
    pr = L.probe(out)
    qa = dict(id=rid, brand=b, style=r["style"], probe=pr, lufs=L.loudness(out), cover=cov,
              ok=(pr["w"], pr["h"]) == (1080, 1920) and 12 <= pr["dur"] <= 18 and pr["mb"] < 19 and pr["acodec"] == "aac" and not cov["errors"])
    L.sheet(out, L.OUT / f"{rid}-cover.jpg", L.QA / f"{rid}-sheet.png", times)
    (L.QA / f"{rid}.json").write_text(json.dumps(qa, indent=1, default=str))
    print(json.dumps(qa, default=str))
    return qa


if __name__ == "__main__":
    ids = sys.argv[1:] or list(R)
    for i in ids:
        build(i)
