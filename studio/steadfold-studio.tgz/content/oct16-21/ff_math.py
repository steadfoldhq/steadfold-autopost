#!/usr/bin/env python3
"""Fully Funded example math for the Oct 16-21 posts and Reels. Every number shown on a slide, in a Reel or a caption
comes from here. Example rates only: not guaranteed; real returns vary, before fees, tax and inflation."""
from pathlib import Path


def fv_monthly(pmt, annual, years):
    r, n = annual / 12, years * 12
    return pmt * ((1 + r) ** n - 1) / r if r else pmt * n


def fv_lump(pv, annual, years):
    return pv * (1 + annual / 12) ** (years * 12)


M = {}
# 1. Fees (Reel Oct 16): 200 a month for 30 years, 6% a year before fees; a 1% yearly fee leaves 5%; 0.2% leaves 5.8%
M["fee_gross"] = fv_monthly(200, 0.06, 30)
M["fee_02"] = fv_monthly(200, 0.058, 30)
M["fee_1"] = fv_monthly(200, 0.05, 30)
M["fee_in"] = 200 * 12 * 30
M["fee_cost_1"] = M["fee_gross"] - M["fee_1"]
M["fee_share_1"] = M["fee_cost_1"] / M["fee_gross"]
# 2. Raise rule (Reel Oct 17): a raise of 200 a month, save half (100 a month) for 20 years at 6%
M["raise_half_20"] = fv_monthly(100, 0.06, 20)
M["raise_in_20"] = 100 * 12 * 20
# 3. Price per use (feed Oct 19): 240 coat worn 120 times vs 60 coat worn 6 times
M["ppu_a"] = 240 / 120
M["ppu_b"] = 60 / 6
# 4. Where the money sits (feed Oct 20): 10,000 left for 20 years at 0%, 3% and 6% a year, compounded monthly
M["home_0"] = fv_lump(10000, 0.0, 20)
M["home_3"] = fv_lump(10000, 0.03, 20)
M["home_6"] = fv_lump(10000, 0.06, 20)

lines = [
    "Example math (Fully Funded, Oct 16-21 2026). Not guaranteed. Real returns vary, before fees, tax and inflation.",
    "FV of monthly payments = P x ((1 + r/12)^(12n) - 1) / (r/12); lump sum = PV x (1 + r/12)^(12n).",
    f"Fees: 200/month x 30 yrs = {M['fee_in']:,} put in. 6% -> {M['fee_gross']:,.0f}; 5.8% (0.2% fee) -> {M['fee_02']:,.0f}; "
    f"5% (1% fee) -> {M['fee_1']:,.0f}. A 1% fee costs {M['fee_cost_1']:,.0f} = {M['fee_share_1']:.1%} of the pot.",
    f"Raise rule: save 100/month of a 200/month raise for 20 yrs at 6% -> {M['raise_half_20']:,.0f} (put in {M['raise_in_20']:,}).",
    f"Price per use: 240 / 120 wears = {M['ppu_a']:.2f}; 60 / 6 wears = {M['ppu_b']:.2f}.",
    f"Where it sits: 10,000 for 20 yrs: 0% -> {M['home_0']:,.0f}; 3% -> {M['home_3']:,.0f}; 6% -> {M['home_6']:,.0f}.",
]
if __name__ == "__main__":
    Path(__file__).with_name("ff-math.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
